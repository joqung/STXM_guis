#!/usr/bin/env python3
"""
Readers and writers for STXM data, shared by the GUI/CLI converter.

Two input formats are understood:

  'cls'  CLS SM beamline, post-upgrade acquisition software. Modern NeXus:
         entry0, NXdata groups named after the detector channel
         (DNM_SIS3820_CHAN_17), group-level @signal/@axes, NX_units="NX_ANY".

  'als'  ALS 5.3.2.2 .stxm files. entry0/counter0 (or binned_values, or
         default in v3), an entry0/motors group, and a version field that
         selects between four different internal layouts.

Two output formats are produced:

  'nxstxm'  Old-style NXstxm HDF5: entry1/counter0, per-dataset axis= and
            primary= attributes, real units, fixed-length ASCII strings.

  'hdr'     ALS .hdr + .xim text files, the format Axis2000 has always read.
            The writer is a port of the beamline's own batch-convert
            notebook, so the layout matches what 5.3.2.2 users already load.

The ALS reader and .hdr writer are adapted from "STXM_to_HDR_Batch_Convert"
by the 5.3.2.2 beamline. Differences from that original are marked ADAPTED.
"""

import os
import re
import time
import uuid
import inspect

import numpy as np
import h5py

_LOCKING_SUPPORTED = "locking" in inspect.signature(h5py.File.__init__).parameters

# scan kinds
IMAGE = "image"
BATCH_IMAGE = "batch_image"
LINE = "line"
FOCUS = "focus"
SINGLE_MOTOR = "single_motor"


# ==========================================================================
# small helpers
# ==========================================================================

def canon(path):
    """Canonical key for a path: resolves links, ., .., drive case on Windows."""
    return os.path.normcase(os.path.realpath(os.path.abspath(path)))


def open_read(path):
    """Open read-only, bypassing HDF5 locking so files open elsewhere still read."""
    if _LOCKING_SUPPORTED:
        try:
            return h5py.File(path, "r", locking=False)
        except (OSError, TypeError, ValueError):
            pass
    return h5py.File(path, "r")


def _decode(val):
    """bytes / 0-d array / 1-element array -> str."""
    if isinstance(val, np.ndarray):
        if val.size == 0:
            return ""
        val = val.flat[0]
    if isinstance(val, bytes):
        return val.decode("utf-8", "replace")
    return str(val)


def _get_str(grp, path, default=""):
    try:
        return _decode(grp[path][()])
    except Exception:                                     # noqa: BLE001
        return default


def _scalar(val, default=0.0):
    """Coerce a motor reading to a plain float where possible."""
    try:
        arr = np.asarray(val)
        if arr.size == 0:
            return default
        if arr.dtype.kind in "SUO":
            return _decode(arr)
        return float(arr.flat[0])
    except Exception:                                     # noqa: BLE001
        return default


def _ascii_ds(grp, name, text):
    """Fixed-length ASCII dataset. Old IDL/NeXus readers choke on VL strings."""
    return grp.create_dataset(name, data=np.bytes_(str(text)))


def _entry_names(f):
    """Top-level groups called entryN, in numeric order."""
    names = [k for k in f
             if isinstance(f[k], h5py.Group) and re.fullmatch(r"entry\d*", k)]
    names.sort(key=lambda s: int(re.sub(r"\D", "", s) or 0))
    return names


# ==========================================================================
# scan container
# ==========================================================================

class Scan(object):
    """One region of one scan, normalised across input formats."""

    def __init__(self, label, kind, counts, energies, sample_x, sample_y,
                 dwell, motors=None, sample_z=None, meta=None,
                 scan_type_raw="", source="", channel=""):
        self.label = label
        self.kind = kind
        self.counts = counts                # (nE, nY, nX)
        self.energies = np.atleast_1d(np.asarray(energies, dtype="float64"))
        self.sample_x = np.asarray(sample_x, dtype="float64")
        self.sample_y = np.asarray(sample_y, dtype="float64")
        self.sample_z = None if sample_z is None else np.asarray(
            sample_z, dtype="float64")
        self.dwell = dwell
        self.motors = motors or {}
        self.meta = meta or {}
        self.scan_type_raw = scan_type_raw
        self.source = source
        self.channel = channel

    @property
    def n_energies(self):
        return self.counts.shape[0]

    def describe(self):
        return "%s, %d energ%s, %dx%d" % (
            self.kind, self.n_energies, "y" if self.n_energies == 1 else "ies",
            self.counts.shape[2], self.counts.shape[1])


def swap_scan_xy(scan):
    """Return a copy of the scan with the two spatial axes exchanged."""
    return Scan(
        label=scan.label, kind=scan.kind,
        counts=np.transpose(scan.counts, (0, 2, 1)),
        energies=scan.energies,
        sample_x=scan.sample_y, sample_y=scan.sample_x,
        dwell=scan.dwell, motors=scan.motors, sample_z=scan.sample_z,
        meta=scan.meta, scan_type_raw=scan.scan_type_raw,
        source=scan.source, channel=scan.channel)


# ==========================================================================
# format detection
# ==========================================================================

def detect_format(path):
    """Return 'cls', 'als' or 'unknown'.

    Both formats are HDF5 and both carry an entry0/version field (CLS says
    '1.0', ALS says 0/2/2.1/3.0), so the version alone cannot separate them.
    Structure can: only ALS has a motors group or a counter0/binned_values
    group; only CLS has NXdata groups named after the detector channel.
    """
    try:
        with open_read(path) as f:
            entries = _entry_names(f)
            if not entries:
                return "unknown"
            e = f[entries[0]]
            if "motors" in e or "instrument/motors" in e:
                return "als"
            if "counter0" in e or "binned_values" in e or "requested_values" in e:
                return "als"
            for key in e:
                obj = e[key]
                if (isinstance(obj, h5py.Group)
                        and _decode(obj.attrs.get("NX_class", "")) == "NXdata"
                        and "data" in obj):
                    return "cls"
            return "unknown"
    except Exception:                                     # noqa: BLE001
        return "unknown"


# ==========================================================================
# CLS reader
# ==========================================================================

def _cls_channels(entry):
    out = []
    for key in entry:
        obj = entry[key]
        if not isinstance(obj, h5py.Group):
            continue
        if _decode(obj.attrs.get("NX_class", "")) != "NXdata":
            continue
        if "data" not in obj or obj["data"].ndim not in (2, 3):
            continue
        out.append(key)
    out.sort()
    if not out:
        raise ValueError("no NXdata detector groups found")
    return out


def read_cls(path):
    """Read a CLS post-upgrade file. Returns a list of Scan, one per channel."""
    scans = []
    with open_read(path) as f:
        entries = _entry_names(f)
        if not entries:
            raise ValueError("no NXentry group found - is this an STXM file?")
        entry = f[entries[0]]
        stem = os.path.splitext(os.path.basename(path))[0]

        meta = {
            "start_time": _get_str(entry, "start_time"),
            "end_time": _get_str(entry, "end_time"),
            "experimenters": _get_str(entry, "experimenters", "unknown"),
            "proposal": _get_str(entry, "title", "unknown"),
            "sample_description": _get_str(entry, "sample/description",
                                           _get_str(entry, "title", "")),
        }

        # entry0/collection holds the EPICS readbacks; the ones that look like
        # motor positions are useful as .hdr LastPosition lines.
        motors = {}
        if "collection" in entry:
            for key in entry["collection"]:
                grp = entry["collection"][key]
                if isinstance(grp, h5py.Group) and "value" in grp:
                    val = _scalar(grp["value"][()], None)
                    if isinstance(val, float):
                        motors[key] = val

        for ch in _cls_channels(entry):
            s = entry[ch]
            counts = np.asarray(s["data"][()], dtype="float64")
            if counts.ndim == 2:
                counts = counts[np.newaxis, :, :]
            x = np.asarray(s["sample_x"][()], dtype="float64")
            y = np.asarray(s["sample_y"][()], dtype="float64")
            ev = np.atleast_1d(np.asarray(
                s["energy"][()] if "energy" in s else np.zeros(counts.shape[0]),
                dtype="float64"))
            dwell = _scalar(s["count_time"][()], 1.0) if "count_time" in s else 1.0

            raw_type = _get_str(s, "stxm_scan_type", "")
            if counts.shape[0] > 1:
                kind = BATCH_IMAGE
            else:
                kind = IMAGE

            scans.append(Scan(
                label=stem, kind=kind, counts=counts, energies=ev,
                sample_x=x, sample_y=y, dwell=dwell, motors=motors,
                meta=meta, scan_type_raw=raw_type, source="cls", channel=ch))
    return scans


# ==========================================================================
# ALS 5.3.2.2 reader
# ==========================================================================

def _norm_version(raw):
    """ALS version field -> float. Missing or unparseable counts as 0."""
    try:
        if isinstance(raw, (bytes, str)):
            return float(_decode(raw))
        arr = np.asarray(raw)
        if arr.dtype.kind in "SUO":
            return float(_decode(arr))
        return float(arr.flat[0])
    except Exception:                                     # noqa: BLE001
        return 0.0


def _rebin_line(x_req, y_vals, x_meas, y_meas, counts):
    """Resample one measured line onto the requested x grid.

    ADAPTED: the original notebook calls self._rebinLine for version-2 files
    but no such method is defined in it (it lives in pystxm_core, which was
    not included). This is a straight 1-D interpolation of the measured
    counts onto the requested positions, which is what the surrounding code
    expects. Version-2 files therefore convert, but this particular step has
    not been checked against the beamline's own implementation.
    """
    x_meas = np.asarray(x_meas, dtype="float64").ravel()
    counts = np.asarray(counts, dtype="float64").ravel()
    x_req = np.asarray(x_req, dtype="float64").ravel()
    if x_meas.size != counts.size or x_meas.size == 0:
        # nothing sensible to interpolate from; fall back to a straight copy
        out = np.zeros(x_req.size)
        n = min(out.size, counts.size)
        out[:n] = counts[:n]
        return out
    order = np.argsort(x_meas)
    return np.interp(x_req, x_meas[order], counts[order])


class ALSFile(object):
    """Reader for ALS 5.3.2.2 .stxm files. Port of the notebook's stxm class."""

    def __init__(self, path):
        self.path = path
        try:
            self._f = h5py.File(path, "r", swmr=True)
        except Exception:                                 # noqa: BLE001
            self._f = open_read(path)                     # ADAPTED: fallback
        f = self._f
        self.entries = _entry_names(f)
        self.nRegions = len(self.entries)
        if not self.nRegions:
            raise ValueError("no entry groups found")

        version = _norm_version(f["entry0/version"][()]
                                if "entry0/version" in f else 0)
        self.meta = {"version": version}

        if version < 3:
            self.meta["start_time"] = _get_str(f, "entry0/start_time")
            self.meta["end_time"] = _get_str(f, "entry0/end_time")
            self.meta["experimenters"] = _get_str(f, "entry0/experimenters",
                                                  "unknown")
            self.meta["sample_description"] = _get_str(
                f, "entry0/sample_description", "")
            self.meta["proposal"] = _get_str(f, "entry0/proposal", "unknown")
            self.meta["scan_type"] = _get_str(f, "entry0/counter0/stxm_scan_type")
        else:
            self.meta["start_time"] = _get_str(f, "entry0/start_time")
            self.meta["end_time"] = _get_str(f, "entry0/end_time")
            self.meta["experimenters"] = _get_str(f, "entry0/experimenters",
                                                  "unknown")
            self.meta["sample_description"] = _get_str(
                f, "entry0/sample/description", "")
            self.meta["proposal"] = _get_str(f, "entry0/title", "unknown")
            self.meta["scan_type"] = _get_str(f, "entry0/default/stxm_scan_type")

        self.data = {}
        for i, entry_str in enumerate(self.entries):
            if abs(version - 2.0) < 1e-9:
                self.data[entry_str] = self._read_v2(entry_str)
            elif abs(version - 2.1) < 1e-9:
                self.data[entry_str] = self._read_v21(entry_str)
            elif version >= 3.0:
                self.data[entry_str] = self._read_v3(entry_str)
            else:
                self.data[entry_str] = self._read_legacy(entry_str)

    def close(self):
        try:
            self._f.close()
        except Exception:                                 # noqa: BLE001
            pass

    # -- per-version readers ------------------------------------------------

    def _motors(self, group_path):
        f = self._f
        out = {}
        if group_path in f:
            for item in f[group_path]:
                out[item] = _scalar(f[group_path + "/" + item][()])
        return out

    def _finish(self, d):
        xpos, ypos = d["xpos"], d["ypos"]
        # ADAPTED: divide by (n-1), not n, so the step size is the real
        # spacing between points. The notebook does this for v3 already.
        d["xstepsize"] = ((xpos.max() - xpos.min()) / (xpos.size - 1)
                          if xpos.size > 1 else 0.0)
        d["ystepsize"] = ((ypos.max() - ypos.min()) / (ypos.size - 1)
                          if ypos.size > 1 else 0.0)
        return d

    def _read_legacy(self, e):
        f = self._f
        d = {"motors": self._motors(e + "/motors")}
        m = d["motors"]
        if "Beamline Energy" not in m and "Energy" in m:
            m["Beamline Energy"] = m["Energy"]
        m.setdefault("Dummy Motor", 0)
        m.setdefault("Detector Y", 0)
        d["energy"] = np.atleast_1d(
            f[e + "/counter0/energy"][()].astype("float64"))
        d["dwell"] = np.atleast_1d(
            f[e + "/counter0/count_time"][()].astype("float64"))
        d["counts"] = f[e + "/counter0/data"][()].astype("float64")
        d["xpos"] = np.asarray(f[e + "/counter0/sample_x"][()], dtype="float64")
        d["ypos"] = np.asarray(f[e + "/counter0/sample_y"][()], dtype="float64")
        return self._finish(d)

    def _read_v2(self, e):
        f = self._f
        d = {"motors": self._motors(e + "/motors")}
        d["energy"] = np.atleast_1d(
            f[e + "/counter0/energy"][()].astype("float64"))
        d["dwell"] = np.atleast_1d(
            f[e + "/counter0/count_time"][()].astype("float64"))

        x_meas = np.asarray(f[e + "/counter0/sample_x"][()], dtype="float64")
        y_meas = np.asarray(f[e + "/counter0/sample_y"][()], dtype="float64")
        x_req = np.asarray(f[e + "/requested_values/sample_x"][()],
                           dtype="float64")
        y_req = np.asarray(f[e + "/requested_values/sample_y"][()],
                           dtype="float64")
        raw = f[e + "/counter0/data"][()].astype("float64")

        if self.meta["scan_type"] == "Ptychography Image":
            new_counts = raw
        else:
            new_counts = np.zeros((raw.shape[0], raw.shape[1], len(x_req)))
            for i in range(new_counts.shape[0]):
                for j in range(new_counts.shape[1]):
                    x_line = x_meas[i, j]
                    y_line = y_meas[i, j]
                    if self.meta["scan_type"] == "Image":
                        y_vals = np.ones(np.shape(x_line)) * y_req[j]
                    else:
                        y_vals = y_req
                    new_counts[i, j] = _rebin_line(
                        x_req, y_vals, x_line, y_line, raw[i, j])

        d["counts"] = new_counts
        d["xpos"] = x_req
        d["ypos"] = y_req
        return self._finish(d)

    def _read_v21(self, e):
        f = self._f
        d = {"motors": self._motors(e + "/motors")}
        d["energy"] = np.atleast_1d(
            f[e + "/counter0/energy"][()].astype("float64"))
        d["dwell"] = np.atleast_1d(
            f[e + "/counter0/count_time"][()].astype("float64"))
        d["counts"] = f[e + "/binned_values/data"][()].astype("float64")
        d["xpos"] = np.asarray(f[e + "/binned_values/sample_x"][()],
                               dtype="float64")
        d["ypos"] = np.asarray(f[e + "/binned_values/sample_y"][()],
                               dtype="float64")
        return self._finish(d)

    def _read_v3(self, e):
        f = self._f
        d = {"motors": self._motors(e + "/instrument/motors")}
        d["energy"] = np.atleast_1d(
            f[e + "/instrument/monochromator/energy"][()].astype("float64"))
        d["dwell"] = np.atleast_1d(
            f[e + "/default/count_time"][()].astype("float64"))
        d["counts"] = f[e + "/default/data"][()].astype("float64")
        d["xpos"] = np.asarray(f[e + "/default/sample_x"][()], dtype="float64")
        d["ypos"] = np.asarray(f[e + "/default/sample_y"][()], dtype="float64")
        return self._finish(d)


def _als_kind(scan_type, n_energies):
    if scan_type == "Line Spectrum":
        return LINE
    if scan_type in ("Image", "Ptychography Image", "Spiral Image"):
        return BATCH_IMAGE if n_energies > 1 else IMAGE
    if scan_type == "Focus":
        return FOCUS
    if scan_type == "Single Motor":
        return SINGLE_MOTOR
    return None


def read_als(path):
    """Read an ALS 5.3.2.2 .stxm file. Returns a list of Scan, one per region."""
    src = ALSFile(path)
    try:
        stem = os.path.splitext(os.path.basename(path))[0]
        # NS_########.stxm -> the scan number; anything else keeps its stem
        parts = stem.split("_")
        scan_num = parts[1] if len(parts) > 1 else stem

        scan_type = src.meta["scan_type"]
        n_e = src.data[src.entries[0]]["counts"].shape[0]
        kind = _als_kind(scan_type, n_e)
        if kind is None:
            raise ValueError(
                "unsupported scan type %r" % (scan_type or "<missing>"))

        out = []
        for i, entry_str in enumerate(src.entries):
            d = src.data[entry_str]
            label = ("NS_%s_%d" % (scan_num, i) if src.nRegions > 1
                     else "NS_%s" % scan_num)
            counts = d["counts"]
            if counts.ndim == 2:
                counts = counts[np.newaxis, :, :]
            out.append(Scan(
                label=label, kind=kind, counts=counts, energies=d["energy"],
                sample_x=d["xpos"], sample_y=d["ypos"],
                sample_z=d["ypos"] if kind == FOCUS else None,
                dwell=float(np.atleast_1d(d["dwell"])[0]),
                motors=d["motors"], meta=src.meta,
                scan_type_raw=scan_type, source="als"))
        return out
    finally:
        src.close()


def read_any(path):
    """Read either format. Returns (format_name, [Scan, ...])."""
    fmt = detect_format(path)
    if fmt == "cls":
        return fmt, read_cls(path)
    if fmt == "als":
        return fmt, read_als(path)
    raise ValueError("unrecognised STXM file (neither CLS nor ALS 5.3.2.2)")


# ==========================================================================
# writer 1: old-style NXstxm HDF5
# ==========================================================================

def _replace_with_retry(tmp_path, dst_path, attempts=5, delay=0.4):
    last = None
    for i in range(attempts):
        try:
            os.replace(tmp_path, dst_path)
            return
        except PermissionError as exc:
            last = exc
            time.sleep(delay * (i + 1))
    raise PermissionError(
        "could not write %s - it is probably open in another program "
        "(Axis2000, HDFView, NeXpy) or locked by antivirus / cloud sync. "
        "Close it and try again." % os.path.basename(dst_path)) from last


def friendly(exc, dst_path):
    """Translate opaque HDF5 errors into something actionable."""
    text = str(exc)
    if "already open" in text or "truncate" in text:
        return RuntimeError(
            "cannot write %s - that file is already open. Close it in "
            "Axis2000 / HDFView / NeXpy, and make sure the same scan is not "
            "queued twice." % os.path.basename(dst_path))
    if "file signature not found" in text:
        return RuntimeError("not an HDF5 file")
    if "unable to lock file" in text or "errno = 11" in text:
        return RuntimeError(
            "file is locked by another program - close it and try again")
    return exc


def write_nxstxm(scans, dst_path, swap_xy=False, meta=None):
    """Write scans as one old-style NXstxm file: entry1/counter0, counter1, ..."""
    parent = os.path.dirname(os.path.abspath(dst_path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    tmp_path = "%s.%d.%s.partial" % (dst_path, os.getpid(), uuid.uuid4().hex[:8])
    meta = meta or (scans[0].meta if scans else {})
    try:
        with h5py.File(tmp_path, "w", libver="earliest") as dst:
            dst.attrs["HDF5_Version"] = np.bytes_("1.8.4")
            dst.attrs["NeXus_version"] = np.bytes_("4.3.0")
            dst.attrs["file_name"] = np.bytes_(os.path.basename(dst_path))

            e1 = dst.create_group("entry1")
            e1.attrs["NX_class"] = np.bytes_("NXentry")
            _ascii_ds(e1, "definition", "NXstxm")
            _ascii_ds(e1, "title", scans[0].label if scans else "")
            for key in ("start_time", "end_time"):
                if meta.get(key):
                    _ascii_ds(e1, key, meta[key])

            for i, sc in enumerate(scans):
                g = e1.create_group("counter%d" % i)
                g.attrs["NX_class"] = np.bytes_("NXdata")

                data = np.asarray(sc.counts, dtype=np.float32)
                x = np.asarray(sc.sample_x, dtype=np.float32)
                y = np.asarray(sc.sample_y, dtype=np.float32)
                ev = np.asarray(sc.energies, dtype=np.float32)
                if swap_xy:
                    data = np.transpose(data, (0, 2, 1))
                    x, y = y, x

                if data.shape != (ev.size, y.size, x.size):
                    raise ValueError(
                        "shape mismatch: data %s vs energy %d, y %d, x %d"
                        % (data.shape, ev.size, y.size, x.size))

                d = g.create_dataset("data", data=data)
                d.attrs["signal"] = np.int32(1)
                d.attrs["axes"] = np.bytes_("energy:sample_y:sample_x")
                d.attrs["units"] = np.bytes_("counts")

                de = g.create_dataset("energy", data=ev)
                de.attrs["axis"] = np.int32(1)
                de.attrs["primary"] = np.int32(1)
                de.attrs["units"] = np.bytes_("eV")

                dy = g.create_dataset("sample_y", data=y)
                dy.attrs["axis"] = np.int32(2)
                dy.attrs["primary"] = np.int32(1)
                dy.attrs["units"] = np.bytes_("um")

                dx = g.create_dataset("sample_x", data=x)
                dx.attrs["axis"] = np.int32(3)
                dx.attrs["primary"] = np.int32(1)
                dx.attrs["units"] = np.bytes_("um")

                ct = g.create_dataset(
                    "count_time",
                    data=np.full(ev.size, float(sc.dwell), dtype=np.float32))
                ct.attrs["units"] = np.bytes_("ms")
                _ascii_ds(g, "stxm_scan_type",
                          "sample image stack" if data.shape[0] > 1
                          else "sample image")

            inst = e1.create_group("instrument")
            inst.attrs["NX_class"] = np.bytes_("NXinstrument")
            srcg = inst.create_group("source")
            srcg.attrs["NX_class"] = np.bytes_("NXsource")
            _ascii_ds(srcg, "name",
                      "Advanced Light Source" if scans and scans[0].source == "als"
                      else "Canadian Light Source")
            _ascii_ds(srcg, "probe", "x-ray")
            _ascii_ds(srcg, "type", "Synchrotron X-ray Source")
            mono = inst.create_group("monochromator")
            mono.attrs["NX_class"] = np.bytes_("NXmonochromator")
            me = mono.create_dataset(
                "energy", data=np.asarray(scans[0].energies, dtype=np.float32))
            me.attrs["units"] = np.bytes_("eV")

            samp = e1.create_group("sample")
            samp.attrs["NX_class"] = np.bytes_("NXsample")
            samp.create_dataset("rotation_angle", data=np.float32(0.0))

        _replace_with_retry(tmp_path, dst_path)
    except OSError as exc:
        raise friendly(exc, dst_path) from exc
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass

    return "%d channel%s, %d energ%s" % (
        len(scans), "" if len(scans) == 1 else "s",
        scans[0].n_energies, "y" if scans[0].n_energies == 1 else "ies")


# ==========================================================================
# writer 2: ALS .hdr + .xim
# ==========================================================================

def determine_en_regions(energies, decimals=4):
    """Group an energy list into constant-step regions.

    ADAPTED: step differences are rounded before comparison. The original
    compares raw floats, so float64 energies from a CLS file (where the step
    is never bit-identical twice) would otherwise produce one region per
    point instead of one region per ramp.
    """
    energies = np.asarray(energies, dtype="float64")
    if energies.size < 2:
        return [0.0], [energies.size], [energies[0]], [energies[-1]]

    diffs = np.round(energies[1:] - energies[:-1], decimals)
    uniques, nums, firsts, lasts = [], [], [], []
    for i, diff in enumerate(diffs):
        if not uniques:
            uniques.append(diff)
            nums.append(2)       # first point is never counted in diffs
            firsts.append(energies[i])
        elif diff != uniques[-1]:
            uniques.append(diff)
            nums.append(1)
            lasts.append(energies[i])
            firsts.append(energies[i + 1])
        else:
            nums[-1] += 1
    lasts.append(energies[-1])
    return uniques, nums, firsts, lasts


def _time_series(start_time, end_time, n):
    """Interpolate n timestamps between start and end, as the notebook does."""
    try:
        t0 = np.datetime64(start_time)
        t1 = np.datetime64(end_time)
        if n == 1:
            return [str(t0)]
        step = (t1 - t0) / (n - 1)
        times = np.arange(t0, t1, step)
        if len(times) != n:
            times = np.append(times, t1)
        return [str(t) for t in times[:n]]
    except Exception:                                     # noqa: BLE001
        return [str(start_time)] * n


def write_hdr_xim(scan, out_dir, xim_float=False, verbose=None):
    """Write one Scan as ALS .hdr + .xim files. Returns the .hdr path.

    Port of the beamline notebook's writer, minus the ptychography branches
    (those need the sibling .cxi/.mat reconstructions).
    """
    say = verbose or (lambda _m: None)
    os.makedirs(out_dir, exist_ok=True)

    label = scan.label
    kind = scan.kind
    data = np.asarray(scan.counts, dtype="float64")
    sample_x = np.asarray(scan.sample_x, dtype="float64")
    sample_y = np.asarray(scan.sample_y, dtype="float64")
    sample_z = scan.sample_z
    energies = scan.energies
    dwell = scan.dwell
    motors = scan.motors
    meta = scan.meta

    start_time = meta.get("start_time", "")
    end_time = meta.get("end_time", start_time)
    experimenters = meta.get("experimenters", "unknown")
    proposal = meta.get("proposal", "unknown")
    sample_description = meta.get("sample_description", "")
    all_times = _time_series(start_time, end_time, len(energies))

    # -- single motor scans are a two-column text file, not a .hdr ----------
    if kind == SINGLE_MOTOR:
        fn = os.path.join(out_dir, label + ".xsp")
        np.savetxt(fn, np.array([sample_x, data[0][0]]).T)
        say("wrote %s" % os.path.basename(fn))
        return fn

    hdr_file = label + ".hdr"
    L = []

    if kind == BATCH_IMAGE:
        L.append(('ScanDefinition = {{ Label = {0}; Type = "NEXAFS Image Scan"; '
                  'Flags = "Image Stack"; Dwell = {1};').format(hdr_file, dwell))
    elif kind == IMAGE:
        L.append(('ScanDefinition = {{ Label = {0}; Type = "Image Scan"; '
                  'Flags = "Image"; Dwell = {1};').format(hdr_file, dwell))
    elif kind == LINE:
        L.append(('ScanDefinition = {{ Label = {0}; Type = "NEXAFS Line Scan"; '
                  'Flags = "Image"; Dwell = {1};').format(hdr_file, dwell))
    elif kind == FOCUS:
        L.append(('ScanDefinition = {{ Label = {0}; Type = "Focus Scan"; '
                  'Flags = "Image"; Dwell = {1};').format(hdr_file, dwell))

    def axis_block(tag, name, unit, values):
        L.append(('\t\t\t{0} = {{ Name = "{1}"; Unit = "{2}"; '
                  'Min = {3}; Max = {4}; Dir = 1;').format(
                      tag, name, unit, values.min(), values.max()))
        body = ", ".join(["{:.4f}".format(v) for v in values])
        L.append("\t\t\t\tPoints = (" + str(len(values)) + ", " + body + ");")
        L.append("};")

    if kind in (BATCH_IMAGE, IMAGE):
        L.append("\tRegions = (1,")
        L.append("{")
        axis_block("PAxis", "Sample X", "um", sample_x)
        axis_block("QAxis", "Sample Y", "um", sample_y)
        L.append("});")

    if kind in (FOCUS, LINE):
        dist = np.abs(sample_x - sample_x[0])

    if kind == FOCUS:
        L.append("\tRegions = (1,")
        L.append("{")
        axis_block("PAxis", "Length", "um", dist)
        axis_block("QAxis", "Zone Plate", "um", sample_z)
        L.append("});")

    if kind == LINE:
        L.append("\tRegions = (1,")
        L.append("{")
        axis_block("PAxis", "Energy", "eV", energies)
        axis_block("QAxis", "Sample", "um", dist)
        L.append("});")

    if kind != LINE:
        L.append(('\tStackAxis = {{ Name = "Energy"; Unit = "eV"; '
                  'Min = {0}; Max = {1}; Dir = 1;').format(
                      energies.min(), energies.max()))
        estr = ", ".join(["{:.3f}".format(v) for v in energies])
        L.append("\t\tPoints = (" + str(len(energies)) + ", " + estr + ");")
    else:
        # a line scan is not a stack but does have many energies, so the
        # stack axis is declared with a single point
        L.append(('\tStackAxis = {{ Name = "Energy"; Unit = "eV"; '
                  'Min = {0}; Max = {1}; Dir = 1;').format(
                      energies.min(), energies.min()))
        L.append("\t\tPoints = (1, {:.4f});".format(energies.min()))

    L.append("};")
    L.append("\tChannels = (1,")
    L.append('{ Name = "PD"; Unit = "counts";});')
    L.append("};")
    L.append(' Time = "{0}"; BeamFeedback = true; ShutterAutomatic = true; '
             'Experimenters = {1}; Proposal = {2}; Sample Description = {3};\n'
             .format(start_time, experimenters, proposal, sample_description))
    L.append("")
    L.append("Channels = (1,")
    L.append('{ ID = 4; Type = 0; Name = "PD"; Controller = 0; DeviceNumber = 0; '
             'UnitName = "counts"; LinearCoefficient = 1; ConstantCoefficient = 0;'
             'ProcessString = "C2";});')

    for motor in motors:
        L.append("")
        L.append('{0} = {{ Name = "{1}"; LastPosition = {2};}};'.format(
            motor, motor, motors[motor]))

    # ADAPTED: the original writes the CoarseX motor position into the
    # Polarization field. Use a real polarization reading when the file has
    # one, otherwise 0.
    polarization = 0
    for key in ("polarization", "POLARIZATION", "Polarization",
                "epu_polarization"):
        if key in motors:
            polarization = motors[key]
            break
    L.append((' StorageRingCurrent = 0; EPUPhase = 0; Polarization = {0}; '
              'PMT_CounterDivider = 1; A0 = 1;').format(polarization))

    if kind in (BATCH_IMAGE, IMAGE, LINE):
        scan_kind_text = ('Line (Full Horiz. Line)' if kind == LINE
                          else 'Image (Line - unidirection)')
        L.append('ImageScan = {{ ScanType = "{0}"; Stage = "Automatic"; '
                 'Shutter = "Automatic"; Interferometry = "Off"; '
                 'SingleEnergy = false; AutoShutterPointScan = true;'
                 .format(scan_kind_text))

        if kind == IMAGE:
            L.append("\tEnergyRegions = (1,")
            L.append(('{{ StartEnergy = {0}; EndEnergy = {1}; Range = 0; '
                      'Step = 1; Points = 1; DwellTime = {2};}});').format(
                          energies[0], energies[0], dwell))
        else:
            steps, points, starts, stops = determine_en_regions(energies)
            ranges = np.array(stops) - np.array(starts)
            L.append("\tEnergyRegions = ({},".format(len(steps)))
            for j in range(len(steps)):
                L.append(('{{ StartEnergy = {0}; EndEnergy = {1}; Range = {2}; '
                          'Step = {3}; Points = {4}; DwellTime = {5};}},').format(
                              starts[j], stops[j], ranges[j], steps[j],
                              points[j], dwell))
            L[-1] = L[-1][:-1] + ");"
        L.append(" Point Delay = 0.0; LineDelay = 50; AccelDist = 1; "
                 "MultipleRegions = False;")

    if kind in (BATCH_IMAGE, IMAGE):
        L.append("\tSpatialRegions = (1,")
        xrange_ = sample_x.max() - sample_x.min()
        yrange_ = sample_y.max() - sample_y.min()
        params = [
            (sample_x.min() + sample_x.max()) / 2,
            (sample_y.min() + sample_y.max()) / 2,
            xrange_, yrange_,
            xrange_ / (len(sample_x) - 1) if len(sample_x) > 1 else 0.0,
            yrange_ / (len(sample_y) - 1) if len(sample_y) > 1 else 0.0,
            len(sample_x), len(sample_y)]
        L.append(('{{ CentreXPos = {0:.4f}; CentreYPos = {1:.4f}; XRange = {2:.4f}; '
                  'YRange = {3:.4f}; XStep = {4:.4f}; YStep = {5:.4f}; XPoints = {6}; '
                  'YPoints = {7}; SquareRegion = false; SquarePixels = false;}});'
                  ).format(*params))
        L.append("};")

    if kind == FOCUS:
        length = ((sample_x.max() - sample_x.min()) ** 2
                  + (sample_y.max() - sample_y.min()) ** 2) ** 0.5
        theta = np.arctan2(sample_y.max() - sample_y.min(),
                           sample_x.max() - sample_x.min()) * 180 / np.pi
        n_points = len(sample_x)
        zp_range = float(np.abs(sample_z[-1] - sample_z[0]))
        params = [
            (sample_x.min() + sample_x.max()) / 2,
            (sample_y.min() + sample_y.max()) / 2,
            length, theta, n_points,
            length / (n_points - 1) if n_points > 1 else 0.0,
            sample_z[0], sample_z[-1], zp_range, len(sample_z),
            zp_range / (len(sample_z) - 1) if len(sample_z) > 1 else 0.0,
            dwell]
        L.append(('FocusScan = {{ CentreXPos = {0:.4f}; CentreYPos = {1:.4f}; '
                  'Length = {2:.4f}; Theta = {3:.2f}; nPoints = {4}; Step = {5:.4f}; '
                  'ZPStartPos = {6:.4f}; ZPEndPos = {7:.4f}; ZPRange = {8:.4f}; '
                  'nZPoints = {9}; ZPStep = {10:.4f}; DwellTime = {11}; '
                  'AccelDist = 0;}};').format(*params))

    if kind == LINE:
        L.append("\tSpatialRegions = (1,")
        length = ((sample_x.max() - sample_x.min()) ** 2
                  + (sample_y.max() - sample_y.min()) ** 2) ** 0.5
        theta = np.arctan2(sample_y.max() - sample_y.min(),
                           sample_x.max() - sample_x.min()) * 180 / np.pi
        params = [
            (sample_x.min() + sample_x.max()) / 2,
            (sample_y.min() + sample_y.max()) / 2,
            length, theta,
            length / (len(sample_x) - 1) if len(sample_x) > 1 else 0.0,
            len(sample_x)]
        L.append(('{{ CentreXPos = {0:.4f}; CentreYPos = {1:.4f}; Length = {2:.4f}; '
                  'Theta = {3:.2f}; Step = {4:.4f}; Points = {5};}});'
                  ).format(*params))
        L.append("};")

    # -- image files -------------------------------------------------------
    fmt = "%.4f" if xim_float else "%d"

    if kind == LINE:
        fn = os.path.join(out_dir, label + "_a.xim")
        np.savetxt(fn, data[:, 0].T, fmt=fmt)   # (energy, 1, position)
        say("wrote %s" % os.path.basename(fn))
        L.append(('Image{0:03d}_0 = {{StorageRingCurrent = 0.00; Energy = {1:.3f}; '
                  'Time = {2}; ZP_dest = 0.0; ZP_error = 0.0;}};').format(
                      0, energies[0], all_times[0]))
    elif kind == BATCH_IMAGE:
        for j, img in enumerate(data):
            fn = os.path.join(out_dir, label + "_a{:03d}.xim".format(j))
            np.savetxt(fn, img, fmt=fmt)
            L.append(('Image{0:03d}_0 = {{StorageRingCurrent = 0.00; '
                      'Energy = {1:.3f}; Time = {2}; ZP_dest = 0.0; '
                      'ZP_error = 0.0;}};').format(j, energies[j], all_times[j]))
        say("wrote %d .xim files" % len(data))
    else:                                   # single image or focus scan
        fn = os.path.join(out_dir, label + "_a.xim")
        np.savetxt(fn, data[0], fmt=fmt)
        say("wrote %s" % os.path.basename(fn))
        L.append(('Image{0:03d}_0 = {{StorageRingCurrent = 0.00; Energy = {1:.3f}; '
                  'Time = {2}; ZP_dest = 0.0; ZP_error = 0.0;}};').format(
                      0, energies[0], all_times[0]))

    hdr_path = os.path.join(out_dir, hdr_file)
    with open(hdr_path, "w") as fh:
        fh.writelines([line + "\n" for line in L])
    say("wrote %s" % hdr_file)
    return hdr_path
