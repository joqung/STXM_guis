# STXM → Axis2000 converter

Converts STXM data into formats Axis2000 can open. Two input formats and two
output formats.

## Inputs

**CLS SM beamline `.hdf5`** written by the post-upgrade acquisition software.
Modern NeXus: `entry0`, NXdata groups named after the detector channel
(`DNM_SIS3820_CHAN_17`), group-level `@signal`/`@axes`, `NX_units="NX_ANY"`,
variable-length strings. Axis2000 reads none of that.

**ALS 5.3.2.2 `.stxm`** in all four internal layouts — pre-2 (including files
with no version field), 2, 2.1 and 3. Image, image stack, line spectrum, focus
and single-motor scans.

The two are told apart by structure, not by extension or version number: both
are HDF5 and both carry an `entry0/version` field (CLS says `1.0`, ALS says
0/2/2.1/3.0). Only ALS has a `motors` or `counter0`/`binned_values` group;
only CLS has NXdata groups named after the detector channel.

## Outputs

**Axis2000 HDF5 (NXstxm)** — `entry1/counter0`, per-dataset `axis=1/2/3` and
`primary=1`, real `units` (`eV`, `um`, `counts`), fixed-length ASCII strings,
uncompressed contiguous data, no `control` NXmonitor so Axis2000 reads raw
counts. One file per scan, suffixed `_axis2000`.

**ALS `.hdr` + `.xim`** — the plain-text format Axis2000 has always read. One
folder per scan containing the `.hdr` and the numbered `.xim` images. This
writer is a port of the 5.3.2.2 beamline's own batch-convert notebook, so the
layout matches what that beamline's users already load.

ALS `.stxm` input always produces `.hdr`/`.xim`. Those files carry motor
tables and scan geometry that the `.hdr` format has fields for and NXstxm does
not, and it is the format 5.3.2.2 users already work with. CLS input can go to
either — if the NXstxm route gives Axis2000 trouble, switch to `.hdr`, which
is the better-established path.

Pixel values are copied unchanged in both directions. Nothing is rescaled or
normalised.

## Running it

**As a GUI** — double-click the `.exe`, or run `python stxm_axis2000_converter.py`
with no arguments.

Drag `.hdf5` or `.stxm` files or whole folders onto the file list; the list
highlights while you hover. Dropped folders are expanded using the *include
subfolders* setting, files of other types are ignored, and anything already
queued is skipped, so you can drop the same folder twice without creating
duplicates. You can also drop a folder onto the **Output folder** box to set
it. The Add buttons still work if you prefer them.

Pick an output format, then press Convert. Mixed batches are fine — each file
is detected individually and the log reports what each one was.

The window opens in a dark theme. The button at the bottom right flips between
dark and light; the choice is not remembered between runs, so to change the
default edit `DEFAULT_THEME` near the top of
`stxm_axis2000_converter.py`. Colours live in the `PALETTES` dictionary just
above it if you want to adjust them.

Theming works through ttk's `clam` theme, which is the only built-in theme
that honours background colours on every platform — the Windows native theme
draws buttons and entries with the OS and ignores anything the app sets. One
consequence: the file-picker and message boxes are drawn by Windows itself and
stay in whatever theme Windows is using. That is not something an application
can override.

**From the command line:**

```
python stxm_axis2000_converter.py A260219017.hdf5
python stxm_axis2000_converter.py A260219017.hdf5 --hdr
python stxm_axis2000_converter.py NS_251204043.stxm out_folder
python stxm_axis2000_converter.py --batch C:\data\251204 --out C:\converted --hdr
```

The exe accepts these too: run it from `cmd` with arguments and it attaches to that console for its output, instead of opening the window.

`--hdr` selects the `.hdr`/`.xim` writer, `--swap-xy` transposes, `--overwrite`
replaces existing output. Files already carrying the `_axis2000` suffix are
skipped when scanning folders, so re-running over a directory is safe.

## The Swap X/Y option

The NeXus `axis=1/2/3` numbering maps onto array dimensions in an order that
different readers have historically disagreed about. The default follows
C-order (energy, sample_y, sample_x), which is self-consistent. If a converted
stack opens transposed — features rotated 90°, or mirrored along the diagonal
— reconvert with **Swap X and Y** ticked. It applies to both output formats.
Only one of the two will look right; once you know which, it will be the same
for every file from that beamline.

## What came from the beamline notebook, and what changed

The ALS reader and the `.hdr` writer are adapted from
`STXM_to_HDR_Batch_Convert`. Four deliberate differences, each marked ADAPTED
in `stxm_formats.py`:

- **`_rebinLine` was missing.** Version-2 files call it, but the method is not
  defined anywhere in the notebook — it lives in `pystxm_core`, which was not
  included, so version-2 files would raise `AttributeError`. It is
  reimplemented here as a 1-D interpolation of the measured counts onto the
  requested positions, which is what the surrounding code expects. Version-2
  files therefore convert, but this step has not been checked against the
  beamline's own implementation. If you have version-2 files that matter,
  compare one against the notebook's output before trusting it.
- **Energy regions are grouped on rounded step sizes.** The original compares
  raw floats, so CLS float64 energies (where no two steps are bit-identical)
  would produce one region per point. Rounding to 4 decimals gives 7 regions
  for the test stack instead of 80.
- **Step sizes divide by n−1, not n.** The notebook already does this for
  version-3 files; the other branches divided by n, which is off by one pixel
  of spacing.
- **`Polarization` no longer holds the CoarseX motor position.** The original
  writes `motordict['coarsex']` into that field. It now takes a real
  polarization reading when the file has one and 0 otherwise.

A few smaller robustness fixes: missing `version` is treated as 0 rather than
raising; `swmr=True` falls back to a normal read when the file was not written
for SWMR; metadata fields that are absent get defaults instead of raising.

**Ptychography is not included.** The notebook's `Ptychography Image` path
reads sibling `.cxi` and `.mat` reconstructions and needs scikit-image and
scipy. Pulling those into a one-file executable roughly quadruples its size,
and I had no reconstructions to test against. `Ptychography Image` scans still
convert here, but from the STXM counts channel only. Keep using the notebook
for reconstruction exports.

## Building the .exe

On a **Windows** machine (PyInstaller cannot cross-compile — a Windows exe has
to be built on Windows, and a 64-bit build has to be made on 64-bit Windows).

1. Install Python 3.9 or later from python.org, ticking *"Add python.exe to PATH"*.
2. Put these five files in one folder:
   `stxm_axis2000_converter.py`, `stxm_formats.py`,
   `STXM_Axis2000_Converter.spec`, `version_info.txt`, `stxm_icon.ico`.
3. Double-click `build_exe.bat`.

The result is `dist\STXM_Axis2000_Converter.exe` — one file, roughly 60–90 MB,
containing Python, numpy, h5py, Tcl/Tk and the tkdnd drag-and-drop binaries.
The target PC needs nothing installed. Copy it to a network share, email it,
put it on a USB stick; it runs from wherever it lands.

The build is driven by the `.spec` file rather than a long command line, so
the settings are visible and editable. Three of them matter:

- **UPX compression is off.** It would save about 20 MB, but UPX-packed
  binaries are one of the strongest antivirus false-positive triggers. Not a
  good trade when you are handing the file to other people.
- **A long exclude list.** PyInstaller bundles anything importable it can
  reach. On a machine that also has scipy, matplotlib or Qt installed, those
  get swept in and the exe triples in size for no reason.
- **An icon and a version resource.** An anonymous exe with a generic icon
  makes both SmartScreen and cautious colleagues more suspicious.

## Distributing the exe

The technical part is done; the annoying part is Windows not trusting an
unsigned binary from an unknown author. What to expect:

**SmartScreen** will show "Windows protected your PC" the first few times
anyone runs it. They click *More info → Run anyway*. This fades as the file
accumulates reputation, but a file that few people download may never
accumulate enough. Tell recipients to expect it, in the same message as the
file — an unexpected warning is what makes people delete things.

**Antivirus false positives** are the real risk. PyInstaller one-file
executables unpack themselves into `%TEMP%` at startup, which is behaviourally
indistinguishable from a self-extracting dropper, so heuristic scanners flag
them. Roughly in order of effort:

- Ask IT to allow-list the file by hash, if you are distributing inside one
  organisation. Usually the fastest fix.
- Submit the exe to your AV vendor as a false positive. Most have a web form
  and turn it around in days.
- Build `--onedir` instead of `--onefile` (see below). A folder of DLLs next
  to an exe trips far fewer heuristics and starts faster, at the cost of not
  being a single file. Zip it for sending.
- **Code-sign it.** This is the actual solution. A standard code-signing
  certificate runs a few hundred dollars a year and still needs reputation to
  build; an EV certificate is more expensive and grants SmartScreen trust
  immediately. Worth it only if you are distributing widely or repeatedly. If
  your institution already has a signing certificate, ask — many do.

**Startup time.** A one-file exe unpacks to a temp directory on every launch,
so the first window takes a few seconds. That is normal, not a hang. Some
locked-down machines block execution from `%TEMP%` entirely, in which case the
exe will not start at all and `--onedir` is the answer:

```
python -m PyInstaller STXM_Axis2000_Converter.spec --clean --noconfirm ^
    -- --onedir
```

or edit the spec to use `COLLECT` instead of a one-file `EXE`. If you would
rather hand over a proper installer, Inno Setup will wrap an `--onedir` build
into a single setup.exe with a Start Menu entry.

**Architecture and OS.** The exe matches the machine it was built on: build on
64-bit Intel/AMD Windows and it runs on 64-bit Intel/AMD Windows. It will not
run on Windows ARM without emulation, and Python 3.9+ does not support
Windows 7. Build on the oldest Windows version you need to support — newer
Windows runs older builds, not the reverse.

**Before you send it out**, run it once on a machine that has never had Python
installed. That is the only test that proves the bundle is really
self-contained; a machine with Python on it can mask a missing dependency by
supplying it from the system.

## Requirements when running as a script

Python 3.9+, `numpy`, `h5py`, and `tkinterdnd2` for drag-and-drop:

```
pip install numpy h5py tkinterdnd2
```

`tkinterdnd2` is optional. Without it the GUI runs exactly as before, minus
dropping. Tkinter itself ships with the python.org Windows installer; on Linux
you may need `sudo apt install python3-tk`.

## Troubleshooting

**`OSError: unable to truncate a file which is already open`** — HDF5 refuses
to write a file something already has open. Two causes, both handled since
v1.1: the same scan queued twice under different path spellings, or the output
file open in Axis2000, HDFView or NeXpy. The queue de-duplicates by resolved
path and conversion writes to a uniquely-named temporary file, so what you
should see now is a plain-English message naming the file to close.

**`could not write ... it is probably open in another program`** — close it.
Antivirus and OneDrive/Dropbox sync can also hold a brief lock; the converter
retries for a couple of seconds, so running it again often works. Writing to a
local folder rather than a synced one avoids this.

**`would overwrite the output of ...`** — two queued scans have the same
filename and you set a single output folder. Convert them separately, or leave
the output folder blank.

**`unrecognised STXM file (neither CLS nor ALS 5.3.2.2)`** — the file is
corrupt, is not HDF5, or is from a beamline this does not know. Other files in
the batch still convert.

**`unsupported scan type`** — the `.stxm` file's `stxm_scan_type` is not one of
Image, Ptychography Image, Spiral Image, Line Spectrum, Focus or Single Motor.

**Dropping does nothing** — either `tkinterdnd2` is not installed (the log says
so at startup), or Explorer and the app are running at different privilege
levels. Windows blocks drag-and-drop from a normal Explorer window into a
program running as administrator; run the converter without elevation.

**The exe takes several seconds to open, or does not open at all** — a
one-file build unpacks itself to `%TEMP%` on every launch, which is slow the
first time and blocked outright on some locked-down machines. See
"Distributing the exe" for the `--onedir` alternative.

**Windows says the publisher is unknown / antivirus quarantines the exe** —
expected for an unsigned PyInstaller binary. See "Distributing the exe".

## Testing status

The CLS path was developed against a real file (`A260219017.hdf5`, 80
energies, two channels) and pixel values are verified to round-trip unchanged
into both output formats.

The ALS path was developed against the notebook's source and tested on
synthetic `.stxm` files generated for each of the four internal layouts,
including a two-region version-3 file and a line scan. **It has not been run
against a real 5.3.2.2 file.** Convert one scan you already have a known-good
`.hdr` for and compare before trusting it on a batch.

Neither output format has been checked in Axis2000 itself.
