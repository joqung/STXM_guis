#!/usr/bin/env python3
"""
STXM -> Axis2000 converter.

Reads two input formats:
  * CLS SM beamline files written by the post-upgrade acquisition software
    (modern NeXus: entry0, DNM_SIS3820_CHAN_* NXdata, NX_units="NX_ANY")
  * ALS 5.3.2.2 .stxm files (all four internal layouts: pre-2, 2, 2.1, 3)

Writes two output formats:
  * Old-style NXstxm HDF5 (entry1/counter0, axis= attributes, real units)
  * ALS .hdr + .xim text files, the format Axis2000 has always read

Requires stxm_formats.py alongside it.

Run with no arguments for the GUI:
    python stxm_axis2000_converter.py

Or from the command line:
    python stxm_axis2000_converter.py IN.hdf5 [OUT] [--hdr|--nxstxm] [--swap-xy]
    python stxm_axis2000_converter.py --batch FOLDER [--out FOLDER] [--hdr]
"""

import os
import sys
import queue
import threading
import traceback

import h5py

import stxm_formats as SF
from stxm_formats import canon, detect_format, read_any, swap_scan_xy

__version__ = "2.1"
SUFFIX = "_axis2000"
INPUT_EXTS = (".hdf5", ".h5", ".stxm")

FMT_NXSTXM = "nxstxm"
FMT_HDR = "hdr"
FORMAT_LABELS = {
    FMT_NXSTXM: "Axis2000 HDF5 (NXstxm)",
    FMT_HDR: "ALS .hdr + .xim",
}

# Colour palettes. The ttk widgets are restyled through the 'clam' theme,
# which is the only built-in theme that honours background colours on every
# platform - the Windows native theme draws buttons and entries with the OS
# and ignores anything set here.
PALETTES = {
    "dark": {
        "bg": "#1e2227",          # window and frames
        "panel": "#252b33",       # list and log backgrounds
        "fg": "#f0f2f5",          # main text
        "muted": "#9aa4b0",       # helper captions
        "border": "#3a424c",
        "btn": "#2e353d",
        "btn_active": "#3b444f",
        "select_bg": "#3d6da8",
        "select_fg": "#ffffff",
        "hover": "#2c3d50",       # drag-over highlight
        "accent": "#5aa0e0",      # progress bar
        "caret": "#f0f2f5",
    },
    "light": {
        "bg": "#f0f0f0",
        "panel": "#ffffff",
        "fg": "#1a1a1a",
        "muted": "#555555",
        "border": "#c4c4c4",
        "btn": "#e4e4e4",
        "btn_active": "#d2d2d2",
        "select_bg": "#0a64c8",
        "select_fg": "#ffffff",
        "hover": "#e8f2fb",
        "accent": "#3a7bd5",
        "caret": "#1a1a1a",
    },
}
DEFAULT_THEME = "dark"


# --------------------------------------------------------------------------
# conversion
# --------------------------------------------------------------------------

def output_target(src_path, out_dir=None, out_format=FMT_NXSTXM):
    """Where a source file's output goes.

    NXstxm output is a single file. .hdr output is a folder per scan, which
    is how the ALS tools and Axis2000 expect a stack to be laid out.
    """
    stem = os.path.splitext(os.path.basename(src_path))[0]
    base = out_dir or os.path.dirname(os.path.abspath(src_path))
    if out_format == FMT_HDR:
        return os.path.join(base, stem)
    return os.path.join(base, stem + SUFFIX + ".hdf5")


def _effective_format(src_path, requested, log=None):
    """ALS .stxm input always goes to .hdr/.xim.

    Those files carry motor tables and scan geometry that the .hdr format has
    fields for and NXstxm does not, and .hdr is the format 5.3.2.2 users
    already load into Axis2000.
    """
    if detect_format(src_path) == "als" and requested != FMT_HDR:
        if log:
            log("    (ALS .stxm input - writing .hdr/.xim)")
        return FMT_HDR
    return requested


def convert_file(src_path, dst_path, swap_xy=False, overwrite=False,
                 out_format=FMT_NXSTXM, log=None):
    """Convert one file. Returns a short human-readable status string."""
    if canon(src_path) == canon(dst_path):
        raise ValueError("input and output are the same file - choose a "
                         "different output folder")

    fmt_in, scans = read_any(src_path)
    if swap_xy:
        scans = [swap_scan_xy(s) for s in scans]

    if out_format == FMT_HDR:
        existing = (os.path.isdir(dst_path)
                    and any(f.lower().endswith(".hdr")
                            for f in os.listdir(dst_path)))
        if existing and not overwrite:
            raise FileExistsError(
                "output already exists: %s" % os.path.basename(dst_path))

        written = []
        for sc in scans:
            # CLS files carry several detector channels; give each its own
            # folder so the .hdr and .xim basenames stay in step
            if fmt_in == "cls" and len(scans) > 1:
                sub = os.path.join(dst_path, sc.channel)
                sc.label = "%s_%s" % (sc.label, sc.channel)
            else:
                sub = dst_path
            written.append(SF.write_hdr_xim(sc, sub))
        return "%s -> %d .hdr set%s, %s" % (
            fmt_in.upper(), len(written), "" if len(written) == 1 else "s",
            scans[0].describe())

    if os.path.exists(dst_path) and not overwrite:
        raise FileExistsError(
            "output already exists: %s" % os.path.basename(dst_path))
    info = SF.write_nxstxm(scans, dst_path, swap_xy=False)
    return "%s -> %s" % (fmt_in.upper(), info)


def collect_inputs(folder, recursive=False):
    """Find convertible files in a folder, skipping ones we already made."""
    found = []
    walker = os.walk(folder) if recursive else [
        (folder, [], os.listdir(folder))]
    for root, _dirs, files in walker:
        for name in sorted(files):
            if not name.lower().endswith(INPUT_EXTS):
                continue
            if os.path.splitext(name)[0].endswith(SUFFIX):
                continue
            found.append(os.path.join(root, name))
    return found


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------

def _apply_theme(root, style, palette, plain_widgets):
    """Recolour every widget. ttk goes through the style engine; plain tk
    widgets (Listbox, Text, the drop hint Label) have to be set directly."""
    p = palette
    try:
        style.theme_use("clam")
    except Exception:                                     # noqa: BLE001
        pass

    root.configure(background=p["bg"])

    style.configure(".", background=p["bg"], foreground=p["fg"],
                    fieldbackground=p["panel"], bordercolor=p["border"],
                    lightcolor=p["bg"], darkcolor=p["bg"],
                    troughcolor=p["panel"], focuscolor=p["accent"])
    style.configure("TFrame", background=p["bg"])
    style.configure("TLabel", background=p["bg"], foreground=p["fg"])
    style.configure("Muted.TLabel", background=p["bg"], foreground=p["muted"])
    style.configure("TLabelframe", background=p["bg"], bordercolor=p["border"],
                    lightcolor=p["bg"], darkcolor=p["bg"])
    style.configure("TLabelframe.Label", background=p["bg"],
                    foreground=p["fg"])

    style.configure("TButton", background=p["btn"], foreground=p["fg"],
                    bordercolor=p["border"], lightcolor=p["btn"],
                    darkcolor=p["btn"], focuscolor=p["accent"])
    style.map("TButton",
              background=[("pressed", p["border"]), ("active", p["btn_active"]),
                          ("disabled", p["bg"])],
              foreground=[("disabled", p["muted"])],
              lightcolor=[("active", p["btn_active"])],
              darkcolor=[("active", p["btn_active"])])

    for widget in ("TCheckbutton", "TRadiobutton"):
        style.configure(widget, background=p["bg"], foreground=p["fg"],
                        indicatorbackground=p["panel"],
                        indicatorforeground=p["fg"],
                        focuscolor=p["accent"])
        style.map(widget,
                  background=[("active", p["bg"])],
                  foreground=[("disabled", p["muted"])],
                  indicatorbackground=[("selected", p["accent"]),
                                       ("pressed", p["btn_active"]),
                                       ("active", p["btn_active"])],
                  indicatorforeground=[("selected", p["select_fg"])])

    style.configure("TEntry", fieldbackground=p["panel"], foreground=p["fg"],
                    insertcolor=p["caret"], bordercolor=p["border"],
                    lightcolor=p["border"], darkcolor=p["border"])
    style.map("TEntry",
              fieldbackground=[("disabled", p["bg"])],
              foreground=[("disabled", p["muted"])],
              bordercolor=[("focus", p["accent"])],
              lightcolor=[("focus", p["accent"])])

    style.configure("Vertical.TScrollbar", background=p["btn"],
                    troughcolor=p["panel"], bordercolor=p["border"],
                    arrowcolor=p["fg"], lightcolor=p["btn"],
                    darkcolor=p["btn"])
    style.map("Vertical.TScrollbar",
              background=[("active", p["btn_active"]),
                          ("pressed", p["btn_active"])])

    style.configure("Horizontal.TProgressbar", background=p["accent"],
                    troughcolor=p["panel"], bordercolor=p["border"],
                    lightcolor=p["accent"], darkcolor=p["accent"])

    for widget, role in plain_widgets:
        if role == "list":
            widget.configure(background=p["panel"], foreground=p["fg"],
                             selectbackground=p["select_bg"],
                             selectforeground=p["select_fg"],
                             highlightbackground=p["border"],
                             highlightcolor=p["border"])
        elif role == "text":
            widget.configure(background=p["panel"], foreground=p["fg"],
                             insertbackground=p["caret"],
                             selectbackground=p["select_bg"],
                             selectforeground=p["select_fg"],
                             highlightbackground=p["border"],
                             highlightthickness=1, borderwidth=0)
        elif role == "hint":
            widget.configure(background=p["panel"], foreground=p["muted"])


def run_gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    try:
        from tkinterdnd2 import DND_FILES, TkinterDnD
        dnd_ok = True
    except Exception:                                     # noqa: BLE001
        dnd_ok = False

    root = TkinterDnD.Tk() if dnd_ok else tk.Tk()
    root.title("STXM -> Axis2000 converter  v%s" % __version__)
    root.geometry("790x680")
    root.minsize(640, 580)

    style = ttk.Style(root)
    plain_widgets = []                  # (widget, role) for non-ttk recolouring
    theme_name = tk.StringVar(value=DEFAULT_THEME)
    pal = dict(PALETTES[DEFAULT_THEME])   # live palette, updated on toggle

    files = []
    log_q = queue.Queue()
    running = threading.Event()

    out_dir_var = tk.StringVar(value="")
    format_var = tk.StringVar(value=FMT_NXSTXM)
    swap_var = tk.BooleanVar(value=False)
    overwrite_var = tk.BooleanVar(value=False)
    recurse_var = tk.BooleanVar(value=True)
    status_var = tk.StringVar(value="No files queued.")

    main = ttk.Frame(root, padding=10)
    main.pack(fill="both", expand=True)
    main.columnconfigure(0, weight=1)
    main.rowconfigure(1, weight=3)
    main.rowconfigure(5, weight=2)

    ttk.Label(main, text="Files to convert").grid(row=0, column=0, sticky="w")

    list_frame = ttk.Frame(main)
    list_frame.grid(row=1, column=0, sticky="nsew", pady=(2, 6))
    list_frame.columnconfigure(0, weight=1)
    list_frame.rowconfigure(0, weight=1)

    listbox = tk.Listbox(list_frame, selectmode="extended", activestyle="none",
                         highlightthickness=2, borderwidth=0)
    listbox.grid(row=0, column=0, sticky="nsew")
    plain_widgets.append((listbox, "list"))
    sb = ttk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
    sb.grid(row=0, column=1, sticky="ns")
    listbox.configure(yscrollcommand=sb.set)

    hint_text = ("Drag .hdf5 or .stxm files or folders here"
                 if dnd_ok else "Use the buttons below to add files")
    hint = tk.Label(listbox, text=hint_text)
    plain_widgets.append((hint, "hint"))

    def refresh_list():
        listbox.delete(0, "end")
        for p in files:
            listbox.insert("end", p)
        if files:
            hint.place_forget()
        else:
            hint.place(relx=0.5, rely=0.5, anchor="center")
        status_var.set("%d file%s queued." %
                       (len(files), "" if len(files) == 1 else "s"))

    def log(msg):
        log_q.put(msg)

    def add_paths(paths, expand_folders=True):
        added = dupes = ignored = missing = 0
        seen = {canon(f) for f in files}
        for raw in paths:
            p = os.path.normpath(raw.strip())
            if os.path.isdir(p):
                if not expand_folders:
                    ignored += 1
                    continue
                found = collect_inputs(p, recursive=recurse_var.get())
                if not found:
                    log("  %s - no .hdf5 / .stxm files found"
                        % os.path.basename(p))
                for q in found:
                    key = canon(q)
                    if key in seen:
                        dupes += 1
                        continue
                    seen.add(key)
                    files.append(q)
                    added += 1
            elif os.path.isfile(p):
                if not p.lower().endswith(INPUT_EXTS):
                    ignored += 1
                    continue
                key = canon(p)
                if key in seen:
                    dupes += 1
                    continue
                seen.add(key)
                files.append(p)
                added += 1
            else:
                missing += 1
        refresh_list()
        bits = ["added %d" % added]
        if dupes:
            bits.append("%d already queued" % dupes)
        if ignored:
            bits.append("%d skipped (not .hdf5 / .stxm)" % ignored)
        if missing:
            bits.append("%d not found" % missing)
        log(", ".join(bits).capitalize() + ".")
        return added, dupes, ignored

    if dnd_ok:
        def _split(event):
            try:
                return list(root.tk.splitlist(event.data))
            except Exception:                             # noqa: BLE001
                return event.data.split()

        def on_drop(event):
            listbox.configure(background=pal["panel"])
            hint.configure(bg=pal["panel"])
            if running.is_set():
                log("Conversion in progress - dropped files ignored.")
                return event.action
            add_paths(_split(event))
            return event.action

        def on_enter(event):
            listbox.configure(background=pal["hover"])
            hint.configure(bg=pal["hover"])
            return event.action

        def on_leave(event):
            listbox.configure(background=pal["panel"])
            hint.configure(bg=pal["panel"])
            return event.action

        for widget in (listbox, hint):
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", on_drop)
            widget.dnd_bind("<<DropEnter>>", on_enter)
            widget.dnd_bind("<<DropLeave>>", on_leave)

    def add_files():
        paths = filedialog.askopenfilenames(
            title="Select STXM files",
            filetypes=[("STXM data", "*.hdf5 *.h5 *.stxm"),
                       ("CLS HDF5", "*.hdf5 *.h5"),
                       ("ALS 5.3.2.2", "*.stxm"),
                       ("All files", "*.*")])
        if paths:
            add_paths(paths)

    def add_folder():
        folder = filedialog.askdirectory(title="Select a folder of STXM files")
        if folder:
            log("Scanning %s" % folder)
            add_paths([folder])

    def remove_selected():
        for idx in sorted(listbox.curselection(), reverse=True):
            del files[idx]
        refresh_list()

    def clear_all():
        files.clear()
        refresh_list()

    btns = ttk.Frame(main)
    btns.grid(row=2, column=0, sticky="w", pady=(0, 8))
    ttk.Button(btns, text="Add files...", command=add_files).pack(side="left")
    ttk.Button(btns, text="Add folder...", command=add_folder).pack(
        side="left", padx=(6, 0))
    ttk.Button(btns, text="Remove selected", command=remove_selected).pack(
        side="left", padx=(6, 0))
    ttk.Button(btns, text="Clear", command=clear_all).pack(
        side="left", padx=(6, 0))
    ttk.Checkbutton(btns, text="include subfolders",
                    variable=recurse_var).pack(side="left", padx=(12, 0))

    opts = ttk.LabelFrame(main, text="Options", padding=8)
    opts.grid(row=3, column=0, sticky="ew", pady=(0, 8))
    opts.columnconfigure(1, weight=1)

    ttk.Label(opts, text="Output format:").grid(row=0, column=0, sticky="w")
    fmt_row = ttk.Frame(opts)
    fmt_row.grid(row=0, column=1, columnspan=2, sticky="w", padx=6)
    ttk.Radiobutton(fmt_row, text=FORMAT_LABELS[FMT_NXSTXM],
                    variable=format_var, value=FMT_NXSTXM).pack(side="left")
    ttk.Radiobutton(fmt_row, text=FORMAT_LABELS[FMT_HDR],
                    variable=format_var, value=FMT_HDR).pack(
        side="left", padx=(12, 0))
    ttk.Label(opts, style="Muted.TLabel",
              text="ALS .stxm files always produce .hdr/.xim.").grid(
        row=1, column=1, sticky="w", padx=6, pady=(2, 6))

    ttk.Label(opts, text="Output folder:").grid(row=2, column=0, sticky="w")
    out_entry = ttk.Entry(opts, textvariable=out_dir_var)
    out_entry.grid(row=2, column=1, sticky="ew", padx=6)

    def pick_out():
        folder = filedialog.askdirectory(title="Choose output folder")
        if folder:
            out_dir_var.set(folder)

    ttk.Button(opts, text="Browse...", command=pick_out).grid(row=2, column=2)
    ttk.Label(opts, style="Muted.TLabel",
              text="Leave blank to write beside each source file.").grid(
        row=3, column=1, sticky="w", padx=6, pady=(2, 6))

    if dnd_ok:
        def on_out_drop(event):
            try:
                dropped = list(root.tk.splitlist(event.data))
            except Exception:                             # noqa: BLE001
                dropped = [event.data]
            for p in dropped:
                p = os.path.normpath(p.strip())
                if os.path.isdir(p):
                    out_dir_var.set(p)
                    log("Output folder set to %s" % p)
                    break
            else:
                log("Drop a folder here, not a file.")
            return event.action

        out_entry.drop_target_register(DND_FILES)
        out_entry.dnd_bind("<<Drop>>", on_out_drop)

    ttk.Checkbutton(
        opts, variable=swap_var,
        text="Swap X and Y  (use if the stack opens transposed in Axis2000)"
    ).grid(row=4, column=0, columnspan=3, sticky="w")
    ttk.Checkbutton(
        opts, variable=overwrite_var,
        text="Overwrite existing output"
    ).grid(row=5, column=0, columnspan=3, sticky="w")

    runbar = ttk.Frame(main)
    runbar.grid(row=4, column=0, sticky="ew", pady=(0, 6))
    runbar.columnconfigure(1, weight=1)
    convert_btn = ttk.Button(runbar, text="Convert")
    convert_btn.grid(row=0, column=0, sticky="w")
    progress = ttk.Progressbar(runbar, mode="determinate")
    progress.grid(row=0, column=1, sticky="ew", padx=(10, 0))

    statusbar = ttk.Frame(main)
    statusbar.grid(row=6, column=0, sticky="ew", pady=(4, 0))
    statusbar.columnconfigure(0, weight=1)
    ttk.Label(statusbar, textvariable=status_var).grid(row=0, column=0,
                                                       sticky="w")

    def toggle_theme():
        name = "light" if theme_name.get() == "dark" else "dark"
        theme_name.set(name)
        pal.clear()
        pal.update(PALETTES[name])
        _apply_theme(root, style, pal, plain_widgets)
        theme_btn.configure(text="Light theme" if name == "dark"
                            else "Dark theme")

    theme_btn = ttk.Button(statusbar, text="Light theme", command=toggle_theme)
    theme_btn.grid(row=0, column=1, sticky="e")

    log_box = tk.Text(main, height=10, wrap="word", state="disabled")
    log_box.grid(row=5, column=0, sticky="nsew")
    plain_widgets.append((log_box, "text"))
    log_sb = ttk.Scrollbar(main, orient="vertical", command=log_box.yview)
    log_box.configure(yscrollcommand=log_sb.set)

    def drain_log():
        try:
            while True:
                msg = log_q.get_nowait()
                log_box.configure(state="normal")
                log_box.insert("end", msg + "\n")
                log_box.see("end")
                log_box.configure(state="disabled")
        except queue.Empty:
            pass
        root.after(120, drain_log)

    def worker(jobs, out_dir, swap, overwrite, want_format):
        ok = fail = 0
        claimed = {}
        for i, src in enumerate(jobs, start=1):
            name = os.path.basename(src)
            try:
                fmt = _effective_format(src, want_format, log)
                dst = output_target(src, out_dir or None, fmt)
                key = canon(dst)
                if key in claimed:
                    raise ValueError(
                        "would overwrite the output of %s - two scans with "
                        "the same name cannot share one output folder"
                        % os.path.basename(claimed[key]))
                claimed[key] = src
                info = convert_file(src, dst, swap_xy=swap,
                                    overwrite=overwrite, out_format=fmt,
                                    log=log)
                ok += 1
                log("[%d/%d] OK   %s  ->  %s  (%s)"
                    % (i, len(jobs), name, os.path.basename(dst), info))
            except FileExistsError as exc:
                fail += 1
                log("[%d/%d] SKIP %s  - %s (tick 'Overwrite' to replace)"
                    % (i, len(jobs), name, exc))
            except Exception as exc:                      # noqa: BLE001
                fail += 1
                log("[%d/%d] FAIL %s  - %s: %s"
                    % (i, len(jobs), name, type(exc).__name__, exc))
            root.after(0, lambda v=i: progress.configure(value=v))
        log("Done. %d converted, %d skipped or failed." % (ok, fail))
        running.clear()
        root.after(0, lambda: convert_btn.configure(state="normal"))
        root.after(0, lambda: status_var.set(
            "Finished: %d converted, %d skipped or failed." % (ok, fail)))

    def start():
        if running.is_set():
            return
        if not files:
            messagebox.showinfo("Nothing to do", "Add some files first.")
            return
        out_dir = out_dir_var.get().strip()
        if out_dir and not os.path.isdir(out_dir):
            messagebox.showerror("Bad output folder",
                                 "That output folder does not exist.")
            return
        running.set()
        convert_btn.configure(state="disabled")
        progress.configure(value=0, maximum=len(files))
        status_var.set("Converting...")
        log("--- converting %d file(s) to %s, swap_xy=%s ---"
            % (len(files), FORMAT_LABELS[format_var.get()], swap_var.get()))
        threading.Thread(
            target=worker,
            args=(list(files), out_dir, swap_var.get(), overwrite_var.get(),
                  format_var.get()),
            daemon=True).start()

    convert_btn.configure(command=start)

    def on_close():
        if running.is_set():
            if not messagebox.askokcancel(
                    "Quit", "A conversion is still running. Quit anyway?"):
                return
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    log("STXM -> Axis2000 converter v%s   (h5py %s, HDF5 %s)"
        % (__version__, h5py.__version__, h5py.version.hdf5_version))
    log("Reads CLS post-upgrade .hdf5 and ALS 5.3.2.2 .stxm files.")
    if dnd_ok:
        log("Drag files or folders onto the list above, or use the buttons.")
    else:
        log("Drag and drop unavailable (tkinterdnd2 not installed) - "
            "use the Add buttons.")
    _apply_theme(root, style, pal, plain_widgets)
    refresh_list()
    drain_log()
    root.mainloop()


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def _ensure_console():
    """Make stdout usable when frozen as a windowed Windows app.

    A --windowed PyInstaller build has no console attached, so print() in
    --batch mode goes nowhere (and sys.stdout can be None, which makes it
    raise). Attaching to the console that launched us puts the output back
    where the user is looking. Double-clicking the exe has no parent console,
    in which case this quietly does nothing and the GUI runs as usual.
    """
    if sys.stdout is None or sys.stderr is None:
        devnull = open(os.devnull, "w")
        sys.stdout = sys.stdout or devnull
        sys.stderr = sys.stderr or devnull

    if os.name != "nt" or not getattr(sys, "frozen", False):
        return
    try:
        import ctypes
        if ctypes.windll.kernel32.AttachConsole(-1):      # -1 = parent process
            try:
                sys.stdout = open("CONOUT$", "w", buffering=1)
                sys.stderr = open("CONOUT$", "w", buffering=1)
            except OSError:
                pass
    except Exception:                                     # noqa: BLE001
        pass


def run_cli(argv):
    _ensure_console()
    swap = "--swap-xy" in argv
    overwrite = "--overwrite" in argv
    want = FMT_HDR if "--hdr" in argv else FMT_NXSTXM

    out_dir = None
    if "--out" in argv:
        idx = argv.index("--out")
        if idx + 1 < len(argv):
            out_dir = argv[idx + 1]

    args = [a for a in argv if not a.startswith("--")]
    if out_dir in args:
        args.remove(out_dir)

    def say(msg):
        print(msg)

    if "--batch" in argv:
        if not args:
            print("usage: --batch FOLDER [--out FOLDER] [--hdr] [--swap-xy]")
            return 2
        folder = args[0]
        jobs, seen = [], set()
        for j in collect_inputs(folder, recursive=True):
            k = canon(j)
            if k not in seen:
                seen.add(k)
                jobs.append(j)
        if not jobs:
            print("no .hdf5 / .stxm files found in", folder)
            return 1
        rc = 0
        for src in jobs:
            try:
                fmt = _effective_format(src, want)
                dst = output_target(src, out_dir, fmt)
                info = convert_file(src, dst, swap, overwrite, fmt)
                print("OK   %s -> %s (%s)" % (src, dst, info))
            except Exception as exc:                      # noqa: BLE001
                rc = 1
                print("FAIL %s - %s: %s" % (src, type(exc).__name__, exc))
        return rc

    if not args:
        print(__doc__)
        return 2
    src = args[0]
    fmt = _effective_format(src, want, say)
    dst = args[1] if len(args) > 1 else output_target(src, out_dir, fmt)
    try:
        info = convert_file(src, dst, swap, overwrite, fmt, say)
    except FileExistsError as exc:
        print("SKIP %s - %s (pass --overwrite to replace)" % (src, exc))
        return 1
    except Exception:                                     # noqa: BLE001
        traceback.print_exc()
        return 1
    print("OK   %s -> %s (%s)" % (src, dst, info))
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(run_cli(sys.argv[1:]))
    run_gui()
