# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for the STXM -> Axis2000 converter.

Build with:   pyinstaller STXM_Axis2000_Converter.spec --clean --noconfirm

Choices here that matter for handing the result to other people:

  upx=False        UPX-compressed binaries are one of the strongest triggers
                   for antivirus false positives. Compression saves ~20 MB and
                   costs you support calls. Not worth it.

  excludes         PyInstaller bundles anything importable it can reach. On a
                   machine that also has scipy, matplotlib or Qt installed
                   those get swept in and the exe triples in size. This list
                   keeps the bundle to what the converter actually imports.

  version/icon     An exe with no version resource and a generic icon looks
                   anonymous, which makes both SmartScreen and cautious
                   colleagues more suspicious. Applied on Windows only.
"""

import sys
from PyInstaller.utils.hooks import collect_all

datas, binaries, hiddenimports = [], [], []

# tkinterdnd2 ships prebuilt tkdnd Tcl binaries that must travel with the app
for mod in ("tkinterdnd2",):
    d, b, h = collect_all(mod)
    datas += d
    binaries += b
    hiddenimports += h

hiddenimports += ["h5py", "h5py.defs", "h5py.utils", "h5py._proxy",
                  "stxm_formats"]

a = Analysis(
    ["stxm_axis2000_converter.py"],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        # heavy scientific stack the converter does not use
        "scipy", "matplotlib", "skimage", "sklearn", "pandas", "sympy",
        "numba", "llvmlite", "tables", "zmq", "cython",
        # notebook / IDE machinery
        "IPython", "jupyter", "notebook", "ipykernel", "nbconvert",
        "jedi", "parso", "pytest", "setuptools", "pip",
        # other GUI toolkits
        "PyQt5", "PyQt6", "PySide2", "PySide6", "wx", "gtk",
        # imaging / plotting extras
        "PIL", "pygame", "cv2",
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

_is_windows = sys.platform == "win32"

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="STXM_Axis2000_Converter",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,                       # see note above
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,                   # GUI app, no console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="stxm_icon.ico" if _is_windows else None,
    version="version_info.txt" if _is_windows else None,
)
