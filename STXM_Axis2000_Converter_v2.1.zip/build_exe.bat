@echo off
REM ---------------------------------------------------------------
REM  Builds STXM_Axis2000_Converter.exe - a single self-contained
REM  file you can hand to anyone running 64-bit Windows.
REM
REM  Run this once, on Windows, in the folder containing:
REM      stxm_axis2000_converter.py
REM      stxm_formats.py
REM      STXM_Axis2000_Converter.spec
REM      version_info.txt
REM      stxm_icon.ico
REM  Needs Python 3.9+ installed and on PATH.
REM ---------------------------------------------------------------

setlocal
cd /d "%~dp0"

echo.
echo === Checking files ===
set MISSING=0
for %%F in (stxm_axis2000_converter.py stxm_formats.py STXM_Axis2000_Converter.spec version_info.txt stxm_icon.ico) do (
    if not exist "%%F" (
        echo   MISSING: %%F
        set MISSING=1
    )
)
if "%MISSING%"=="1" (
    echo.
    echo Put all five files in this folder and run again.
    pause
    exit /b 1
)
echo   all present

echo.
echo === Checking Python ===
python --version
if errorlevel 1 (
    echo.
    echo Python was not found on PATH.
    echo Install it from python.org and tick "Add python.exe to PATH".
    pause
    exit /b 1
)

echo.
echo === Installing build dependencies ===
python -m pip install --upgrade pip
python -m pip install numpy h5py tkinterdnd2 pyinstaller
if errorlevel 1 (
    echo.
    echo Dependency install failed. Check your network / proxy settings.
    pause
    exit /b 1
)

echo.
echo === Building (this takes a few minutes) ===
python -m PyInstaller STXM_Axis2000_Converter.spec --clean --noconfirm
if errorlevel 1 (
    echo.
    echo Build failed. See the messages above.
    pause
    exit /b 1
)

echo.
echo === Smoke test ===
dist\STXM_Axis2000_Converter.exe --help >nul 2>&1
echo   (launch dist\STXM_Axis2000_Converter.exe by hand to check the window opens)

echo.
echo ===============================================
echo  Done.
echo     %CD%\dist\STXM_Axis2000_Converter.exe
echo.
echo  That one file is the whole program. Copy it
echo  anywhere; the target PC needs no Python and
echo  no other files.
echo.
echo  Before sending it to colleagues, read the
echo  "Distributing the exe" section of README.md
echo  - antivirus false positives are the main
echo  thing that will bite you.
echo ===============================================
echo.
pause
