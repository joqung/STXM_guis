#!/bin/bash
# ===========================================================================
#  build_mac.sh - build gedgfit.app on macOS
#
#  In Terminal, from this folder:
#      ./build_mac.sh
#  (if macOS says "permission denied":  chmod +x build_mac.sh  first)
#
#  Uses python3 from your PATH, or the one you name:
#      PYTHON=/usr/local/bin/python3.12 ./build_mac.sh
#
#  Result:  dist/gedgfit.app            the application
#           dist/gedgfit-mac-<arch>.zip the same, zipped to send to others
#
#  The app runs on the kind of Mac it was built on: build on an Apple
#  Silicon Mac for Apple Silicon (arm64), on an Intel Mac for Intel (x86_64).
#  An Intel build also runs on Apple Silicon, through Rosetta.
# ===========================================================================
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
VENV=".venv-mac-build"

say()  { printf '\n\033[1m==> %s\033[0m\n' "$*"; }
fail() { printf '\n\033[31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

[[ "$(uname)" == "Darwin" ]] || fail "This script builds the Mac app and must run on macOS. On Windows use build_windows.bat."
command -v "$PY" >/dev/null 2>&1 || fail "'$PY' not found. Install Python 3 from https://www.python.org/downloads/macos/ and run this again."

say "Checking Python"
"$PY" - <<'EOF' || exit 1
import sys, platform
ok = True
print(f"  Python {platform.python_version()} at {sys.executable} ({platform.machine()})")
if sys.version_info < (3, 9):
    print("  Python 3.9 or newer is needed."); ok = False
try:
    import tkinter
    tk = tkinter.Tcl().eval("info patchlevel")
    print(f"  Tk {tk}")
    if tkinter.TkVersion < 8.6:
        print("  Tk 8.6 or newer is needed. This looks like Apple's built-in Python,"
              "\n  whose Tk 8.5 draws the interface badly and cannot do drag and drop.")
        ok = False
except Exception as exc:
    print(f"  tkinter is missing ({exc}).")
    print("  With Homebrew Python: brew install python-tk")
    ok = False
if not ok:
    print("\n  Fix: install Python from https://www.python.org/downloads/macos/"
          "\n  (its installer includes a current Tk), then run:"
          "\n      PYTHON=/usr/local/bin/python3 ./build_mac.sh")
sys.exit(0 if ok else 1)
EOF

say "Setting up the build environment ($VENV)"
if [[ ! -x "$VENV/bin/python" ]]; then
    "$PY" -m venv "$VENV"
fi
VPY="$VENV/bin/python"
"$VPY" -m pip install --quiet --upgrade pip
"$VPY" -m pip install --quiet -r requirements.txt pyinstaller

say "Building gedgfit.app"
rm -rf build dist
"$VPY" -m PyInstaller gedgfit.spec --noconfirm --log-level WARN
APP="dist/gedgfit.app"
[[ -d "$APP" ]] || fail "PyInstaller finished but $APP is missing; see the messages above."

say "Self-test of the built app"
if ! "$APP/Contents/MacOS/gedgfit" --selftest; then
    fail "The self-test failed; the app was built but is not working. See the lines above."
fi

say "Zipping for sharing"
ARCH="$(uname -m)"
ZIP="dist/gedgfit-mac-$ARCH.zip"
# ditto keeps the bundle's structure, permissions and signature intact
ditto -c -k --keepParent "$APP" "$ZIP"

cat <<EOF

Done.
  App:  $APP
  Zip:  $ZIP   (for $ARCH Macs)

Open it by double-clicking $APP, or drag it to Applications first.

The app is not signed with an Apple Developer certificate, so on another Mac
macOS blocks the first launch. To allow it, either:
  - System Settings > Privacy & Security, scroll down, "Open Anyway"
    (macOS 15 Sequoia and later), or right-click the app > Open (earlier), or
  - in Terminal:  xattr -dr com.apple.quarantine /path/to/gedgfit.app
EOF
