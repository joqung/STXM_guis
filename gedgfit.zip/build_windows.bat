@echo off
REM ===================================================================
REM  Build gedgfit into a standalone Windows executable.
REM
REM  Put this file, gedgfit.py, gedgfit.spec and icon.ico in
REM  the same folder, then double-click this file.
REM
REM  You need Python installed, with "Add python.exe to PATH" ticked
REM  in the installer. Nothing else.
REM
REM  The result lands in  dist\gedgfit.exe
REM
REM  NOTE FOR EDITORS: never put a percent sign inside a python -c
REM  command below. cmd.exe expands percent signs before Python sees
REM  the line, and silently corrupts the code.
REM ===================================================================

setlocal
cd /d "%~dp0"

echo.
echo === gedgfit - Windows build =============================
echo.

REM --- check the needed files are present -----------------------------
if not exist "gedgfit.py" (
    echo ERROR: gedgfit.py is not in this folder.
    echo        Put all the downloaded files together and try again.
    echo.
    pause
    exit /b 1
)
if not exist "gedgfit.spec" (
    echo ERROR: gedgfit.spec is not in this folder.
    echo.
    pause
    exit /b 1
)

REM --- locate Python --------------------------------------------------
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY (
    where python >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo ERROR: Python was not found on your PATH.
    echo.
    echo Install it from https://www.python.org/downloads/windows/
    echo and be sure to tick "Add python.exe to PATH" during setup.
    echo.
    pause
    exit /b 1
)
echo Using: %PY%
%PY% --version
echo.

REM --- build inside an isolated virtual environment ---------------------
REM  This keeps your everyday Python installation untouched, and stops
REM  unrelated packages being swept into the executable.
if not exist "build_env\Scripts\python.exe" (
    echo Creating a build environment ^(one time only^)...
    if exist "build_env" rmdir /s /q "build_env"
    %PY% -m venv build_env
    if errorlevel 1 (
        echo ERROR: could not create the virtual environment.
        pause
        exit /b 1
    )
)

call "build_env\Scripts\activate.bat"

echo Installing build requirements. The first run downloads about 100 MB...
python -m pip install --upgrade pip --quiet --disable-pip-version-check
python -m pip install --quiet --disable-pip-version-check numpy scipy matplotlib pyinstaller igor2 tkinterdnd2
if errorlevel 1 (
    echo.
    echo ERROR: package installation failed.
    echo.
    echo   - Check your internet connection.
    echo   - If pip said "no matching distribution found", your Python is
    echo     probably newer than the packages support. Install Python
    echo     3.12 or 3.13 alongside it, delete the build_env folder,
    echo     and run this script again.
    echo.
    pause
    exit /b 1
)
echo.

REM --- preflight: does everything actually load? -------------------------
echo Checking that the program loads...
python -c "import tkinter, numpy, scipy, matplotlib, gedgfit; print('  ok - model has', gedgfit.FULL_LEN, 'parameters')"
if errorlevel 1 (
    echo.
    echo ERROR: the program did not load. The message above says why.
    echo.
    echo   - "No module named tkinter" means Python was installed without
    echo     the Tcl/Tk option. Re-run the Python installer, choose
    echo     Modify, and enable "tcl/tk and IDLE".
    echo.
    pause
    exit /b 1
)

python -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: PyInstaller did not install correctly. It may not support
    echo        this version of Python yet. Install Python 3.12 or 3.13,
    echo        delete the build_env folder, and run this script again.
    echo.
    pause
    exit /b 1
)
echo.

REM --- package -----------------------------------------------------------
echo Building the executable. This takes a few minutes...
echo.
if exist "build" rmdir /s /q "build"
python -m PyInstaller gedgfit.spec --noconfirm --clean
if errorlevel 1 (
    echo.
    echo ERROR: the build failed. The messages above say why.
    echo        A line starting with "ERROR: Hidden import" means a module
    echo        name must be added to the hidden list in gedgfit.spec.
    echo.
    pause
    exit /b 1
)

echo.
echo === Done ========================================================
echo.
if exist "dist\gedgfit.exe" (
    echo   Your program:  %CD%\dist\gedgfit.exe
    echo.
    echo   That single file is everything. Copy it anywhere, or send it
    echo   to a colleague - no Python needed on their machine.
) else (
    echo   Your program is in:  %CD%\dist\gedgfit\
    echo   Keep the whole folder together and run gedgfit.exe inside it.
)
echo.
echo   If Windows SmartScreen warns on first run, choose
echo   "More info" then "Run anyway". That is normal for unsigned programs.
echo.
pause
