#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma IgorVersion=7.00
#pragma version=2.0

// ===========================================================================
//  gedgfit_Model.ipf
//
//  Step edge + up to 12 skewed pseudo-Voigt peaks, with the SAME parameter
//  layout and mathematics as the gedgfit program (gedgfit.py).
//  This is the file gedgfit refers to when it exports a "75-element" wave.
//
//  Replaces EDG_Fit12_SGM_modified.ipf. Close that file before opening this
//  one: both define edg_fit1..12, Plot_step and Plot_wave1..12.
//
//  ---------------------------------------------------------------------------
//  PARAMETER WAVE  (76 points)
//
//    w[0]          step Gaussian fraction   (governs the STEP ONLY)
//    w[1]          step amplitude           (gedgfit's "Step amplitude *";
//                                            keep held at 1 for edge-jump
//                                            normalised data)
//    w[2]          step position E0
//    w[3]          step half-width
//    peak i = 1..12, base b = 4 + 6*(i-1):
//    w[b+0]        amplitude
//    w[b+1]        position
//    w[b+2]        half-width
//    w[b+3]        skew
//    w[b+4]        L/W ratio  (Gaussian width / Lorentzian width)
//    w[b+5]        this peak's own Gaussian fraction
//
//    Peak 1 = w[4..9], peak 2 = w[10..15], ... peak 12 = w[70..75].
//    The text wave <base>_P_Desc says what every row is; SetUp puts it in
//    the table beside <base>_P.
//
//  gedgfit keeps the step amplitude OUTSIDE its 75-point wave, so its waves
//  read  [mix, E0, W0, peaks...]. EDG_FromGedgfitLayout / EDG_ToGedgfitLayout
//  convert between the two; the workflow's ImportGedgfitP / ExportForGedgfit
//  do this for you.
//
//  MODEL  (identical to gedgfit, including its guard on zero denominators)
//    step(x)  = amp*[ 1/2 + m0*(1/2)erf((x-E0)sqrt(ln2)/W0) + (1-m0)*(1/pi)atan((x-E0)/W0) ]
//    w_eff    = W + (x-E)*skew
//    G(x)     = exp(-ln2*(x-E)^2 / (w_eff*R)^2)
//    L(x)     = w_eff^2 / (w_eff^2 + (x-E)^2)
//    peak(x)  = A*( m*G + (1-m)*L )          m = that peak's own fraction
//    edg_fitN = step + peaks 1..N
//
//  Differences from the original EDG_Fit12_SGM_modified.ipf:
//    * 6 parameters per peak instead of 5 (the 6th is the Gaussian fraction)
//    * param[0] no longer controls the peaks, only the step
//    * step amplitude inserted at w[1]; everything after w[0] moved up by 1
//  Setting every peak fraction equal to w[0] (EDG_LinkGauss) and keeping
//  w[1]=1 reproduces the original procedure exactly. Old 53/63-point waves
//  are converted with EDG_FromIgorLayout (SetUp does this automatically).
//
//  GUI-STYLE PARAMETER TABLE
//    <base>_Step   4 x 2  : rows = Gauss frac, amplitude, position, half-width;
//                           columns = value, hold
//    <base>_Peaks 12 x 12 : one row per peak; columns are value/hold pairs for
//                           Amp, Position, Width, Skew, L/W ratio, Gauss frac
//    These mirror gedgfit's "Edge step" and "Peaks" panels, including the
//    hold checkboxes (1 = held). <base>_P is the 1-D coefficient wave FuncFit
//    uses; EDG_Sync keeps the two in step in whichever direction changed.
// ===========================================================================

Constant kEDG_NGlobal = 4			// mix, amplitude, position, half-width
Constant kEDG_PerPeak = 6
Constant kEDG_MaxPeaks = 12
Constant kEDG_StepAmpIdx = 1
Constant kEDG_WaveLen = 76
Constant kEDG_GedgfitLen = 75		// gedgfit's FULL_LEN (no step amplitude)
Constant kEDG_IgorPerPeak = 5		// original EDG_Fit12 layout
Constant kEDG_IgorLen = 63
Constant kEDG_Tiny = 1e-12
// Points in the fit_<base>_Int curve. FuncFit's /D rebuilds that wave with
// this many points (/L) across the fit range, and gedgfit exports it the same way.
Constant kEDG_FitCurvePoints = 1000

StrConstant ksEDG_PeakFields = "Amp;Position;Width;Skew;LW_ratio;Gauss_frac;"
StrConstant ksEDG_PeakHolds = "Amp_hold;Pos_hold;Width_hold;Skew_hold;LWR_hold;Gauss_hold;"
StrConstant ksEDG_StepRows = "Step_Gauss_frac;Step_amplitude;Step_position_E0;Step_half_width;"

// gedgfit's DEFAULT_LIMITS (used only when a fit is run with limits on)
Constant kEDG_AmpMin = 0
Constant kEDG_AmpMax = 100
Constant kEDG_WidthMin = 0.01
Constant kEDG_WidthMax = 20
Constant kEDG_SkewMin = -0.5
Constant kEDG_SkewMax = 0.5
Constant kEDG_LWRMin = 0.05
Constant kEDG_LWRMax = 20
Constant kEDG_PosTol = 2
Constant kEDG_StepPosTol = 5
Constant kEDG_MixMin = 0
Constant kEDG_MixMax = 1


// ===========================================================================
//  Core mathematics
// ===========================================================================

// Keep a denominator away from zero without changing its sign (gedgfit _safe)
Function EDG_Safe(a)
	Variable a
	if(abs(a) < kEDG_Tiny)
		return (a < 0) ? -kEDG_Tiny : kEDG_Tiny
	endif
	return a
End

// Index of the first parameter of peak i (0-based peak number)
Function EDG_PeakBase(i)
	Variable i
	return kEDG_NGlobal + kEDG_PerPeak*i
End

// Step amplitude, w[1]
Function EDG_StepAmp(w)
	Wave w
	return w[kEDG_StepAmpIdx]
End

Function EDG_StepProfile(xx, mix, pos, width, amp)
	Variable xx, mix, pos, width, amp
	Variable wd = EDG_Safe(width)
	Variable dx = xx - pos
	Variable ef = 0.5*erf(dx*sqrt(ln(2))/wd)
	Variable at = atan(dx/wd)/pi
	return amp*(0.5 + mix*ef + (1-mix)*at)
End

Function EDG_PeakProfile(xx, mix, amp, pos, width, skew, lwr)
	Variable xx, mix, amp, pos, width, skew, lwr
	Variable dx = xx - pos
	Variable weff = EDG_Safe(width + dx*skew)
	Variable rr = EDG_Safe(lwr)
	Variable g = exp(-ln(2)*(dx^2)/((weff*rr)^2))
	Variable l = (weff^2)/((weff^2) + (dx^2))
	return amp*(mix*g + (1-mix)*l)
End

// Step component (gedgfit component_step / Igor Plot_step)
Function EDG_StepComp(w, xx)
	Wave w
	Variable xx
	return EDG_StepProfile(xx, w[0], w[2], w[3], w[1])
End

// Peak component, 0-based peak i (gedgfit component_peak / Igor Plot_waveN)
Function EDG_PeakComp(w, xx, i)
	Wave w
	Variable xx, i
	Variable b = EDG_PeakBase(i)
	return EDG_PeakProfile(xx, w[b+5], w[b], w[b+1], w[b+2], w[b+3], w[b+4])
End

// Unit-height Gaussian and Lorentzian parts of peak i (replace Ig1..12, Il1..12)
Function EDG_G(w, xx, i)
	Wave w
	Variable xx, i
	Variable b = EDG_PeakBase(i)
	return EDG_PeakProfile(xx, 1, 1, w[b+1], w[b+2], w[b+3], w[b+4])
End

Function EDG_L(w, xx, i)
	Wave w
	Variable xx, i
	Variable b = EDG_PeakBase(i)
	return EDG_PeakProfile(xx, 0, 1, w[b+1], w[b+2], w[b+3], w[b+4])
End

// Step plus the first n peaks (gedgfit model_total)
Function EDG_Total(w, xx, n)
	Wave w
	Variable xx, n
	Variable tot = EDG_StepComp(w, xx), i
	for(i=0; i<n; i+=1)
		tot += EDG_PeakComp(w, xx, i)
	endfor
	return tot
End


// ===========================================================================
//  Step pieces (same names and meaning as the original procedure)
// ===========================================================================

Function step_fit(param, xx)
	Wave param
	Variable xx
	return EDG_StepComp(param, xx)
End

Function error(param, xx)
	Wave param
	Variable xx
	return 0.5*erf((xx-param[2])*sqrt(ln(2))/EDG_Safe(param[3]))
End

Function arctangent(param, xx)
	Wave param
	Variable xx
	return (1/pi)*atan((xx-param[2])/EDG_Safe(param[3]))
End


// ===========================================================================
//  Fit functions: pick the one matching your number of peaks
// ===========================================================================

Function edg_fit1(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 1)
End

Function edg_fit2(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 2)
End

Function edg_fit3(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 3)
End

Function edg_fit4(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 4)
End

Function edg_fit5(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 5)
End

Function edg_fit6(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 6)
End

Function edg_fit7(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 7)
End

Function edg_fit8(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 8)
End

Function edg_fit9(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 9)
End

Function edg_fit10(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 10)
End

Function edg_fit11(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 11)
End

Function edg_fit12(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 12)
End


// ===========================================================================
//  Plotting components (same names as the original procedure)
// ===========================================================================

Function Plot_step(param, xx)
	Wave param
	Variable xx
	return EDG_StepComp(param, xx)
End

Function Plot_wave1(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 0)
End

Function Plot_wave2(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 1)
End

Function Plot_wave3(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 2)
End

Function Plot_wave4(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 3)
End

Function Plot_wave5(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 4)
End

Function Plot_wave6(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 5)
End

Function Plot_wave7(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 6)
End

Function Plot_wave8(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 7)
End

Function Plot_wave9(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 8)
End

Function Plot_wave10(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 9)
End

Function Plot_wave11(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 10)
End

Function Plot_wave12(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 11)
End


// ===========================================================================
//  Parameter-wave layout utilities
// ===========================================================================

// gedgfit default_params(), plus step amplitude = 1 at w[1]
Function EDG_DefaultParams(w)
	Wave w
	Redimension/D/N=(kEDG_WaveLen) w
	w = 0
	w[0] = 0.5			// step Gaussian fraction
	w[1] = 1			// step amplitude
	w[2] = 0			// step position
	w[3] = 0.5			// step half-width
	Variable i, b
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		b = EDG_PeakBase(i)
		w[b+0] = 0		// amplitude
		w[b+1] = 0		// position
		w[b+2] = 0.5	// half-width
		w[b+3] = 0		// skew
		w[b+4] = 1		// L/W ratio
		w[b+5] = 0.5	// Gaussian fraction
	endfor
	EDG_LabelParams(w)
End

// Name every point so a table of the wave (Edit w.ld) reads like gedgfit
Function EDG_LabelParams(w)
	Wave w
	Variable i, k, n = numpnts(w)
	SetDimLabel 0, 0, Step_Gauss_frac, w
	SetDimLabel 0, 1, Step_amplitude, w
	SetDimLabel 0, 2, Step_position_E0, w
	SetDimLabel 0, 3, Step_half_width, w
	String lbl
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			if(EDG_PeakBase(i)+k < n)
				lbl = "P" + num2istr(i+1) + "_" + StringFromList(k, ksEDG_PeakFields)
				SetDimLabel 0, EDG_PeakBase(i)+k, $lbl, w
			endif
		endfor
	endfor
End

// Plain-language description of parameter k, e.g. "Peak 3 position (eV)"
Function/S EDG_Describe(k)
	Variable k
	if(k < kEDG_NGlobal)
		return StringFromList(k, "Step Gaussian fraction;Step amplitude (hold at 1);Step position E0 (eV);Step half-width (eV);")
	endif
	Variable i = floor((k - kEDG_NGlobal)/kEDG_PerPeak)
	Variable f = mod(k - kEDG_NGlobal, kEDG_PerPeak)
	if(i >= kEDG_MaxPeaks)
		return "(unused)"
	endif
	return "Peak " + num2istr(i+1) + " " + StringFromList(f, "amplitude;position (eV);half-width (eV);skew;L/W ratio (G/L width);Gaussian fraction;")
End

// Text wave <base>_P_Desc: one row per parameter, "p[k]  description".
// Shown next to <base>_P so every row is identified at a glance.
Function EDG_MakeDescWave(base)
	String base
	Make/O/T/N=(kEDG_WaveLen) $(EDG_Name(base, "P_Desc"))
	Wave/T d = $(EDG_Name(base, "P_Desc"))
	d = "p[" + num2istr(p) + "]  " + EDG_Describe(p)
End

// Convert w in place to the current 76-point layout. Recognises:
//   < 75 points          original EDG_Fit12 layout (5 per peak)
//   75 points            gedgfit export (no step amplitude) - amp set to ampDefault
//   76, row 1 labelled Step_position   the previous version of this file
//                        (step amplitude stored last, at w[75])
//   76 points otherwise  already current
// Returns a description of what was done ("" if nothing).
Function/S EDG_ToCurrentLayout(w, ampDefault)
	Wave w
	Variable ampDefault
	Variable n = numpnts(w)
	String what = ""
	if(n < kEDG_GedgfitLen)
		EDG_FromIgorLayout(w, w)
		what = "original 5-per-peak Igor layout (" + num2istr(n) + " points)"
	elseif(n == kEDG_GedgfitLen)
		EDG_FromGedgfitLayout(w, w, ampDefault)
		what = "gedgfit 75-point layout"
	elseif(n == kEDG_WaveLen && cmpstr(GetDimLabel(w, 0, 1), "Step_position") == 0)
		Duplicate/FREE w, src
		w[0] = src[0]
		w[1] = src[75]
		w[2] = src[1]
		w[3] = src[2]
		w[4, 75] = src[p-1]
		what = "previous layout with the step amplitude at p[75]"
	elseif(n > kEDG_WaveLen)
		Redimension/N=(kEDG_WaveLen) w
		what = "longer wave, trimmed to 76 points"
	endif
	EDG_LabelParams(w)
	return what
End

// gedgfit 75-point wave [mix, E0, W0, peaks...] -> current layout
Function EDG_FromGedgfitLayout(g, new, amp)
	Wave g, new
	Variable amp
	Duplicate/FREE g, src
	Redimension/D/N=(kEDG_WaveLen) new
	new[0] = src[0]
	new[1] = amp
	new[2] = src[1]
	new[3] = src[2]
	new[4, 75] = src[p-1]
	EDG_LabelParams(new)
End

// Name every point of a gedgfit 75-point wave [mix, E0, W0, peaks...],
// with the same labels gedgfit writes
Function EDG_LabelGedgfitLayout(w)
	Wave w
	SetDimLabel 0, 0, Step_Gauss_frac, w
	SetDimLabel 0, 1, Step_position_E0, w
	SetDimLabel 0, 2, Step_half_width, w
	Variable i, k, idx
	String lbl
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			idx = 3 + kEDG_PerPeak*i + k
			if(idx < numpnts(w))
				lbl = "P" + num2istr(i+1) + "_" + StringFromList(k, ksEDG_PeakFields)
				SetDimLabel 0, idx, $lbl, w
			endif
		endfor
	endfor
End

// Description of point k of a gedgfit 75-point wave, as gedgfit writes it
Function/S EDG_DescribeGedgfit(k)
	Variable k
	if(k < 3)
		return StringFromList(k, "Step Gaussian fraction;Step position E0 (eV);Step half-width (eV);")
	endif
	Variable i = floor((k - 3)/kEDG_PerPeak)
	Variable f = mod(k - 3, kEDG_PerPeak)
	return "Peak " + num2istr(i+1) + " " + StringFromList(f, "amplitude;position (eV);half-width (eV);skew;L/W ratio (G/L width);Gaussian fraction;")
End

// Current layout -> gedgfit 75-point wave (step amplitude dropped; gedgfit
// holds it in its own "Step amplitude" box)
Function EDG_ToGedgfitLayout(w, out)
	Wave w, out
	Duplicate/FREE w, src
	Redimension/D/N=(kEDG_GedgfitLen) out
	out[0] = src[0]
	out[1] = src[2]
	out[2] = src[3]
	out[3, 74] = src[p+1]
End

// Original 5-per-peak Igor wave (any length, e.g. 53 or 63) -> new layout.
// Every peak fraction is set to old[0], which reproduces Igor exactly
// (gedgfit from_igor_layout).
Function EDG_FromIgorLayout(old, new)
	Wave old, new
	Duplicate/FREE old, src			// allows old and new to be the same wave
	EDG_DefaultParams(new)			// step amplitude = 1, as Igor hard-wired it
	Variable n = numpnts(src), i, k, si, b
	if(n > 0)
		new[0] = src[0]				// mix
	endif
	if(n > 1)
		new[2] = src[1]				// step position
	endif
	if(n > 2)
		new[3] = src[2]				// step half-width
	endif
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		si = 3 + kEDG_IgorPerPeak*i
		if(si + kEDG_IgorPerPeak > n)
			break
		endif
		b = EDG_PeakBase(i)
		for(k=0; k<kEDG_IgorPerPeak; k+=1)
			new[b+k] = src[si+k]
		endfor
	endfor
	EDG_LinkGauss(new)
End

// New layout -> the 63 parameters the ORIGINAL edg_fitN reads
// (gedgfit to_igor_layout). Per-peak fractions are dropped.
Function EDG_ToIgorLayout(w, out)
	Wave w, out
	Duplicate/FREE w, src
	Redimension/D/N=(kEDG_IgorLen) out
	out = 0
	Variable i, k, si, b
	out[0] = src[0]
	out[1] = src[2]
	out[2] = src[3]
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		b = EDG_PeakBase(i)
		si = 3 + kEDG_IgorPerPeak*i
		for(k=0; k<kEDG_IgorPerPeak; k+=1)
			out[si+k] = src[b+k]
		endfor
	endfor
	if(!EDG_MixesLinked(src))
		Print "EDG_ToIgorLayout: the per-peak Gaussian fractions differ from w[0]; the original edg_fitN cannot express that."
	endif
	if(src[1] != 1)
		Print "EDG_ToIgorLayout: the step amplitude is not 1; the original edg_fitN cannot express that."
	endif
End

// gedgfit "Link all Gauss fractions to the step (Igor behaviour)"
Function EDG_LinkGauss(w)
	Wave w
	Variable i
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		w[EDG_PeakBase(i)+5] = w[0]
	endfor
End

Function EDG_MixesLinked(w)
	Wave w
	Variable i
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		if(abs(w[EDG_PeakBase(i)+5] - w[0]) > 1e-12)
			return 0
		endif
	endfor
	return 1
End

// Analytic area of 0-based peak i (gedgfit peak_area). NaN when skewed.
//   Area = A*W*[ m*R*sqrt(pi/ln2) + (1-m)*pi ]
Function EDG_PeakArea(w, i)
	Wave w
	Variable i
	Variable b = EDG_PeakBase(i)
	if(w[b+3] != 0)
		return NaN
	endif
	Variable m = w[b+5]
	return w[b]*w[b+2]*(m*w[b+4]*sqrt(pi/ln(2)) + (1-m)*pi)
End

// Standard error on that area from the full covariance matrix
// (gedgfit peak_area_error). covar is FuncFit's M_Covar; sig is W_sigma.
// M_Covar is rescaled so its diagonal matches W_sigma^2, which makes the
// result follow the same error convention Igor used for W_sigma.
Function EDG_PeakAreaError(w, i, covar, sig, hold)
	Wave w, covar, sig
	Variable i
	String hold
	Variable b = EDG_PeakBase(i), n = numpnts(w)
	if(w[b+3] != 0 || DimSize(covar,0) != n || DimSize(covar,1) != n)
		return NaN
	endif
	Variable k, scale = NaN
	for(k=0; k<n; k+=1)
		if(cmpstr(hold[k], "1") != 0 && covar[k][k] > 0 && numtype(sig[k]) == 0)
			scale = sig[k]^2/covar[k][k]
			break
		endif
	endfor
	if(numtype(scale) != 0)
		return NaN
	endif
	Variable A = w[b], Wd = w[b+2], lw = w[b+4], m = w[b+5]
	Variable kk = sqrt(pi/ln(2))
	Variable brk = m*lw*kk + (1-m)*pi
	Make/FREE/D/N=4 idx, g
	idx[0] = b;			g[0] = Wd*brk				// amplitude
	idx[1] = b+2;		g[1] = A*brk				// width
	idx[2] = b+4;		g[2] = A*Wd*m*kk			// L/W ratio
	idx[3] = b+5;		g[3] = A*Wd*(lw*kk - pi)		// Gaussian fraction
	Variable ri, ci, var = 0
	for(ri=0; ri<4; ri+=1)
		if(cmpstr(hold[idx[ri]], "1") == 0)
			g[ri] = 0
		endif
	endfor
	for(ri=0; ri<4; ri+=1)
		for(ci=0; ci<4; ci+=1)
			var += g[ri]*covar[idx[ri]][idx[ci]]*g[ci]
		endfor
	endfor
	var *= scale
	return (var > 0) ? sqrt(var) : 0
End


// ===========================================================================
//  Derivatives and starting guesses (gedgfit Tools > Derivative viewer,
//  "Guess positions" and the amplitude estimate)
// ===========================================================================

// Igor's "Smooth n": n passes of [1 2 1]/4, end points repeated each pass
Function EDG_BinomialSmooth(w, passes)
	Wave w
	Variable passes
	Variable n = numpnts(w), k
	if(n < 2)
		return 0
	endif
	Duplicate/FREE w, src
	for(k=0; k<passes; k+=1)
		src = w
		if(n >= 3)
			w[1, n-2] = 0.25*src[p-1] + 0.5*src[p] + 0.25*src[p+1]
		endif
		w[0] = 0.75*src[0] + 0.25*src[1]
		w[n-1] = 0.25*src[n-2] + 0.75*src[n-1]
	endfor
End

// dy/dx exactly as numpy.gradient(y, x): second-order non-uniform central
// differences inside, one-sided first differences at the ends
Function EDG_Gradient(yw, xw, out)
	Wave yw, xw, out
	Variable n = numpnts(yw)
	Redimension/D/N=(n) out
	if(n < 2)
		out = NaN
		return 0
	endif
	Duplicate/FREE yw, f
	Duplicate/FREE xw, xs
	if(n >= 3)
		out[1, n-2] = ((xs[p]-xs[p-1])^2*f[p+1] + ((xs[p+1]-xs[p])^2 - (xs[p]-xs[p-1])^2)*f[p] - (xs[p+1]-xs[p])^2*f[p-1]) / ((xs[p]-xs[p-1])*(xs[p+1]-xs[p])*((xs[p+1]-xs[p]) + (xs[p]-xs[p-1])))
	endif
	out[0] = (f[1]-f[0])/(xs[1]-xs[0])
	out[n-1] = (f[n-1]-f[n-2])/(xs[n-1]-xs[n-2])
End

// gedgfit derivatives(): smoothed spectrum, smoothed 1st and 2nd derivatives
Function EDG_Derivatives(xw, yw, passes, ys, d1s, d2s)
	Wave xw, yw, ys, d1s, d2s
	Variable passes
	Redimension/D/N=(numpnts(yw)) ys
	ys = yw[p]
	EDG_BinomialSmooth(ys, passes)
	EDG_Gradient(ys, xw, d1s)
	EDG_BinomialSmooth(d1s, passes)
	EDG_Gradient(d1s, xw, d2s)
	EDG_BinomialSmooth(d2s, passes)
End

// gedgfit suggest_peaks(): up to n positions at the deepest 2nd-derivative
// minima, at least (xmax-xmin)/60 apart, returned sorted by energy
Function EDG_SuggestPeaks(xw, yw, n, passes, posOut)
	Wave xw, yw, posOut
	Variable n, passes
	Make/FREE/D ys, d1, d2
	EDG_Derivatives(xw, yw, passes, ys, d1, d2)
	Variable np = numpnts(xw), i, j, ok
	Make/FREE/D/N=0 cv, cx
	for(i=1; i<np-1; i+=1)
		if(d2[i] < d2[i-1] && d2[i] <= d2[i+1] && d2[i] < 0)
			InsertPoints numpnts(cv), 1, cv, cx
			cv[numpnts(cv)-1] = d2[i]
			cx[numpnts(cx)-1] = xw[i]
		endif
	endfor
	Redimension/D/N=0 posOut
	if(numpnts(cv) == 0)
		return 0
	endif
	Sort {cv, cx}, cv, cx
	Variable minSep = max((WaveMax(xw) - WaveMin(xw))/60, 1e-6)
	for(i=0; i<numpnts(cv); i+=1)
		ok = 1
		for(j=0; j<numpnts(posOut); j+=1)
			if(abs(cx[i] - posOut[j]) < minSep)
				ok = 0
				break
			endif
		endfor
		if(ok)
			InsertPoints numpnts(posOut), 1, posOut
			posOut[numpnts(posOut)-1] = cx[i]
		endif
		if(numpnts(posOut) >= n)
			break
		endif
	endfor
	Sort posOut, posOut
	return numpnts(posOut)
End

// gedgfit auto_amplitudes(): peel intensity off the data above the step
Function EDG_AutoAmplitudes(w, xw, yw, n)
	Wave w, xw, yw
	Variable n
	Duplicate/FREE yw, resid
	Redimension/D resid
	resid = yw[p] - EDG_StepComp(w, xw[p])
	Variable i, j, a, b
	Make/FREE/D/N=(numpnts(xw)) dist
	for(i=0; i<n; i+=1)
		b = EDG_PeakBase(i)
		dist = abs(xw[p] - w[b+1])
		WaveStats/Q/M=1 dist
		j = V_minloc
		a = max(resid[j], 0)
		w[b] = a
		resid -= EDG_PeakComp(w, xw[p], i)
	endfor
	for(i=0; i<n; i+=1)			// gedgfit shows (and keeps) 4 significant figures
		w[EDG_PeakBase(i)] = EDG_Round(w[EDG_PeakBase(i)], 4)
	endfor
End

// Round to 'sig' significant figures, as gedgfit's f"{v:.4g}" widgets do
Function EDG_Round(v, sigfig)
	Variable v, sigfig
	String txt
	String fmt = "%." + num2istr(sigfig) + "g"
	sprintf txt, fmt, v
	return str2num(txt)
End


// ===========================================================================
//  GUI-style parameter tables and synchronisation
// ===========================================================================

Function/S EDG_Name(base, suffix)
	String base, suffix
	return base + "_" + suffix
End

// Make sure <base>_P exists in the new 76-point layout, converting old waves
Function EDG_EnsureP(base)
	String base
	Wave/Z pw = $(EDG_Name(base, "P"))
	if(!WaveExists(pw))
		Make/O/D/N=(kEDG_WaveLen) $(EDG_Name(base, "P"))
		Wave pw = $(EDG_Name(base, "P"))
		EDG_DefaultParams(pw)
		return 0
	endif
	Variable n = numpnts(pw)
	String bak = EDG_Name(base, "P_old" + num2istr(n))
	Duplicate/FREE pw, before
	String what = EDG_ToCurrentLayout(pw, 1)
	if(strlen(what))
		Duplicate/O before, $bak
		Printf "%s was in the %s. Saved a copy as %s and converted it (p[1] = step amplitude, peaks from p[4]).\r", NameOfWave(pw), what, bak
	endif
End

// Create the step and peak tables if needed, then fill their VALUE columns
// from <base>_P (hold columns are left alone)
Function EDG_TablesFromP(base)
	String base
	Wave pw = $(EDG_Name(base, "P"))
	Variable i, k
	Wave/Z st = $(EDG_Name(base, "Step"))
	if(!WaveExists(st) || DimSize(st,0) != 4 || DimSize(st,1) != 2)
		Make/O/D/N=(4,2) $(EDG_Name(base, "Step"))
		Wave st = $(EDG_Name(base, "Step"))
		st[][1] = 0
		st[1][1] = 1				// step amplitude held, as in gedgfit
		for(i=0; i<4; i+=1)
			SetDimLabel 0, i, $StringFromList(i, ksEDG_StepRows), st
		endfor
		SetDimLabel 1, 0, value, st
		SetDimLabel 1, 1, hold, st
	endif
	if(cmpstr(GetDimLabel(st, 0, 1), "Step_amplitude") != 0)
		// step table from the previous version (rows: frac, position,
		// half-width, amplitude) - move the hold flags to the new row order
		Make/FREE/D/N=4 oh
		oh = st[p][1]
		st[0][1] = oh[0]
		st[1][1] = oh[3]
		st[2][1] = oh[1]
		st[3][1] = oh[2]
		for(i=0; i<4; i+=1)
			SetDimLabel 0, i, $StringFromList(i, ksEDG_StepRows), st
		endfor
	endif
	Wave/Z pk = $(EDG_Name(base, "Peaks"))
	if(!WaveExists(pk) || DimSize(pk,0) != kEDG_MaxPeaks || DimSize(pk,1) != 2*kEDG_PerPeak)
		Make/O/D/N=(kEDG_MaxPeaks, 2*kEDG_PerPeak) $(EDG_Name(base, "Peaks"))
		Wave pk = $(EDG_Name(base, "Peaks"))
		pk = 0
		pk[][2*3+1] = 1				// skew held
		pk[][2*4+1] = 1				// L/W ratio held
		pk[][2*5+1] = 1				// Gaussian fraction held
		for(i=0; i<kEDG_MaxPeaks; i+=1)
			SetDimLabel 0, i, $("Peak" + num2istr(i+1)), pk
		endfor
		for(k=0; k<kEDG_PerPeak; k+=1)
			SetDimLabel 1, 2*k, $StringFromList(k, ksEDG_PeakFields), pk
			SetDimLabel 1, 2*k+1, $StringFromList(k, ksEDG_PeakHolds), pk
		endfor
	endif
	for(i=0; i<kEDG_NGlobal; i+=1)
		st[i][0] = pw[i]
	endfor
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			pk[i][2*k] = pw[EDG_PeakBase(i)+k]
		endfor
	endfor
End

// Parameter vector described by the tables
Function EDG_VectorFromTables(base, out)
	String base
	Wave out
	Wave st = $(EDG_Name(base, "Step"))
	Wave pk = $(EDG_Name(base, "Peaks"))
	Redimension/D/N=(kEDG_WaveLen) out
	Variable i, k
	for(i=0; i<kEDG_NGlobal; i+=1)
		out[i] = st[i][0]
	endfor
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			out[EDG_PeakBase(i)+k] = pk[i][2*k]
		endfor
	endfor
End

// Bring <base>_P and the tables into agreement.
//  * _P changed since the last sync (a fit, the Curve Fitting dialog, OldP,
//    an import)  -> copied into the tables
//  * only the tables changed (you typed in them) -> copied into _P
Function EDG_Sync(base)
	String base
	EDG_EnsureP(base)
	Wave pw = $(EDG_Name(base, "P"))
	Wave/Z st = $(EDG_Name(base, "Step"))
	Wave/Z pk = $(EDG_Name(base, "Peaks"))
	Wave/Z ps = $(EDG_Name(base, "P_sync"))
	if(!WaveExists(st) || !WaveExists(pk) || !WaveExists(ps))
		EDG_TablesFromP(base)
	else
		Make/FREE/D tv
		EDG_VectorFromTables(base, tv)
		Variable pChanged = !EqualWaves(pw, ps, 1)
		Variable tChanged = !EqualWaves(tv, ps, 1)
		if(pChanged)
			if(tChanged)
				Print "EDG_Sync: both the parameter tables and " + NameOfWave(pw) + " were edited; keeping " + NameOfWave(pw) + "."
			endif
			EDG_TablesFromP(base)
		elseif(tChanged)
			pw = tv[p]
		endif
	endif
	Duplicate/O pw, $(EDG_Name(base, "P_sync"))
End

// FuncFit hold string from the hold columns. Every parameter of a peak
// beyond nPeaks is held, as gedgfit does.
Function/S EDG_HoldString(base, nPeaks)
	String base
	Variable nPeaks
	Wave st = $(EDG_Name(base, "Step"))
	Wave pk = $(EDG_Name(base, "Peaks"))
	Wave pw = $(EDG_Name(base, "P"))
	String hs = ""
	Variable k, i, f, h
	for(k=0; k<numpnts(pw); k+=1)
		if(k < kEDG_NGlobal)
			h = st[k][1]
		else
			i = floor((k - kEDG_NGlobal)/kEDG_PerPeak)
			f = mod(k - kEDG_NGlobal, kEDG_PerPeak)
			h = (i >= nPeaks) ? 1 : pk[i][2*f+1]
		endif
		hs += SelectString(h != 0, "0", "1")
	endfor
	return hs
End

Function EDG_ShowParamTable(base)
	String base
	String win = base + "_Params"
	if(WinType(win) == 2)
		DoWindow/F $win
		return 0
	endif
	Wave st = $(EDG_Name(base, "Step"))
	Wave pk = $(EDG_Name(base, "Peaks"))
	Edit/K=1/N=$win st.ld, pk.ld as base + " parameters (hold: 1 = held)"
	ModifyTable format=3, digits=6
End

// gedgfit's fit_slice: points within [xmin,xmax]; NaN = open end. Falls back
// to every point if fewer than 5 remain.
Function EDG_RangeMask(xw, xmin, xmax, mask)
	Wave xw, mask
	Variable xmin, xmax
	Variable lo = (numtype(xmin) == 0) ? xmin : -inf
	Variable hi = (numtype(xmax) == 0) ? xmax : inf
	if(hi < lo)
		Variable tmp = lo
		lo = hi
		hi = tmp
	endif
	Redimension/D/N=(numpnts(xw)) mask
	mask = (xw[p] >= lo && xw[p] <= hi) ? 1 : 0
	if(sum(mask) < 5)
		mask = 1
	endif
End

// gedgfit make_weights("poisson") expressed as standard deviations
Function EDG_PoissonSigma(yw, mask, sig)
	Wave yw, mask, sig
	Duplicate/FREE yw, mag
	mag = abs(yw[p])
	Extract/FREE mag, mm, mask[p] != 0
	Variable fl = max((WaveMax(mm) - WaveMin(mm))*1e-3, 1e-12)
	Redimension/D/N=(numpnts(yw)) sig
	sig = sqrt(max(mag[p], fl))
End

// Constraint wave reproducing gedgfit's build_bounds (only free parameters)
Function EDG_MakeConstraints(base, nPeaks, xw, mask, hold)
	String base, hold
	Variable nPeaks
	Wave xw, mask
	Wave pw = $(EDG_Name(base, "P"))
	Make/O/T/N=0 $(EDG_Name(base, "Constraints"))
	Wave/T C = $(EDG_Name(base, "Constraints"))
	Extract/FREE xw, xs, mask[p] != 0
	Variable xlo = WaveMin(xs), xhi = WaveMax(xs)
	Variable i, b, lo, hi
	EDG_AddLimit(C, hold, 0, kEDG_MixMin, kEDG_MixMax)
	EDG_AddLimit(C, hold, 1, 0, inf)
	EDG_AddLimit(C, hold, 2, pw[2]-kEDG_StepPosTol, pw[2]+kEDG_StepPosTol)
	EDG_AddLimit(C, hold, 3, kEDG_WidthMin, kEDG_WidthMax)
	for(i=0; i<nPeaks; i+=1)
		b = EDG_PeakBase(i)
		EDG_AddLimit(C, hold, b, kEDG_AmpMin, kEDG_AmpMax)
		lo = pw[b+1] - kEDG_PosTol
		hi = pw[b+1] + kEDG_PosTol
		lo = max(lo, xlo)
		hi = max(hi, xlo + 1e-6)
		hi = min(hi, xhi)
		lo = min(lo, xhi - 1e-6)
		EDG_AddLimit(C, hold, b+1, lo, hi)
		EDG_AddLimit(C, hold, b+2, kEDG_WidthMin, kEDG_WidthMax)
		EDG_AddLimit(C, hold, b+3, kEDG_SkewMin, kEDG_SkewMax)
		EDG_AddLimit(C, hold, b+4, kEDG_LWRMin, kEDG_LWRMax)
		EDG_AddLimit(C, hold, b+5, kEDG_MixMin, kEDG_MixMax)
	endfor
	return numpnts(C)
End

static Function EDG_AddLimit(C, hold, k, lo, hi)
	Wave/T C
	String hold
	Variable k, lo, hi
	if(cmpstr(hold[k], "1") == 0)
		return 0
	endif
	String cline
	if(numtype(lo) == 0)
		sprintf cline, "K%d > %.17g", k, lo
		InsertPoints numpnts(C), 1, C
		C[numpnts(C)-1] = cline
	endif
	if(numtype(hi) == 0)
		sprintf cline, "K%d < %.17g", k, hi
		InsertPoints numpnts(C), 1, C
		C[numpnts(C)-1] = cline
	endif
End


// ===========================================================================
//  Fitting and reporting
// ===========================================================================

// Goodness of fit at the current parameters (gedgfit evaluate). Results go
// into the free wave 'stats': chi2, red_chi2, dof, R2, rms, n_points.
Function EDG_Evaluate(pw, xw, yw, mask, nPeaks, weighting, nFree, stats)
	Wave pw, xw, yw, mask, stats
	Variable nPeaks, nFree
	String weighting
	Extract/FREE xw, xs, mask[p] != 0
	Extract/FREE yw, ys, mask[p] != 0
	Variable n = numpnts(xs)
	Make/FREE/D/N=(n) fit, wt
	fit = EDG_Total(pw, xs[p], nPeaks)
	wt = 1
	if(cmpstr(weighting, "poisson") == 0)
		Make/FREE/D/N=(n) one = 1
		Make/FREE/D sg
		EDG_PoissonSigma(ys, one, sg)
		wt = 1/sg[p]
	endif
	Make/FREE/D/N=(n) r2w, r2u
	r2w = ((fit[p] - ys[p])*wt[p])^2
	r2u = (ys[p] - fit[p])^2
	Variable chi2 = sum(r2w)
	Variable dof = max(n - max(nFree, 0), 1)
	Variable mY = mean(ys)
	Make/FREE/D/N=(n) tot = (ys[p] - mY)^2
	Variable ssTot = sum(tot), ssRes = sum(r2u)
	Redimension/D/N=6 stats
	stats[0] = chi2
	stats[1] = chi2/dof
	stats[2] = dof
	stats[3] = (ssTot > 0) ? 1 - ssRes/ssTot : NaN
	stats[4] = sqrt(ssRes/n)
	stats[5] = n
	return chi2
End

// Run FuncFit with the hold columns, fit range and options. Returns V_FitError.
//   weighting : "none" (default, as gedgfit) or "poisson"
//   useLimits : 0 = unconstrained Levenberg-Marquardt, like gedgfit's default
//               1 = apply gedgfit's fit limits as constraints
//   tol       : V_FitTol (gedgfit's default chi-square tolerance is 1e-8;
//               Igor's own default is 1e-3)
Function EDG_DoFit(base, xw, yw, nPeaks, xmin, xmax, weighting, useLimits, tol)
	String base, weighting
	Wave xw, yw
	Variable nPeaks, xmin, xmax, useLimits, tol
	if(nPeaks < 1 || nPeaks > kEDG_MaxPeaks)
		Abort "Number of peaks must be 1 to 12."
	endif
	EDG_Sync(base)
	Wave pw = $(EDG_Name(base, "P"))
	String hold = EDG_HoldString(base, nPeaks)
	Variable k, nFree = 0
	for(k=0; k<strlen(hold); k+=1)
		nFree += (cmpstr(hold[k], "0") == 0)
	endfor
	Make/O/D/N=(numpnts(yw)) $(EDG_Name(base, "FitMask"))
	Wave mask = $(EDG_Name(base, "FitMask"))
	EDG_RangeMask(xw, xmin, xmax, mask)
	if(nFree == 0)
		Abort "Every parameter is held fixed - nothing to refine."
	endif
	if(nFree > sum(mask))
		Abort num2istr(nFree) + " free parameters but only " + num2istr(sum(mask)) + " data points in the fit range."
	endif

	String extra = ""
	if(cmpstr(weighting, "poisson") == 0)
		Make/O/D $(EDG_Name(base, "FitSigma"))
		Wave sg = $(EDG_Name(base, "FitSigma"))
		EDG_PoissonSigma(yw, mask, sg)
		extra += " /W=" + GetWavesDataFolder(sg, 2) + " /I=1"
		if(WaveMax(yw) < 50)
			Print "Note: Poisson weighting assumes raw counts; these data peak below 50. Weighting \"none\" is usually right for normalised spectra."
		endif
	endif
	if(useLimits)
		EDG_MakeConstraints(base, nPeaks, xw, mask, hold)
		Wave/T C = $(EDG_Name(base, "Constraints"))
		if(numpnts(C) > 0)
			extra += " /C=" + GetWavesDataFolder(C, 2)
		endif
	endif

	Make/FREE/D st0
	Variable chiStart = EDG_Evaluate(pw, xw, yw, mask, nPeaks, weighting, nFree, st0)

	Variable/G V_FitError = 0
	Variable/G V_FitTol = tol
	Variable/G V_FitMaxIters = 500
	Variable/G V_FitNumIters = 0
	String cmd
	sprintf cmd, "FuncFit/N/M=2/L=%d/H=\"%s\" edg_fit%d %s %s /X=%s /M=%s /D%s", kEDG_FitCurvePoints, hold, nPeaks, GetWavesDataFolder(pw,2), GetWavesDataFolder(yw,2), GetWavesDataFolder(xw,2), GetWavesDataFolder(mask,2), extra
	Execute cmd
	if(V_FitError != 0)
		Printf "Fit failed (V_FitError = %d). Parameters left as they were before the fit.\r", V_FitError
		return V_FitError
	endif

	Wave/Z W_sigma, M_Covar
	Make/O/D/N=(numpnts(pw)) $(EDG_Name(base, "Sigma"))
	Wave sig = $(EDG_Name(base, "Sigma"))
	sig = NaN
	if(WaveExists(W_sigma) && numpnts(W_sigma) == numpnts(pw))
		sig = W_sigma[p]
		for(k=0; k<numpnts(pw); k+=1)
			if(cmpstr(hold[k], "1") == 0)
				sig[k] = NaN				// gedgfit reports held parameters as NaN
			endif
		endfor
	endif
	EDG_LabelParams(sig)
	if(WaveExists(M_Covar))
		Duplicate/O M_Covar, $(EDG_Name(base, "Covar"))
	endif
	String/G $(EDG_Name(base, "LastHold"))
	SVAR lh = $(EDG_Name(base, "LastHold"))
	lh = hold

	EDG_Sync(base)		// fit result -> tables
	Printf "Fit converged after %d iterations.\r", V_FitNumIters
	EDG_Report(base, xw, yw, nPeaks, xmin, xmax, weighting, chiStart)
	return 0
End

// Print a gedgfit-style report of the current parameters
Function EDG_Report(base, xw, yw, nPeaks, xmin, xmax, weighting, chiStart)
	String base, weighting
	Wave xw, yw
	Variable nPeaks, xmin, xmax, chiStart
	EDG_Sync(base)
	Wave pw = $(EDG_Name(base, "P"))
	Wave/Z sig = $(EDG_Name(base, "Sigma"))
	Wave/Z cov = $(EDG_Name(base, "Covar"))
	SVAR/Z lastHold = $(EDG_Name(base, "LastHold"))
	String hold = EDG_HoldString(base, nPeaks)
	Variable k, nFree = 0
	for(k=0; k<strlen(hold); k+=1)
		nFree += (cmpstr(hold[k], "0") == 0)
	endfor
	Make/FREE/D/N=(numpnts(yw)) mask
	EDG_RangeMask(xw, xmin, xmax, mask)
	Make/FREE/D st
	EDG_Evaluate(pw, xw, yw, mask, nPeaks, weighting, nFree, st)

	Print "------------------------------------------------------------"
	Printf "%s   %d peaks   weighting: %s\r", base, nPeaks, weighting
	if(numtype(chiStart) == 0)
		Printf "chi-square  %.8g -> %.8g  (%.3g%% lower)\r", chiStart, st[0], 100*(chiStart - st[0])/max(chiStart, 1e-300)
	else
		Printf "chi-square  %.8g\r", st[0]
	endif
	Printf "red. chi2   %.8g   (dof %d)\rR^2         %.8g\rRMS resid   %.8g\rpoints      %d\r", st[1], st[2], st[3], st[4], st[5]
	Printf "%-33s %14s %14s\r", "parameter", "value", "error"
	Variable i, f, b, sv
	String nm, flag
	for(k=0; k<kEDG_NGlobal; k+=1)
		sv = EDG_SigAt(sig, k)
		flag = SelectString(cmpstr(hold[k], "1") == 0, "", "  (held)")
		Printf "p[%-2d] %-28s %14.6g %14.6g%s\r", k, EDG_Describe(k), pw[k], sv, flag
	endfor
	Variable pkArea, aerr
	for(i=0; i<nPeaks; i+=1)
		b = EDG_PeakBase(i)
		for(f=0; f<kEDG_PerPeak; f+=1)
			sv = EDG_SigAt(sig, b+f)
			flag = SelectString(cmpstr(hold[b+f], "1") == 0, "", "  (held)")
			Printf "p[%-2d] %-28s %14.6g %14.6g%s\r", b+f, EDG_Describe(b+f), pw[b+f], sv, flag
		endfor
		pkArea = EDG_PeakArea(pw, i)
		aerr = NaN
		if(WaveExists(cov) && WaveExists(sig) && SVAR_Exists(lastHold))
			aerr = EDG_PeakAreaError(pw, i, cov, sig, lastHold)
		endif
		Printf "      %-28s %14.6g %14.6g\r", "Peak " + num2istr(i+1) + " area", pkArea, aerr
	endfor
	if(!EDG_MixesLinked(pw))
		Print "Peaks use their own Gaussian fractions (gedgfit behaviour). EDG_LinkGauss() sets them all to the step's."
	endif
	Print "------------------------------------------------------------"
End

static Function EDG_SigAt(sig, k)
	Wave/Z sig
	Variable k
	if(!WaveExists(sig) || k >= numpnts(sig))
		return NaN
	endif
	return sig[k]
End

