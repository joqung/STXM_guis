"""
Core model / IO / fitting engine for soft X-ray XAS edge fitting.

Faithful port of the Igor Pro procedures in:
  * EDG_Fit12_SGM_modified.ipf   (the model: step edge + up to 12 pseudo-Voigt peaks)
  * Cp2VCl2_CK_Apr2012_8CF.ipf   (the workflow: setup, update, residuals, derivatives)

PARAMETER VECTOR  (identical indexing to the Igor `_P` wave, so parameter
waves round-trip between this code and Igor without renumbering):

    p[0]  mix          Gaussian fraction, shared by the step AND every peak
    p[1]  step position
    p[2]  step half-width
    then for peak i (i = 1..12), base = 3 + 5*(i-1):
    p[base+0]  amplitude
    p[base+1]  position
    p[base+2]  half-width
    p[base+3]  skew
    p[base+4]  lw ratio   (Gaussian width / Lorentzian width)

Full length = 3 + 5*12 = 63.

MODEL
    step(x)  = 1/2 + mix*(1/2)erf((x-p1)*sqrt(ln2)/p2) + (1-mix)*(1/pi)atan((x-p1)/p2)
    w_eff    = W + (x-E0)*skew                       (linear width skew)
    G(x)     = exp(-ln2*(x-E0)^2 / (w_eff*R)^2)
    L(x)     = w_eff^2 / (w_eff^2 + (x-E0)^2)
    peak(x)  = A*(mix*G + (1-mix)*L)
    total(x) = step_amp*step(x) + sum_i peak_i(x)

`step_amp` is an EXTENSION, not in the Igor code (Igor hard-wires the edge
jump to 1.0 because the data is normalised first). It is kept outside the
63-element vector so Igor compatibility is preserved. Leave it fixed at 1.0
to reproduce Igor exactly.
"""

from __future__ import annotations

import datetime
import json
import os
import re
import sys

import math

import numpy as np

# SciPy is not imported at module level. Importing scipy.optimize costs about
# 0.4 s, and nothing needs it until the user actually fits: the model, the
# plot, the file readers and the derivative tools are pure NumPy. It is
# imported inside fit_spectrum instead, so the window appears sooner and the
# cost lands where the user is already expecting the program to be busy.
#
# The error function is the one piece of scipy.special the model needs, and
# the standard library provides it. math.erf agrees with scipy.special.erf to
# one unit in the last place, and the vectorised wrapper costs 0.16 ms on a
# 2000-point spectrum, which is nothing beside a fit.
_erf_scalar = np.frompyfunc(math.erf, 1, 1)


def erf(z):
    """Vectorised error function, without pulling in SciPy."""
    return _erf_scalar(np.asarray(z, dtype=float)).astype(float)

LN2 = np.log(2.0)
TINY = 1e-12

MAX_PEAKS = 12
N_GLOBAL = 3

# Igor's original edg_fitN uses one Gaussian fraction, param[0], for the step
# AND every peak, so changing the edge shape changes all the line shapes with
# it. Here p[0] governs the step alone and each peak carries its own fraction,
# kept alongside that peak's other parameters:
#
#     p[0]           step Gaussian fraction   (0.5 = 1:1 arctan : erf)
#     p[1]           step position
#     p[2]           step half-width
#     p[3+6i+0..5]   peak i+1: amplitude, position, half-width, skew,
#                    L/W ratio, Gaussian fraction
#
PARAMS_PER_PEAK = 6
FULL_LEN = N_GLOBAL + PARAMS_PER_PEAK * MAX_PEAKS   # 75

# The original Igor wave: 5 parameters per peak and no per-peak fraction.
# Kept only for converting waves to and from that layout.
IGOR_PARAMS_PER_PEAK = 5
IGOR_LEN = N_GLOBAL + IGOR_PARAMS_PER_PEAK * MAX_PEAKS   # 63


def peak_mix_index(i):
    """Index of peak i's own Gaussian fraction (0-based peak number)."""
    return peak_base(i) + 5


def from_igor_layout(vec):
    """Build a 75-element vector from an original 63-element Igor wave.

    The peaks are re-spaced from five slots to six and every peak fraction is
    set to the wave's single param[0], which reproduces Igor exactly.
    """
    vec = np.asarray(vec, dtype=float)
    p = default_params()
    p[:N_GLOBAL] = vec[:N_GLOBAL]
    for i in range(MAX_PEAKS):
        s = N_GLOBAL + IGOR_PARAMS_PER_PEAK * i
        if s + IGOR_PARAMS_PER_PEAK > len(vec):
            break
        b = peak_base(i)
        p[b:b + IGOR_PARAMS_PER_PEAK] = vec[s:s + IGOR_PARAMS_PER_PEAK]
    return link_mixes(p)


def to_igor_layout(p):
    """Gather the 63 parameters the original edg_fitN reads."""
    p = np.asarray(p, dtype=float)
    out = np.zeros(IGOR_LEN)
    out[:N_GLOBAL] = p[:N_GLOBAL]
    for i in range(MAX_PEAKS):
        b = peak_base(i)
        s = N_GLOBAL + IGOR_PARAMS_PER_PEAK * i
        out[s:s + IGOR_PARAMS_PER_PEAK] = p[b:b + IGOR_PARAMS_PER_PEAK]
    return out


def from_appended_layout(vec):
    """Convert a 75-element vector written by the earlier appended layout,
    where the twelve fractions sat together at indices 63..74."""
    vec = np.asarray(vec, dtype=float)
    p = default_params()
    p[:N_GLOBAL] = vec[:N_GLOBAL]
    for i in range(MAX_PEAKS):
        s = N_GLOBAL + IGOR_PARAMS_PER_PEAK * i
        b = peak_base(i)
        p[b:b + IGOR_PARAMS_PER_PEAK] = vec[s:s + IGOR_PARAMS_PER_PEAK]
        p[peak_mix_index(i)] = vec[IGOR_LEN + i]
    return p

PEAK_FIELDS = ("amplitude", "position", "width", "skew", "lwratio", "gauss")
PEAK_LABELS = ("Amp", "Position", "Width", "Skew", "L/W ratio", "Gauss frac")

# A row of the peak table is exactly one peak's block of parameters.
PEAK_ROW_FIELDS = PEAK_FIELDS
PEAK_ROW_LABELS = PEAK_LABELS
GLOBAL_LABELS = ("Gauss frac (mix)", "Step position", "Step half-width")


def peak_base(i: int) -> int:
    """Index of the first parameter of peak `i` (0-based peak number)."""
    return N_GLOBAL + PARAMS_PER_PEAK * i


def peak_index(i: int, field: str) -> int:
    return peak_base(i) + PEAK_FIELDS.index(field)


def link_mixes(p, value=None):
    """Set every peak's Gaussian fraction to the step's (Igor behaviour)."""
    p = np.array(p, dtype=float)
    v = p[0] if value is None else float(value)
    for i in range(MAX_PEAKS):
        p[peak_mix_index(i)] = v
    return p


def mixes_linked(p, tol=1e-12):
    """True when the model is behaving the way Igor's single param[0] does."""
    p = np.asarray(p)
    return bool(all(abs(p[peak_mix_index(i)] - p[0]) <= tol
                    for i in range(MAX_PEAKS)))


# --------------------------------------------------------------------------
# Model components
# --------------------------------------------------------------------------

def _safe(a, eps=TINY):
    """Keep a denominator away from zero without changing its sign."""
    a = np.asarray(a, dtype=float)
    return np.where(np.abs(a) < eps, np.copysign(eps, np.where(a == 0.0, 1.0, a)), a)


def step_profile(x, mix, pos, width, amp=1.0):
    """Igor step_fit(): erf/arctan blend rising 0 -> 1 (times amp)."""
    x = np.asarray(x, dtype=float)
    w = float(_safe(np.array(width)))
    dx = x - pos
    e = 0.5 * erf(dx * np.sqrt(LN2) / w)
    a = np.arctan(dx / w) / np.pi
    return amp * (0.5 + mix * e + (1.0 - mix) * a)


def peak_profile(x, mix, amplitude, position, width, skew=0.0, lwratio=1.0):
    """Igor IgN/IlN blend: skewed pseudo-Voigt, amplitude-normalised to 1 at E0."""
    x = np.asarray(x, dtype=float)
    dx = x - position
    weff = _safe(width + dx * skew)
    r = float(_safe(np.array(lwratio)))
    g = np.exp(-LN2 * dx**2 / (weff * r) ** 2)
    l = weff**2 / (weff**2 + dx**2)
    return amplitude * (mix * g + (1.0 - mix) * l)


def component_step(x, p, step_amp=1.0):
    """Igor Plot_step()."""
    return step_profile(x, p[0], p[1], p[2], amp=step_amp)


def component_peak(x, p, i):
    """Igor Plot_waveN() for 0-based peak index i, with that peak's own
    Gaussian fraction."""
    b = peak_base(i)
    return peak_profile(x, p[b + 5], p[b], p[b + 1], p[b + 2], p[b + 3],
                        p[b + 4])


def model_total(x, p, n_peaks, step_amp=1.0):
    """Igor edg_fitN(): step plus the first `n_peaks` peaks."""
    y = component_step(x, p, step_amp)
    for i in range(n_peaks):
        y = y + component_peak(x, p, i)
    return y


def all_components(x, p, n_peaks, step_amp=1.0):
    """Return (step, [peak0..peakN-1], total)."""
    stp = component_step(x, p, step_amp)
    peaks = [component_peak(x, p, i) for i in range(n_peaks)]
    total = stp + (np.sum(peaks, axis=0) if peaks else 0.0)
    return stp, peaks, total


def isolated_peak_residual(x, y, p, n_peaks, i, step_amp=1.0):
    """
    Igor RSD_i = data - (everything except peak i).

    Plotted against peak i itself, this shows how well that single component
    accounts for the intensity left over by all the others.
    """
    stp, peaks, _ = all_components(x, p, n_peaks, step_amp)
    others = stp + sum(pk for j, pk in enumerate(peaks) if j != i)
    return y - others


def default_params() -> np.ndarray:
    """A 63-element vector with neutral defaults."""
    p = np.zeros(FULL_LEN, dtype=float)
    p[0] = 0.5      # step Gaussian fraction
    p[1] = 0.0      # step position
    p[2] = 0.5      # step half-width
    for i in range(MAX_PEAKS):
        b = peak_base(i)
        p[b + 0] = 0.0    # amplitude
        p[b + 1] = 0.0    # position
        p[b + 2] = 0.5    # half-width
        p[b + 3] = 0.0    # skew
        p[b + 4] = 1.0    # lw ratio
        p[b + 5] = 0.5    # this peak's Gaussian fraction
    return p


# --------------------------------------------------------------------------
# Bounds
# --------------------------------------------------------------------------

DEFAULT_LIMITS = {
    "amp_min": 0.0, "amp_max": 100.0,
    "width_min": 0.01, "width_max": 20.0,
    "skew_min": -0.5, "skew_max": 0.5,
    "lwr_min": 0.05, "lwr_max": 20.0,
    "pos_tol": 2.0,          # peak centres may move +/- this many eV from start
    "step_pos_tol": 5.0,
    "mix_min": 0.0, "mix_max": 1.0,
}


def build_bounds(p0, n_peaks, limits=None, xlo=None, xhi=None):
    """Lower/upper bound vectors of length FULL_LEN, matched to p0."""
    lim = dict(DEFAULT_LIMITS)
    if limits:
        lim.update(limits)
    lo = np.full(FULL_LEN, -np.inf)
    hi = np.full(FULL_LEN, np.inf)

    lo[0], hi[0] = lim["mix_min"], lim["mix_max"]
    lo[1] = p0[1] - lim["step_pos_tol"]
    hi[1] = p0[1] + lim["step_pos_tol"]
    lo[2], hi[2] = lim["width_min"], lim["width_max"]

    for i in range(MAX_PEAKS):
        b = peak_base(i)
        lo[b + 0], hi[b + 0] = lim["amp_min"], lim["amp_max"]
        lo[b + 1] = p0[b + 1] - lim["pos_tol"]
        hi[b + 1] = p0[b + 1] + lim["pos_tol"]
        if xlo is not None:
            lo[b + 1] = max(lo[b + 1], xlo)
            hi[b + 1] = max(hi[b + 1], xlo + 1e-6)
        if xhi is not None:
            hi[b + 1] = min(hi[b + 1], xhi)
            lo[b + 1] = min(lo[b + 1], xhi - 1e-6)
        lo[b + 2], hi[b + 2] = lim["width_min"], lim["width_max"]
        lo[b + 3], hi[b + 3] = lim["skew_min"], lim["skew_max"]
        lo[b + 4], hi[b + 4] = lim["lwr_min"], lim["lwr_max"]
        lo[b + 5], hi[b + 5] = lim["mix_min"], lim["mix_max"]

    # never let a start value sit outside its own box
    p0 = np.clip(p0, lo, hi)
    return lo, hi, p0


# --------------------------------------------------------------------------
# Fitting
# --------------------------------------------------------------------------

# --- optimisers -----------------------------------------------------------
#
# "lm"     MINPACK's Levenberg-Marquardt, the same algorithm Igor Pro's
#          FuncFit uses. Cannot honour bounds: SciPy rejects them outright,
#          exactly as Igor's FuncFit is unconstrained unless you hand it a
#          constraint wave. Held parameters still work, because holding is
#          done by removing a parameter from the free vector, not by pinning
#          it with bounds.
# "trf"    Trust Region Reflective. Honours bounds. Steadier on badly scaled
#          or strongly correlated problems, which is most multi-peak edges.
# "dogbox" Dogleg with a rectangular trust region. Honours bounds. Often
#          quicker than trf when few parameters are near their limits.

METHODS = ("lm", "trf", "dogbox")
METHOD_LABELS = {
    "lm": "Levenberg-Marquardt (as Igor, unbounded)",
    "trf": "Trust region reflective (bounded)",
    "dogbox": "Dogbox (bounded)",
}

# --- parameter error conventions -----------------------------------------
#
# Both start from the same covariance matrix, C = (J'J)^-1, evaluated on the
# weighted residuals. They differ in whether the noise level is inferred from
# the fit or taken from the weights you supplied:
#
# "scaled"    C is multiplied by the reduced chi-square, i.e. the scatter of
#             the residuals is taken as the measurement error. This is what
#             Igor reports for an unweighted fit, and what SciPy's curve_fit
#             does with absolute_sigma=False. It assumes the model is correct;
#             a systematically poor fit inflates the errors rather than
#             revealing itself.
# "unscaled"  C is used as is, so the weights are trusted as genuine 1/sigma.
#             This is the convention for a fit weighted by real uncertainties,
#             as Igor does when given a weighting wave. With weighting set to
#             "none" the weights are all 1, so these errors are only
#             meaningful if your intensities really do have unit variance.

# --- convergence tolerance -------------------------------------------------
#
# Where the optimiser stops, which on a shallow multi-peak surface matters more
# than which optimiser you chose. Igor's FuncFit defaults to V_FitTol = 1e-3;
# SciPy defaults to 1e-8. The two convergence tests are not the same quantity,
# so 1e-3 here does not reproduce Igor's stopping point exactly, but it puts
# the two programs in the same regime instead of an order of magnitude apart.
#
# This value is applied to ftol ONLY, the relative reduction in chi-square,
# because that is the quantity Igor's V_FitTol governs. It must not be applied
# to xtol, SciPy's *relative* change in the parameters themselves. Peak
# positions are around 285 eV, so a perfectly ordinary 0.2 eV shift is a
# relative change of 7e-4 - below an xtol of 1e-3. The optimiser would declare
# success and return the starting parameters untouched, and the fit would look
# like it had done nothing at all.

TOLERANCES = {
    "1e-3  (Igor V_FitTol, loose)": 1e-3,
    "1e-6": 1e-6,
    "1e-8  (SciPy default)": 1e-8,
    "1e-12 (tightest)": 1e-12,
}

# Step and gradient tolerances, kept tight regardless of the chi-square
# tolerance for the reason above.
STEP_TOL = 1e-10
DEFAULT_TOL = 1e-8

ERROR_MODELS = ("scaled", "unscaled")
ERROR_LABELS = {
    "scaled": "Residual scatter (Igor default, unweighted)",
    "unscaled": "Trust the weights (Igor with a weight wave)",
}


def covariance_from_jacobian(J, red_chi2, error_model="scaled"):
    """
    (J'J)^-1 via SVD, which stays usable when parameters are strongly
    correlated and the normal-equations matrix is close to singular.
    Returns None if the Jacobian is rank deficient beyond recovery.
    """
    J = np.asarray(J, dtype=float)
    try:
        _, s, VT = np.linalg.svd(J, full_matrices=False)
    except np.linalg.LinAlgError:
        return None
    if s.size == 0 or not np.all(np.isfinite(s)):
        return None
    tol = np.finfo(float).eps * max(J.shape) * s[0]
    keep = s > tol
    if not np.any(keep):
        return None
    s = s[keep]
    VT = VT[keep]
    cov = (VT.T / s**2) @ VT
    if error_model == "scaled":
        cov = cov * red_chi2
    return cov


def _describe_index(i):
    """Human-readable name for a full-vector parameter index."""
    if i == 0:
        return "step Gauss fraction"
    if i == 1:
        return "step position"
    if i == 2:
        return "step half-width"
    return f"peak {(i - N_GLOBAL) // PARAMS_PER_PEAK + 1} " \
           f"{PEAK_LABELS[(i - N_GLOBAL) % PARAMS_PER_PEAK]}"


class FitResult:
    def __init__(self, p, errors, chi2, red_chi2, r2, nfev, message, success, free_idx):
        self.p = p
        self.errors = errors          # length FULL_LEN, nan for fixed params
        self.chi2 = chi2
        self.red_chi2 = red_chi2
        self.r2 = r2
        self.nfev = nfev
        self.message = message
        self.success = success
        self.free_idx = free_idx
        self.method = "trf"
        self.error_model = "scaled"
        self.bounds_applied = True
        self.notes = []


def make_weights(y, mode="none", sigma=None):
    """
    Weights applied to the residuals, i.e. 1/sigma.

    Poisson mode assumes the noise on a point scales as the square root of its
    value, which holds for raw photon counts. The variance is floored at a
    thousandth of the data's range: without that, a point that happens to come
    out at zero gets a weight of 1/sqrt(0) and a handful of such pixels hijack
    the whole fit. This matters in practice, because a weak pre-edge really can
    record zero counts.
    """
    y = np.asarray(y, dtype=float)
    if mode == "poisson":
        mag = np.abs(y)
        span = float(np.max(mag) - np.min(mag))
        floor = max(span * 1e-3, 1e-12)
        s = np.sqrt(np.maximum(mag, floor))
        return 1.0 / s
    if mode == "sigma" and sigma is not None:
        s = np.clip(np.asarray(sigma, dtype=float), 1e-12, None)
        return 1.0 / s
    return np.ones_like(y)


def fit_spectrum(x, y, p0, n_peaks, fixed_mask, step_amp=1.0, fit_step_amp=False,
                 limits=None, weight_mode="none", sigma=None, max_nfev=20000,
                 method="trf", error_model="scaled", tol=DEFAULT_TOL):
    """
    Least-squares refinement of the free parameters.

    fixed_mask  : boolean array, length FULL_LEN. True = hold that parameter.
                  Parameters belonging to unused peaks are ignored automatically.
    method      : one of METHODS. "lm" reproduces Igor's algorithm but cannot
                  take bounds, so the limits are dropped and that is recorded
                  in result.notes.
    error_model : one of ERROR_MODELS. See the notes above the constant.
    tol         : relative chi-square reduction below which the fit stops
                  (SciPy's ftol). The step and gradient tolerances are held
                  tight independently - see the note above TOLERANCES.
    """
    if method not in METHODS:
        raise ValueError(f"method must be one of {METHODS}, got {method!r}")
    if error_model not in ERROR_MODELS:
        raise ValueError(f"error_model must be one of {ERROR_MODELS}")

    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    p0 = np.array(p0, dtype=float).copy()
    fixed_mask = np.asarray(fixed_mask, dtype=bool).copy()

    # freeze everything past the active peak count
    fixed_mask[peak_base(n_peaks):] = True

    lo, hi, _clipped = build_bounds(p0, n_peaks, limits,
                                    float(np.min(x)), float(np.max(x)))
    free_idx = np.where(~fixed_mask)[0]

    # Only pull the starting values inside the limits when the limits are
    # actually going to be enforced, and then only for the parameters being
    # refined. Levenberg-Marquardt runs unconstrained, so clipping its start
    # would silently fit from somewhere other than the values on screen; and a
    # held parameter is a statement of fact, not a starting guess, so it must
    # never be moved either.
    if method != "lm" and len(free_idx):
        p0[free_idx] = np.clip(p0[free_idx], lo[free_idx], hi[free_idx])

    extra_amp = bool(fit_step_amp)
    n_free = len(free_idx) + (1 if extra_amp else 0)
    if n_free == 0:
        raise ValueError("Every parameter is held fixed - nothing to refine.")
    if n_free > len(x):
        raise ValueError(f"{n_free} free parameters but only {len(x)} data points "
                         "in the fit range.")

    # imported here rather than at module level: see the note at the top
    from scipy.optimize import least_squares

    notes = []
    w = make_weights(y, weight_mode, sigma)
    if weight_mode == "poisson" and float(np.max(np.abs(y))) < 50.0:
        notes.append("Poisson weighting assumes the values are raw counts, but "
                     "these peak near "
                     f"{float(np.max(np.abs(y))):.3g}. Normalised data has had "
                     "its counting statistics scaled away, so 1/sqrt(y) is no "
                     "longer the true 1/sigma. Weighting 'none' is usually the "
                     "right choice for edge-jump normalised spectra.")
    if error_model == "unscaled" and weight_mode == "none":
        notes.append("Unscaled errors with no weighting assume the intensities "
                     "have unit variance. Set a weighting first, or the errors "
                     "are not meaningful.")

    def unpack(v):
        p = p0.copy()
        p[free_idx] = v[: len(free_idx)]
        amp = v[-1] if extra_amp else step_amp
        return p, amp

    def resid(v):
        p, amp = unpack(v)
        return (model_total(x, p, n_peaks, amp) - y) * w

    v0 = np.array(list(p0[free_idx]) + ([step_amp] if extra_amp else []), dtype=float)

    if method == "lm":
        # MINPACK will not accept bounds, so this runs unconstrained.
        notes.append("Levenberg-Marquardt is unconstrained: the fit limits were "
                     "not applied. Held parameters were still held.")
        res = least_squares(resid, v0, method="lm", max_nfev=max_nfev,
                            ftol=tol, xtol=min(tol, STEP_TOL),
                            gtol=min(tol, STEP_TOL), x_scale="jac")
        bounds_applied = False
    else:
        vlo = np.array(list(lo[free_idx]) + ([0.0] if extra_amp else []), dtype=float)
        vhi = np.array(list(hi[free_idx]) + ([np.inf] if extra_amp else []), dtype=float)
        res = least_squares(resid, v0, bounds=(vlo, vhi), method=method,
                            max_nfev=max_nfev, ftol=tol,
                            xtol=min(tol, STEP_TOL), gtol=min(tol, STEP_TOL),
                            x_scale="jac")
        bounds_applied = True

    p_fit, amp_fit = unpack(res.x)

    # --- did anything actually change? -------------------------------------
    #
    # Measured on the model curve, not on the parameters. A relative parameter
    # change is meaningless here: the vector mixes positions near 285 with a
    # skew that starts at exactly 0, so dividing by the starting value gives
    # either a vanishing number or an enormous one. What the user actually
    # sees is whether the drawn curve moved, so that is what is reported:
    # the largest shift of the model, as a fraction of the data's range.
    start_curve = model_total(x, p0, n_peaks, step_amp)
    chi2_start = float(np.sum(((start_curve - y) * w) ** 2))
    span = float(np.max(y) - np.min(y))
    if span <= 0:
        span = max(float(np.max(np.abs(y))), 1e-12)

    # --- goodness of fit ---------------------------------------------------
    dof = max(len(x) - n_free, 1)
    chi2 = float(2.0 * res.cost)          # sum of weighted squared residuals
    red = chi2 / dof

    # --- parameter standard errors ----------------------------------------
    errors = np.full(FULL_LEN, np.nan)
    amp_err = np.nan
    cov = covariance_from_jacobian(res.jac, red, error_model)
    if cov is None:
        notes.append("The Jacobian is rank deficient, so no parameter errors "
                     "could be computed. Two components are probably "
                     "indistinguishable - hold one, or use fewer peaks.")
        out_cov = None
    else:
        out_cov = cov
        var = np.diag(cov)
        if np.any(var < 0):
            notes.append("Negative variance on at least one parameter: the fit "
                         "is at a badly conditioned point and its errors are "
                         "not trustworthy.")
        sd = np.sqrt(np.clip(var, 0, None))
        errors[free_idx] = sd[: len(free_idx)]
        if extra_amp:
            amp_err = float(sd[-1])

    # Near-degeneracy: two parameters that the data cannot tell apart. The
    # classic case here is freeing both the width and the L/W ratio while the
    # Gaussian fraction is 1, where only their product is defined. The fit
    # still converges and still reports errors - absurd ones - so it is worth
    # saying so plainly rather than leaving it to be noticed.
    try:
        sv = np.linalg.svd(res.jac, compute_uv=False)
        cond = float(sv[0] / sv[-1]) if sv[-1] > 0 else np.inf
    except np.linalg.LinAlgError:
        cond = np.inf
    if cond > 1e7:
        worst = []
        for k, idx in enumerate(free_idx):
            e = errors[idx]
            v = abs(p_fit[idx])
            if np.isfinite(e) and e > 100 * max(v, 1e-12):
                worst.append(int(idx))
        detail = ""
        if worst:
            detail = (" Worst affected: " +
                      ", ".join(_describe_index(j) for j in worst[:4]) + ".")
        notes.append("The parameters are very nearly degenerate (Jacobian "
                     f"condition number {cond:.1e}): some combination of them "
                     "is not determined by the data, and the errors on those "
                     "are meaningless." + detail +
                     " Hold one of each redundant pair. Note that with a "
                     "Gaussian fraction of 1 the width and the L/W ratio are "
                     "exactly redundant, since only their product matters.")

    if bounds_applied:
        at_limit = []
        for k, idx in enumerate(free_idx):
            if np.isclose(p_fit[idx], lo[idx], rtol=1e-6, atol=1e-9) or \
               np.isclose(p_fit[idx], hi[idx], rtol=1e-6, atol=1e-9):
                at_limit.append(int(idx))
        if at_limit:
            notes.append(f"{len(at_limit)} parameter(s) came to rest on a fit "
                         "limit. Their errors are meaningless there - widen the "
                         "limits or reconsider the model.")

    fitted = model_total(x, p_fit, n_peaks, amp_fit)
    moved = float(np.max(np.abs(fitted - start_curve))) / span
    ss_res = float(np.sum((y - fitted) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan

    gain = (chi2_start - chi2) / chi2_start if chi2_start > 0 else 0.0
    if moved < 1e-5:
        notes.append("Nothing changed: the parameters were already at a local "
                     "minimum for this configuration, so there was no downhill "
                     "direction to take. That is a converged fit, not a "
                     "failure. To move it, change a starting value, free a "
                     "held parameter, or add a peak.")
    elif gain < 1e-4 and res.nfev <= 3:
        notes.append(f"The fit stopped after {res.nfev} evaluations having "
                     f"improved chi-square by only {100 * gain:.4f} per cent. "
                     "That is the tolerance halting it almost immediately - "
                     "tighten 'Stop at' and run it again.")


    out = FitResult(p_fit, errors, chi2, red, r2, res.nfev, res.message,
                    res.success, free_idx)
    out.step_amp = amp_fit
    out.step_amp_err = amp_err
    out.method = method
    out.error_model = error_model
    out.bounds_applied = bounds_applied
    out.dof = dof
    out.n_free = n_free
    out.notes = notes
    out.tol = tol
    out.cov = out_cov          # covariance of the free parameters, in free_idx order
    out.chi2_start = chi2_start
    out.gain = gain
    out.moved = moved
    return out


def evaluate(x, y, p, n_peaks, step_amp=1.0, weight_mode="none", sigma=None,
             n_free=0):
    """
    Goodness of fit at the parameters as they stand, with no refinement.

    This is the cheapest way to check this program against Igor: feed both the
    same parameters and the same data, and compare chi-square. If they agree,
    the model and the objective function are confirmed identical on your real
    data, and any later disagreement is down to the optimiser rather than the
    mathematics.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    w = make_weights(y, weight_mode, sigma)
    fit = model_total(x, p, n_peaks, step_amp)
    r = (fit - y) * w
    chi2 = float(np.sum(r ** 2))
    dof = max(len(x) - max(n_free, 0), 1)
    ss_res = float(np.sum((y - fit) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    return {
        "chi2": chi2,
        "red_chi2": chi2 / dof,
        "dof": dof,
        "r2": 1.0 - ss_res / ss_tot if ss_tot > 0 else float("nan"),
        "rms": float(np.sqrt(np.mean((fit - y) ** 2))),
        "n_points": int(len(x)),
    }


GAUSS_AREA_K = np.sqrt(np.pi / LN2)      # 2.128934039...


def peak_area(p, i):
    """
    Analytic area of peak i.

        Area = A * W * [ m*R*sqrt(pi/ln2) + (1-m)*pi ]

    The Gaussian half-width is W*R and the Lorentzian half-width is W, which
    is why R multiplies only the first term. Valid for skew = 0; with a skew
    the width varies across the peak and there is no closed form, so NaN is
    returned and you should integrate numerically instead.
    """
    b = peak_base(i)
    A, W, S, R = p[b], p[b + 2], p[b + 3], p[b + 4]
    if S != 0:
        return float("nan")
    m = p[b + 5]
    return float(A * W * (m * R * GAUSS_AREA_K + (1.0 - m) * np.pi))


def peak_area_error(result, i):
    """
    Standard error on the area of peak i, propagated from the full covariance
    matrix of the fit.

    Doing this from the individual parameter errors alone would be wrong:
    amplitude and width are strongly anticorrelated in a peak fit, because a
    taller peak can be made narrower with little change to the area. Ignoring
    that correlation typically overstates the uncertainty by a large factor.

    Returns NaN if the fit produced no usable covariance, or if the peak is
    skewed, where the area has no closed form.
    """
    cov = getattr(result, "cov", None)
    if cov is None:
        return float("nan")
    p = result.p
    b = peak_base(i)
    A, W, S, R = p[b], p[b + 2], p[b + 3], p[b + 4]
    if S != 0:
        return float("nan")
    mi = peak_mix_index(i)
    m = p[mi]
    bracket = m * R * GAUSS_AREA_K + (1.0 - m) * np.pi

    # d(Area)/d(parameter), for the four parameters the area depends on
    grads = {
        b + 0: W * bracket,                       # amplitude
        b + 2: A * bracket,                       # width
        b + 4: A * W * m * GAUSS_AREA_K,          # L/W ratio
        mi:    A * W * (R * GAUSS_AREA_K - np.pi),  # this peak's fraction
    }
    idx = list(result.free_idx)
    g = np.zeros(len(idx))
    for full_i, val in grads.items():
        if full_i in idx:
            g[idx.index(full_i)] = val
    var = float(g @ cov @ g)
    return float(np.sqrt(var)) if var > 0 else 0.0


# --------------------------------------------------------------------------
# Derivatives (Igor derivPlot equivalent)
# --------------------------------------------------------------------------

def binomial_smooth(y, n):
    """Igor's `Smooth n, wave`: n successive [1 2 1]/4 passes."""
    y = np.asarray(y, dtype=float).copy()
    k = np.array([0.25, 0.5, 0.25])
    for _ in range(int(n)):
        pad = np.concatenate(([y[0]], y, [y[-1]]))
        y = np.convolve(pad, k, mode="valid")
    return y


def derivatives(x, y, smooth_passes=5):
    """Smoothed spectrum with its 1st and 2nd derivatives w.r.t. energy."""
    ys = binomial_smooth(y, smooth_passes)
    d1 = np.gradient(ys, x)
    d1s = binomial_smooth(d1, smooth_passes)
    d2 = np.gradient(d1s, x)
    d2s = binomial_smooth(d2, smooth_passes)
    return ys, d1s, d2s


def suggest_peaks(x, y, n_peaks, smooth_passes=5, min_sep=None):
    """
    Candidate peak positions from minima of the 2nd derivative, which is the
    standard way of locating overlapping transitions on a rising edge.
    Returns positions sorted by prominence, trimmed to n_peaks, then sorted by energy.
    """
    _, _, d2 = derivatives(x, y, smooth_passes)
    cand = []
    for i in range(1, len(x) - 1):
        if d2[i] < d2[i - 1] and d2[i] <= d2[i + 1] and d2[i] < 0:
            cand.append((d2[i], x[i]))
    cand.sort()
    if min_sep is None:
        min_sep = max((x.max() - x.min()) / 60.0, 1e-6)
    chosen = []
    for _, xc in cand:
        if all(abs(xc - c) >= min_sep for c in chosen):
            chosen.append(xc)
        if len(chosen) >= n_peaks:
            break
    return sorted(chosen)


# --------------------------------------------------------------------------
# Data IO
# --------------------------------------------------------------------------

def read_igor_text(path):
    """Parse an Igor Text (.itx/.awav) file into {wave_name: ndarray}.
    2-D waves give their first column; read_igor_text_full keeps them whole."""
    c = read_igor_text_full(path)
    return {k: (v if np.ndim(v) == 1 else v[:, 0]) for k, v in c.waves.items()}


def read_columns(path, prefer=None):
    """
    Load a data file.

    Returns (column_names, 2-D array). Text files: comment lines (#, ;, //),
    one optional header row, and whitespace / comma / tab / semicolon
    delimiters. Igor files (.itx, .pxp, .ibw): the 1-D waves of one length,
    chosen by `prefer` = (x name, y name) when given.
    """
    low = path.lower()
    if low.endswith(IGOR_TEXT_EXTS + IGOR_PACKED_EXTS + IGOR_BINARY_EXTS):
        return _columns_from_containers(read_igor_any(path), prefer)

    rows, header = [], None
    with open(path, "r", errors="replace") as fh:
        for raw in fh:
            s = raw.strip()
            if not s or s.startswith(("#", ";", "//", "!", "%")):
                continue
            parts = re.split(r"[\s,;\t]+", s)
            try:
                rows.append([float(v) for v in parts])
            except ValueError:
                if header is None and not rows:
                    header = parts
                continue
    if not rows:
        raise ValueError("No numeric data found in the file.")
    width = min(len(r) for r in rows)
    data = np.array([r[:width] for r in rows], dtype=float)
    if header and len(header) >= width:
        names = header[:width]
    else:
        names = [f"col{i+1}" for i in range(width)]
    return names, data


# ---- parameter names, per layout ------------------------------------------
#
# Every exported parameter wave carries its names twice: a dimension label on
# each point (Igor shows them beside the values with  Edit name.ld ) and a
# text wave <name>_Desc with a plain description of each row. Igor Text
# cannot put text on the same line as a number, so these are the Igor ways
# of naming rows. Readers that don't want them ignore both.

_STEP_DESC = {"mix": "Step Gaussian fraction", "amp": "Step amplitude (hold at 1)",
              "pos": "Step position E0 (eV)", "wid": "Step half-width (eV)"}
_STEP_LABEL = {"mix": "Step_Gauss_frac", "amp": "Step_amplitude",
               "pos": "Step_position_E0", "wid": "Step_half_width"}
_PEAK_DESC = ("amplitude", "position (eV)", "half-width (eV)", "skew",
              "L/W ratio (G/L width)", "Gaussian fraction")
_PEAK_LABEL = ("Amp", "Position", "Width", "Skew", "LW_ratio", "Gauss_frac")

PARAM_LAYOUTS = {
    # name: (global parameters in order, parameters per peak)
    "igor63": (("mix", "pos", "wid"), 5),          # original EDG_Fit12
    "gedgfit75": (("mix", "pos", "wid"), 6),       # this program's own
    "igor76": (("mix", "amp", "pos", "wid"), 6),   # gedgfit's Igor procedures
}


def param_names(layout):
    """[(dimension label, description)] for every point of a parameter wave
    in the given layout ("igor63", "gedgfit75" or "igor76")."""
    glob, per = PARAM_LAYOUTS[layout]
    out = []
    for k in glob:
        desc = _STEP_DESC[k]
        if layout == "igor63" and k == "mix":
            desc = "Gaussian fraction (step and every peak)"
        out.append((_STEP_LABEL[k], desc))
    for i in range(MAX_PEAKS):
        for f in range(per):
            out.append((f"P{i + 1}_{_PEAK_LABEL[f]}", f"Peak {i + 1} {_PEAK_DESC[f]}"))
    return [(lab, f"p[{k}]  {d}") for k, (lab, d) in enumerate(out)]


def _itx_quote(t):
    return '"' + t.replace("\\", "\\\\").replace('"', '\\"') + '"'


def itx_param_wave_lines(name, values, layout, with_desc=True):
    """Igor Text lines for a parameter wave with a dimension label on every
    point and, optionally, the text wave <name>_Desc describing each row."""
    names = param_names(layout)
    values = list(values)
    L = [f"WAVES/D\t{name}", "BEGIN"]
    L += [f"\t{_itx_num(v)}" for v in values]
    L.append("END")
    L.append(f'X SetScale/P x 0,1,"", {name}')
    for k, (lab, _d) in enumerate(names[:len(values)]):
        L.append(f"X SetDimLabel 0,{k},{lab},{name}")
    if with_desc:
        L += [f"WAVES/T\t{name}_Desc", "BEGIN"]
        L += ["\t" + _itx_quote(d) for _lab, d in names[:len(values)]]
        L.append("END")
    return L


def write_igor_param_wave(path, p, wave_name="Fit_P", full=False):
    """
    Export a parameter wave as Igor Text, every point named (see above).

    full=False writes the 63 parameters that Igor's original edg_fitN reads.
    The per-peak Gaussian fractions have no counterpart there, so they are
    dropped; if they are not all equal to p[0] the wave will not reproduce
    this fit in Igor, and the caller should say so.

    full=True writes all 75 in this program's own layout (ImportGedgfitP in
    the Igor procedures reads it): w[0] governs the step alone and each peak
    holds six parameters, w[3+6i+0..5], the last being its Gaussian fraction.

    17 significant figures round-trip a float64 exactly; at 10 an exported
    position of ~290 eV loses about 3e-8, more than the fit's own precision.
    """
    vals = np.asarray(p)[:FULL_LEN] if full else to_igor_layout(p)
    L = ["IGOR"] + itx_param_wave_lines(wave_name, vals,
                                        "gedgfit75" if full else "igor63")
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("\r\n".join(L) + "\r\n")


def read_igor_param_wave_full(path):
    """
    Read a parameter wave from an Igor text or binary file, or a one-column
    text file. Returns (75-element vector, step amplitude, description).

    In a file holding several waves (a gedgfit Igor export, an experiment)
    the wave named *_P is used, not simply the first one.
    """
    low = path.lower()
    if low.endswith(IGOR_TEXT_EXTS + IGOR_PACKED_EXTS + IGOR_BINARY_EXTS):
        for c in read_igor_any(path):
            for g in find_fit_groups(c):
                if g["P"] is not None:
                    return params_from_igor_wave(g["P"], g["P_row1"])
            ones = [(k, v) for k, v in c.waves.items()
                    if _is_1d(v) and _plausible_param_len(len(v))]
            if ones:
                k, v = ones[0]
                return params_from_igor_wave(v, c.label(k, 0, 1))
        raise ValueError("No parameter wave found in the file.")
    names, data = read_columns(path)
    return params_from_igor_wave(data[:, 0])


def read_igor_param_wave(path):
    """Read a parameter wave back as this program's 75-element vector."""
    return read_igor_param_wave_full(path)[0]


# --------------------------------------------------------------------------
# Igor Pro export: data + parameter state + procedure files
# --------------------------------------------------------------------------
#
# The two procedure files written beside the .itx. They are embedded at the
# bottom of this file so the single-file program and the .exe carry them;
# a copy of either file placed beside the program (or the .exe) is used
# instead, so the procedures can be updated without rebuilding.

IGOR_PROC_FILES = ("gedgfit_Model.ipf", "gedgfit_Workflow.ipf")

# Names the procedures are written under on export, following the original
# Igor convention: one shared model file, and a workflow file per sample
# named like Cp2VCl2_8CF.ipf (sample name, number of components fitted).
EXPORT_MODEL_IPF = "EDG_Fit12_SGM_JQN_modified.ipf"


def export_workflow_ipf(sample, n_peaks):
    """'Cp2VCl2', 8 -> 'Cp2VCl2_8CF.ipf'."""
    return f"{igor_name_stem(sample)}_{int(n_peaks)}CF.ipf"


def exported_procedure_texts(sample, n_peaks):
    """
    [(file name, text)] for the two procedure files as written on export:
    renamed, with their headers and cross-references updated, and the
    workflow's default base set to this sample.
    """
    wf_name = export_workflow_ipf(sample, n_peaks)
    stem = igor_name_stem(sample)
    model = procedure_text(IGOR_PROC_FILES[0])
    wf = procedure_text(IGOR_PROC_FILES[1])
    model = model.replace("//  " + IGOR_PROC_FILES[0], "//  " + EXPORT_MODEL_IPF, 1)
    wf = wf.replace("//  " + IGOR_PROC_FILES[1], "//  " + wf_name, 1)
    wf = wf.replace(IGOR_PROC_FILES[0], EXPORT_MODEL_IPF)
    wf = re.sub(r'StrConstant ksDefaultBase = "[^"]*"',
                f'StrConstant ksDefaultBase = "{stem}"', wf, count=1)
    return [(EXPORT_MODEL_IPF, model), (wf_name, wf)]

# Igor 7 limits wave names to 31 characters; the longest suffix the
# procedures append to the base name is "_Constraints" (12).
# Points in the exported fit_<base>_Int curve; the procedures' FuncFit uses
# the same number (/L=kEDG_FitCurvePoints), so a fit in Igor overwrites it
# like for like.
FIT_CURVE_POINTS = 1000

IGOR7_NAME_LIMIT = 31
IGOR_LONGEST_SUFFIX = 12


def _app_dirs():
    """
    Folders the program lives in, for finding files placed beside it.

    From source: the folder of this file. A Windows build: the folder of the
    .exe. A Mac build: the executable is buried at
    gedgfit.app/Contents/MacOS/, so the folder holding gedgfit.app comes
    first - that is where someone would put a file "next to the program".
    """
    if not _is_frozen():
        return [os.path.dirname(os.path.abspath(__file__))]
    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    dirs = []
    m = re.search(r"^(.*?)/[^/]+\.app/Contents/MacOS$", exe_dir)
    if m:
        dirs.append(m.group(1) or "/")
    dirs.append(exe_dir)
    return dirs


def procedure_text(fname):
    """Text of a bundled Igor procedure file, preferring a copy on disk."""
    for d in _app_dirs():
        disk = os.path.join(d, fname)
        if os.path.isfile(disk):
            with open(disk, "r", encoding="utf-8", errors="replace") as fh:
                return fh.read()
    return _EMBEDDED_IPF[fname]


def igor_name_stem(name):
    """Make `name` usable as the start of an Igor wave name: letters, digits
    and underscores, beginning with a letter."""
    s = re.sub(r"[^A-Za-z0-9_]", "_", str(name).strip())
    s = re.sub(r"_+", "_", s).strip("_")
    if not s:
        s = "sample"
    if not s[0].isalpha():
        s = "S_" + s
    return s


def igor_base_name(sample, n_peaks):
    """Base name for every export: '<sample>_<N>CF', e.g. Cp2VCl2_8CF."""
    return f"{igor_name_stem(sample)}_{int(n_peaks)}CF"


def to_igor76_layout(p, step_amp=1.0):
    """This program's 75-element vector -> the 76-point wave the Igor
    procedures use, which carries the step amplitude at p[1]:
        [mix, step_amp, E0, W0, peak1(6) ... peak12(6)]"""
    p = np.asarray(p, dtype=float)
    return np.concatenate(([p[0], float(step_amp), p[1], p[2]],
                           p[N_GLOBAL:FULL_LEN]))


def from_igor76_layout(w):
    """Inverse of to_igor76_layout: returns (75-element vector, step_amp)."""
    w = np.asarray(w, dtype=float)
    p = np.concatenate(([w[0], w[2], w[3]], w[4:76]))
    return p, float(w[1])


def _igor_quote(text):
    """An Igor string literal."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _igor_path_expr(folder, platform=None):
    """
    A folder as an Igor string expression, for NewPath in the exported .itx.

    Igor takes colon-separated paths on both platforms; it does not take
    POSIX (/Users/...) paths. On Mac a full colon path starts with the disk's
    name ("Macintosh HD:Users:me:Data:"), and that name varies from Mac to
    Mac, so for the startup disk the .itx asks Igor for it at load time:
        ParseFilePath(0, SpecialDirPath("Documents",0,0,0), ":", 0, 0)
    is the first element of the user's Documents path, i.e. the disk name.
    Folders on other disks (/Volumes/<Name>/...) name their disk directly.

    Windows:  C:\\Users\\me\\Data  ->  "C:Users:me:Data:"
              \\\\server\\share   ->  "\\\\\\\\server\\\\share\\\\"  (UNC, escaped)
    """
    platform = platform or sys.platform
    if platform == "win32":
        import ntpath
        folder = ntpath.abspath(folder) if os.name == "nt" else folder
        drive, rest = ntpath.splitdrive(folder)
        if drive.startswith("\\\\"):                     # UNC share
            return _igor_quote(folder.rstrip("\\") + "\\")
        parts = [q for q in re.split(r"[\\/]", rest) if q]
        return _igor_quote(drive + "".join(q + ":" for q in parts))  # D:\ -> "D:"
    if platform == "darwin":
        folder = os.path.realpath(folder) if sys.platform == "darwin" else folder
        parts = [q for q in folder.split("/") if q]
        # In POSIX names macOS shows a Finder "/" as ":"; HFS has it the other way
        parts = [q.replace(":", "/") for q in parts]
        if len(parts) >= 2 and parts[0] == "Volumes":
            return _igor_quote(":".join(parts[1:]) + ":")       # another disk
        rest = "".join(":" + q for q in parts) + ":"
        return ('ParseFilePath(0, SpecialDirPath("Documents", 0, 0, 0), ":", 0, 0) + '
                + _igor_quote(rest))
    return _igor_quote(folder.rstrip("/") + "/")                # other systems


def _itx_num(v):
    v = float(v)
    if np.isnan(v):
        return "NaN"
    if np.isinf(v):
        return "INF" if v > 0 else "-INF"
    return f"{v:.17g}"


def write_igor_bundle(itx_path, base, x, y, p, n_peaks, *, step_amp=1.0,
                      fixed=None, fix_step_amp=True, xmin=np.nan,
                      xmax=np.nan, p_saved=None, errors=None,
                      step_amp_err=np.nan, smooth=5):
    """
    Write an Igor Text file plus the two procedure files beside it:
    EDG_Fit12_SGM_JQN_modified.ipf (the model) and <base>_<N>CF.ipf (the
    workflow). `base` is the sample name; waves are named <base>_eV,
    <base>_Int, <base>_P, ... with no _<N>CF suffix.

    Opening the .itx in Igor Pro 7+ opens the procedures, loads the data,
    the total fit twice - <base>_Fit at the data points, a record of the fit
    made here that Igor leaves alone, and fit_<base>_Int, which a fit in
    Igor overwrites - and the complete parameter state, then
    compiles and runs derivPlot (with `smooth` passes, as the derivative
    viewer here), SetUp(), Wv_Plotter_Tot() and RSD_Plot_Tot(): the same
    tables (values and hold flags), peak count and fit range as here.

    p, p_saved, fixed, errors are in this program's 75-element layout; they
    are written in the 76-point order the procedures use (step amplitude at
    p[1]). Returns the list of files written.
    """
    base = igor_name_stem(base)
    folder = os.path.dirname(os.path.abspath(itx_path))
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    P = to_igor76_layout(p, step_amp)
    prev = to_igor76_layout(p if p_saved is None else p_saved, step_amp)
    fixed = (np.zeros(FULL_LEN, bool) if fixed is None
             else np.asarray(fixed, dtype=bool))

    # step table rows: Gauss frac, amplitude, position, half-width
    step_tbl = [(P[0], fixed[0]), (P[1], fix_step_amp),
                (P[2], fixed[1]), (P[3], fixed[2])]
    # peak table: 12 rows of (value, hold) pairs over the six fields
    peak_rows = []
    for i in range(MAX_PEAKS):
        b = peak_base(i)
        row = []
        for k in range(PARAMS_PER_PEAK):
            row += [p[b + k], float(bool(fixed[b + k]))]
        peak_rows.append(row)

    procs = exported_procedure_texts(base, n_peaks)
    nl = "\r\n"
    L = ["IGOR"]
    # the procedures first, from this folder; they compile once loading ends
    L.append(f'X NewPath/O/Q EDGBundle, {_igor_path_expr(folder)}')
    for fname, _txt in procs:
        L.append(f'X OpenProc/P=EDGBundle/V=0 "{fname}"')

    def block(decl, rows):
        L.append(decl)
        L.append("BEGIN")
        for r in rows:
            L.append("\t" + "\t".join(_itx_num(v) for v in r))
        L.append("END")

    block(f"WAVES/D\t{base}_eV", ([v] for v in x))
    block(f"WAVES/D\t{base}_Int", ([v] for v in y))
    # gedgfit's total fit at every data point, as a record of the fit made
    # here. The Igor procedures never read or change it.
    block(f"WAVES/D\t{base}_Fit",
          ([v] for v in model_total(x, p, n_peaks, step_amp)))
    # The total fit (step + every active peak, drawn in red here) as Igor's
    # own fit_<data> wave: evenly spaced over the fit range with x scaling,
    # which is what FuncFit /D writes. A fit in Igor overwrites it in place.
    lo = float(xmin) if xmin is not None and np.isfinite(xmin) else float(np.min(x))
    hi = float(xmax) if xmax is not None and np.isfinite(xmax) else float(np.max(x))
    if not hi > lo:
        lo, hi = float(np.min(x)), float(np.max(x))
    xf = np.linspace(lo, hi, FIT_CURVE_POINTS)
    fit_name = f"fit_{base}_Int"
    block(f"WAVES/D\t{fit_name}",
          ([v] for v in model_total(xf, p, n_peaks, step_amp)))
    L.append(f'X SetScale/I x {_itx_num(lo)},{_itx_num(hi)},"", {fit_name}')
    L += itx_param_wave_lines(f"{base}_P", P, "igor76")
    L += itx_param_wave_lines(f"{base}_Prev_P", prev, "igor76", with_desc=False)
    block(f"WAVES/D/N=(4,2)\t{base}_Step",
          ([v, float(bool(h))] for v, h in step_tbl))
    block(f"WAVES/D/N=({MAX_PEAKS},{2 * PARAMS_PER_PEAK})\t{base}_Peaks",
          peak_rows)
    if errors is not None:
        e = np.asarray(errors, dtype=float)
        sig = np.concatenate(([e[0], step_amp_err, e[1], e[2]], e[3:FULL_LEN]))
        block(f"WAVES/D\t{base}_Sigma", ([v] for v in sig))

    # dimension labels: the procedures recognise the tables by them
    step_rows = ("Step_Gauss_frac", "Step_amplitude", "Step_position_E0",
                 "Step_half_width")
    fields = ("Amp", "Position", "Width", "Skew", "LW_ratio", "Gauss_frac")
    holds = ("Amp_hold", "Pos_hold", "Width_hold", "Skew_hold", "LWR_hold",
             "Gauss_hold")
    for k, lab in enumerate(step_rows):
        L.append(f"X SetDimLabel 0,{k},{lab},{base}_Step")
    L.append(f"X SetDimLabel 1,0,value,{base}_Step")
    L.append(f"X SetDimLabel 1,1,hold,{base}_Step")
    for i in range(MAX_PEAKS):
        L.append(f"X SetDimLabel 0,{i},Peak{i + 1},{base}_Peaks")
    for k in range(PARAMS_PER_PEAK):
        L.append(f"X SetDimLabel 1,{2 * k},{fields[k]},{base}_Peaks")
        L.append(f"X SetDimLabel 1,{2 * k + 1},{holds[k]},{base}_Peaks")

    # state the procedures read
    L.append(f'X String/G root:gEDG_Base = "{base}"')
    L.append(f"X Variable/G {base}_nPk = {int(n_peaks)}")
    L.append(f"X Variable/G {base}_xmin = {_itx_num(xmin)}")
    L.append(f"X Variable/G {base}_xmax = {_itx_num(xmax)}")

    # once loading has finished: compile, derivatives, set up, figures
    for cmd in ("COMPILEPROCEDURES ",
                f"derivPlot({base}_Int, {base}_eV, {max(0, int(smooth))})",
                "SetUp()", "Wv_Plotter_Tot()", "RSD_Plot_Tot()"):
        L.append(f'X Execute/P/Q "{cmd}"')

    written = []
    with open(itx_path, "w", encoding="utf-8", newline="") as fh:
        fh.write(nl.join(L) + nl)
    written.append(itx_path)
    for fname, txt in procs:
        dest = os.path.join(folder, fname)
        txt = txt.replace("\r\n", "\n").replace("\r", "\n")
        with open(dest, "w", encoding="utf-8", newline="") as fh:
            fh.write(txt.replace("\n", nl))
        written.append(dest)
    return written


# --------------------------------------------------------------------------
# Rebuilding a fit from files: Igor experiments, Igor text, gedgfit
# sessions, parameter waves and normalised data (drag and drop)
# --------------------------------------------------------------------------
#
# Igor packed experiments (.pxp) and binary waves (.ibw) are read with the
# igor2 package, which is imported only when such a file is opened. Without
# it everything else here still works.

DATA_EXTS = (".txt", ".dat", ".csv", ".xy", ".asc", ".tsv", ".prn")
IGOR_TEXT_EXTS = (".itx", ".awav")
IGOR_PACKED_EXTS = (".pxp", ".pxt", ".uxp")
IGOR_BINARY_EXTS = (".ibw", ".bwav")
SESSION_EXTS = (".json",)
SCAN_MAX_FILES = 500        # stop walking a dropped folder after this many
SCAN_MAX_DEPTH = 3          # and this many folder levels below it
MIN_DATA_POINTS = 10        # fewer than this is not a spectrum


class IgorContainer:
    """
    What was found in one place inside an Igor file: an Igor Text file, one
    data folder of a packed experiment, or one folder of .ibw files.

    waves   {name: ndarray}   1-D, or 2-D as rows x columns like Igor
    labels  {name: {dim: {index: label}}}
    xscale  {name: (x0, dx)}
    vars    {name: float}     global numeric variables
    strs    {name: str}       global strings
    """

    def __init__(self, source, where=""):
        self.source = source
        self.where = where
        self.waves = {}
        self.labels = {}
        self.xscale = {}
        self.vars = {}
        self.strs = {}

    def find(self, name, table="waves"):
        """Case-insensitive lookup, as Igor names are case-insensitive."""
        d = getattr(self, table)
        if name in d:
            return d[name]
        low = name.lower()
        for k, v in d.items():
            if k.lower() == low:
                return v
        return None

    def real_name(self, name):
        low = name.lower()
        return next((k for k in self.waves if k.lower() == low), None)

    def label(self, name, dim, index):
        real = self.real_name(name) or name
        return self.labels.get(real, {}).get(dim, {}).get(index, "")

    def describe(self):
        w = os.path.basename(self.source)
        return f"{w}:{self.where}" if self.where else w


_ITX_FLAG = re.compile(r"/[A-Za-z]+(?:=\([^)]*\)|=[^\s/]+)?")


def _strip_igor_name(s):
    s = s.strip()
    if s.startswith("$"):
        s = s[1:]
    return s.strip().strip("'\"")


def _parse_igor_command(c, cmd):
    """Pick up the X commands that carry state: SetDimLabel, Variable,
    String and SetScale. Anything else is ignored."""
    m = re.match(r"SetDimLabel\s+(\d+)\s*,\s*(-?\d+)\s*,\s*(.+?)\s*,\s*(\S+)\s*$",
                 cmd, re.I)
    if m:
        dim, idx = int(m.group(1)), int(m.group(2))
        lab, name = _strip_igor_name(m.group(3)), _strip_igor_name(m.group(4))
        c.labels.setdefault(name, {}).setdefault(dim, {})[idx] = lab
        return
    m = re.match(r"Variable(?:/\w+)*\s+(?:[\w:]*:)?([A-Za-z]\w*)\s*=\s*([^,;]+)",
                 cmd, re.I)
    if m:
        try:
            c.vars[m.group(1)] = float(m.group(2).strip())
        except ValueError:
            pass
        return
    m = re.match(r'String(?:/\w+)*\s+(?:[\w:]*:)?([A-Za-z]\w*)\s*=\s*"(.*)"\s*$',
                 cmd, re.I)
    if m:
        c.strs[m.group(1)] = m.group(2)
        return
    m = re.match(r'SetScale(/[PI])?\s+x\s+([^,]+),\s*([^,]+),\s*"[^"]*"\s*,\s*(\S+)',
                 cmd, re.I)
    if m:
        try:
            a, b = float(m.group(2)), float(m.group(3))
        except ValueError:
            return
        name = _strip_igor_name(m.group(4))
        if (m.group(1) or "").upper() == "/I":
            w = c.find(name)
            n = len(w) if w is not None else 0
            c.xscale[name] = (a, (b - a) / (n - 1) if n > 1 else 1.0)
        else:
            c.xscale[name] = (a, b)


def read_igor_text_full(path):
    """
    Parse an Igor Text file (.itx/.awav) into an IgorContainer: every
    numeric wave, 2-D waves kept 2-D, plus dimension labels, x scaling and
    the global variables and strings set by X commands.
    """
    c = IgorContainer(path)
    with open(path, "r", errors="replace") as fh:
        lines = fh.read().splitlines()        # \r\n, \n and old-Mac \r
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        m = re.match(r"^WAVES?\b(.*)$", line, re.IGNORECASE)
        if m:
            decl = _ITX_FLAG.sub(" ", m.group(1))
            names = [_strip_igor_name(n) for n in re.split(r"[\s,]+", decl)
                     if n.strip()]
            block = []
            i += 1
            if i < len(lines) and lines[i].strip().upper().startswith("BEGIN"):
                i += 1
                while i < len(lines) and not lines[i].strip().upper().startswith("END"):
                    parts = lines[i].replace(",", " ").split()
                    if parts:
                        try:
                            block.append([float(v) for v in parts])
                        except ValueError:
                            pass                # a text wave: not ours
                    i += 1
            if block and names:
                width = min(len(r) for r in block)
                arr = np.array([r[:width] for r in block], dtype=float)
                if len(names) == 1:
                    c.waves[names[0]] = arr if width > 1 else arr[:, 0]
                else:
                    for k, nm in enumerate(names):
                        if k < width:
                            c.waves[nm] = arr[:, k]
        elif line.upper().startswith("X "):
            for cmd in line[2:].split(";"):
                if cmd.strip():
                    _parse_igor_command(c, cmd.strip())
        i += 1
    return c


def _igor2():
    """igor2's packed and binarywave modules, or (None, None)."""
    try:
        from igor2 import packed, binarywave
        return packed, binarywave
    except Exception:
        return None, None


def igor_binary_supported():
    return _igor2()[0] is not None


def _bytes_to_str(b):
    if isinstance(b, bytes):
        return b.split(b"\0", 1)[0].decode("latin-1")
    return str(b)


def _add_igor2_wave(c, wave):
    """Copy one igor2 wave dict into a container. Text waves are skipped."""
    w = wave["wave"]
    h = w["wave_header"]
    data = np.asarray(w["wData"])
    if data.dtype.kind not in "fiuc" or data.size == 0:
        return None
    if data.dtype.kind == "c":
        data = data.real
    data = data.astype(float)
    name = _bytes_to_str(h.get("bname", b"wave"))
    c.waves[name] = data
    labels = w.get("labels")
    if labels:
        out = {}
        for dim, lst in enumerate(labels):
            entries = {k - 1: _bytes_to_str(v) for k, v in enumerate(lst)
                       if k > 0 and _bytes_to_str(v)}
            if entries:
                out[dim] = entries
        if out:
            c.labels[name] = out
    if h.get("sfA") is not None:
        c.xscale[name] = (float(h["sfB"][0]), float(h["sfA"][0]))
    elif h.get("hsA") is not None:
        c.xscale[name] = (float(h["hsB"]), float(h["hsA"]))
    return name


def read_pxp(path):
    """An Igor packed experiment as one IgorContainer per data folder."""
    packed, _ = _igor2()
    if packed is None:
        raise ImportError("Reading Igor packed experiments needs the igor2 "
                          "package (pip install igor2).")
    _records, fs = packed.load(path)
    out = []

    def walk(folder, where):
        c = IgorContainer(path, where)
        for key, val in folder.items():
            name = _bytes_to_str(key)
            if isinstance(val, dict):
                walk(val, f"{where}:{name}" if where else name)
            elif type(val).__name__ == "WaveRecord":
                try:
                    _add_igor2_wave(c, val.wave)
                except Exception:
                    pass
            elif isinstance(val, (bytes, bytearray)):
                c.strs[name] = _bytes_to_str(bytes(val))
            else:
                try:
                    c.vars[name] = float(val)
                except (TypeError, ValueError):
                    pass
        if c.waves or c.strs:
            out.append(c)

    for top, val in fs.items():
        if isinstance(val, dict):
            walk(val, _bytes_to_str(top))
    return out


def read_ibw_files(paths):
    """Several .ibw files (normally one folder's worth) as one container."""
    _, binarywave = _igor2()
    if binarywave is None:
        raise ImportError("Reading Igor binary waves needs the igor2 "
                          "package (pip install igor2).")
    paths = list(paths)
    folder = os.path.dirname(os.path.abspath(paths[0])) if paths else ""
    c = IgorContainer(os.path.join(folder, "*.ibw"), "")
    for f in sorted(paths):
        try:
            _add_igor2_wave(c, binarywave.load(f))
        except Exception:
            pass
    return c


def read_igor_any(path):
    """Every container in an Igor file. For an .ibw, the whole folder of
    .ibw files around it, since a wave saved alone is rarely the whole
    story."""
    low = path.lower()
    if low.endswith(IGOR_TEXT_EXTS):
        return [read_igor_text_full(path)]
    if low.endswith(IGOR_PACKED_EXTS):
        return read_pxp(path)
    if low.endswith(IGOR_BINARY_EXTS):
        d = os.path.dirname(os.path.abspath(path))
        sib = [os.path.join(d, f) for f in os.listdir(d)
               if f.lower().endswith(IGOR_BINARY_EXTS)]
        return [read_ibw_files(sib or [path])]
    raise ValueError(f"Not an Igor file: {path}")


# ---- recognising a fit inside Igor data ------------------------------------

def _is_1d(a):
    return a is not None and np.ndim(a) == 1


def _plausible_param_len(n):
    """Lengths a parameter wave can have: the original 5-per-peak layout
    (3 + 5k, as made by make/n=53 etc.), gedgfit's 75, or the 76-point
    Igor layout."""
    return n in (FULL_LEN, FULL_LEN + 1) or (8 <= n <= IGOR_LEN and (n - 3) % 5 == 0)


def find_fit_groups(c):
    """
    Wave groups that make up a fit: <base>_eV and <base>_Int for the data,
    <base>_P for the parameters, plus the optional extras the workflow keeps
    (_Prev_P, _Step, _Peaks, _Sigma, fit_<base>_Int, <base>_nPk, ...).
    Returns a list of dicts; the base named by root:gEDG_Base comes first.
    """
    bases = {}
    for name in c.waves:
        low = name.lower()
        if low.startswith("fit_"):
            continue
        for suf in ("_int", "_ev", "_p"):
            if low.endswith(suf):
                base = name[:-len(suf)]
                if base.lower().endswith("_prev") or not base:
                    continue
                bases.setdefault(base.lower(), base)
    groups = []
    for base in bases.values():
        x, y = c.find(base + "_eV"), c.find(base + "_Int")
        P = c.find(base + "_P")
        has_data = (_is_1d(x) and _is_1d(y) and len(x) == len(y)
                    and len(x) >= MIN_DATA_POINTS)
        has_p = _is_1d(P) and _plausible_param_len(len(P))
        if not (has_data or has_p):
            continue
        g = {"base": base, "container": c,
             "x": x if has_data else None, "y": y if has_data else None,
             "x_name": c.real_name(base + "_eV"),
             "y_name": c.real_name(base + "_Int"),
             "P": P if has_p else None,
             "P_row1": c.label(base + "_P", 0, 1) if has_p else "",
             "prev": c.find(base + "_Prev_P"),
             "prev_row1": c.label(base + "_Prev_P", 0, 1),
             "step": c.find(base + "_Step"),
             "step_row1": c.label(base + "_Step", 0, 1),
             "peaks": c.find(base + "_Peaks"),
             "npk": c.find(base + "_nPk", "vars"),
             "xmin": c.find(base + "_xmin", "vars"),
             "xmax": c.find(base + "_xmax", "vars")}
        fw = c.find("fit_" + base + "_Int")
        fn = c.real_name("fit_" + base + "_Int")
        if _is_1d(fw) and fn in c.xscale and len(fw) > 1:
            x0, dx = c.xscale[fn]
            g["fit_range"] = tuple(sorted((x0, x0 + dx * (len(fw) - 1))))
        groups.append(g)
    pref = (c.find("gEDG_Base", "strs") or "").lower()
    groups.sort(key=lambda g: (g["base"].lower() != pref,
                               g["x"] is None, g["P"] is None, g["base"].lower()))
    if not groups:
        g = _generic_data_group(c)
        if g:
            groups.append(g)
    if not groups:
        # a lone parameter wave, e.g. <base>_P75 from File > Export
        for name, w in c.waves.items():
            m = re.match(r"(.+?)_P\d*$", name, re.I)
            if m and _is_1d(w) and _plausible_param_len(len(w)):
                groups.append({"base": m.group(1), "container": c,
                               "x": None, "y": None, "x_name": None, "y_name": None,
                               "P": w, "P_row1": c.label(name, 0, 1),
                               "prev": None, "prev_row1": "", "step": None,
                               "step_row1": "", "peaks": None,
                               "npk": None, "xmin": None, "xmax": None})
                break
    return groups


def _guess_xy(names):
    """The energy and intensity columns by name, as File > Open does."""
    xg = next((n for n in names if re.search(r"ev|energ|^x$", n, re.I)), names[0])
    rest = [n for n in names if n != xg] or names
    yg = next((n for n in rest if re.search(r"int|norm|mu|tey|tfy|^y$", n, re.I)),
              rest[0])
    return xg, yg


def _generic_data_group(c):
    """Fallback for Igor data not named <base>_eV / <base>_Int: two 1-D
    waves of the same length that look like energy and intensity."""
    one = {k: v for k, v in c.waves.items()
           if _is_1d(v) and len(v) >= MIN_DATA_POINTS and not k.lower().startswith("fit_")}
    if len(one) < 2:
        return None
    lens = [len(v) for v in one.values()]
    L = max(set(lens), key=lens.count)
    names = [k for k, v in one.items() if len(v) == L]
    if len(names) < 2:
        return None
    xn, yn = _guess_xy(names)
    if not re.search(r"ev|energ", xn, re.I):
        return None                         # too ambiguous to guess
    stem = os.path.splitext(os.path.basename(c.source))[0]
    return {"base": igor_name_stem(stem), "container": c,
            "x": one[xn], "y": one[yn], "x_name": xn, "y_name": yn,
            "P": None, "P_row1": "", "prev": None, "prev_row1": "",
            "step": None, "step_row1": "", "peaks": None,
            "npk": None, "xmin": None, "xmax": None}


def params_from_igor_wave(P, row1_label=""):
    """
    Any parameter wave -> (75-element gedgfit vector, step amplitude,
    description). Handles:
      76 points   the gedgfit Igor layout, step amplitude at p[1]
      76 points   whose row 1 is labelled Step_position: the earlier
                  procedure version, with the step amplitude at p[75]
      75 points   gedgfit's own export
      3 + 5k      the original EDG_Fit12 layout (53, 63, ...)
    """
    P = np.asarray(P, dtype=float).ravel()
    n = len(P)
    if n >= FULL_LEN + 1:
        if row1_label.lower() == "step_position":
            p = default_params()
            p[:FULL_LEN] = P[:FULL_LEN]
            return p, float(P[FULL_LEN]), \
                "76-point wave from the earlier procedures (step amplitude at p[75])"
        p, amp = from_igor76_layout(P[:FULL_LEN + 1])
        return p, amp, "76-point gedgfit Igor wave (step amplitude at p[1])"
    if n == FULL_LEN:
        return P.copy(), 1.0, "75-point gedgfit wave"
    return from_igor_layout(P), 1.0, \
        f"{n}-point original EDG_Fit12 wave (peak fractions linked to p[0])"


def default_fixed_mask():
    """The hold flags gedgfit starts with: skew, L/W ratio and Gaussian
    fraction held on every peak, everything else free."""
    m = np.zeros(FULL_LEN, dtype=bool)
    for i in range(MAX_PEAKS):
        b = peak_base(i)
        m[b + 3] = m[b + 4] = m[b + 5] = True
    return m


def holds_from_igor_tables(step, peaks, step_row1=""):
    """Hold flags from the workflow's <base>_Step / <base>_Peaks tables.
    Returns (75-element mask, step-amplitude held) or (None, None)."""
    have_step = step is not None and np.shape(step) == (4, 2)
    have_peaks = peaks is not None and np.shape(peaks) == (MAX_PEAKS, 2 * PARAMS_PER_PEAK)
    if not (have_step or have_peaks):
        return None, None
    m = default_fixed_mask()
    fix_amp = True
    if have_step:
        h = np.asarray(step)[:, 1] != 0
        if step_row1.lower() in ("step_position", "step_position_e0"):
            m[0], m[1], m[2], fix_amp = h[0], h[1], h[2], h[3]     # earlier order
        else:
            m[0], fix_amp, m[1], m[2] = h[0], h[1], h[2], h[3]
    if have_peaks:
        pk = np.asarray(peaks)
        for i in range(MAX_PEAKS):
            for k in range(PARAMS_PER_PEAK):
                m[peak_base(i) + k] = pk[i, 2 * k + 1] != 0
    return m, bool(fix_amp)


def _peaks_in_use(p):
    """Highest peak with a non-zero amplitude: the edg_fitN that was used,
    when the wave itself does not say."""
    filled = [i for i in range(MAX_PEAKS) if abs(p[peak_base(i)]) > 0]
    return (max(filled) + 1) if filled else 4


def sample_from_base(base):
    """'Cp2VCl2_8CF' -> 'Cp2VCl2', so exports rebuild the same base."""
    return re.sub(r"_\d+CF$", "", base, flags=re.I) or base


# ---- scanning what was dropped --------------------------------------------

def _expand_paths(paths, max_files=SCAN_MAX_FILES, max_depth=SCAN_MAX_DEPTH):
    files, truncated = [], False
    for p in paths:
        p = os.path.abspath(p)
        if os.path.isfile(p):
            files.append(p)
        elif os.path.isdir(p):
            top = p.rstrip(os.sep).count(os.sep)
            for d, sub, fs in os.walk(p):
                sub[:] = sorted(s for s in sub if not s.startswith((".", "__")))
                if d.count(os.sep) - top >= max_depth:
                    sub[:] = []
                for f in sorted(fs):
                    files.append(os.path.join(d, f))
        if len(files) > max_files:
            files, truncated = files[:max_files], True
            break
    seen, out = set(), []
    for f in files:
        k = os.path.normcase(f)
        if k not in seen:
            seen.add(k)
            out.append(f)
    return out, truncated


def scan_for_fit(paths):
    """
    Read everything usable in the dropped files and folders.

    Returns a dict:
      sessions    [(path, session dict)]
      containers  [IgorContainer]           .itx, .pxp, folders of .ibw
      tables      [(path, names, 2-D data)] normalised data files
      params      [(path, vector)]          one-column parameter files
      ignored     [path]
      errors      [(path, message)]
      truncated   bool                      the folder was too big to read whole
    """
    files, truncated = _expand_paths(paths)
    out = {"sessions": [], "containers": [], "tables": [], "params": [],
           "ignored": [], "errors": [], "truncated": truncated}
    ibw = {}
    for f in files:
        low = f.lower()
        try:
            if low.endswith(SESSION_EXTS):
                s = load_session(f)
                if isinstance(s, dict) and "params" in s:
                    out["sessions"].append((f, s))
                else:
                    out["ignored"].append(f)
            elif low.endswith(IGOR_TEXT_EXTS):
                out["containers"].append(read_igor_text_full(f))
            elif low.endswith(IGOR_PACKED_EXTS):
                out["containers"].extend(read_pxp(f))
            elif low.endswith(IGOR_BINARY_EXTS):
                ibw.setdefault(os.path.dirname(f), []).append(f)
            elif low.endswith(DATA_EXTS):
                names, data = read_columns(f)
                if data.shape[1] >= 2 and data.shape[0] >= MIN_DATA_POINTS:
                    out["tables"].append((f, names, data))
                elif data.shape[1] == 1 and _plausible_param_len(data.shape[0]):
                    out["params"].append((f, data[:, 0]))
                else:
                    out["ignored"].append(f)
            else:
                out["ignored"].append(f)
        except Exception as exc:
            out["errors"].append((f, str(exc) or type(exc).__name__))
    for d, fs in ibw.items():
        try:
            out["containers"].append(read_ibw_files(fs))
        except Exception as exc:
            out["errors"].append((d, str(exc)))
    return out


# ---- assembling complete fits from what was found -------------------------

def _data_entry(names, raw, source, xcol, ycol, label):
    return {"names": list(names), "raw": np.asarray(raw, dtype=float),
            "source": source, "xcol": xcol, "ycol": ycol, "label": label}


def assemble_fit_candidates(scan):
    """
    Turn a scan into the fits it can rebuild, most complete first. Each
    candidate is a dict:

      kind     "session" | "igor" | "combined" | "data" | "params"
      label    one line for a chooser
      data     {"names", "raw", "source", "xcol", "ycol"} or None
      session  the session dict, for kind "session"
      p, step_amp, fixed, fix_step_amp, n_peaks, xmin, xmax, p_saved,
      sample   (when parameters were found)
      notes    lines explaining where each piece came from
    """
    pool = []                                    # every data set found
    for f, names, data in scan["tables"]:
        xc, yc = _guess_xy(names)
        pool.append(_data_entry(names, data, f, xc, yc,
                                f"{os.path.basename(f)} ({data.shape[0]} pts)"))
    groups = [g for c in scan["containers"] for g in find_fit_groups(c)]
    for g in groups:
        if g["x"] is not None:
            g["data"] = _data_entry([g["x_name"], g["y_name"]],
                                    np.column_stack([g["x"], g["y"]]),
                                    g["container"].source, g["x_name"], g["y_name"],
                                    f"{g['base']} in {g['container'].describe()}")
            pool.append(g["data"])

    def find_data(path_hint):
        if not path_hint:
            return None
        # split on both separators: the session may come from another OS
        key = re.split(r"[\\/]", path_hint)[-1].lower()
        return next((d for d in pool
                     if os.path.basename(d["source"]).lower() == key), None)

    cands = []
    used_sources = set()

    # 1. gedgfit sessions: everything, if their data can be found
    for f, s in scan["sessions"]:
        dp = s.get("data_path") or ""
        c = {"kind": "session", "session": s, "source": f, "data": None,
             "notes": [f"session: {f}"]}
        loc = locate_session_data(s, f, allow_embedded=False)
        if loc is not None:
            c["notes"].append(f"data: {loc[2]} (found at {loc[3]})")
            where = os.path.basename(loc[2])
            used_sources.add(os.path.normcase(os.path.abspath(loc[2])))
        else:
            d = find_data(dp)
            if d is None and not session_has_embedded_data(s) and len(pool) == 1:
                d = pool[0]
            if d is None and session_has_embedded_data(s):
                where = "data stored in the session"
                c["notes"].append("data: the copy stored in the session (the "
                                  f"file {dp or '-'} was not found)")
            elif d is not None:
                c["data"] = d
                c["notes"].append(f"data: {d['source']}  (the session's "
                                  f"original path {dp or '-'} was not found)")
                where = os.path.basename(d["source"])
                used_sources.add(os.path.normcase(d["source"]))
            else:
                where = "data not found"
                c["notes"].append(f"data: not found ({dp or 'no path stored'})")
        n = s.get("n_peaks", "?")
        c["label"] = (f"Session   {os.path.basename(f)}   - {n} peaks, {where}")
        cands.append(c)

    # 2. fits stored in Igor
    for g in groups:
        c = {"kind": "igor", "data": g.get("data"), "source": g["container"].source,
             "notes": [f"Igor: {g['base']} in {g['container'].source}"
                       + (f" (folder {g['container'].where})"
                          if g['container'].where else "")]}
        if c["data"] is not None:
            c["notes"].append(f"data: {g['x_name']}, {g['y_name']} "
                              f"({len(g['x'])} pts)")
        if g["P"] is not None:
            _apply_igor_params(c, g)
        if c["data"] is None and "p" not in c:
            continue
        what = []
        if c["data"] is not None:
            what.append(f"data {len(g['x'])} pts")
        if "p" in c:
            what.append(f"{c['n_peaks']}-peak parameters")
        c["kind"] = "igor" if (c["data"] is not None and "p" in c) else \
                    ("data" if c["data"] is not None else "params")
        c["label"] = (f"Igor      {g['base']}   in {g['container'].describe()}"
                      f"   - {' + '.join(what)}")
        if c["data"] is not None and c["kind"] == "igor":
            used_sources.add(os.path.normcase(g["container"].source))
        cands.append(c)

    # 3. stand-alone parameter files (one-column text)
    for f, vec in scan["params"]:
        p, amp, note = params_from_igor_wave(vec)
        cands.append({"kind": "params", "data": None, "source": f,
                      "p": p, "step_amp": amp, "fixed": None, "fix_step_amp": None,
                      "n_peaks": _peaks_in_use(p), "xmin": None, "xmax": None,
                      "p_saved": None, "sample": None,
                      "label": f"Params    {os.path.basename(f)}   - {note}",
                      "notes": [f"parameters: {f} ({note})"]})

    # 4. plain data files nobody else claimed
    for d in pool:
        if d["source"].lower().endswith(DATA_EXTS) and \
                os.path.normcase(d["source"]) not in used_sources:
            cands.append({"kind": "data", "data": d, "source": d["source"],
                          "label": f"Data      {d['label']}",
                          "notes": [f"data: {d['source']}"]})

    # 5. data from one place and parameters from another: offer the pair
    complete = [c for c in cands if c["kind"] in ("session", "igor")]
    datas = [c for c in cands if c["kind"] == "data"]
    params = [c for c in cands if c["kind"] == "params"]
    if not complete and datas and params:
        d, p = datas[0], params[0]
        comb = dict(p)
        comb.update({"kind": "combined", "data": d["data"],
                     "label": f"Combine   {os.path.basename(d['source'])} + "
                              f"{os.path.basename(p['source'])}",
                     "notes": d["notes"] + p["notes"]})
        cands.append(comb)

    order = {"session": 0, "igor": 1, "combined": 2, "data": 3, "params": 4}
    cands.sort(key=lambda c: order[c["kind"]])
    return cands


def _apply_igor_params(c, g):
    """Fill candidate c with everything a fit group says about the model."""
    p, amp, note = params_from_igor_wave(g["P"], g["P_row1"])
    c["p"], c["step_amp"] = p, amp
    c["notes"].append(f"parameters: {g['base']}_P, {note}")
    fixed, fix_amp = holds_from_igor_tables(g["step"], g["peaks"], g["step_row1"])
    c["fixed"], c["fix_step_amp"] = fixed, fix_amp
    c["notes"].append("holds: from the Igor parameter tables" if fixed is not None
                      else "holds: none stored in Igor; gedgfit defaults kept")
    npk = g.get("npk")
    if npk is not None and np.isfinite(npk) and 1 <= int(npk) <= MAX_PEAKS:
        c["n_peaks"] = int(npk)
        c["notes"].append(f"peaks: {c['n_peaks']} (from {g['base']}_nPk)")
    else:
        c["n_peaks"] = _peaks_in_use(p)
        c["notes"].append(f"peaks: {c['n_peaks']} (highest non-zero amplitude)")
    xmin, xmax = g.get("xmin"), g.get("xmax")
    if (xmin is None or not np.isfinite(xmin)) and (xmax is None or not np.isfinite(xmax)) \
            and g.get("fit_range"):
        xmin, xmax = g["fit_range"]
        c["notes"].append(f"fit range: {xmin:.6g} to {xmax:.6g} eV "
                          f"(span of Igor's fit_{g['base']}_Int)")
    elif xmin is not None or xmax is not None:
        c["notes"].append("fit range: from the Igor globals")
    c["xmin"], c["xmax"] = xmin, xmax
    prev = g.get("prev")
    if _is_1d(prev) and _plausible_param_len(len(prev)):
        c["p_saved"] = params_from_igor_wave(prev, g["prev_row1"])[0]
    else:
        c["p_saved"] = None
    c["sample"] = sample_from_base(g["base"])
    c["base"] = g["base"]


def _columns_from_containers(conts, prefer=None):
    """Same-length 1-D waves from Igor containers as (names, 2-D array),
    for read_columns. The length is that of `prefer` (x, y names) when
    given, else of the first <base>_eV/_Int pair, else the most common."""
    waves = {}
    for c in conts:
        for k, v in c.waves.items():
            if _is_1d(v):
                key = k if k not in waves else f"{c.where}:{k}"
                waves[key] = v
    if not waves:
        raise ValueError("No numeric waves found in the Igor file.")
    L = None
    if prefer:
        hits = [waves.get(n) for n in prefer if n in waves]
        if len(hits) == len(prefer) and len({len(h) for h in hits}) == 1:
            L = len(hits[0])
    if L is None:
        for c in conts:
            gs = [g for g in find_fit_groups(c) if g["x"] is not None]
            if gs:
                L = len(gs[0]["x"])
                break
    if L is None:
        lens = [len(v) for v in waves.values() if len(v) >= MIN_DATA_POINTS] \
            or [len(v) for v in waves.values()]
        L = max(set(lens), key=lens.count)
    names = [k for k, v in waves.items() if len(v) == L]
    return names, np.column_stack([waves[k] for k in names])


def session_has_embedded_data(s):
    d = s.get("data") if isinstance(s, dict) else None
    return isinstance(d, dict) and len(d.get("x") or []) >= 2 \
        and len(d.get("x") or []) == len(d.get("y") or [])


def locate_session_data(s, session_path, allow_embedded=True):
    """
    Find the data a session was fitted on. Tries, in order:
      1. the stored path, if the file is still there
      2. next to the session file: the stored relative path, then the file
         name alone (a folder that was moved, copied or zipped)
      3. the copy of the data stored inside the session itself
    Returns (names, 2-D data, path, how) or None.
    """
    prefer = (s.get("x_col"), s.get("y_col"))
    dp = s.get("data_path") or ""
    here = os.path.dirname(os.path.abspath(session_path)) if session_path else ""
    tries = []
    if dp:
        tries.append((dp, "its original location"))
    if here:
        rel = s.get("data_relpath")
        if rel:
            tries.append((os.path.normpath(os.path.join(here, rel)), "next to the session"))
        if dp:
            # split on both separators: the session may come from another OS
            tries.append((os.path.join(here, re.split(r"[\\/]", dp)[-1]),
                          "next to the session"))
    seen = set()
    for path, how in tries:
        key = os.path.normcase(os.path.abspath(path))
        if key in seen or not os.path.isfile(path):
            continue
        seen.add(key)
        try:
            names, raw = read_columns(path, prefer=prefer)
            return names, raw, path, how
        except Exception:
            continue
    if allow_embedded and session_has_embedded_data(s):
        d = s["data"]
        names = [d.get("x_col") or prefer[0] or "energy",
                 d.get("y_col") or prefer[1] or "intensity"]
        if names[0] == names[1]:
            names[1] += "_y"
        raw = np.column_stack([np.asarray(d["x"], dtype=float),
                               np.asarray(d["y"], dtype=float)])
        return names, raw, dp, "the copy stored in the session"
    return None


def save_session(path, state: dict):
    with open(path, "w") as fh:
        json.dump(state, fh, indent=2)


def load_session(path) -> dict:
    with open(path, "r") as fh:
        return json.load(fh)

# ==========================================================================
#  GRAPHICAL INTERFACE
# ==========================================================================

# --------------------------------------------------------------------------
#  Desktop / frozen-executable support
# --------------------------------------------------------------------------

_ICON_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAOnRFWHRTb2Z0d2FyZQBNYXRwbG90"
    "bGliIHZlcnNpb24zLjEwLjgsIGh0dHBzOi8vbWF0cGxvdGxpYi5vcmcvwVt1zgAAAAlwSFlzAAAP"
    "YQAAD2EBqD+naQAABp5JREFUeJztm3tMU1ccx7+lbwqFPqDdpjwVnANhr/gKIo45p1PnXJyZzhkX"
    "E9lQnIrOmRldnHtrdFGzZE7DkBiWKUHN4oZhChpiHHOKgCApD3m/Wii0vQ/ZH7jipS3c0gtXQz8J"
    "ob9fzz39ni/n/M49FxBo9GF9GMf48C2Ab7wG8C2Ab7wG8C2Ab7wG8C2Ab7wG8C2Ab7wG8C2Ab7wG"
    "8C2Ab7wG8C2Ab7wG8C2Ab7wG8C2Ab7wGjOQimUwKtVrFtRZecNuA+LhY/F10BRV3inH61AmIxeLR"
    "0DVmuG3Arp3p0OmCAQDJ8+bi3ZVvcy5qLHHLAKFQiKTEBEZuXlIip4LGGrcM0GrUDjldcDBnYvjA"
    "PQO0WoecXj+ODNA4mQHBQUGcieEDtwwI0mocchKJBCpVIFd6xhyPZwDwZNcBj2sA4HxmPCl4vAsA"
    "gHbcGOBioK5mxpOAyJ3GGrXzGeCqNnCNVqOBVquBShWIwMAAqFUqKJX+kMlkkMvlkMukkMlk9lgm"
    "lUIsEUMsEkH08EssFkEkEvd/F4rcM8DVWh+NGqBU+mPhgvmYPWsG4qbFIDQ0BApfX84/x70ZoHG1"
    "BLgzwE+hwPZtm7H2/VXwlcs569cVrA2QSCQICFA6fY+rJTApMgKnT51AWGgIJ/2xgbUBQ53/gzSe"
    "F8HIiHBcyP3VZZ0BAJqm0NLRiXZTN4zdZhi7zejq6UGv1QaLjYCVIGC1EbDYbLDaCNhIAiRJgaRp"
    "UBQNkqZA0w9AUpQ9Zm3AUOvc0yXgp1Ag48SPDoPvNJlwLv8vXCq+gzJDLZra2kE/eODRZw2GtQGu"
    "1j8ABAQoIRaLQZLkiETs2pmO6KjJjNy5K9eQfvAYunt7R9QnW1jfBwxX6UdaB2JjpmLd2tWMXH5R"
    "EVL2Hxj1wQNuGTD0Oh/pVvjpJ9sgFArtcZexFSlfH0Ff39j8/SZ7A4KGNmCoJeKKuGkxePWVJEZu"
    "59GMMfnJ/w9nBoxkBmze9CEjvl97DzmXr7ndjyewLoLBwcwHH+ZeC/x8B25UnO0EC+YnI2nuHJSV"
    "lyMzKxsURdnfi46ajMWLXme03//LGdbCucKNbZA5A+5W1+LFqdH2eHAR3Pf5Z9iwfp09XvLGQqxc"
    "vQ4EQQAANqVuYLSvqKlDbsF19so5gvUSCB60BMoMNYxY+0gNSJg9kzF4AJiTMBtbP94IAJg44Rks"
    "X7aE8f6R7LNjVvgehZUBPj4+DlO8rLqWEev1Ovvr9K1pTvtJTVmPiPAwpG1MgUg0MPmaWpqRk1/I"
    "WjSXsFoCQVoNY6uyEgTuVBkYbcJC+u/f4+NiMWvmdKf9SKVS5OddcDjVnTn/Gyiadks4V7CaAaGD"
    "Dif1za0w1DcOajMRQqEQa9esGrKvwYMnTE34PqeAjYxRYUQG1DQ1o81ogrnXYs+JxWLExkzF8mVL"
    "GW0/+uogim6Xuuw78/RPsNoIdzRzCisDwkImMuLaxmYAcJgFX+7bA7lcZo9bO424UFCEzd/+gM6u"
    "bod+e0vOYu/ZYrdFcwkrAyZPimTEtU39BtysqGTkX37pBUac9XseSIpCXXML3tyyC1dv3gZN0zB2"
    "m3E4KxuL9/4Mqk/giX6PYVUE4+OnMeLSh1vg9ZJyvLfoNafXWAkCGecv2uN7dfVYsWMPBIL+Afdv"
    "eZKRaOaUYWeAShWIiPAwRu5WRRUAoPDmLZfVO+PcRTS1dzByszRmKIQUL/u9K4Y1YMH8ZEZsqG+E"
    "ydwDAGjpMCL38lWHa6obmnAgM5uRi/K3ImO6AX8kVuL5wLE77AzHkAYEBCiRlprCyP1ZdIMR7z56"
    "HMVlFfa4qq4ea3bvZ5zoIv2syJphgFzUh1AFAYWInz3fGYLB/zip1+vw7JRoJCUm4J0Vbzk8pkre"
    "sMXhNljo44OYSeGQSaS4UVrOeGw1U2PGyenV8BP1574p0+FQpQ6PC6KTx49Bo1ZDrVbhKb0OSqXz"
    "J78AkJNf6DB4XyENrdQGSdst6GQk1ocTuNSsRKW5fzssMclB0AJABHxXrsOhysfrF6mCPpYVydxY"
    "hqrMD1DSSmP7vxPs+R1TmrApqoXR9otSPY7eGxjokqeN6CSFKGj150g2dwy/DZIWoOQU/K4fRpyv"
    "BaQ/81a2i3IsI88pLYw4tyHQI5GjiYMBBEmiylCD0opK3P2nEEvFebD0GEHQAtgoIco7SJA1Aweh"
    "PDON1gYZmnsFaDQL0GD2gclGAzAM7vqxRJCatrWvra0D7R2daG9vx/36BtA8ncz4wGEXGG/8B0VG"
    "DkHs0mDgAAAAAElFTkSuQmCC"
)


def _is_frozen():
    return getattr(sys, "frozen", False)


def _log_path():
    """Somewhere writable for a crash log: next to the .exe on Windows if
    possible, ~/Library/Logs on a Mac (never inside gedgfit.app, which
    would break its code signature), else the home folder."""
    if _is_frozen() and sys.platform != "darwin":
        base = os.path.dirname(sys.executable)
        probe = os.path.join(base, ".write_test")
        try:
            with open(probe, "w"):
                pass
            os.remove(probe)
            return os.path.join(base, "gedgfit_error.log")
        except OSError:
            pass
    if sys.platform == "darwin":
        logs = os.path.join(os.path.expanduser("~"), "Library", "Logs")
        try:
            os.makedirs(logs, exist_ok=True)
            return os.path.join(logs, "gedgfit_error.log")
        except OSError:
            pass
    return os.path.join(os.path.expanduser("~"), "gedgfit_error.log")


def _report(exc_type, exc, tb):
    """Log an unhandled error and tell the user. A --windowed build has no
    console, so without this the application would vanish without a word."""
    import traceback
    text = "".join(traceback.format_exception(exc_type, exc, tb))
    path = _log_path()
    try:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write("\n=== %s ===\n%s" % (datetime.datetime.now().isoformat(" ", "seconds"), text))
    except OSError:
        path = "(could not be written)"
    sys.stderr.write(text)
    try:
        import tkinter.messagebox as mb
        mb.showerror("gedgfit - unexpected error",
                     "%s: %s\n\nThe application will keep running, but the last "
                     "action did not complete.\n\nDetails were written to:\n%s"
                     % (exc_type.__name__, exc, path))
    except Exception:
        pass


APP_VERSION = "2.0"
IS_MAC = sys.platform == "darwin"


def _mac():
    """True on macOS. Read at run time (not frozen into constants) so the
    Mac code paths can also be exercised from tests on other systems."""
    return bool(IS_MAC)


def _shortcut(key):
    """(Tk event sequence, menu label) for a keyboard shortcut: Command on a
    Mac, where Tk draws "Command-O" as the native glyph, Control elsewhere."""
    if _mac():
        return f"<Command-{key}>", f"Command-{key.upper()}"
    return f"<Control-{key}>", f"Ctrl+{key.upper()}"


def _mono(win_family="Consolas"):
    """A monospaced font: Menlo is the Mac's; Consolas/Courier on Windows."""
    return ("Menlo", 11) if _mac() else (win_family, 9)


def _mac_fonts(root):
    """
    macOS measures the screen in points and does Retina scaling itself, so
    Tk's own scaling (1 pixel per point) is already right there and must not
    be replaced by the Windows DPI arithmetic. What does need setting is the
    font size: Tk's Mac default is 13 pt, where the layout was designed
    around Windows' 9 pt at 96 dpi (about 11 pixels). 11 pt on a Mac gives
    the same proportions.
    """
    import tkinter.font as tkfont

    def named(name):
        try:
            return tkfont.nametofont(name, root=root)
        except TypeError:                          # Python < 3.10
            return tkfont.nametofont(name)

    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont",
                 "TkCaptionFont", "TkSmallCaptionFont", "TkIconFont",
                 "TkTooltipFont"):
        try:
            named(name).configure(size=11)
        except Exception:
            pass
    try:
        named("TkFixedFont").configure(family="Menlo", size=11)
    except Exception:
        pass


def _enable_dpi_awareness():
    """Ask Windows for real pixels so the interface is not blurry."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)   # per-monitor v2
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()        # older Windows
    except Exception:
        pass


def _set_taskbar_id():
    """Without this Windows groups the app under the python.exe icon."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "anthropic.xas.edgefitter.1")
    except Exception:
        pass


# Width of the control column in pixels at 100% scaling. Wide enough for the
# five buttons of the Refine row to sit side by side without clipping.
PANEL_WIDTH = 620

# How long the window must be still before the figure is re-rendered, in ms.
RESIZE_DELAY_MS = 120

APP_TITLE = "gedgfit  -  step + 12 pseudo-Voigt (Igor EDG_Fit12 port)"

# Dark palette. Kept slightly blue rather than neutral grey so the spectrum
# colours stay legible against it.
THEME = {
    "bg":      "#171b23",   # window background
    "panel":   "#212734",   # raised controls
    "field":   "#0e1117",   # entry / text backgrounds
    "fg":      "#f0f3f8",   # primary text, near white
    "muted":   "#98a3b6",   # captions
    "accent":  "#5aa9ff",   # group titles, focus, selection
    "border":  "#3a4353",
    "plot_bg": "#101319",   # figure background
    "cross":   "#8fbcff",   # crosshair
}

PEAK_COLORS = [
    "#e6c700", "#00b400", "#00cfe0", "#ff2fa0", "#00a05a", "#3f7fd0",
    "#ff8c1a", "#a06ce0", "#8ab800", "#e05050", "#00b8a0", "#b0a0ff",
]


def _launch_error(exc):
    msg = (
        "This program needs Tk, NumPy, SciPy and Matplotlib.\n\n"
        f"Import failed: {exc}\n\n"
        "  pip install numpy scipy matplotlib\n"
        "  Debian/Ubuntu also need:  sudo apt install python3-tk\n"
        "  macOS (Homebrew python):  brew install python-tk\n"
    )
    sys.stderr.write(msg)
    try:
        import tkinter, tkinter.messagebox as mb
        r = tkinter.Tk(); r.withdraw()
        mb.showerror("gedgfit - missing components", msg)
        r.destroy()
    except Exception:
        pass
    raise SystemExit(1)


def main(run=True):
    """Build and show the application. `run=False` returns (root, app)
    without entering the event loop, which is useful for testing."""
    try:
        import tkinter as tk
        from tkinter import ttk, filedialog, messagebox
        import matplotlib
        matplotlib.use("TkAgg")
        from matplotlib.figure import Figure
        from matplotlib.backends.backend_tkagg import (
            FigureCanvasTkAgg, NavigationToolbar2Tk)
        from matplotlib.widgets import SpanSelector
    except Exception as exc:                     # pragma: no cover
        _launch_error(exc)

    # ----------------------------------------------------------------- theme
    T = THEME

    def apply_dark_theme(root):
        """Restyle ttk and the classic Tk widgets that ttk does not cover."""
        style = ttk.Style()
        try:
            style.theme_use("clam")       # the only stock theme that recolours
        except Exception:
            pass

        style.configure(".",
                        background=T["bg"], foreground=T["fg"],
                        fieldbackground=T["field"], bordercolor=T["border"],
                        darkcolor=T["panel"], lightcolor=T["panel"],
                        troughcolor=T["field"], arrowcolor=T["fg"],
                        insertcolor=T["fg"], focuscolor=T["accent"],
                        selectbackground=T["accent"], selectforeground="#ffffff")
        style.configure("TFrame", background=T["bg"])
        style.configure("TLabel", background=T["bg"], foreground=T["fg"])
        style.configure("Muted.TLabel", background=T["bg"], foreground=T["muted"])
        style.configure("TLabelframe", background=T["bg"], bordercolor=T["border"],
                        relief="groove")
        style.configure("TLabelframe.Label", background=T["bg"],
                        foreground=T["accent"])
        style.configure("TButton", background=T["panel"], foreground=T["fg"],
                        bordercolor=T["border"], focusthickness=1, padding=3)
        style.map("TButton",
                  background=[("active", "#2c3444"), ("pressed", "#39445a"),
                              ("disabled", T["bg"])],
                  foreground=[("disabled", T["muted"])])
        style.configure("Accent.TButton", background="#2a4d7a", foreground="#ffffff")
        style.map("Accent.TButton",
                  background=[("active", "#35608f"), ("pressed", "#24405f")])
        style.configure("TEntry", fieldbackground=T["field"], foreground=T["fg"],
                        bordercolor=T["border"], insertcolor=T["fg"], padding=2)
        style.map("TEntry",
                  fieldbackground=[("disabled", T["bg"])],
                  foreground=[("disabled", T["muted"])])
        style.configure("TCheckbutton", background=T["bg"], foreground=T["fg"],
                        indicatorcolor=T["field"], focuscolor=T["bg"])
        style.map("TCheckbutton",
                  background=[("active", T["bg"])],
                  indicatorcolor=[("selected", T["accent"]),
                                  ("disabled", T["bg"])],
                  foreground=[("disabled", T["muted"])])
        style.configure("TCombobox", fieldbackground=T["field"],
                        foreground=T["fg"], background=T["panel"],
                        arrowcolor=T["fg"], bordercolor=T["border"])
        style.map("TCombobox",
                  fieldbackground=[("readonly", T["field"])],
                  foreground=[("readonly", T["fg"])],
                  background=[("readonly", T["panel"])])
        style.configure("TSpinbox", fieldbackground=T["field"], foreground=T["fg"],
                        arrowcolor=T["fg"], bordercolor=T["border"])
        style.map("TSpinbox",
                  fieldbackground=[("disabled", T["bg"])],
                  foreground=[("disabled", T["muted"])])
        style.configure("TScrollbar", background=T["panel"],
                        troughcolor=T["field"], bordercolor=T["border"],
                        arrowcolor=T["fg"])
        style.map("TScrollbar", background=[("active", "#333d4f")])
        style.configure("TPanedwindow", background=T["bg"])
        style.configure("Sash", background=T["border"])

        # the Combobox dropdown is a classic Listbox, invisible to ttk styling
        root.option_add("*TCombobox*Listbox.background", T["field"])
        root.option_add("*TCombobox*Listbox.foreground", T["fg"])
        root.option_add("*TCombobox*Listbox.selectBackground", T["accent"])
        root.option_add("*TCombobox*Listbox.selectForeground", "#ffffff")
        root.configure(background=T["bg"])

    def style_menu(menu):
        try:
            menu.configure(background=T["panel"], foreground=T["fg"],
                           activebackground=T["accent"], activeforeground="#ffffff",
                           selectcolor=T["fg"], borderwidth=0)
        except tk.TclError:
            pass

    def style_toolbar(tb):
        """
        Darken the Matplotlib navigation toolbar. Matplotlib regenerates each
        icon in the button's own foreground colour when it detects a dark
        button background, so the glyphs must be re-rendered after recolouring
        or they stay black on black.
        """
        try:
            tb.configure(background=T["bg"])
        except tk.TclError:
            pass
        for child in tb.winfo_children():
            for opt, val in (("background", T["bg"]),
                             ("foreground", T["fg"]),
                             ("activebackground", T["panel"]),
                             ("activeforeground", T["fg"]),
                             ("selectcolor", T["panel"]),
                             ("highlightbackground", T["bg"]),
                             ("highlightcolor", T["border"]),
                             ("borderwidth", 1),
                             ("relief", "flat")):
                try:
                    child.configure(**{opt: val})
                except tk.TclError:
                    pass
            try:
                tb._set_image_for_button(child)     # re-render with new colours
            except Exception:
                pass
        for attr in ("_message_label", "message_label"):
            lbl = getattr(tb, attr, None)
            if lbl is not None:
                try:
                    lbl.configure(background=T["bg"], foreground=T["muted"])
                except tk.TclError:
                    pass

    # ------------------------------------------------------------ crosshair
    class Crosshair:
        """
        Igor-style crosshair. Dashed lines run the full width and height of
        the axes; a short solid cross marks the exact point. The vertical line
        is echoed in the residual panel, which shares the energy axis.

        Drawn by blitting so it stays responsive with twelve components on
        screen: the figure is cached once per draw and only the crosshair is
        redrawn as the pointer moves.
        """

        SOLID = 0.045          # half-length of the solid arms, in axes fraction

        def __init__(self, canvas, fig, readout=None):
            from matplotlib.lines import Line2D
            self._Line2D = Line2D
            self.canvas, self.fig = canvas, fig
            self.readout = readout
            self.enabled = True
            self.parts = {}
            self.bg = None
            canvas.mpl_connect("motion_notify_event", self._move)
            canvas.mpl_connect("figure_leave_event", self._leave)
            canvas.mpl_connect("draw_event", self._draw)

        def attach(self, axes):
            """(Re)create the artists. Must run after every axes clear."""
            self.parts = {}
            for ax in axes:
                common = dict(transform=ax.transAxes, color=T["cross"],
                              animated=True, visible=False, zorder=50)
                d = {
                    "v":  self._Line2D([0, 0], [0, 1], lw=0.8,
                                       ls=(0, (5, 4)), **common),
                    "h":  self._Line2D([0, 1], [0, 0], lw=0.8,
                                       ls=(0, (5, 4)), **common),
                    # same dash pattern as the long lines, just heavier, so
                    # the centre reads as emphasis rather than a different mark
                    "sv": self._Line2D([0, 0], [0, 0], lw=2.2,
                                       ls=(0, (5, 4)), **common),
                    "sh": self._Line2D([0, 0], [0, 0], lw=2.2,
                                       ls=(0, (5, 4)), **common),
                }
                for a in d.values():
                    ax.add_line(a)
                self.parts[ax] = d
            self.bg = None

        def _draw(self, _event):
            try:
                self.bg = self.canvas.copy_from_bbox(self.fig.bbox)
            except Exception:
                self.bg = None

        def _leave(self, _event):
            self._hide()

        def _hide(self):
            if not any(a.get_visible() for d in self.parts.values()
                       for a in d.values()):
                return
            for d in self.parts.values():
                for a in d.values():
                    a.set_visible(False)
            if self.readout:
                self.readout("")
            self._blit()

        def _move(self, event):
            if not self.enabled or not self.parts:
                return
            ax = event.inaxes
            if ax not in self.parts:
                self._hide()
                return
            # Work in axes fractions. Both panels span the same horizontal
            # extent, so one fraction places the vertical line in both.
            try:
                xa, ya = ax.transAxes.inverted().transform((event.x, event.y))
            except Exception:
                return
            f = self.SOLID
            for a, d in self.parts.items():
                here = (a is ax)
                d["v"].set_data([xa, xa], [0, 1]);      d["v"].set_visible(True)
                d["h"].set_data([0, 1], [ya, ya]);      d["h"].set_visible(here)
                d["sv"].set_data([xa, xa], [ya - f, ya + f])
                d["sv"].set_visible(here)
                d["sh"].set_data([xa - f, xa + f], [ya, ya])
                d["sh"].set_visible(here)
            self._blit()
            if self.readout and event.xdata is not None:
                self.readout(f"E = {event.xdata:.4f} eV     "
                             f"y = {event.ydata:.5g}")

        def _blit(self):
            if self.bg is None:
                self.canvas.draw_idle()
                return
            try:
                self.canvas.restore_region(self.bg)
                for ax, d in self.parts.items():
                    for a in d.values():
                        if a.get_visible():
                            ax.draw_artist(a)
                self.canvas.blit(self.fig.bbox)
            except Exception:
                self.canvas.draw_idle()

    # ----------------------------------------------------------------- utils
    class ScrollFrame(ttk.Frame):
        """A vertically scrollable container."""

        def __init__(self, parent, width=470, **kw):
            super().__init__(parent, **kw)
            self.canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0,
                                    width=width, background=T["bg"])
            vsb = ttk.Scrollbar(self, orient="vertical",
                                command=self.canvas.yview)
            self.canvas.configure(yscrollcommand=vsb.set)
            vsb.pack(side="right", fill="y")
            self.canvas.pack(side="left", fill="both", expand=True)
            self.body = ttk.Frame(self.canvas)
            self._win = self.canvas.create_window((0, 0), window=self.body,
                                                  anchor="nw")
            self.body.bind("<Configure>", lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")))
            self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(
                self._win, width=e.width))
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                self.canvas.bind_all(seq, self._wheel, add="+")

        def _wheel(self, event):
            w = self.winfo_containing(event.x_root, event.y_root)
            while w is not None:
                if w is self.canvas:
                    break
                w = getattr(w, "master", None)
            if w is None:
                return
            if getattr(event, "num", None) == 4:
                delta = -1
            elif getattr(event, "num", None) == 5:
                delta = 1
            else:
                delta = -1 if event.delta > 0 else 1
            self.canvas.yview_scroll(delta, "units")

    def fentry(parent, var, width=8, on_commit=None):
        e = ttk.Entry(parent, textvariable=var, width=width, justify="right")
        if on_commit is not None:
            e.bind("<Return>", lambda ev: on_commit())
            e.bind("<FocusOut>", lambda ev: on_commit())
        return e

    def getf(var, fallback=0.0):
        try:
            return float(str(var.get()).strip())
        except (ValueError, tk.TclError):
            return fallback

    # ------------------------------------------------------------------ app
    class App(ttk.Frame):

        def __init__(self, master, scale=1.0):
            super().__init__(master, padding=4)
            self.scale = float(scale)
            self.pack(fill="both", expand=True)
            master.title(APP_TITLE)

            # data state
            self.x = None
            self.y = None
            self.col_names = []
            self.raw = None
            self.data_path = ""
            self.last_dir = ""

            # model state
            self.p = default_params()
            self.p_saved = self.p.copy()          # Igor SP() / OldP()
            self.limits = dict(DEFAULT_LIMITS)
            self.last_fit = None
            self.pick_mode = False
            self.span = None
            # Fitting redraws the plot, and a redraw clears the axes, which
            # would throw away whatever you had zoomed in on. Limits are
            # carried across unless something has genuinely changed the data.
            self._autoscale_next = True
            self._drawn = False
            self._drag_src = None

            self._build_vars()
            self._build_menu()
            self._build_layout()
            self._sync_widgets_from_p()
            self.on_method()
            self._demo_data()
            self.replot()

        # ---------------------------------------------------------- variables
        def _build_vars(self):
            self.v_npeaks = tk.IntVar(value=4)
            self.v_mix = tk.StringVar(value="0.5")
            self.v_steppos = tk.StringVar(value="0")
            self.v_stepw = tk.StringVar(value="0.5")
            self.v_stepamp = tk.StringVar(value="1.0")
            self.f_mix = tk.BooleanVar(value=False)
            self.f_steppos = tk.BooleanVar(value=False)
            self.f_stepw = tk.BooleanVar(value=False)
            self.f_stepamp = tk.BooleanVar(value=True)   # Igor keeps this at 1

            self.pk_vars = []      # [ {field: StringVar} ]
            self.pk_fix = []       # [ {field: BooleanVar} ]
            for i in range(MAX_PEAKS):
                self.pk_vars.append({f: tk.StringVar(value="0")
                                     for f in PEAK_ROW_FIELDS})
                fx = {f: tk.BooleanVar(value=False) for f in PEAK_ROW_FIELDS}
                fx["gauss"].set(True)
                fx["skew"].set(True)        # sensible defaults: hold the
                fx["lwratio"].set(True)     # line-shape distortions
                self.pk_fix.append(fx)

            self.v_sample = tk.StringVar(value="")   # export base name
            self._auto_sample = ""
            self.v_xmin = tk.StringVar(value="")
            self.v_xmax = tk.StringVar(value="")
            self.v_xcol = tk.StringVar(value="")
            self.v_ycol = tk.StringVar(value="")
            self.v_weight = tk.StringVar(value="none")
            self.v_smooth = tk.IntVar(value=5)
            self.v_method = tk.StringVar(value=METHOD_LABELS["lm"])
            self.v_errmodel = tk.StringVar(value=ERROR_LABELS["scaled"])
            self.v_tol = tk.StringVar(value="1e-8  (SciPy default)")

            self.show_comp = tk.BooleanVar(value=True)
            self.show_step = tk.BooleanVar(value=True)
            self.show_total = tk.BooleanVar(value=True)
            self.show_fill = tk.BooleanVar(value=False)
            self.dark = tk.BooleanVar(value=True)
            self.show_cross = tk.BooleanVar(value=True)
            self.v_resmode = tk.StringVar(value="Total (fit - data)")
            self.v_respeak = tk.IntVar(value=1)
            self.status = tk.StringVar(value="Ready.")
            self.coord = tk.StringVar(value="")

        # --------------------------------------------------------------- menu
        def _build_menu(self):
            m = tk.Menu(self.master)
            style_menu(m)
            self.master.config(menu=m)

            fm = tk.Menu(m, tearoff=0)
            style_menu(fm)
            fm.add_command(label="Open data file...", command=self.open_data,
                           accelerator=_shortcut("o")[1])
            fm.add_separator()
            fm.add_command(label="Rebuild fit from files...",
                           command=self.rebuild_files_dlg)
            fm.add_command(label="Rebuild fit from folder...",
                           command=self.rebuild_folder_dlg)
            fm.add_separator()
            fm.add_command(label="Load session (JSON)...", command=self.load_session_dlg)
            fm.add_command(label="Save session (JSON)...", command=self.save_session_dlg)
            fm.add_separator()
            fm.add_command(label="Export to Igor: data + procedures (.itx)...",
                           command=self.export_igor_bundle)
            fm.add_separator()
            fm.add_command(label="Import Igor parameter wave (.itx)...",
                           command=self.import_itx)
            fm.add_command(label="Export Igor parameter wave, 63 (.itx)...",
                           command=self.export_itx)
            fm.add_command(label="Export parameter wave, 75 "
                                 "(Igor: ImportGedgfitP) (.itx)...",
                           command=lambda: self.export_itx(full=True))
            fm.add_separator()
            fm.add_command(label="Export components (CSV)...", command=self.export_csv)
            fm.add_command(label="Export report (txt)...", command=self.export_report)
            fm.add_command(label="Export figure...", command=self.export_figure)
            if not _mac():          # a Mac has Quit (Command-Q) in the app menu
                fm.add_separator()
                fm.add_command(label="Quit", command=self.master.destroy)
            m.add_cascade(label="File", menu=fm)

            tm = tk.Menu(m, tearoff=0)
            style_menu(tm)
            tm.add_command(label="Derivative viewer (find peak positions)...",
                           command=self.derivative_window)
            tm.add_command(label="Fit limits / bounds...", command=self.limits_window)
            tm.add_separator()
            tm.add_command(label="Guess peaks from 2nd derivative",
                           command=self.guess_peaks)
            tm.add_command(label="Estimate amplitudes from data",
                           command=self.auto_amplitudes)
            tm.add_command(label="Reset model", command=self.reset_model)
            m.add_cascade(label="Tools", menu=tm)

            hm = tk.Menu(m, tearoff=0)
            style_menu(hm)
            hm.add_command(label="Model reference", command=self.about_model)
            m.add_cascade(label="Help", menu=hm)

            self.master.bind(_shortcut("o")[0], lambda e: self.open_data())
            self.master.bind(_shortcut("f")[0], lambda e: self.do_fit())
            self.master.bind(_shortcut("u")[0], lambda e: self.replot())

        # ------------------------------------------------------------- layout
        def _build_layout(self):
            pane = ttk.PanedWindow(self, orient="horizontal")
            pane.pack(fill="both", expand=True)

            panel_w = int(PANEL_WIDTH * self.scale)
            left = ScrollFrame(pane, width=panel_w)
            pane.add(left, weight=0)
            right = ttk.Frame(pane)
            pane.add(right, weight=1)
            # A PanedWindow sizes its sash from the child's requested width,
            # which Tk has not computed yet. Set it explicitly once the
            # geometry manager has run, or the Refine row is clipped.
            self.master.after_idle(lambda: self._set_sash(pane, panel_w))

            c = left.body
            c.columnconfigure(0, weight=1)
            r = 0

            # ---- data ----
            g = ttk.LabelFrame(c, text="1.  Data", padding=6)
            g.grid(row=r, column=0, sticky="ew", padx=4, pady=3); r += 1
            ttk.Button(g, text="Open data file...", command=self.open_data)\
                .grid(row=0, column=0, columnspan=2, sticky="ew")
            self.lbl_file = ttk.Label(g, text="(demo spectrum)", width=44)
            self.lbl_file.grid(row=1, column=0, columnspan=4, sticky="w", pady=(3, 3))
            ttk.Label(g, text="Energy col").grid(row=2, column=0, sticky="w")
            self.cb_x = ttk.Combobox(g, textvariable=self.v_xcol, width=14,
                                     state="readonly")
            self.cb_x.grid(row=2, column=1, sticky="w")
            ttk.Label(g, text="Intensity col").grid(row=2, column=2, sticky="w",
                                                    padx=(8, 0))
            self.cb_y = ttk.Combobox(g, textvariable=self.v_ycol, width=14,
                                     state="readonly")
            self.cb_y.grid(row=2, column=3, sticky="w")
            self.cb_x.bind("<<ComboboxSelected>>", lambda e: self.apply_columns())
            self.cb_y.bind("<<ComboboxSelected>>", lambda e: self.apply_columns())

            ttk.Label(g, text="Fit range").grid(row=3, column=0, sticky="w", pady=(5, 0))
            fentry(g, self.v_xmin, 9, self.replot).grid(row=3, column=1, sticky="w", pady=(5, 0))
            fentry(g, self.v_xmax, 9, self.replot).grid(row=3, column=2, sticky="w", pady=(5, 0))
            ttk.Button(g, text="Full", width=5, command=self.full_range)\
                .grid(row=3, column=3, sticky="w", pady=(5, 0))
            ttk.Button(g, text="Drag a range on the plot to set it",
                       command=self.arm_span).grid(row=4, column=0, columnspan=4,
                                                   sticky="ew", pady=(4, 0))

            ttk.Label(g, text="Sample name").grid(row=5, column=0, sticky="w",
                                                  pady=(6, 0))
            ttk.Entry(g, textvariable=self.v_sample, width=22)\
                .grid(row=5, column=1, columnspan=2, sticky="ew", pady=(6, 0))
            self.lbl_base = ttk.Label(g, text="", style="Muted.TLabel")
            self.lbl_base.grid(row=6, column=0, columnspan=4, sticky="w")
            self.lbl_drop = ttk.Label(g, text="", style="Muted.TLabel")
            self.lbl_drop.grid(row=7, column=0, columnspan=4, sticky="w", pady=(4, 0))
            self.v_sample.trace_add("write", lambda *a: self._update_base_label())
            self.v_npeaks.trace_add("write", lambda *a: self._update_base_label())
            self._update_base_label()

            # ---- global / step ----
            g = ttk.LabelFrame(c, text="2.  Edge step and shared shape", padding=6)
            g.grid(row=r, column=0, sticky="ew", padx=4, pady=3); r += 1
            ttk.Label(g, text="", width=2).grid(row=0, column=0)
            ttk.Label(g, text="value").grid(row=0, column=1)
            ttk.Label(g, text="hold").grid(row=0, column=2)
            rows = [("Step Gaussian fraction", self.v_mix, self.f_mix),
                    ("Step position  E0", self.v_steppos, self.f_steppos),
                    ("Step half-width", self.v_stepw, self.f_stepw),
                    ("Step amplitude *", self.v_stepamp, self.f_stepamp)]
            for k, (lab, var, fx) in enumerate(rows, start=1):
                ttk.Label(g, text=lab).grid(row=k, column=0, sticky="w")
                fentry(g, var, 10, self.replot).grid(row=k, column=1, sticky="w", padx=3)
                ttk.Checkbutton(g, variable=fx).grid(row=k, column=2)
            ttk.Label(g, text="* not an Igor parameter; keep held at 1 for\n"
                              "   edge-jump normalised data.  The step's "
                              "Gaussian\n   fraction is now separate from the "
                              "peaks' -\n   set them per peak in the table "
                              "below.",
                      foreground="#666").grid(row=5, column=0, columnspan=3,
                                              sticky="w", pady=(2, 0))

            # ---- peaks ----
            g = ttk.LabelFrame(c, text="3.  Peaks", padding=6)
            g.grid(row=r, column=0, sticky="ew", padx=4, pady=3); r += 1
            top = ttk.Frame(g); top.grid(row=0, column=0, columnspan=12, sticky="w")
            ttk.Label(top, text="Number of peaks").pack(side="left")
            sp = ttk.Spinbox(top, from_=1, to=MAX_PEAKS, width=4,
                             textvariable=self.v_npeaks,
                             command=self.on_npeaks)
            sp.pack(side="left", padx=4)
            sp.bind("<Return>", lambda e: self.on_npeaks())
            sp.bind("<FocusOut>", lambda e: self.on_npeaks())
            ttk.Button(top, text="Guess positions", command=self.guess_peaks)\
                .pack(side="left", padx=2)
            self.btn_pick = ttk.Button(top, text="Click to place",
                                       command=self.toggle_pick)
            self.btn_pick.pack(side="left", padx=2)

            hdr = ["#"] + list(PEAK_ROW_LABELS)
            for cc, h in enumerate(hdr):
                ttk.Label(g, text=h, anchor="center").grid(
                    row=1, column=(0 if cc == 0 else 2 * cc - 1),
                    columnspan=(1 if cc == 0 else 2), pady=(4, 1))

            self.peak_widgets = []
            for i in range(MAX_PEAKS):
                lab = ttk.Label(g, text=str(i + 1), width=2, anchor="center",
                                foreground=PEAK_COLORS[i % len(PEAK_COLORS)],
                                cursor="fleur")
                lab.grid(row=2 + i, column=0)
                lab.bind("<Button-1>", lambda e, i=i: self._drag_start(i))
                lab.bind("<B1-Motion>", self._drag_motion)
                lab.bind("<ButtonRelease-1>", self._drag_drop)
                row_w = {"label": lab, "entries": {}, "checks": {}}
                for k, f in enumerate(PEAK_ROW_FIELDS):
                    e = fentry(g, self.pk_vars[i][f], 8, self.replot)
                    e.grid(row=2 + i, column=1 + 2 * k, padx=(2, 0), pady=1)
                    cb = ttk.Checkbutton(g, variable=self.pk_fix[i][f])
                    cb.grid(row=2 + i, column=2 + 2 * k)
                    row_w["entries"][f] = e
                    row_w["checks"][f] = cb
                self.peak_widgets.append(row_w)
            ttk.Button(g, text="Link all Gauss fractions to the step "
                                "(Igor behaviour)",
                       command=self.link_gauss).grid(row=3 + MAX_PEAKS, column=0,
                                                     columnspan=12, sticky="ew",
                                                     pady=(4, 0))
            ttk.Label(g, text="checkbox = hold parameter fixed during the fit\n"
                              "drag a row number to reorder the peaks",
                      style="Muted.TLabel", justify="left")\
                .grid(row=2 + MAX_PEAKS, column=0, columnspan=12, sticky="w",
                      pady=(3, 0))

            # ---- run ----
            g = ttk.LabelFrame(c, text="4.  Refine", padding=6)
            g.grid(row=r, column=0, sticky="ew", padx=4, pady=3); r += 1
            for _c in range(5):
                g.columnconfigure(_c, weight=1, uniform="refine")
            ttk.Button(g, text="Update plot", command=self.replot)\
                .grid(row=0, column=0, sticky="ew", padx=2)
            ttk.Button(g, text="FIT", command=self.do_fit, style="Accent.TButton")\
                .grid(row=0, column=1, sticky="ew", padx=2)
            ttk.Button(g, text="Evaluate", command=self.do_evaluate)\
                .grid(row=0, column=4, sticky="ew", padx=2)
            ttk.Button(g, text="Store params", command=self.store_params)\
                .grid(row=0, column=2, sticky="ew", padx=2)
            ttk.Button(g, text="Recall params", command=self.recall_params)\
                .grid(row=0, column=3, sticky="ew", padx=2)
            ttk.Label(g, text="Algorithm").grid(row=1, column=0, sticky="w",
                                                pady=(8, 0))
            cbm = ttk.Combobox(g, textvariable=self.v_method, width=34,
                               state="readonly",
                               values=[METHOD_LABELS[m] for m in METHODS])
            cbm.grid(row=1, column=1, columnspan=3, sticky="w", pady=(8, 0))
            cbm.bind("<<ComboboxSelected>>", lambda e: self.on_method())

            ttk.Label(g, text="Errors from").grid(row=2, column=0, sticky="w",
                                                  pady=(4, 0))
            ttk.Combobox(g, textvariable=self.v_errmodel, width=34,
                         state="readonly",
                         values=[ERROR_LABELS[m] for m in ERROR_MODELS]
                         ).grid(row=2, column=1, columnspan=3, sticky="w",
                                pady=(4, 0))

            ttk.Label(g, text="Weighting").grid(row=3, column=0, sticky="w",
                                                pady=(4, 0))
            ttk.Combobox(g, textvariable=self.v_weight, width=12, state="readonly",
                         values=("none", "poisson")).grid(row=3, column=1,
                                                          sticky="w", pady=(4, 0))
            ttk.Label(g, text="Stop at").grid(row=3, column=2, sticky="e",
                                              pady=(4, 0))
            ttk.Combobox(g, textvariable=self.v_tol, width=22, state="readonly",
                         values=list(TOLERANCES)).grid(row=3, column=3,
                                                       sticky="w", pady=(4, 0))
            self.lbl_method = ttk.Label(g, text="", style="Muted.TLabel",
                                        wraplength=430, justify="left")
            self.lbl_method.grid(row=4, column=0, columnspan=4, sticky="w",
                                 pady=(5, 0))

            # ---- display ----
            g = ttk.LabelFrame(c, text="5.  Display", padding=6)
            g.grid(row=r, column=0, sticky="ew", padx=4, pady=3); r += 1
            def _cross():
                self.crosshair.enabled = bool(self.show_cross.get())
                if not self.crosshair.enabled:
                    self.crosshair._hide()

            for k, (lab, var) in enumerate([("components", self.show_comp),
                                            ("step", self.show_step),
                                            ("total fit", self.show_total),
                                            ("shade peaks", self.show_fill),
                                            ("dark plot", self.dark),
                                            ("crosshair", self.show_cross)]):
                cmd = _cross if var is self.show_cross else self.replot
                ttk.Checkbutton(g, text=lab, variable=var,
                                command=cmd).grid(row=k // 3, column=k % 3,
                                                  sticky="w", padx=2)
            ttk.Button(g, text="Autoscale view", command=self.autoscale)\
                .grid(row=1, column=3, columnspan=2, sticky="ew", padx=2,
                      pady=(2, 0))

            ttk.Label(g, text="Lower panel").grid(row=2, column=0, sticky="w",
                                                  pady=(6, 0))
            cb = ttk.Combobox(g, textvariable=self.v_resmode, width=22,
                              state="readonly",
                              values=("Total (fit - data)",
                                      "Isolated peak (data - others)"))
            cb.grid(row=2, column=1, columnspan=2, sticky="w", pady=(6, 0))
            cb.bind("<<ComboboxSelected>>", lambda e: self.replot())
            ttk.Label(g, text="peak #").grid(row=3, column=0, sticky="w")
            ttk.Spinbox(g, from_=1, to=MAX_PEAKS, width=4,
                        textvariable=self.v_respeak,
                        command=self.replot).grid(row=3, column=1, sticky="w")

            # ---- report ----
            g = ttk.LabelFrame(c, text="6.  Fit report", padding=4)
            g.grid(row=r, column=0, sticky="nsew", padx=4, pady=3); r += 1
            self.txt = tk.Text(g, width=56, height=16, wrap="none",
                               font=_mono("Courier"),
                               background=THEME["field"], foreground=THEME["fg"],
                               insertbackground=THEME["fg"],
                               selectbackground=THEME["accent"],
                               selectforeground="#ffffff",
                               highlightthickness=1,
                               highlightbackground=THEME["border"],
                               highlightcolor=THEME["border"],
                               borderwidth=0)
            sb = ttk.Scrollbar(g, orient="vertical", command=self.txt.yview)
            sb.pack(side="right", fill="y")
            self.txt.pack(side="left", fill="both", expand=True)
            self.txt.configure(yscrollcommand=sb.set)

            # ---- figure ----
            self.fig = Figure(figsize=(7.6, 7.0), dpi=int(100 * self.scale))
            gs = self.fig.add_gridspec(3, 1, hspace=0.06)
            self.ax = self.fig.add_subplot(gs[0:2, 0])
            self.axr = self.fig.add_subplot(gs[2, 0], sharex=self.ax)
            self.canvas = FigureCanvasTkAgg(self.fig, master=right)
            self.canvas.get_tk_widget().configure(background=THEME["plot_bg"],
                                                  highlightthickness=0)
            self.canvas.get_tk_widget().pack(fill="both", expand=True)
            self.toolbar = NavigationToolbar2Tk(self.canvas, right)
            self.toolbar.update()
            style_toolbar(self.toolbar)
            self.canvas.mpl_connect("button_press_event", self.on_click)

            self.crosshair = Crosshair(self.canvas, self.fig,
                                       readout=self.coord.set)
            self.install_resize_debounce()


            # Zoom-to-rectangle armed from the start, so dragging on the plot
            # zooms without having to reach for the toolbar first.
            self.master.after(150, self.arm_zoom)

            bar = ttk.Frame(self)
            bar.pack(fill="x", side="bottom")
            ttk.Label(bar, textvariable=self.status, relief="sunken",
                      anchor="w").pack(side="left", fill="x", expand=True)
            ttk.Label(bar, textvariable=self.coord, relief="sunken",
                      anchor="e", width=32,
                      font=_mono("Courier")).pack(side="right")

        # ------------------------------------------------- widget <-> vector
        # A box shows a rounded number, but the parameter behind it keeps full
        # precision. Reading the boxes back verbatim would truncate every
        # parameter to six figures on each fit, so a converged model would
        # keep drifting slightly each time FIT was pressed and could never
        # settle. A box is only read when its text no longer matches the
        # stored value at display precision, i.e. when you have edited it.
        def row_index(self, i, field):
            """Full-vector index for a cell of the peak table."""
            return peak_base(i) + PEAK_FIELDS.index(field)

        def link_gauss(self):
            self._sync_p_from_widgets()
            self.p = link_mixes(self.p)
            self._sync_widgets_from_p()
            self.replot()
            self.status.set(f"All peak Gaussian fractions set to the step's "
                            f"({self.p[0]:g}) - this is how Igor behaves.")

        def _fmt(self, idx):
            if idx == 0:
                return f"{self.p[0]:.5g}"
            if idx == 2:
                return f"{self.p[2]:.5g}"
            return f"{self.p[idx]:.6g}"

        def _take(self, var, idx, fallback):
            text = str(var.get()).strip()
            if text == self._fmt(idx):
                return self.p[idx]          # untouched, keep full precision
            return getf(var, fallback)

        def _sync_widgets_from_p(self):
            self.v_mix.set(self._fmt(0))
            self.v_steppos.set(self._fmt(1))
            self.v_stepw.set(self._fmt(2))
            for i in range(MAX_PEAKS):
                b = peak_base(i)
                for f in PEAK_ROW_FIELDS:
                    self.pk_vars[i][f].set(self._fmt(self.row_index(i, f)))
            self.on_npeaks()

        def _sync_p_from_widgets(self):
            new = self.p.copy()
            new[0] = self._take(self.v_mix, 0, 0.5)
            new[1] = self._take(self.v_steppos, 1, 0.0)
            new[2] = self._take(self.v_stepw, 2, 0.5)
            for i in range(MAX_PEAKS):
                for f in PEAK_ROW_FIELDS:
                    j = self.row_index(i, f)
                    new[j] = self._take(self.pk_vars[i][f], j, 0.0)
            self.p = new
            return self.p

        def fixed_mask(self):
            m = np.zeros(FULL_LEN, dtype=bool)
            m[0] = self.f_mix.get()
            m[1] = self.f_steppos.get()
            m[2] = self.f_stepw.get()
            for i in range(MAX_PEAKS):
                b = peak_base(i)
                for f in PEAK_ROW_FIELDS:
                    m[self.row_index(i, f)] = self.pk_fix[i][f].get()
            return m

        def method(self):
            for k, v in METHOD_LABELS.items():
                if v == self.v_method.get():
                    return k
            return "trf"

        def tolerance(self):
            return TOLERANCES.get(self.v_tol.get(), DEFAULT_TOL)

        def error_model(self):
            for k, v in ERROR_LABELS.items():
                if v == self.v_errmodel.get():
                    return k
            return "scaled"

        def on_method(self):
            if self.method() == "lm":
                self.lbl_method.configure(
                    text="Levenberg-Marquardt matches Igor's FuncFit, and like "
                         "it runs unconstrained: the fit limits are ignored. "
                         "Held parameters are still held.")
            else:
                self.lbl_method.configure(
                    text="Bounded fit. Parameters stay inside the limits set "
                         "under Tools > Fit limits.")

        def install_resize_debounce(self, delay=RESIZE_DELAY_MS):
            """
            Coalesce window-resize events.

            Matplotlib binds <Configure> straight to its own resize handler,
            which reallocates the canvas image and redraws the whole figure.
            Dragging a window edge fires that dozens of times a second, and
            with twelve components on screen the redraws cannot keep up, so
            the whole interface stutters.

            Here the events are collected and only the last one is acted on,
            once the drag has been still for `delay` ms. During the drag the
            previous image simply stays put, then snaps to the new size.
            """
            widget = self.canvas.get_tk_widget()
            original = self.canvas.resize
            widget.unbind("<Configure>")
            state = {"job": None, "event": None}

            def flush():
                state["job"] = None
                ev, state["event"] = state["event"], None
                if ev is None:
                    return
                try:
                    original(ev)
                except Exception:
                    pass

            def on_configure(event):
                state["event"] = event
                if state["job"] is not None:
                    try:
                        widget.after_cancel(state["job"])
                    except Exception:
                        pass
                state["job"] = widget.after(delay, flush)

            widget.bind("<Configure>", on_configure)
            self._resize_state = state

        def _reset_nav_stack(self):
            """Make the current view the one the toolbar's Home button returns
            to. Without this, Home restores limits from a cleared axes."""
            try:
                self.toolbar.update()
                self.arm_zoom()          # update() drops the active mode
            except Exception:
                pass

        def autoscale(self):
            """Rescale both panels to show everything in the fit range."""
            self._autoscale_next = True
            self.replot()
            self.status.set("View rescaled to the full fit range.")

        def arm_zoom(self):
            """Put the toolbar into zoom-to-rectangle mode."""
            try:
                if "zoom" not in str(getattr(self.toolbar, "mode", "")).lower():
                    self.toolbar.zoom()
            except Exception:
                pass

        def smoothing(self):
            try:
                return max(0, int(self.v_smooth.get()))
            except (tk.TclError, ValueError):
                return 5

        def _set_sash(self, pane, pos, tries=40):
            """
            Place the split explicitly.

            A ttk PanedWindow ignores sashpos until it has been laid out, and
            at after_idle time it is still one pixel wide, so the call is
            silently dropped. Retry until the pane has a real width.
            """
            try:
                if pane.winfo_width() < pos + 60:
                    if tries > 0:
                        pane.after(40, lambda: self._set_sash(pane, pos, tries - 1))
                    return
                if abs(pane.sashpos(0) - pos) > 2:
                    pane.sashpos(0, pos)
            except Exception:
                pass

        def npeaks(self):
            try:
                n = int(self.v_npeaks.get())
            except (tk.TclError, ValueError):
                n = 1
            return min(max(n, 1), MAX_PEAKS)

        # ---------------------------------------------------- reorder peaks
        def _row_at(self, y_root):
            """Which peak row is the pointer nearest, vertically."""
            n = self.npeaks()
            best, best_d = 0, None
            for i in range(n):
                lab = self.peak_widgets[i]["label"]
                centre = lab.winfo_rooty() + lab.winfo_height() / 2.0
                d = abs(y_root - centre)
                if best_d is None or d < best_d:
                    best, best_d = i, d
            return best

        def _highlight_row(self, i, on):
            lab = self.peak_widgets[i]["label"] if 0 <= i < MAX_PEAKS else None
            if lab is None:
                return
            try:
                lab.configure(background=THEME["accent"] if on else "")
            except tk.TclError:
                pass

        def _drag_start(self, i):
            if i >= self.npeaks():
                return
            self._drag_src = i
            self._drag_dst = i
            self._highlight_row(i, True)
            self.status.set(f"Moving peak {i + 1} - drop it on the row it "
                            f"should take.")

        def _drag_motion(self, event):
            if self._drag_src is None:
                return
            dst = self._row_at(event.y_root)
            if dst != self._drag_dst:
                self._highlight_row(self._drag_dst, False)
                self._drag_dst = dst
                self._highlight_row(dst, True)
                if dst == self._drag_src:
                    self.status.set(f"Moving peak {self._drag_src + 1} - "
                                    f"back where it started.")
                else:
                    self.status.set(f"Moving peak {self._drag_src + 1} "
                                    f"to position {dst + 1}.")

        def _drag_drop(self, event):
            if self._drag_src is None:
                return
            src = self._drag_src
            dst = self._row_at(event.y_root)
            self._highlight_row(self._drag_dst, False)
            self._highlight_row(src, False)
            self._drag_src = None
            if dst == src:
                self.status.set("Peak order unchanged.")
                return
            self.move_peak(src, dst)

        def move_peak(self, src, dst):
            """
            Move a peak to another position in the table.

            The widgets stay where they are; the values move between them,
            carrying their hold checkboxes along. Row colours belong to the
            row, so a moved peak takes on the colour of its new position.
            """
            n = self.npeaks()
            if not (0 <= src < n and 0 <= dst < n) or src == dst:
                return
            # Move the stored numbers, not the text in the boxes: the boxes
            # show six figures, so shuffling their contents would quietly
            # round every parameter each time you reordered the table.
            self._sync_p_from_widgets()
            blocks = [self.p[peak_base(i):peak_base(i) + PARAMS_PER_PEAK].copy()
                      for i in range(n)]
            held = [{f: self.pk_fix[i][f].get() for f in PEAK_ROW_FIELDS}
                    for i in range(n)]
            blocks.insert(dst, blocks.pop(src))
            held.insert(dst, held.pop(src))
            for i in range(n):
                self.p[peak_base(i):peak_base(i) + PARAMS_PER_PEAK] = blocks[i]
                for f in PEAK_ROW_FIELDS:
                    self.pk_fix[i][f].set(held[i][f])
            self._sync_widgets_from_p()
            self.replot()
            self.status.set(f"Peak {src + 1} moved to position {dst + 1}.")

        def on_npeaks(self):
            n = self.npeaks()
            for i, w in enumerate(self.peak_widgets):
                st = "normal" if i < n else "disabled"
                for f in PEAK_ROW_FIELDS:
                    w["entries"][f].configure(state=st)
                    w["checks"][f].configure(state=st)
            self.replot()

        # ------------------------------------------------------------- data
        def _demo_data(self):
            """A synthetic C K-edge so the window is never empty on launch."""
            x = np.linspace(280.0, 300.0, 500)
            p = default_params()
            p[0], p[1], p[2] = 0.5, 289.5, 0.8
            for i, (a, c, w) in enumerate([(0.55, 285.1, 0.35),
                                           (0.30, 286.6, 0.45),
                                           (0.45, 288.3, 0.55),
                                           (0.60, 292.0, 1.60)]):
                b = peak_base(i)
                p[b:b + 5] = [a, c, w, 0.0, 1.0]
            rng = np.random.default_rng(3)
            self.x = x
            self.y = model_total(x, p, 4) + rng.normal(0, 0.006, x.size)
            self.col_names = ["energy", "intensity"]
            self.raw = np.column_stack([self.x, self.y])
            self.cb_x.configure(values=self.col_names)
            self.cb_y.configure(values=self.col_names)
            self.v_xcol.set("energy"); self.v_ycol.set("intensity")
            self.full_range()
            self.p = p.copy()
            self.p[0] = 0.5
            for i in range(4):
                b = peak_base(i)
                self.p[b + 0] *= 0.8
                self.p[b + 2] = 0.5
            self.v_npeaks.set(4)
            self._sync_widgets_from_p()

        def open_data(self):
            fn = filedialog.askopenfilename(
                title="Open XAS data",
                initialdir=self._dialog_dir(),
                filetypes=[("Data files", "*.txt *.dat *.csv *.xy *.itx *.awav *.asc "
                                          "*.pxp *.ibw"),
                           ("All files", "*")])
            if not fn:
                return
            try:
                names, data = read_columns(fn)
            except Exception as exc:
                messagebox.showerror("Could not read file", str(exc))
                return
            if data.shape[1] < 2:
                messagebox.showerror("Could not read file",
                                     "At least two columns are required.")
                return
            self._set_data(names, data, self._remember(fn))
            self.full_range()
            self._auto_fill_sample()
            self.status.set(f"Loaded {fn}")

        def _set_data(self, names, data, path, xcol=None, ycol=None):
            """Install a table of columns as the current data."""
            names = list(names)
            self.data_path = path
            self.col_names, self.raw = names, np.asarray(data, dtype=float)
            self.lbl_file.configure(text=f"{os.path.basename(path)}   "
                                         f"({self.raw.shape[0]} pts, "
                                         f"{self.raw.shape[1]} cols)")
            self.cb_x.configure(values=names)
            self.cb_y.configure(values=names)
            gx, gy = _guess_xy(names) if len(names) > 1 else (names[0], names[0])
            self.v_xcol.set(xcol if xcol in names else gx)
            self.v_ycol.set(ycol if ycol in names else gy)
            self.apply_columns()

        def apply_columns(self):
            if self.raw is None:
                return
            try:
                ix = self.col_names.index(self.v_xcol.get())
                iy = self.col_names.index(self.v_ycol.get())
            except ValueError:
                return
            x = self.raw[:, ix].astype(float)
            y = self.raw[:, iy].astype(float)
            good = np.isfinite(x) & np.isfinite(y)
            order = np.argsort(x[good])
            self.x, self.y = x[good][order], y[good][order]
            self._autoscale_next = True
            self.replot()

        def full_range(self):
            if self.x is None:
                return
            self.v_xmin.set(f"{self.x.min():.6g}")
            self.v_xmax.set(f"{self.x.max():.6g}")
            self._autoscale_next = True
            self.replot()

        def fit_slice(self):
            lo = getf(self.v_xmin, -np.inf)
            hi = getf(self.v_xmax, np.inf)
            if hi < lo:
                lo, hi = hi, lo
            m = (self.x >= lo) & (self.x <= hi)
            if m.sum() < 5:
                m = np.ones_like(self.x, dtype=bool)
            return self.x[m], self.y[m], m

        def arm_span(self):
            self.status.set("Drag across the top plot to set the fit range.")

            def on_select(a, b):
                self.v_xmin.set(f"{min(a, b):.6g}")
                self.v_xmax.set(f"{max(a, b):.6g}")
                self.status.set(f"Fit range {min(a,b):.4g} - {max(a,b):.4g}")
                self.span.set_active(False)
                self.replot()

            try:
                self.span = SpanSelector(self.ax, on_select, "horizontal",
                                         useblit=False, interactive=False,
                                         props=dict(alpha=0.2, facecolor="tab:blue"))
            except TypeError:            # matplotlib < 3.5
                self.span = SpanSelector(self.ax, on_select, "horizontal",
                                         useblit=False,
                                         rectprops=dict(alpha=0.2,
                                                        facecolor="tab:blue"))
            self.span.set_active(True)

        # -------------------------------------------------------- peak setup
        def toggle_pick(self):
            self.pick_mode = not self.pick_mode
            self.btn_pick.configure(text="Click to place *ON*" if self.pick_mode
                                    else "Click to place")
            self.status.set("Click the plot to set peak positions in order."
                            if self.pick_mode else "Placement off.")
            self._pick_i = 0

        def on_click(self, event):
            if not self.pick_mode or event.inaxes is not self.ax:
                return
            if event.xdata is None:
                return
            i = getattr(self, "_pick_i", 0)
            n = self.npeaks()
            if i >= n:
                i = 0
            self.pk_vars[i]["position"].set(f"{event.xdata:.4g}")
            if getf(self.pk_vars[i]["width"], 0) <= 0:
                self.pk_vars[i]["width"].set("0.5")
            if getf(self.pk_vars[i]["lwratio"], 0) <= 0:
                self.pk_vars[i]["lwratio"].set("1")
            self._pick_i = i + 1
            self.auto_amplitudes(quiet=True)
            self.status.set(f"Peak {i+1} placed at {event.xdata:.4g}. "
                            f"Next click sets peak {min(self._pick_i, n-1)+1}.")
            self.replot()

        def guess_peaks(self):
            if self.x is None:
                return
            x, y, _ = self.fit_slice()
            n = self.npeaks()
            pos = suggest_peaks(x, y, n, smooth_passes=self.smoothing())
            if not pos:
                self.status.set("No clear 2nd-derivative minima found.")
                return
            for i, c in enumerate(pos[:n]):
                self.pk_vars[i]["position"].set(f"{c:.4g}")
                if getf(self.pk_vars[i]["width"], 0) <= 0:
                    self.pk_vars[i]["width"].set("0.5")
                if getf(self.pk_vars[i]["lwratio"], 0) <= 0:
                    self.pk_vars[i]["lwratio"].set("1")
            if getf(self.v_stepw, 0) <= 0:
                self.v_stepw.set("0.5")
            if getf(self.v_steppos) == 0:
                self.v_steppos.set(f"{np.mean(x):.5g}")
            self.auto_amplitudes(quiet=True)
            self.status.set(f"Placed {min(n, len(pos))} peaks from the 2nd derivative.")
            self.replot()

        def auto_amplitudes(self, quiet=False):
            """Peel intensity off the data at each centre, above the step."""
            if self.x is None:
                return
            self._sync_p_from_widgets()
            x, y, _ = self.fit_slice()
            n = self.npeaks()
            amp = getf(self.v_stepamp, 1.0)
            resid = y - component_step(x, self.p, amp)
            for i in range(n):
                c = getf(self.pk_vars[i]["position"], 0.0)
                j = int(np.argmin(np.abs(x - c)))
                a = max(float(resid[j]), 0.0)
                self.pk_vars[i]["amplitude"].set(f"{a:.4g}")
                b = peak_base(i)
                self.p[b] = a
                resid = resid - component_peak(x, self.p, i)
            if not quiet:
                self.status.set("Amplitudes estimated from the data.")
                self.replot()

        def reset_model(self):
            self.p = default_params()
            if self.x is not None:
                self.p[1] = float(np.mean(self.x))
            self._sync_widgets_from_p()
            self._autoscale_next = True
            self.replot()

        def store_params(self):
            self.p_saved = self._sync_p_from_widgets().copy()
            self.status.set("Parameters stored (Igor SP).")

        def recall_params(self):
            self.p = self.p_saved.copy()
            self._sync_widgets_from_p()
            self.status.set("Stored parameters recalled (Igor OldP).")
            self.replot()

        # ---------------------------------------------------------------- fit
        def do_fit(self):
            if self.x is None:
                return
            self._sync_p_from_widgets()
            x, y, _ = self.fit_slice()
            n = self.npeaks()
            try:
                res = fit_spectrum(
                    x, y, self.p, n, self.fixed_mask(),
                    step_amp=getf(self.v_stepamp, 1.0),
                    fit_step_amp=not self.f_stepamp.get(),
                    limits=self.limits,
                    weight_mode=self.v_weight.get(),
                    method=self.method(),
                    error_model=self.error_model(),
                    tol=self.tolerance())
            except Exception as exc:
                messagebox.showerror("Fit failed", str(exc))
                self.status.set(f"Fit failed: {exc}")
                return
            self.p_saved = self.p.copy()          # implicit SP before overwriting
            self.p = res.p
            self.v_stepamp.set(f"{res.step_amp:.6g}")
            self.last_fit = res
            self._sync_widgets_from_p()
            self.write_report(res, n)
            self.status.set(f"Fit done: reduced chi2 = {res.red_chi2:.4g}, "
                            f"R2 = {res.r2:.6f}  ({res.nfev} evaluations)")
            self.replot()

        def do_evaluate(self):
            """Chi-square at the current parameters, without moving them.

            Use this to check the program against Igor: put the same
            parameters into both and compare chi-square. Agreement confirms
            the model and objective function match on your own data."""
            if self.x is None:
                return
            self._sync_p_from_widgets()
            x, y, _ = self.fit_slice()
            n = self.npeaks()
            n_free = int(np.sum(~self.fixed_mask()[:peak_base(n)])) \
                + (0 if self.f_stepamp.get() else 1)
            st = evaluate(x, y, self.p, n, getf(self.v_stepamp, 1.0),
                          self.v_weight.get(), n_free=n_free)
            L = ["EVALUATION ONLY - no parameters were changed", "",
                 f"data      : {self.data_path or 'demo spectrum'}",
                 f"range     : {self.v_xmin.get()} to {self.v_xmax.get()}"
                 f"   ({st['n_points']} points)",
                 f"peaks     : {n}      weighting: {self.v_weight.get()}",
                 f"free      : {n_free}      dof: {st['dof']}",
                 "",
                 f"chi2      : {st['chi2']:.8g}",
                 f"red. chi2 : {st['red_chi2']:.8g}",
                 f"R^2       : {st['r2']:.8f}",
                 f"RMS resid : {st['rms']:.8g}",
                 "",
                 ]
            ignored = [i + 1 for i in range(n, MAX_PEAKS)
                       if abs(self.p[peak_base(i)]) > 0]
            if ignored:
                L += ["!  Peak(s) " + ", ".join(str(i) for i in ignored) +
                      " carry a non-zero amplitude but sit beyond the",
                      "!  peak count of " + str(n) + ", so they are not in the "
                      "model. If Igor",
                      "!  was fitting them, raise the peak count.", ""]
            L += [
                 "Compare chi2 against Igor's V_chisq for the same parameters",
                 "and the same fit range. Igor's V_chisq is unweighted unless",
                 "you gave FuncFit a weight wave, so leave weighting at none."]
            self.txt.delete("1.0", "end")
            self.txt.insert("1.0", "\n".join(L))
            self.status.set(f"Evaluated at current parameters: chi2 = "
                            f"{st['chi2']:.6g}, R2 = {st['r2']:.6f}")
            self.replot()

        def report_text(self, res, n):
            L = []
            L.append(f"data      : {self.data_path or 'demo spectrum'}")
            L.append(f"range     : {self.v_xmin.get()} to {self.v_xmax.get()}")
            L.append(f"peaks     : {n}      weighting: {self.v_weight.get()}")
            L.append(f"algorithm : {METHOD_LABELS[res.method]}")
            L.append(f"errors    : {ERROR_LABELS[res.error_model]}")
            L.append(f"bounds    : {'applied' if res.bounds_applied else 'not applied'}")
            L.append(f"stop at   : {getattr(res, 'tol', DEFAULT_TOL):g}")
            L.append(f"converged : {res.success}   ({res.message.strip()})")
            gain = getattr(res, "gain", 0.0)
            L.append(f"chi2      : {getattr(res, 'chi2_start', float('nan')):.6g}"
                     f"  ->  {res.chi2:.6g}")
            L.append(f"            improved by {100 * gain:.4f} %"
                     f"   in {res.nfev} evaluations")
            L.append(f"red. chi2 : {res.red_chi2:.6g}   "
                     f"({getattr(res, 'n_free', 0)} free, "
                     f"{getattr(res, 'dof', 0)} dof)")
            L.append(f"R^2       : {res.r2:.6f}")
            for note in getattr(res, "notes", []):
                L.append("")
                first = True
                words, line = note.split(), "  ! "
                for wd in words:
                    if len(line) + len(wd) > 60:
                        L.append(line); line = "    " + wd
                    else:
                        line = line + ("" if first else " ") + wd
                        first = False
                L.append(line)
            L.append("")
            L.append(f"{'parameter':<22}{'value':>13}{'std. err':>13}")
            L.append("-" * 48)

            def line(name, idx):
                e = res.errors[idx]
                es = f"{'(held)':>13}" if np.isnan(e) else f"{e:13.5g}"
                L.append(f"{name:<22}{res.p[idx]:13.6g}{es}")

            line("Gaussian fraction", 0)
            line("step position", 1)
            line("step half-width", 2)
            sa = getattr(res, "step_amp_err", np.nan)
            L.append(f"{'step amplitude':<22}{res.step_amp:13.6g}"
                     + (f"{'(held)':>13}" if np.isnan(sa) else f"{sa:13.5g}"))
            for i in range(n):
                L.append("")
                b = peak_base(i)
                for k, f in enumerate(PEAK_FIELDS):
                    line(f"peak {i+1} {PEAK_LABELS[k]}", b + k)
                a_an = peak_area(res.p, i)
                a_er = peak_area_error(res, i)
                if np.isnan(a_an):
                    L.append(f"{'  area (numeric)':<22}"
                             f"{self.peak_area(i):13.6g}"
                             f"{'  skewed':>13}")
                else:
                    L.append(f"{'  area':<22}{a_an:13.6g}"
                             + (f"{a_er:13.5g}" if np.isfinite(a_er)
                                else f"{'-':>13}"))
                    L.append(f"{'  area (numeric)':<22}"
                             f"{self.peak_area(i):13.6g}")
            areas = [peak_area(res.p, i) for i in range(n)]
            if not any(np.isnan(a) for a in areas):
                tot = float(np.sum(areas))
                L.append("")
                L.append(f"{'total peak area':<22}{tot:13.6g}")
                L.append("  share: " + "  ".join(
                    f"{i+1}:{100*areas[i]/tot:.1f}%" for i in range(n))
                    if tot else "")
            return "\n".join(L)

        def write_report(self, res, n):
            self.txt.delete("1.0", "end")
            self.txt.insert("1.0", self.report_text(res, n))

        def peak_area(self, i):
            if self.x is None:
                return float("nan")
            x, _, _ = self.fit_slice()
            xf = np.linspace(x.min(), x.max(), max(2000, x.size))
            return float(np.trapezoid(component_peak(xf, self.p, i), xf)) \
                if hasattr(np, "trapezoid") else \
                float(np.trapz(component_peak(xf, self.p, i), xf))

        # --------------------------------------------------------------- plot
        def replot(self, *_):
            if self.x is None:
                return
            self._sync_p_from_widgets()
            n = self.npeaks()
            amp = getf(self.v_stepamp, 1.0)
            x, y, mask = self.fit_slice()

            keep = None
            if self._drawn and not self._autoscale_next:
                keep = (self.ax.get_xlim(), self.ax.get_ylim(),
                        self.axr.get_ylim())

            fg = THEME["fg"] if self.dark.get() else "#222222"
            bg = THEME["plot_bg"] if self.dark.get() else "#ffffff"
            grid = "#2a3140" if self.dark.get() else "#d8d8d8"
            self.fig.set_facecolor(bg)
            for a in (self.ax, self.axr):
                a.clear()
                a.set_facecolor(bg)
                for s in a.spines.values():
                    s.set_color(fg)
                a.tick_params(colors=fg, which="both")
                a.yaxis.label.set_color(fg)
                a.xaxis.label.set_color(fg)
                a.grid(True, color=grid, lw=0.6, alpha=0.55)
                a.set_axisbelow(True)

            xf = np.linspace(x.min(), x.max(), max(1200, x.size))
            stp, peaks, total = all_components(xf, self.p, n, amp)

            self.ax.plot(self.x, self.y, ls="none", marker="o", ms=3,
                         mfc="none", mec=fg, alpha=0.55, label="data")
            self.ax.plot(x, y, ls="none", marker="o", ms=3.4,
                         color=fg, label="data (fit range)")
            if self.show_step.get():
                self.ax.plot(xf, stp, color="#ff8c1a", lw=1.4, ls="--", label="step")
            if self.show_comp.get():
                for i, pk in enumerate(peaks):
                    col = PEAK_COLORS[i % len(PEAK_COLORS)]
                    self.ax.plot(xf, pk, color=col, lw=1.3, label=f"peak {i+1}")
                    if self.show_fill.get():
                        self.ax.fill_between(xf, 0, pk, color=col, alpha=0.18)
            if self.show_total.get():
                self.ax.plot(xf, total, color="#d62728", lw=1.9, label="total fit")

            lo, hi = getf(self.v_xmin, x.min()), getf(self.v_xmax, x.max())
            if self.x.min() < lo or self.x.max() > hi:
                self.ax.axvspan(self.x.min(), lo, color="0.5", alpha=0.12, lw=0)
                self.ax.axvspan(hi, self.x.max(), color="0.5", alpha=0.12, lw=0)

            self.ax.set_ylabel("Normalized intensity", color=fg)
            self.ax.legend(fontsize=7, ncol=3, framealpha=0.25,
                           labelcolor=fg, facecolor=bg, edgecolor=fg)
            self.ax.tick_params(labelbottom=False)

            # lower panel
            mode = self.v_resmode.get()
            if mode.startswith("Total"):
                fitv = model_total(x, self.p, n, amp)
                self.axr.plot(x, fitv - y, color="#8f6fd0", lw=1.2)
                self.axr.axhline(0, color=fg, lw=0.8, ls=":")
                self.axr.set_ylabel("fit - data", color=fg)
                rms = float(np.sqrt(np.mean((fitv - y) ** 2)))
                self.axr.text(0.99, 0.9, f"RMS {rms:.4g}", ha="right", va="top",
                              transform=self.axr.transAxes, color=fg, fontsize=8)
            else:
                try:
                    sel = int(self.v_respeak.get())
                except (tk.TclError, ValueError):
                    sel = 1
                i = min(max(sel, 1), max(n, 1)) - 1
                iso = isolated_peak_residual(x, y, self.p, n, i, amp)
                col = PEAK_COLORS[i % len(PEAK_COLORS)]
                self.axr.plot(x, iso, ls="none", marker="o", ms=3,
                              color=fg, alpha=0.6, label=f"data - others")
                self.axr.plot(xf, peaks[i] if i < len(peaks) else np.zeros_like(xf),
                              color=col, lw=1.6, label=f"peak {i+1}")
                self.axr.axhline(0, color=fg, lw=0.8, ls=":")
                self.axr.set_ylabel(f"isolated peak {i+1}", color=fg)
                self.axr.legend(fontsize=7, framealpha=0.25, labelcolor=fg,
                                facecolor=bg, edgecolor=fg)

            if keep is not None:
                self.ax.set_xlim(keep[0])
                self.ax.set_ylim(keep[1])
                self.axr.set_ylim(keep[2])
            else:
                # a fresh scaling becomes the toolbar's new Home view
                self._autoscale_next = False
                self._drawn = True
                self.master.after_idle(self._reset_nav_stack)

            self.axr.set_xlabel("Energy (eV)", color=fg)
            self.fig.subplots_adjust(left=0.11, right=0.985, top=0.985,
                                     bottom=0.075, hspace=0.07)
            # the axes were cleared, so the crosshair artists are gone
            self.crosshair.attach((self.ax, self.axr))
            self.canvas.draw_idle()

        # ------------------------------------------------------------- tools
        def derivative_window(self):
            if self.x is None:
                return
            win = tk.Toplevel(self.master)
            win.title("Derivative viewer - locate transitions")
            bar = ttk.Frame(win, padding=4); bar.pack(fill="x")
            ttk.Label(bar, text="Smoothing passes").pack(side="left")
            sv = tk.IntVar(value=self.smoothing())
            ttk.Spinbox(bar, from_=0, to=50, width=5, textvariable=sv,
                        command=lambda: draw()).pack(side="left", padx=4)
            ttk.Button(bar, text="Redraw", command=lambda: draw()).pack(side="left")
            ttk.Button(bar, text="Send positions to peak table",
                       command=lambda: send()).pack(side="left", padx=6)

            fig = Figure(figsize=(7.5, 5.4), dpi=int(100 * self.scale))
            ax1 = fig.add_subplot(211)
            ax2 = fig.add_subplot(212, sharex=ax1)
            cv = FigureCanvasTkAgg(fig, master=win)
            cv.get_tk_widget().pack(fill="both", expand=True)
            NavigationToolbar2Tk(cv, win).update()

            def _sv():
                try:
                    return max(0, int(sv.get()))
                except (tk.TclError, ValueError):
                    return 5

            def draw():
                x, y, _ = self.fit_slice()
                ys, d1, d2 = derivatives(x, y, _sv())
                ax1.clear(); ax2.clear()
                ax1.plot(x, y, ".", ms=3, color="0.55", label="data")
                ax1.plot(x, ys, "-", lw=1.4, color="k", label="smoothed")
                ax1.legend(fontsize=8); ax1.set_ylabel("intensity")
                ax1.tick_params(labelbottom=False)
                ax2.axhline(0, color="0.6", lw=0.8)
                ax2.plot(x, d1 / (np.max(np.abs(d1)) or 1), lw=1.2,
                         color="#00a05a", label="1st derivative (scaled)")
                ax2.plot(x, d2 / (np.max(np.abs(d2)) or 1), lw=1.2,
                         color="#3f7fd0", label="2nd derivative (scaled)")
                for c in suggest_peaks(x, y, self.npeaks(), _sv()):
                    ax2.axvline(c, color="#d62728", ls=":", lw=1)
                    ax1.axvline(c, color="#d62728", ls=":", lw=1)
                ax2.legend(fontsize=8); ax2.set_xlabel("Energy (eV)")
                ax2.set_ylabel("derivative")
                fig.tight_layout(); cv.draw_idle()

            def send():
                self.v_smooth.set(_sv())
                self.guess_peaks()

            draw()

        def limits_window(self):
            win = tk.Toplevel(self.master)
            win.title("Fit limits")
            frm = ttk.Frame(win, padding=8); frm.pack(fill="both", expand=True)
            rows = [("Amplitude min", "amp_min"), ("Amplitude max", "amp_max"),
                    ("Width min", "width_min"), ("Width max", "width_max"),
                    ("Skew min", "skew_min"), ("Skew max", "skew_max"),
                    ("L/W ratio min", "lwr_min"), ("L/W ratio max", "lwr_max"),
                    ("Peak position tolerance (eV)", "pos_tol"),
                    ("Step position tolerance (eV)", "step_pos_tol"),
                    ("Gauss fraction min", "mix_min"),
                    ("Gauss fraction max", "mix_max")]
            vars_ = {}
            for k, (lab, key) in enumerate(rows):
                ttk.Label(frm, text=lab).grid(row=k, column=0, sticky="w", pady=1)
                v = tk.StringVar(value=str(self.limits[key]))
                ttk.Entry(frm, textvariable=v, width=10, justify="right")\
                    .grid(row=k, column=1, padx=6)
                vars_[key] = v
            ttk.Label(frm, text="Positions are additionally clamped to the\n"
                                "fit range. Tolerances are relative to the\n"
                                "current starting values.",
                      foreground="#666").grid(row=len(rows), column=0, columnspan=2,
                                              sticky="w", pady=(6, 4))

            def apply():
                for key, v in vars_.items():
                    try:
                        self.limits[key] = float(v.get())
                    except ValueError:
                        pass
                win.destroy()
                self.status.set("Fit limits updated.")

            ttk.Button(frm, text="Apply", command=apply)\
                .grid(row=len(rows) + 1, column=0, columnspan=2, sticky="ew")

        def about_model(self):
            messagebox.showinfo("Model reference", __doc__.strip())

        # --------------------------------------------------------------- i/o
        # ------------------------------------------------- where files go
        def _dialog_dir(self):
            """
            Folder the file dialogs open in.

            The last folder you actually used, else the folder your data came
            from, else your home directory. Without this the dialog opens in
            the program's working directory, which for a packaged build is
            wherever the executable happens to live.
            """
            for cand in (self.last_dir,
                         os.path.dirname(self.data_path) if self.data_path else ""):
                if cand and os.path.isdir(cand):
                    return cand
            return os.path.expanduser("~")

        def _data_stem(self):
            if self.data_path:
                return os.path.splitext(os.path.basename(self.data_path))[0]
            return "xas_fit"

        def export_base(self):
            """'<sample name>_<N>CF': the base of every export and of the Igor
            wave names. Falls back to the data file name when the box is
            empty."""
            name = self.v_sample.get().strip() or self._data_stem()
            return igor_base_name(name, self.npeaks())

        def _stem(self):
            """Base name for suggested output files."""
            return self.export_base()

        def igor_wave_base(self):
            """Base of the wave names inside exported Igor files: the sample
            name alone, without the _<N>CF of the file names."""
            return igor_name_stem(self.v_sample.get().strip() or self._data_stem())

        def _update_base_label(self):
            if not hasattr(self, "lbl_base"):
                return
            try:
                base = self.export_base()
            except Exception:
                return
            note = ""
            if len(self.igor_wave_base()) + IGOR_LONGEST_SUFFIX > IGOR7_NAME_LIMIT:
                note = "   (long: Igor 8+ needed for the wave names)"
            self.lbl_base.configure(text=f"exports as  {base}{note}")

        def _auto_fill_sample(self):
            """Put the data file name in the Sample name box unless the user
            has typed their own."""
            cur = self.v_sample.get().strip()
            if not cur or cur == self._auto_sample:
                stem = self._data_stem()
                self._auto_sample = stem
                self.v_sample.set(stem)

        def _remember(self, path):
            d = os.path.dirname(os.path.abspath(path))
            if os.path.isdir(d):
                self.last_dir = d
            return path

        def _state(self):
            self._sync_p_from_widgets()
            return {
                "data_path": self.data_path,
                # the fitted columns themselves, so the session can always
                # restore its data even if the file has moved or is missing
                "data": ({"x_col": self.v_xcol.get(), "y_col": self.v_ycol.get(),
                          "source": os.path.basename(self.data_path or ""),
                          "x": [float(v) for v in self.x],
                          "y": [float(v) for v in self.y]}
                         if self.x is not None else None),
                "sample_name": self.v_sample.get(),
                "x_col": self.v_xcol.get(), "y_col": self.v_ycol.get(),
                "n_peaks": self.npeaks(),
                "layout": 2,          # 6 parameters per peak, interleaved
                "params": list(self.p),
                "params_saved": list(self.p_saved),
                "step_amp": getf(self.v_stepamp, 1.0),
                "fixed": [bool(v) for v in self.fixed_mask()],
                "fix_step_amp": bool(self.f_stepamp.get()),
                "xmin": self.v_xmin.get(), "xmax": self.v_xmax.get(),
                "weight": self.v_weight.get(),
                "method": self.method(),
                "error_model": self.error_model(),
                "tol_label": self.v_tol.get(),
                "limits": self.limits,
                "smooth": self.smoothing(),
            }

        def save_session_dlg(self):
            fn = filedialog.asksaveasfilename(
                title="Save session",
                defaultextension=".json",
                initialdir=self._dialog_dir(),
                initialfile=f"{self._stem()}_session.json",
                filetypes=[("JSON", "*.json")])
            if fn:
                self._remember(fn)
                state = self._state()
                if self.data_path and os.path.isfile(self.data_path):
                    try:            # fails across Windows drives: not needed then
                        state["data_relpath"] = os.path.relpath(
                            self.data_path, os.path.dirname(os.path.abspath(fn)))
                    except ValueError:
                        pass
                save_session(fn, state)
                self.status.set(f"Session saved to {fn} (data included)")

        def load_session_dlg(self):
            fn = filedialog.askopenfilename(
                title="Load session",
                initialdir=self._dialog_dir(),
                filetypes=[("JSON", "*.json"), ("All files", "*")])
            if not fn:
                return
            try:
                s = load_session(fn)
            except Exception as exc:
                messagebox.showerror("Could not load session", str(exc))
                return
            self._remember(fn)
            self._apply_session(s, fn)
            msg = getattr(self, "_session_data_msg", "")
            self.status.set(f"Session loaded from {fn}" + (f" - {msg}" if msg else ""))
            if msg.startswith("data NOT found"):
                messagebox.showwarning(
                    "Data file not found",
                    f"The parameters were loaded, but the data file\n"
                    f"  {s.get('data_path')}\nis not there or next to the "
                    f"session, and this session is from an older gedgfit that "
                    f"did not store the data.\n\nOpen the data file with "
                    f"File > Open, or drop the session and the data file onto "
                    f"the window together.")

        def _apply_session(self, s, fn, data=None):
            """Apply a session dict. `data` (a rebuild data entry) replaces
            the session's own data file, for when that path is not on this
            computer."""
            self._session_data_msg = ""
            if data is not None:
                self._set_data(data["names"], data["raw"], data["source"],
                               s.get("x_col") if s.get("x_col") in data["names"]
                               else data["xcol"],
                               s.get("y_col") if s.get("y_col") in data["names"]
                               else data["ycol"])
                self._session_data_msg = f"data from {data['source']}"
            else:
                loc = locate_session_data(s, fn)
                if loc is not None:
                    names, raw, path, how = loc
                    self._set_data(names, raw, path, s.get("x_col"), s.get("y_col"))
                    shown = os.path.basename(path) or \
                        (s.get("data") or {}).get("source") or "data"
                    if how == "the copy stored in the session":
                        self.lbl_file.configure(
                            text=f"{shown}   ({raw.shape[0]} pts, stored in session)")
                    self._session_data_msg = f"data from {how}"
                elif s.get("data_path") or s.get("data"):
                    self._session_data_msg = (
                        "data NOT found: the file has moved and this session "
                        "was saved before gedgfit stored data in sessions")
            p = np.array(s["params"], dtype=float)
            layout = int(s.get("layout", 0))
            if layout >= 2 and p.size >= FULL_LEN:
                p = p[:FULL_LEN]                    # already interleaved
            elif p.size >= FULL_LEN:
                # written by the version that kept the fractions at 63..74
                p = from_appended_layout(p)
                migrated = "the appended layout"
            else:
                # written before peaks had their own fraction: original Igor order
                p = from_igor_layout(p)
                migrated = "the original Igor order"
            self.p = p
            self._sync_widgets_from_p()        # before anything redraws
            self.p_saved = np.array(s.get("params_saved", self.p), dtype=float)
            self.v_npeaks.set(int(s.get("n_peaks", 4)))
            self.v_stepamp.set(str(s.get("step_amp", 1.0)))
            self.f_stepamp.set(bool(s.get("fix_step_amp", True)))
            fx = s.get("fixed", [False] * FULL_LEN)
            if layout < 2:
                # hold flags follow the parameters they belong to
                old = list(fx) + [True] * (IGOR_LEN + MAX_PEAKS - len(fx))
                fx = [True] * FULL_LEN
                fx[:N_GLOBAL] = old[:N_GLOBAL]
                for i in range(MAX_PEAKS):
                    s0 = N_GLOBAL + IGOR_PARAMS_PER_PEAK * i
                    b = peak_base(i)
                    fx[b:b + IGOR_PARAMS_PER_PEAK] = old[s0:s0 + IGOR_PARAMS_PER_PEAK]
                    fx[b + 5] = (old[IGOR_LEN + i]
                                 if len(old) > IGOR_LEN + i else True)
            self.f_mix.set(fx[0]); self.f_steppos.set(fx[1]); self.f_stepw.set(fx[2])
            for i in range(MAX_PEAKS):
                for f in PEAK_ROW_FIELDS:
                    j = self.row_index(i, f)
                    self.pk_fix[i][f].set(bool(fx[j]) if j < len(fx) else True)
            self.v_xmin.set(s.get("xmin", "")); self.v_xmax.set(s.get("xmax", ""))
            if s.get("sample_name"):
                self.v_sample.set(s["sample_name"])
            else:
                self._auto_fill_sample()
            self.v_weight.set(s.get("weight", "none"))
            self.v_method.set(METHOD_LABELS.get(s.get("method", "lm"),
                                                METHOD_LABELS["lm"]))
            self.v_errmodel.set(ERROR_LABELS.get(s.get("error_model", "scaled"),
                                                 ERROR_LABELS["scaled"]))
            if s.get("tol_label") in TOLERANCES:
                self.v_tol.set(s["tol_label"])
            self.on_method()
            self.v_smooth.set(int(s.get("smooth", 5)))
            self.limits.update(s.get("limits", {}))
            self._sync_widgets_from_p()
            self.replot()

        def import_itx(self):
            fn = filedialog.askopenfilename(
                title="Import Igor parameter wave",
                initialdir=self._dialog_dir(),
                filetypes=[("Igor text / column data", "*.itx *.awav *.txt *.dat"),
                           ("All files", "*")])
            if not fn:
                return
            try:
                self.p, amp, _note = read_igor_param_wave_full(fn)
                self.v_stepamp.set(f"{amp:.6g}")
            except Exception as exc:
                messagebox.showerror("Could not read parameter wave", str(exc))
                return
            # An Igor coefficient wave is usually longer than the function
            # that used it: make/n=53 holds ten peaks, but edg_fit8 only ever
            # reads the first eight. Say how many are actually populated, so
            # the peak count here can be set to match what Igor was fitting.
            filled = [i for i in range(MAX_PEAKS)
                      if abs(self.p[peak_base(i)]) > 0]
            n_filled = (max(filled) + 1) if filled else 0
            self._sync_widgets_from_p()
            self.replot()
            if n_filled and n_filled != self.npeaks():
                self.status.set(
                    f"Loaded {fn}. The wave has {n_filled} peaks with a "
                    f"non-zero amplitude but the peak count is set to "
                    f"{self.npeaks()} - set it to whichever edg_fitN you used "
                    f"in Igor.")
            else:
                self.status.set(f"Igor parameter wave loaded from {fn}")

        def export_itx(self, full=False):
            fn = filedialog.asksaveasfilename(
                title=("Export extended parameter wave (75)" if full
                       else "Export Igor parameter wave (63)"),
                defaultextension=".itx",
                initialdir=self._dialog_dir(),
                initialfile=f"{self._stem()}_P{'75' if full else ''}.itx",
                filetypes=[("Igor text", "*.itx")])
            if not fn:
                return
            self._sync_p_from_widgets()
            # wave named after the sample, without the file's _<N>CF
            name = self.igor_wave_base() + ("_P75" if full else "_P")
            self._remember(fn)
            write_igor_param_wave(fn, self.p, name, full=full)
            if full:
                self.status.set(
                    f"75-element wave written to {fn}. In Igor, load it with "
                    f"ImportGedgfitP(), which re-indexes it to the 76-point "
                    f"layout (step amplitude at p[1]).")
                return
            if mixes_linked(self.p):
                self.status.set(f"Igor parameter wave written to {fn}")
            else:
                self.status.set(
                    f"Written to {fn}, but only the 63 Igor parameters. This "
                    f"fit uses different Gaussian fractions per peak, which "
                    f"edg_fitN cannot express, so the wave will not reproduce "
                    f"it in Igor.")
                messagebox.showwarning(
                    "Per-peak Gaussian fractions not exported",
                    "Igor's edg_fitN has a single Gaussian fraction shared by "
                    "the step and every peak. This fit uses different values "
                    "per peak, so those cannot be written into the parameter "
                    "wave.\n\nThe 63 Igor parameters were saved and will load "
                    "back here correctly, but opening the wave in Igor will "
                    "give a different line shape.\n\nUse 'Link all Gauss "
                    "fractions to the step' first if you need an exact Igor "
                    "match.")

        # ----------------------------------------------- rebuild from files
        def enable_drop(self, dnd_files):
            """Accept files and folders dropped anywhere on the window."""
            self._dnd_ok = dnd_files is not None
            if not self._dnd_ok:
                self.lbl_drop.configure(
                    text="Drag and drop needs the tkinterdnd2 package;\n"
                         "use File > Rebuild fit from files / folder.")
                return
            self.lbl_drop.configure(
                text="Drop Igor files (.pxp .ibw .itx), sessions, data or a\n"
                     "whole folder anywhere on this window to rebuild a fit.")

            def register(w):
                try:
                    w.drop_target_register(dnd_files)
                    w.dnd_bind("<<DropEnter>>", self._on_drop_enter)
                    w.dnd_bind("<<DropLeave>>", self._on_drop_leave)
                    w.dnd_bind("<<Drop>>", self._on_drop)
                except Exception:
                    pass
                for ch in w.winfo_children():
                    register(ch)
            register(self.master)

        def _on_drop_enter(self, event):
            self._status_before_drop = self.status.get()
            self.status.set("Drop to rebuild the fit from these files...")
            return event.action

        def _on_drop_leave(self, event):
            self.status.set(getattr(self, "_status_before_drop", ""))
            return event.action

        def _on_drop(self, event):
            paths = list(self.master.tk.splitlist(event.data))
            # return to the drag source first, then do the work
            self.after(20, lambda: self.rebuild_from_paths(paths))
            return event.action

        def rebuild_files_dlg(self):
            fns = filedialog.askopenfilenames(
                title="Rebuild fit from files",
                initialdir=self._dialog_dir(),
                filetypes=[("Igor, sessions, data",
                            "*.pxp *.pxt *.ibw *.itx *.awav *.json *.txt "
                            "*.dat *.csv *.xy *.asc"),
                           ("All files", "*")])
            if fns:
                self.rebuild_from_paths(list(fns))

        def rebuild_folder_dlg(self):
            d = filedialog.askdirectory(title="Rebuild fit from folder",
                                        initialdir=self._dialog_dir())
            if d:
                self.rebuild_from_paths([d])

        def rebuild_from_paths(self, paths, choose=None):
            """
            Read every dropped file and folder and rebuild the fit from what
            is there: data, parameters, holds, peak count, fit range and
            stored parameters. `choose(candidates)` picks among several fits
            (a dialog by default); it returns one candidate or None.
            """
            self.status.set("Reading dropped files...")
            self.update_idletasks()
            try:
                scan = scan_for_fit(paths)
            except Exception as exc:
                messagebox.showerror("Could not read the files", str(exc))
                return None
            cands = assemble_fit_candidates(scan)
            if not cands:
                msg = "Nothing in these files could be used to build a fit."
                if scan["errors"]:
                    msg += "\n\nProblems:\n" + "\n".join(
                        f"  {os.path.basename(f)}: {e}" for f, e in scan["errors"][:8])
                messagebox.showinfo("Rebuild fit", msg)
                self.status.set("Nothing usable in the dropped files.")
                return None
            if len(cands) == 1:
                cand = cands[0]
            else:
                cand = (choose or self._choose_candidate)(cands)
                if cand is None:
                    self.status.set("Rebuild cancelled.")
                    return None
            self._remember(cand.get("source") or paths[0])
            self._apply_candidate(cand, scan)
            return cand

        def _choose_candidate(self, cands):
            """Modal list of the fits found; the most complete is selected."""
            win = tk.Toplevel(self.master)
            win.title("Rebuild fit - choose")
            win.configure(background=THEME["bg"])
            win.transient(self.master)
            ttk.Label(win, text="Several fits were found. Choose one to load:",
                      padding=(10, 8, 10, 4)).pack(anchor="w")
            lb = tk.Listbox(win, width=96, height=min(14, len(cands)),
                            activestyle="none", font=_mono("Consolas"),
                            background=THEME["field"], foreground=THEME["fg"],
                            selectbackground=THEME["accent"],
                            highlightthickness=0, borderwidth=0)
            for c in cands:
                lb.insert("end", "  " + c["label"])
            lb.selection_set(0)
            lb.pack(fill="both", expand=True, padx=10)
            result = {"c": None}

            def ok(*_):
                sel = lb.curselection()
                result["c"] = cands[sel[0]] if sel else None
                win.destroy()

            bar = ttk.Frame(win, padding=10)
            bar.pack(fill="x")
            ttk.Button(bar, text="Cancel", command=win.destroy).pack(side="right")
            ttk.Button(bar, text="Load", style="Accent.TButton",
                       command=ok).pack(side="right", padx=6)
            lb.bind("<Double-Button-1>", ok)
            win.bind("<Return>", ok)
            win.bind("<Escape>", lambda e: win.destroy())
            win.grab_set()
            lb.focus_set()
            self.master.wait_window(win)
            return result["c"]

        def _apply_fixed(self, mask, fix_amp=None):
            """Set the hold checkboxes from a 75-element mask."""
            self.f_mix.set(bool(mask[0]))
            self.f_steppos.set(bool(mask[1]))
            self.f_stepw.set(bool(mask[2]))
            for i in range(MAX_PEAKS):
                for f in PEAK_ROW_FIELDS:
                    self.pk_fix[i][f].set(bool(mask[self.row_index(i, f)]))
            if fix_amp is not None:
                self.f_stepamp.set(bool(fix_amp))

        def _apply_candidate(self, c, scan):
            """Put a rebuilt fit on screen and say where each piece came from."""
            if c["kind"] == "session":
                self._apply_session(c["session"], c["source"], data=c.get("data"))
                self.last_fit = None
            else:
                if c.get("data") is not None:
                    d = c["data"]
                    self._set_data(d["names"], d["raw"], d["source"],
                                   d["xcol"], d["ycol"])
                if c.get("p") is not None:
                    self.p = np.array(c["p"], dtype=float)[:FULL_LEN]
                    # into the widgets at once: any redraw reads them back
                    self._sync_widgets_from_p()
                    self.v_stepamp.set(f"{c.get('step_amp', 1.0):.6g}")
                    if c.get("fixed") is not None:
                        self._apply_fixed(c["fixed"], c.get("fix_step_amp"))
                    self.v_npeaks.set(int(c.get("n_peaks") or self.npeaks()))
                    self.p_saved = (np.array(c["p_saved"], dtype=float)[:FULL_LEN]
                                    if c.get("p_saved") is not None else self.p.copy())
                    self.last_fit = None
                xmin, xmax = c.get("xmin"), c.get("xmax")
                ok = lambda v: v is not None and np.isfinite(v)
                if c.get("data") is not None or ok(xmin) or ok(xmax):
                    if self.x is not None:
                        self.full_range()
                    if ok(xmin):
                        self.v_xmin.set(f"{xmin:.6g}")
                    if ok(xmax):
                        self.v_xmax.set(f"{xmax:.6g}")
                if c.get("sample"):
                    self._auto_sample = ""
                    self.v_sample.set(c["sample"])
                elif c.get("data") is not None:
                    self._auto_fill_sample()
                self._sync_widgets_from_p()
                self._autoscale_next = True
                self.replot()

            L = ["REBUILT FROM FILES", "=" * 46, c["label"].strip(), ""]
            L += [f"  {n}" for n in c["notes"]]
            other = len(scan["sessions"]) + len(scan["containers"]) + \
                len(scan["tables"]) + len(scan["params"])
            L += ["", f"read: {other} usable source(s), "
                      f"{len(scan['ignored'])} other file(s) skipped"]
            if scan["truncated"]:
                L.append(f"note: stopped after {SCAN_MAX_FILES} files; drop a "
                         f"smaller folder to read everything")
            for f, e in scan["errors"][:10]:
                L.append(f"could not read {os.path.basename(f)}: {e}")
            if c.get("data") is None and c["kind"] == "params":
                L.append("")
                L.append("Only parameters were found; they are shown on the "
                         "data already loaded.")
            self.txt.delete("1.0", "end")
            self.txt.insert("1.0", "\n".join(L))
            self.status.set(f"Rebuilt: {c['label'].split('  ')[0].strip()} - "
                            f"{os.path.basename(c.get('source') or '')}")

        def export_igor_bundle(self):
            """Data, parameters, holds, peak count and fit range as an Igor
            Text file, with the procedure files beside it. Opening the .itx
            in Igor loads everything and runs SetUp()."""
            if self.x is None:
                messagebox.showinfo("Export to Igor", "Load data first.")
                return
            self._sync_p_from_widgets()
            base = self.export_base()               # file names: <sample>_<N>CF
            wbase = self.igor_wave_base()           # wave names: <sample>_...
            if len(wbase) + IGOR_LONGEST_SUFFIX > IGOR7_NAME_LIMIT:
                if not messagebox.askokcancel(
                        "Long name",
                        f"'{wbase}' plus the procedures' suffixes exceeds "
                        f"Igor 7's 31-character wave-name limit. It works in "
                        f"Igor 8 or later. Continue?"):
                    return
            fn = filedialog.asksaveasfilename(
                title="Export to Igor (data + procedures)",
                defaultextension=".itx",
                initialdir=self._dialog_dir(),
                initialfile=f"{base}.itx",
                filetypes=[("Igor text", "*.itx")])
            if not fn:
                return
            self._remember(fn)
            n = self.npeaks()
            amp = getf(self.v_stepamp, 1.0)
            # carry the fit errors only if they belong to these parameters
            errors, amp_err = None, np.nan
            res = getattr(self, "last_fit", None)
            if res is not None and np.allclose(res.p[:FULL_LEN],
                                               self.p[:FULL_LEN],
                                               rtol=1e-12, atol=0):
                errors = res.errors
                amp_err = getattr(res, "step_amp_err", np.nan)
            try:
                files = write_igor_bundle(
                    fn, wbase, self.x, self.y, self.p, n,
                    step_amp=amp, fixed=self.fixed_mask(),
                    fix_step_amp=bool(self.f_stepamp.get()),
                    xmin=getf(self.v_xmin, np.nan),
                    xmax=getf(self.v_xmax, np.nan),
                    p_saved=self.p_saved, errors=errors,
                    step_amp_err=amp_err, smooth=self.smoothing())
            except (OSError, KeyError) as exc:
                messagebox.showerror("Export to Igor failed", str(exc))
                return
            self.status.set(f"Igor bundle written: {files[0]} + "
                            f"{os.path.basename(files[1])}, {os.path.basename(files[2])}")
            messagebox.showinfo(
                "Exported to Igor",
                "Wrote:\n  " + "\n  ".join(os.path.basename(f) for f in files) +
                f"\nin {os.path.dirname(files[0])}\n\n"
                f"In Igor Pro 7 or later, open {os.path.basename(files[0])} "
                f"(double-click it, or File > Open File > Igor Text). It "
                f"opens the two procedure files, loads the data, total "
                f"fit and parameters as {wbase}_*, then runs derivPlot, "
                f"SetUp, Wv_Plotter_Tot and RSD_Plot_Tot.\n\n"
                f"Keep the three files together. Close any other copies of "
                f"these procedure files (including another sample's "
                f"workflow .ipf, or the older Cp2VCl2 / "
                f"EDG_Fit12_SGM_modified ones) in Igor first: they define "
                f"the same functions.\n\n"
                f"Then File > Save Experiment As gives a packed .pxp.")

        def export_csv(self):
            if self.x is None:
                return
            fn = filedialog.asksaveasfilename(
                title="Export components",
                defaultextension=".csv",
                initialdir=self._dialog_dir(),
                initialfile=f"{self._stem()}_components.csv",
                filetypes=[("CSV", "*.csv")])
            if not fn:
                return
            self._sync_p_from_widgets()
            n = self.npeaks()
            amp = getf(self.v_stepamp, 1.0)
            x, y, _ = self.fit_slice()
            stp, peaks, total = all_components(x, self.p, n, amp)
            cols = [x, y, total, stp] + peaks + [total - y]
            hdr = ["energy", "data", "total_fit", "step"] + \
                  [f"peak{i+1}" for i in range(n)] + ["residual_fit_minus_data"]
            for i in range(n):
                cols.append(isolated_peak_residual(x, y, self.p, n, i, amp))
                hdr.append(f"isolated{i+1}")
            self._remember(fn)
            np.savetxt(fn, np.column_stack(cols), delimiter=",",
                       header=",".join(hdr), comments="", fmt="%.8g")
            self.status.set(f"Components written to {fn}")

        def export_report(self):
            fn = filedialog.asksaveasfilename(
                title="Export report",
                defaultextension=".txt",
                initialdir=self._dialog_dir(),
                initialfile=f"{self._stem()}_report.txt",
                filetypes=[("Text", "*.txt")])
            if fn:
                self._remember(fn)
                with open(fn, "w") as fh:
                    fh.write(self.txt.get("1.0", "end"))
                self.status.set(f"Report written to {fn}")

        def export_figure(self):
            fn = filedialog.asksaveasfilename(
                title="Export figure",
                defaultextension=".png",
                initialdir=self._dialog_dir(),
                initialfile=f"{self._stem()}_fit.png",
                filetypes=[("PNG", "*.png"), ("PDF", "*.pdf"), ("SVG", "*.svg")])
            if fn:
                self._remember(fn)
                self.fig.savefig(fn, dpi=300, facecolor=self.fig.get_facecolor())
                self.status.set(f"Figure written to {fn}")

    sys.excepthook = _report
    _enable_dpi_awareness()
    _set_taskbar_id()

    try:                                          # drag and drop, if installed
        from tkinterdnd2 import TkinterDnD, DND_FILES
        root = TkinterDnD.Tk()
    except Exception:
        DND_FILES = None
        root = tk.Tk()
    root.report_callback_exception = _report   # errors inside widget callbacks
    apply_dark_theme(root)

    if _mac():
        # macOS works in points and scales for Retina itself; see _mac_fonts
        scale = 1.0
        _mac_fonts(root)
    else:
        # match the interface to the monitor's real DPI
        try:
            dpi = float(root.winfo_fpixels("1i"))
        except Exception:
            dpi = 96.0
        scale = min(max(dpi / 96.0, 1.0), 2.5)
        try:
            root.call("tk", "scaling", (dpi / 72.0) * 0.92)
        except Exception:
            pass
    try:
        root.iconphoto(True, tk.PhotoImage(data=_ICON_PNG_B64))
    except Exception:
        pass

    # never open larger than the screen
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    w = min(int(1520 * scale), int(sw * 0.94))
    h = min(int(900 * scale), int(sh * 0.90))
    root.geometry(f"{w}x{h}+{max((sw - w) // 2, 0)}+{max((sh - h) // 3, 0)}")
    root.minsize(int(PANEL_WIDTH * scale) + 430, 660)

    app = App(root, scale=scale)
    app.enable_drop(DND_FILES)
    if _mac():
        _mac_app_hooks(root, app)
    if not run:
        return root, app
    root.mainloop()
    return None


def _mac_app_hooks(root, app):
    """
    The Mac application menu and Dock: Command-Q and "Quit gedgfit" close
    the window properly, "About gedgfit" says what this is, and files or
    folders dropped on the Dock icon (or opened with "Open With > gedgfit")
    rebuild a fit, as dropping them on the window does.
    """
    def open_documents(*paths):
        if paths:
            app.after(50, lambda: app.rebuild_from_paths(list(paths)))

    def about():
        from tkinter import messagebox
        messagebox.showinfo(
            "About gedgfit",
            f"gedgfit {APP_VERSION}\n\nStep edge + up to 12 skewed "
            f"pseudo-Voigt peaks for soft X-ray absorption spectra, "
            f"matching Igor's EDG_Fit12 procedures.", parent=root)

    for name, fn in (("::tk::mac::Quit", root.destroy),
                     ("::tk::mac::OpenDocument", open_documents),
                     ("tkAboutDialog", about)):
        try:
            root.createcommand(name, fn)
        except Exception:
            pass


def selftest():
    """
    Verify a packaged build end to end, without opening a window.

        gedgfit.exe --selftest                          (Windows)
        gedgfit.app/Contents/MacOS/gedgfit --selftest   (Mac)

    Checks the model against known values and runs a real fit with every
    optimiser. Useful after trimming the bundle: a smaller executable that
    starts is not proof that fitting still works, because SciPy loads much of
    itself lazily and a missing submodule only shows up when it is called.

    Writes selftest_report.txt beside the executable and, when there is no
    console to print to, shows the verdict in a dialog.
    """
    lines = []
    ok = True

    def say(s):
        lines.append(s)
        try:
            print(s)
        except Exception:
            pass

    say("gedgfit self-test")
    say("=" * 46)
    try:
        say(f"numpy      {np.__version__}")
        import scipy
        say(f"scipy      {scipy.__version__}")
        import matplotlib
        say(f"matplotlib {matplotlib.__version__}")
    except Exception as exc:
        say(f"FAIL importing a dependency: {exc}")
        ok = False

    rng = np.random.default_rng(0)
    x = np.linspace(280.0, 300.0, 400)
    p = default_params()
    p[0], p[1], p[2] = 0.5, 290.0, 0.8
    truth = [(0.60, 285.2, 0.40), (0.35, 287.1, 0.50), (0.50, 292.5, 1.50)]
    for i, (a, c, w) in enumerate(truth):
        b = peak_base(i)
        p[b:b + 5] = [a, c, w, 0.0, 1.0]
    y = model_total(x, p, 3) + rng.normal(0, 0.006, x.size)

    # the step must run from 0 to 1, and a unit-width peak must be 2 eV FWHM
    lim = step_profile(np.array([-1e6, 1e6]) + p[1], p[0], p[1], p[2])
    if abs(lim[0]) < 1e-6 and abs(lim[1] - 1) < 1e-6:
        say("model      step limits 0 -> 1                  ok")
    else:
        say(f"model      step limits wrong: {lim}           FAIL"); ok = False

    p0 = p.copy()
    p0[0] = 0.5
    for i in range(3):
        b = peak_base(i)
        p0[b] *= 0.75
        p0[b + 1] += 0.2
        p0[b + 2] = 0.5
    fixed = np.zeros(FULL_LEN, bool)
    for i in range(3):
        fixed[peak_base(i) + 3] = True
        fixed[peak_base(i) + 4] = True

    for meth in METHODS:
        for em in ERROR_MODELS:
            try:
                r = fit_spectrum(x, y, p0, 3, fixed, method=meth,
                                 error_model=em, tol=1e-8)
                err = r.errors[peak_base(0) + 1]
                good = r.r2 > 0.99 and np.isfinite(err)
                ok &= bool(good)
                say(f"fit        {meth:<7s} {em:<9s} R2={r.r2:.6f} "
                    f"sigma(E1)={err:.5g}   {'ok' if good else 'FAIL'}")
            except Exception as exc:
                say(f"fit        {meth:<7s} {em:<9s} FAIL: "
                    f"{type(exc).__name__}: {exc}")
                ok = False

    try:
        _, _, d2 = derivatives(x, y, 5)
        pos = suggest_peaks(x, y, 3, 5)
        say(f"derivative peak finder returned {len(pos)} positions      ok")
    except Exception as exc:
        say(f"derivative FAIL: {exc}"); ok = False

    try:
        import tempfile, os as _os
        fn = _os.path.join(tempfile.gettempdir(), "_gedgfit_selftest.itx")
        write_igor_param_wave(fn, p, "T")
        back = read_igor_param_wave(fn)
        _os.remove(fn)
        good = np.allclose(p, back, rtol=1e-9)
        ok &= bool(good)
        say(f"igor i/o   parameter wave round trip          "
            f"{'ok' if good else 'FAIL'}")
    except Exception as exc:
        say(f"igor i/o   FAIL: {exc}"); ok = False

    try:
        import tempfile, shutil, os as _os
        d = tempfile.mkdtemp(prefix="_gedgfit_igor_")
        try:
            files = write_igor_bundle(_os.path.join(d, "T_3CF.itx"), "T",
                                      x, x * 0 + 1, p, 3, step_amp=1.25)
            waves = read_igor_text(files[0])
            back, amp = from_igor76_layout(waves["T_P"])
            names = [_os.path.basename(f) for f in files[1:]]
            good = (np.allclose(back, p, rtol=1e-12) and amp == 1.25 and
                    names == [EXPORT_MODEL_IPF, "T_3CF.ipf"] and
                    all(_os.path.getsize(f) > 1000 for f in files[1:]))
        finally:
            shutil.rmtree(d, ignore_errors=True)
        ok &= bool(good)
        say(f"igor i/o   data + procedures bundle               "
            f"{'ok' if good else 'FAIL'}")
    except Exception as exc:
        say(f"igor bundle FAIL: {exc}"); ok = False

    try:
        import tempfile, shutil, os as _os
        d = tempfile.mkdtemp(prefix="_gedgfit_rebuild_")
        try:
            fx = default_fixed_mask()
            fx[0] = True
            write_igor_bundle(_os.path.join(d, "T_3CF.itx"), "T", x,
                              model_total(x, p, 3), p, 3, step_amp=1.25,
                              fixed=fx, xmin=283.0, xmax=297.0)
            cands = assemble_fit_candidates(scan_for_fit([d]))
            c = cands[0] if cands else {}
            good = (len(cands) == 1 and np.allclose(c["p"], p, rtol=1e-12)
                    and c["step_amp"] == 1.25 and np.array_equal(c["fixed"], fx)
                    and c["n_peaks"] == 3 and (c["xmin"], c["xmax"]) == (283.0, 297.0))
        finally:
            shutil.rmtree(d, ignore_errors=True)
        ok &= bool(good)
        say(f"rebuild    Igor export dropped back in            "
            f"{'ok' if good else 'FAIL'}")
    except Exception as exc:
        say(f"rebuild    FAIL: {exc}"); ok = False

    have_igor2 = igor_binary_supported()
    say(f"igor files .pxp / .ibw reader (igor2)          "
        f"{'ok' if have_igor2 else 'MISSING'}")
    try:
        import tkinterdnd2, os as _os
        tkdnd_dir = _os.path.join(_os.path.dirname(tkinterdnd2.__file__), "tkdnd")
        have_dnd = _os.path.isdir(tkdnd_dir) and bool(_os.listdir(tkdnd_dir))
    except Exception:
        have_dnd = False
    say(f"drag and drop (tkinterdnd2 + tkdnd library)    "
        f"{'ok' if have_dnd else 'MISSING'}")
    if _is_frozen():
        # a built .exe is meant to include both
        ok &= have_igor2 and have_dnd

    say("=" * 46)
    say("PASS - this build is working" if ok else "FAIL - see the lines above")

    text = "\n".join(lines)
    try:
        with open(_log_path().replace("error.log", "selftest.txt"), "w") as fh:
            fh.write(text + "\n")
    except OSError:
        pass
    if not sys.stdout or not sys.stdout.isatty():
        try:
            import tkinter, tkinter.messagebox as mb
            r = tkinter.Tk(); r.withdraw()
            (mb.showinfo if ok else mb.showerror)("gedgfit self-test", text)
            r.destroy()
        except Exception:
            pass
    return 0 if ok else 1



# ==========================================================================
#  Embedded Igor procedure files (written by File > Export to Igor).
#  A copy of either file beside the program takes precedence.
# ==========================================================================

_EMBEDDED_IPF = {
    "gedgfit_Model.ipf": r'''#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma IgorVersion=7.00
#pragma version=2.0

// ===========================================================================
//  gedgfit_Model.ipf
//
//  Step edge + up to 12 skewed pseudo-Voigt peaks, with the SAME parameter
//  layout and mathematics as the gedgfit program (gedgfit.py).
//  This is the file gedgfit refers to when it exports a "75-element" wave.
//
//  Replaces EDG_Fit12_SGM_modified.ipf. Close that file before opening this
//  one: both define edg_fit1..12, Plot_step and Plot_wave1..12.
//
//  ---------------------------------------------------------------------------
//  PARAMETER WAVE  (76 points)
//
//    w[0]          step Gaussian fraction   (governs the STEP ONLY)
//    w[1]          step amplitude           (gedgfit's "Step amplitude *";
//                                            keep held at 1 for edge-jump
//                                            normalised data)
//    w[2]          step position E0
//    w[3]          step half-width
//    peak i = 1..12, base b = 4 + 6*(i-1):
//    w[b+0]        amplitude
//    w[b+1]        position
//    w[b+2]        half-width
//    w[b+3]        skew
//    w[b+4]        L/W ratio  (Gaussian width / Lorentzian width)
//    w[b+5]        this peak's own Gaussian fraction
//
//    Peak 1 = w[4..9], peak 2 = w[10..15], ... peak 12 = w[70..75].
//    The text wave <base>_P_Desc says what every row is; SetUp puts it in
//    the table beside <base>_P.
//
//  gedgfit keeps the step amplitude OUTSIDE its 75-point wave, so its waves
//  read  [mix, E0, W0, peaks...]. EDG_FromGedgfitLayout / EDG_ToGedgfitLayout
//  convert between the two; the workflow's ImportGedgfitP / ExportForGedgfit
//  do this for you.
//
//  MODEL  (identical to gedgfit, including its guard on zero denominators)
//    step(x)  = amp*[ 1/2 + m0*(1/2)erf((x-E0)sqrt(ln2)/W0) + (1-m0)*(1/pi)atan((x-E0)/W0) ]
//    w_eff    = W + (x-E)*skew
//    G(x)     = exp(-ln2*(x-E)^2 / (w_eff*R)^2)
//    L(x)     = w_eff^2 / (w_eff^2 + (x-E)^2)
//    peak(x)  = A*( m*G + (1-m)*L )          m = that peak's own fraction
//    edg_fitN = step + peaks 1..N
//
//  Differences from the original EDG_Fit12_SGM_modified.ipf:
//    * 6 parameters per peak instead of 5 (the 6th is the Gaussian fraction)
//    * param[0] no longer controls the peaks, only the step
//    * step amplitude inserted at w[1]; everything after w[0] moved up by 1
//  Setting every peak fraction equal to w[0] (EDG_LinkGauss) and keeping
//  w[1]=1 reproduces the original procedure exactly. Old 53/63-point waves
//  are converted with EDG_FromIgorLayout (SetUp does this automatically).
//
//  GUI-STYLE PARAMETER TABLE
//    <base>_Step   4 x 2  : rows = Gauss frac, amplitude, position, half-width;
//                           columns = value, hold
//    <base>_Peaks 12 x 12 : one row per peak; columns are value/hold pairs for
//                           Amp, Position, Width, Skew, L/W ratio, Gauss frac
//    These mirror gedgfit's "Edge step" and "Peaks" panels, including the
//    hold checkboxes (1 = held). <base>_P is the 1-D coefficient wave FuncFit
//    uses; EDG_Sync keeps the two in step in whichever direction changed.
// ===========================================================================

Constant kEDG_NGlobal = 4			// mix, amplitude, position, half-width
Constant kEDG_PerPeak = 6
Constant kEDG_MaxPeaks = 12
Constant kEDG_StepAmpIdx = 1
Constant kEDG_WaveLen = 76
Constant kEDG_GedgfitLen = 75		// gedgfit's FULL_LEN (no step amplitude)
Constant kEDG_IgorPerPeak = 5		// original EDG_Fit12 layout
Constant kEDG_IgorLen = 63
Constant kEDG_Tiny = 1e-12
// Points in the fit_<base>_Int curve. FuncFit's /D rebuilds that wave with
// this many points (/L) across the fit range, and gedgfit exports it the same way.
Constant kEDG_FitCurvePoints = 1000

StrConstant ksEDG_PeakFields = "Amp;Position;Width;Skew;LW_ratio;Gauss_frac;"
StrConstant ksEDG_PeakHolds = "Amp_hold;Pos_hold;Width_hold;Skew_hold;LWR_hold;Gauss_hold;"
StrConstant ksEDG_StepRows = "Step_Gauss_frac;Step_amplitude;Step_position_E0;Step_half_width;"

// gedgfit's DEFAULT_LIMITS (used only when a fit is run with limits on)
Constant kEDG_AmpMin = 0
Constant kEDG_AmpMax = 100
Constant kEDG_WidthMin = 0.01
Constant kEDG_WidthMax = 20
Constant kEDG_SkewMin = -0.5
Constant kEDG_SkewMax = 0.5
Constant kEDG_LWRMin = 0.05
Constant kEDG_LWRMax = 20
Constant kEDG_PosTol = 2
Constant kEDG_StepPosTol = 5
Constant kEDG_MixMin = 0
Constant kEDG_MixMax = 1


// ===========================================================================
//  Core mathematics
// ===========================================================================

// Keep a denominator away from zero without changing its sign (gedgfit _safe)
Function EDG_Safe(a)
	Variable a
	if(abs(a) < kEDG_Tiny)
		return (a < 0) ? -kEDG_Tiny : kEDG_Tiny
	endif
	return a
End

// Index of the first parameter of peak i (0-based peak number)
Function EDG_PeakBase(i)
	Variable i
	return kEDG_NGlobal + kEDG_PerPeak*i
End

// Step amplitude, w[1]
Function EDG_StepAmp(w)
	Wave w
	return w[kEDG_StepAmpIdx]
End

Function EDG_StepProfile(xx, mix, pos, width, amp)
	Variable xx, mix, pos, width, amp
	Variable wd = EDG_Safe(width)
	Variable dx = xx - pos
	Variable ef = 0.5*erf(dx*sqrt(ln(2))/wd)
	Variable at = atan(dx/wd)/pi
	return amp*(0.5 + mix*ef + (1-mix)*at)
End

Function EDG_PeakProfile(xx, mix, amp, pos, width, skew, lwr)
	Variable xx, mix, amp, pos, width, skew, lwr
	Variable dx = xx - pos
	Variable weff = EDG_Safe(width + dx*skew)
	Variable rr = EDG_Safe(lwr)
	Variable g = exp(-ln(2)*(dx^2)/((weff*rr)^2))
	Variable l = (weff^2)/((weff^2) + (dx^2))
	return amp*(mix*g + (1-mix)*l)
End

// Step component (gedgfit component_step / Igor Plot_step)
Function EDG_StepComp(w, xx)
	Wave w
	Variable xx
	return EDG_StepProfile(xx, w[0], w[2], w[3], w[1])
End

// Peak component, 0-based peak i (gedgfit component_peak / Igor Plot_waveN)
Function EDG_PeakComp(w, xx, i)
	Wave w
	Variable xx, i
	Variable b = EDG_PeakBase(i)
	return EDG_PeakProfile(xx, w[b+5], w[b], w[b+1], w[b+2], w[b+3], w[b+4])
End

// Unit-height Gaussian and Lorentzian parts of peak i (replace Ig1..12, Il1..12)
Function EDG_G(w, xx, i)
	Wave w
	Variable xx, i
	Variable b = EDG_PeakBase(i)
	return EDG_PeakProfile(xx, 1, 1, w[b+1], w[b+2], w[b+3], w[b+4])
End

Function EDG_L(w, xx, i)
	Wave w
	Variable xx, i
	Variable b = EDG_PeakBase(i)
	return EDG_PeakProfile(xx, 0, 1, w[b+1], w[b+2], w[b+3], w[b+4])
End

// Step plus the first n peaks (gedgfit model_total)
Function EDG_Total(w, xx, n)
	Wave w
	Variable xx, n
	Variable tot = EDG_StepComp(w, xx), i
	for(i=0; i<n; i+=1)
		tot += EDG_PeakComp(w, xx, i)
	endfor
	return tot
End


// ===========================================================================
//  Step pieces (same names and meaning as the original procedure)
// ===========================================================================

Function step_fit(param, xx)
	Wave param
	Variable xx
	return EDG_StepComp(param, xx)
End

Function error(param, xx)
	Wave param
	Variable xx
	return 0.5*erf((xx-param[2])*sqrt(ln(2))/EDG_Safe(param[3]))
End

Function arctangent(param, xx)
	Wave param
	Variable xx
	return (1/pi)*atan((xx-param[2])/EDG_Safe(param[3]))
End


// ===========================================================================
//  Fit functions: pick the one matching your number of peaks
// ===========================================================================

Function edg_fit1(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 1)
End

Function edg_fit2(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 2)
End

Function edg_fit3(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 3)
End

Function edg_fit4(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 4)
End

Function edg_fit5(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 5)
End

Function edg_fit6(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 6)
End

Function edg_fit7(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 7)
End

Function edg_fit8(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 8)
End

Function edg_fit9(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 9)
End

Function edg_fit10(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 10)
End

Function edg_fit11(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 11)
End

Function edg_fit12(w, xx) : FitFunc
	Wave w
	Variable xx
	return EDG_Total(w, xx, 12)
End


// ===========================================================================
//  Plotting components (same names as the original procedure)
// ===========================================================================

Function Plot_step(param, xx)
	Wave param
	Variable xx
	return EDG_StepComp(param, xx)
End

Function Plot_wave1(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 0)
End

Function Plot_wave2(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 1)
End

Function Plot_wave3(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 2)
End

Function Plot_wave4(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 3)
End

Function Plot_wave5(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 4)
End

Function Plot_wave6(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 5)
End

Function Plot_wave7(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 6)
End

Function Plot_wave8(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 7)
End

Function Plot_wave9(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 8)
End

Function Plot_wave10(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 9)
End

Function Plot_wave11(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 10)
End

Function Plot_wave12(param, xx)
	Wave param
	Variable xx
	return EDG_PeakComp(param, xx, 11)
End


// ===========================================================================
//  Parameter-wave layout utilities
// ===========================================================================

// gedgfit default_params(), plus step amplitude = 1 at w[1]
Function EDG_DefaultParams(w)
	Wave w
	Redimension/D/N=(kEDG_WaveLen) w
	w = 0
	w[0] = 0.5			// step Gaussian fraction
	w[1] = 1			// step amplitude
	w[2] = 0			// step position
	w[3] = 0.5			// step half-width
	Variable i, b
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		b = EDG_PeakBase(i)
		w[b+0] = 0		// amplitude
		w[b+1] = 0		// position
		w[b+2] = 0.5	// half-width
		w[b+3] = 0		// skew
		w[b+4] = 1		// L/W ratio
		w[b+5] = 0.5	// Gaussian fraction
	endfor
	EDG_LabelParams(w)
End

// Name every point so a table of the wave (Edit w.ld) reads like gedgfit
Function EDG_LabelParams(w)
	Wave w
	Variable i, k, n = numpnts(w)
	SetDimLabel 0, 0, Step_Gauss_frac, w
	SetDimLabel 0, 1, Step_amplitude, w
	SetDimLabel 0, 2, Step_position_E0, w
	SetDimLabel 0, 3, Step_half_width, w
	String lbl
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			if(EDG_PeakBase(i)+k < n)
				lbl = "P" + num2istr(i+1) + "_" + StringFromList(k, ksEDG_PeakFields)
				SetDimLabel 0, EDG_PeakBase(i)+k, $lbl, w
			endif
		endfor
	endfor
End

// Plain-language description of parameter k, e.g. "Peak 3 position (eV)"
Function/S EDG_Describe(k)
	Variable k
	if(k < kEDG_NGlobal)
		return StringFromList(k, "Step Gaussian fraction;Step amplitude (hold at 1);Step position E0 (eV);Step half-width (eV);")
	endif
	Variable i = floor((k - kEDG_NGlobal)/kEDG_PerPeak)
	Variable f = mod(k - kEDG_NGlobal, kEDG_PerPeak)
	if(i >= kEDG_MaxPeaks)
		return "(unused)"
	endif
	return "Peak " + num2istr(i+1) + " " + StringFromList(f, "amplitude;position (eV);half-width (eV);skew;L/W ratio (G/L width);Gaussian fraction;")
End

// Text wave <base>_P_Desc: one row per parameter, "p[k]  description".
// Shown next to <base>_P so every row is identified at a glance.
Function EDG_MakeDescWave(base)
	String base
	Make/O/T/N=(kEDG_WaveLen) $(EDG_Name(base, "P_Desc"))
	Wave/T d = $(EDG_Name(base, "P_Desc"))
	d = "p[" + num2istr(p) + "]  " + EDG_Describe(p)
End

// Convert w in place to the current 76-point layout. Recognises:
//   < 75 points          original EDG_Fit12 layout (5 per peak)
//   75 points            gedgfit export (no step amplitude) - amp set to ampDefault
//   76, row 1 labelled Step_position   the previous version of this file
//                        (step amplitude stored last, at w[75])
//   76 points otherwise  already current
// Returns a description of what was done ("" if nothing).
Function/S EDG_ToCurrentLayout(w, ampDefault)
	Wave w
	Variable ampDefault
	Variable n = numpnts(w)
	String what = ""
	if(n < kEDG_GedgfitLen)
		EDG_FromIgorLayout(w, w)
		what = "original 5-per-peak Igor layout (" + num2istr(n) + " points)"
	elseif(n == kEDG_GedgfitLen)
		EDG_FromGedgfitLayout(w, w, ampDefault)
		what = "gedgfit 75-point layout"
	elseif(n == kEDG_WaveLen && cmpstr(GetDimLabel(w, 0, 1), "Step_position") == 0)
		Duplicate/FREE w, src
		w[0] = src[0]
		w[1] = src[75]
		w[2] = src[1]
		w[3] = src[2]
		w[4, 75] = src[p-1]
		what = "previous layout with the step amplitude at p[75]"
	elseif(n > kEDG_WaveLen)
		Redimension/N=(kEDG_WaveLen) w
		what = "longer wave, trimmed to 76 points"
	endif
	EDG_LabelParams(w)
	return what
End

// gedgfit 75-point wave [mix, E0, W0, peaks...] -> current layout
Function EDG_FromGedgfitLayout(g, new, amp)
	Wave g, new
	Variable amp
	Duplicate/FREE g, src
	Redimension/D/N=(kEDG_WaveLen) new
	new[0] = src[0]
	new[1] = amp
	new[2] = src[1]
	new[3] = src[2]
	new[4, 75] = src[p-1]
	EDG_LabelParams(new)
End

// Name every point of a gedgfit 75-point wave [mix, E0, W0, peaks...],
// with the same labels gedgfit writes
Function EDG_LabelGedgfitLayout(w)
	Wave w
	SetDimLabel 0, 0, Step_Gauss_frac, w
	SetDimLabel 0, 1, Step_position_E0, w
	SetDimLabel 0, 2, Step_half_width, w
	Variable i, k, idx
	String lbl
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			idx = 3 + kEDG_PerPeak*i + k
			if(idx < numpnts(w))
				lbl = "P" + num2istr(i+1) + "_" + StringFromList(k, ksEDG_PeakFields)
				SetDimLabel 0, idx, $lbl, w
			endif
		endfor
	endfor
End

// Description of point k of a gedgfit 75-point wave, as gedgfit writes it
Function/S EDG_DescribeGedgfit(k)
	Variable k
	if(k < 3)
		return StringFromList(k, "Step Gaussian fraction;Step position E0 (eV);Step half-width (eV);")
	endif
	Variable i = floor((k - 3)/kEDG_PerPeak)
	Variable f = mod(k - 3, kEDG_PerPeak)
	return "Peak " + num2istr(i+1) + " " + StringFromList(f, "amplitude;position (eV);half-width (eV);skew;L/W ratio (G/L width);Gaussian fraction;")
End

// Current layout -> gedgfit 75-point wave (step amplitude dropped; gedgfit
// holds it in its own "Step amplitude" box)
Function EDG_ToGedgfitLayout(w, out)
	Wave w, out
	Duplicate/FREE w, src
	Redimension/D/N=(kEDG_GedgfitLen) out
	out[0] = src[0]
	out[1] = src[2]
	out[2] = src[3]
	out[3, 74] = src[p+1]
End

// Original 5-per-peak Igor wave (any length, e.g. 53 or 63) -> new layout.
// Every peak fraction is set to old[0], which reproduces Igor exactly
// (gedgfit from_igor_layout).
Function EDG_FromIgorLayout(old, new)
	Wave old, new
	Duplicate/FREE old, src			// allows old and new to be the same wave
	EDG_DefaultParams(new)			// step amplitude = 1, as Igor hard-wired it
	Variable n = numpnts(src), i, k, si, b
	if(n > 0)
		new[0] = src[0]				// mix
	endif
	if(n > 1)
		new[2] = src[1]				// step position
	endif
	if(n > 2)
		new[3] = src[2]				// step half-width
	endif
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		si = 3 + kEDG_IgorPerPeak*i
		if(si + kEDG_IgorPerPeak > n)
			break
		endif
		b = EDG_PeakBase(i)
		for(k=0; k<kEDG_IgorPerPeak; k+=1)
			new[b+k] = src[si+k]
		endfor
	endfor
	EDG_LinkGauss(new)
End

// New layout -> the 63 parameters the ORIGINAL edg_fitN reads
// (gedgfit to_igor_layout). Per-peak fractions are dropped.
Function EDG_ToIgorLayout(w, out)
	Wave w, out
	Duplicate/FREE w, src
	Redimension/D/N=(kEDG_IgorLen) out
	out = 0
	Variable i, k, si, b
	out[0] = src[0]
	out[1] = src[2]
	out[2] = src[3]
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		b = EDG_PeakBase(i)
		si = 3 + kEDG_IgorPerPeak*i
		for(k=0; k<kEDG_IgorPerPeak; k+=1)
			out[si+k] = src[b+k]
		endfor
	endfor
	if(!EDG_MixesLinked(src))
		Print "EDG_ToIgorLayout: the per-peak Gaussian fractions differ from w[0]; the original edg_fitN cannot express that."
	endif
	if(src[1] != 1)
		Print "EDG_ToIgorLayout: the step amplitude is not 1; the original edg_fitN cannot express that."
	endif
End

// gedgfit "Link all Gauss fractions to the step (Igor behaviour)"
Function EDG_LinkGauss(w)
	Wave w
	Variable i
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		w[EDG_PeakBase(i)+5] = w[0]
	endfor
End

Function EDG_MixesLinked(w)
	Wave w
	Variable i
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		if(abs(w[EDG_PeakBase(i)+5] - w[0]) > 1e-12)
			return 0
		endif
	endfor
	return 1
End

// Analytic area of 0-based peak i (gedgfit peak_area). NaN when skewed.
//   Area = A*W*[ m*R*sqrt(pi/ln2) + (1-m)*pi ]
Function EDG_PeakArea(w, i)
	Wave w
	Variable i
	Variable b = EDG_PeakBase(i)
	if(w[b+3] != 0)
		return NaN
	endif
	Variable m = w[b+5]
	return w[b]*w[b+2]*(m*w[b+4]*sqrt(pi/ln(2)) + (1-m)*pi)
End

// Standard error on that area from the full covariance matrix
// (gedgfit peak_area_error). covar is FuncFit's M_Covar; sig is W_sigma.
// M_Covar is rescaled so its diagonal matches W_sigma^2, which makes the
// result follow the same error convention Igor used for W_sigma.
Function EDG_PeakAreaError(w, i, covar, sig, hold)
	Wave w, covar, sig
	Variable i
	String hold
	Variable b = EDG_PeakBase(i), n = numpnts(w)
	if(w[b+3] != 0 || DimSize(covar,0) != n || DimSize(covar,1) != n)
		return NaN
	endif
	Variable k, scale = NaN
	for(k=0; k<n; k+=1)
		if(cmpstr(hold[k], "1") != 0 && covar[k][k] > 0 && numtype(sig[k]) == 0)
			scale = sig[k]^2/covar[k][k]
			break
		endif
	endfor
	if(numtype(scale) != 0)
		return NaN
	endif
	Variable A = w[b], Wd = w[b+2], lw = w[b+4], m = w[b+5]
	Variable kk = sqrt(pi/ln(2))
	Variable brk = m*lw*kk + (1-m)*pi
	Make/FREE/D/N=4 idx, g
	idx[0] = b;			g[0] = Wd*brk				// amplitude
	idx[1] = b+2;		g[1] = A*brk				// width
	idx[2] = b+4;		g[2] = A*Wd*m*kk			// L/W ratio
	idx[3] = b+5;		g[3] = A*Wd*(lw*kk - pi)		// Gaussian fraction
	Variable ri, ci, var = 0
	for(ri=0; ri<4; ri+=1)
		if(cmpstr(hold[idx[ri]], "1") == 0)
			g[ri] = 0
		endif
	endfor
	for(ri=0; ri<4; ri+=1)
		for(ci=0; ci<4; ci+=1)
			var += g[ri]*covar[idx[ri]][idx[ci]]*g[ci]
		endfor
	endfor
	var *= scale
	return (var > 0) ? sqrt(var) : 0
End


// ===========================================================================
//  Derivatives and starting guesses (gedgfit Tools > Derivative viewer,
//  "Guess positions" and the amplitude estimate)
// ===========================================================================

// Igor's "Smooth n": n passes of [1 2 1]/4, end points repeated each pass
Function EDG_BinomialSmooth(w, passes)
	Wave w
	Variable passes
	Variable n = numpnts(w), k
	if(n < 2)
		return 0
	endif
	Duplicate/FREE w, src
	for(k=0; k<passes; k+=1)
		src = w
		if(n >= 3)
			w[1, n-2] = 0.25*src[p-1] + 0.5*src[p] + 0.25*src[p+1]
		endif
		w[0] = 0.75*src[0] + 0.25*src[1]
		w[n-1] = 0.25*src[n-2] + 0.75*src[n-1]
	endfor
End

// dy/dx exactly as numpy.gradient(y, x): second-order non-uniform central
// differences inside, one-sided first differences at the ends
Function EDG_Gradient(yw, xw, out)
	Wave yw, xw, out
	Variable n = numpnts(yw)
	Redimension/D/N=(n) out
	if(n < 2)
		out = NaN
		return 0
	endif
	Duplicate/FREE yw, f
	Duplicate/FREE xw, xs
	if(n >= 3)
		out[1, n-2] = ((xs[p]-xs[p-1])^2*f[p+1] + ((xs[p+1]-xs[p])^2 - (xs[p]-xs[p-1])^2)*f[p] - (xs[p+1]-xs[p])^2*f[p-1]) / ((xs[p]-xs[p-1])*(xs[p+1]-xs[p])*((xs[p+1]-xs[p]) + (xs[p]-xs[p-1])))
	endif
	out[0] = (f[1]-f[0])/(xs[1]-xs[0])
	out[n-1] = (f[n-1]-f[n-2])/(xs[n-1]-xs[n-2])
End

// gedgfit derivatives(): smoothed spectrum, smoothed 1st and 2nd derivatives
Function EDG_Derivatives(xw, yw, passes, ys, d1s, d2s)
	Wave xw, yw, ys, d1s, d2s
	Variable passes
	Redimension/D/N=(numpnts(yw)) ys
	ys = yw[p]
	EDG_BinomialSmooth(ys, passes)
	EDG_Gradient(ys, xw, d1s)
	EDG_BinomialSmooth(d1s, passes)
	EDG_Gradient(d1s, xw, d2s)
	EDG_BinomialSmooth(d2s, passes)
End

// gedgfit suggest_peaks(): up to n positions at the deepest 2nd-derivative
// minima, at least (xmax-xmin)/60 apart, returned sorted by energy
Function EDG_SuggestPeaks(xw, yw, n, passes, posOut)
	Wave xw, yw, posOut
	Variable n, passes
	Make/FREE/D ys, d1, d2
	EDG_Derivatives(xw, yw, passes, ys, d1, d2)
	Variable np = numpnts(xw), i, j, ok
	Make/FREE/D/N=0 cv, cx
	for(i=1; i<np-1; i+=1)
		if(d2[i] < d2[i-1] && d2[i] <= d2[i+1] && d2[i] < 0)
			InsertPoints numpnts(cv), 1, cv, cx
			cv[numpnts(cv)-1] = d2[i]
			cx[numpnts(cx)-1] = xw[i]
		endif
	endfor
	Redimension/D/N=0 posOut
	if(numpnts(cv) == 0)
		return 0
	endif
	Sort {cv, cx}, cv, cx
	Variable minSep = max((WaveMax(xw) - WaveMin(xw))/60, 1e-6)
	for(i=0; i<numpnts(cv); i+=1)
		ok = 1
		for(j=0; j<numpnts(posOut); j+=1)
			if(abs(cx[i] - posOut[j]) < minSep)
				ok = 0
				break
			endif
		endfor
		if(ok)
			InsertPoints numpnts(posOut), 1, posOut
			posOut[numpnts(posOut)-1] = cx[i]
		endif
		if(numpnts(posOut) >= n)
			break
		endif
	endfor
	Sort posOut, posOut
	return numpnts(posOut)
End

// gedgfit auto_amplitudes(): peel intensity off the data above the step
Function EDG_AutoAmplitudes(w, xw, yw, n)
	Wave w, xw, yw
	Variable n
	Duplicate/FREE yw, resid
	Redimension/D resid
	resid = yw[p] - EDG_StepComp(w, xw[p])
	Variable i, j, a, b
	Make/FREE/D/N=(numpnts(xw)) dist
	for(i=0; i<n; i+=1)
		b = EDG_PeakBase(i)
		dist = abs(xw[p] - w[b+1])
		WaveStats/Q/M=1 dist
		j = V_minloc
		a = max(resid[j], 0)
		w[b] = a
		resid -= EDG_PeakComp(w, xw[p], i)
	endfor
	for(i=0; i<n; i+=1)			// gedgfit shows (and keeps) 4 significant figures
		w[EDG_PeakBase(i)] = EDG_Round(w[EDG_PeakBase(i)], 4)
	endfor
End

// Round to 'sig' significant figures, as gedgfit's f"{v:.4g}" widgets do
Function EDG_Round(v, sigfig)
	Variable v, sigfig
	String txt
	String fmt = "%." + num2istr(sigfig) + "g"
	sprintf txt, fmt, v
	return str2num(txt)
End


// ===========================================================================
//  GUI-style parameter tables and synchronisation
// ===========================================================================

Function/S EDG_Name(base, suffix)
	String base, suffix
	return base + "_" + suffix
End

// Make sure <base>_P exists in the new 76-point layout, converting old waves
Function EDG_EnsureP(base)
	String base
	Wave/Z pw = $(EDG_Name(base, "P"))
	if(!WaveExists(pw))
		Make/O/D/N=(kEDG_WaveLen) $(EDG_Name(base, "P"))
		Wave pw = $(EDG_Name(base, "P"))
		EDG_DefaultParams(pw)
		return 0
	endif
	Variable n = numpnts(pw)
	String bak = EDG_Name(base, "P_old" + num2istr(n))
	Duplicate/FREE pw, before
	String what = EDG_ToCurrentLayout(pw, 1)
	if(strlen(what))
		Duplicate/O before, $bak
		Printf "%s was in the %s. Saved a copy as %s and converted it (p[1] = step amplitude, peaks from p[4]).\r", NameOfWave(pw), what, bak
	endif
End

// Create the step and peak tables if needed, then fill their VALUE columns
// from <base>_P (hold columns are left alone)
Function EDG_TablesFromP(base)
	String base
	Wave pw = $(EDG_Name(base, "P"))
	Variable i, k
	Wave/Z st = $(EDG_Name(base, "Step"))
	if(!WaveExists(st) || DimSize(st,0) != 4 || DimSize(st,1) != 2)
		Make/O/D/N=(4,2) $(EDG_Name(base, "Step"))
		Wave st = $(EDG_Name(base, "Step"))
		st[][1] = 0
		st[1][1] = 1				// step amplitude held, as in gedgfit
		for(i=0; i<4; i+=1)
			SetDimLabel 0, i, $StringFromList(i, ksEDG_StepRows), st
		endfor
		SetDimLabel 1, 0, value, st
		SetDimLabel 1, 1, hold, st
	endif
	if(cmpstr(GetDimLabel(st, 0, 1), "Step_amplitude") != 0)
		// step table from the previous version (rows: frac, position,
		// half-width, amplitude) - move the hold flags to the new row order
		Make/FREE/D/N=4 oh
		oh = st[p][1]
		st[0][1] = oh[0]
		st[1][1] = oh[3]
		st[2][1] = oh[1]
		st[3][1] = oh[2]
		for(i=0; i<4; i+=1)
			SetDimLabel 0, i, $StringFromList(i, ksEDG_StepRows), st
		endfor
	endif
	Wave/Z pk = $(EDG_Name(base, "Peaks"))
	if(!WaveExists(pk) || DimSize(pk,0) != kEDG_MaxPeaks || DimSize(pk,1) != 2*kEDG_PerPeak)
		Make/O/D/N=(kEDG_MaxPeaks, 2*kEDG_PerPeak) $(EDG_Name(base, "Peaks"))
		Wave pk = $(EDG_Name(base, "Peaks"))
		pk = 0
		pk[][2*3+1] = 1				// skew held
		pk[][2*4+1] = 1				// L/W ratio held
		pk[][2*5+1] = 1				// Gaussian fraction held
		for(i=0; i<kEDG_MaxPeaks; i+=1)
			SetDimLabel 0, i, $("Peak" + num2istr(i+1)), pk
		endfor
		for(k=0; k<kEDG_PerPeak; k+=1)
			SetDimLabel 1, 2*k, $StringFromList(k, ksEDG_PeakFields), pk
			SetDimLabel 1, 2*k+1, $StringFromList(k, ksEDG_PeakHolds), pk
		endfor
	endif
	for(i=0; i<kEDG_NGlobal; i+=1)
		st[i][0] = pw[i]
	endfor
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			pk[i][2*k] = pw[EDG_PeakBase(i)+k]
		endfor
	endfor
End

// Parameter vector described by the tables
Function EDG_VectorFromTables(base, out)
	String base
	Wave out
	Wave st = $(EDG_Name(base, "Step"))
	Wave pk = $(EDG_Name(base, "Peaks"))
	Redimension/D/N=(kEDG_WaveLen) out
	Variable i, k
	for(i=0; i<kEDG_NGlobal; i+=1)
		out[i] = st[i][0]
	endfor
	for(i=0; i<kEDG_MaxPeaks; i+=1)
		for(k=0; k<kEDG_PerPeak; k+=1)
			out[EDG_PeakBase(i)+k] = pk[i][2*k]
		endfor
	endfor
End

// Bring <base>_P and the tables into agreement.
//  * _P changed since the last sync (a fit, the Curve Fitting dialog, OldP,
//    an import)  -> copied into the tables
//  * only the tables changed (you typed in them) -> copied into _P
Function EDG_Sync(base)
	String base
	EDG_EnsureP(base)
	Wave pw = $(EDG_Name(base, "P"))
	Wave/Z st = $(EDG_Name(base, "Step"))
	Wave/Z pk = $(EDG_Name(base, "Peaks"))
	Wave/Z ps = $(EDG_Name(base, "P_sync"))
	if(!WaveExists(st) || !WaveExists(pk) || !WaveExists(ps))
		EDG_TablesFromP(base)
	else
		Make/FREE/D tv
		EDG_VectorFromTables(base, tv)
		Variable pChanged = !EqualWaves(pw, ps, 1)
		Variable tChanged = !EqualWaves(tv, ps, 1)
		if(pChanged)
			if(tChanged)
				Print "EDG_Sync: both the parameter tables and " + NameOfWave(pw) + " were edited; keeping " + NameOfWave(pw) + "."
			endif
			EDG_TablesFromP(base)
		elseif(tChanged)
			pw = tv[p]
		endif
	endif
	Duplicate/O pw, $(EDG_Name(base, "P_sync"))
End

// FuncFit hold string from the hold columns. Every parameter of a peak
// beyond nPeaks is held, as gedgfit does.
Function/S EDG_HoldString(base, nPeaks)
	String base
	Variable nPeaks
	Wave st = $(EDG_Name(base, "Step"))
	Wave pk = $(EDG_Name(base, "Peaks"))
	Wave pw = $(EDG_Name(base, "P"))
	String hs = ""
	Variable k, i, f, h
	for(k=0; k<numpnts(pw); k+=1)
		if(k < kEDG_NGlobal)
			h = st[k][1]
		else
			i = floor((k - kEDG_NGlobal)/kEDG_PerPeak)
			f = mod(k - kEDG_NGlobal, kEDG_PerPeak)
			h = (i >= nPeaks) ? 1 : pk[i][2*f+1]
		endif
		hs += SelectString(h != 0, "0", "1")
	endfor
	return hs
End

Function EDG_ShowParamTable(base)
	String base
	String win = base + "_Params"
	if(WinType(win) == 2)
		DoWindow/F $win
		return 0
	endif
	Wave st = $(EDG_Name(base, "Step"))
	Wave pk = $(EDG_Name(base, "Peaks"))
	Edit/K=1/N=$win st.ld, pk.ld as base + " parameters (hold: 1 = held)"
	ModifyTable format=3, digits=6
End

// gedgfit's fit_slice: points within [xmin,xmax]; NaN = open end. Falls back
// to every point if fewer than 5 remain.
Function EDG_RangeMask(xw, xmin, xmax, mask)
	Wave xw, mask
	Variable xmin, xmax
	Variable lo = (numtype(xmin) == 0) ? xmin : -inf
	Variable hi = (numtype(xmax) == 0) ? xmax : inf
	if(hi < lo)
		Variable tmp = lo
		lo = hi
		hi = tmp
	endif
	Redimension/D/N=(numpnts(xw)) mask
	mask = (xw[p] >= lo && xw[p] <= hi) ? 1 : 0
	if(sum(mask) < 5)
		mask = 1
	endif
End

// gedgfit make_weights("poisson") expressed as standard deviations
Function EDG_PoissonSigma(yw, mask, sig)
	Wave yw, mask, sig
	Duplicate/FREE yw, mag
	mag = abs(yw[p])
	Extract/FREE mag, mm, mask[p] != 0
	Variable fl = max((WaveMax(mm) - WaveMin(mm))*1e-3, 1e-12)
	Redimension/D/N=(numpnts(yw)) sig
	sig = sqrt(max(mag[p], fl))
End

// Constraint wave reproducing gedgfit's build_bounds (only free parameters)
Function EDG_MakeConstraints(base, nPeaks, xw, mask, hold)
	String base, hold
	Variable nPeaks
	Wave xw, mask
	Wave pw = $(EDG_Name(base, "P"))
	Make/O/T/N=0 $(EDG_Name(base, "Constraints"))
	Wave/T C = $(EDG_Name(base, "Constraints"))
	Extract/FREE xw, xs, mask[p] != 0
	Variable xlo = WaveMin(xs), xhi = WaveMax(xs)
	Variable i, b, lo, hi
	EDG_AddLimit(C, hold, 0, kEDG_MixMin, kEDG_MixMax)
	EDG_AddLimit(C, hold, 1, 0, inf)
	EDG_AddLimit(C, hold, 2, pw[2]-kEDG_StepPosTol, pw[2]+kEDG_StepPosTol)
	EDG_AddLimit(C, hold, 3, kEDG_WidthMin, kEDG_WidthMax)
	for(i=0; i<nPeaks; i+=1)
		b = EDG_PeakBase(i)
		EDG_AddLimit(C, hold, b, kEDG_AmpMin, kEDG_AmpMax)
		lo = pw[b+1] - kEDG_PosTol
		hi = pw[b+1] + kEDG_PosTol
		lo = max(lo, xlo)
		hi = max(hi, xlo + 1e-6)
		hi = min(hi, xhi)
		lo = min(lo, xhi - 1e-6)
		EDG_AddLimit(C, hold, b+1, lo, hi)
		EDG_AddLimit(C, hold, b+2, kEDG_WidthMin, kEDG_WidthMax)
		EDG_AddLimit(C, hold, b+3, kEDG_SkewMin, kEDG_SkewMax)
		EDG_AddLimit(C, hold, b+4, kEDG_LWRMin, kEDG_LWRMax)
		EDG_AddLimit(C, hold, b+5, kEDG_MixMin, kEDG_MixMax)
	endfor
	return numpnts(C)
End

static Function EDG_AddLimit(C, hold, k, lo, hi)
	Wave/T C
	String hold
	Variable k, lo, hi
	if(cmpstr(hold[k], "1") == 0)
		return 0
	endif
	String cline
	if(numtype(lo) == 0)
		sprintf cline, "K%d > %.17g", k, lo
		InsertPoints numpnts(C), 1, C
		C[numpnts(C)-1] = cline
	endif
	if(numtype(hi) == 0)
		sprintf cline, "K%d < %.17g", k, hi
		InsertPoints numpnts(C), 1, C
		C[numpnts(C)-1] = cline
	endif
End


// ===========================================================================
//  Fitting and reporting
// ===========================================================================

// Goodness of fit at the current parameters (gedgfit evaluate). Results go
// into the free wave 'stats': chi2, red_chi2, dof, R2, rms, n_points.
Function EDG_Evaluate(pw, xw, yw, mask, nPeaks, weighting, nFree, stats)
	Wave pw, xw, yw, mask, stats
	Variable nPeaks, nFree
	String weighting
	Extract/FREE xw, xs, mask[p] != 0
	Extract/FREE yw, ys, mask[p] != 0
	Variable n = numpnts(xs)
	Make/FREE/D/N=(n) fit, wt
	fit = EDG_Total(pw, xs[p], nPeaks)
	wt = 1
	if(cmpstr(weighting, "poisson") == 0)
		Make/FREE/D/N=(n) one = 1
		Make/FREE/D sg
		EDG_PoissonSigma(ys, one, sg)
		wt = 1/sg[p]
	endif
	Make/FREE/D/N=(n) r2w, r2u
	r2w = ((fit[p] - ys[p])*wt[p])^2
	r2u = (ys[p] - fit[p])^2
	Variable chi2 = sum(r2w)
	Variable dof = max(n - max(nFree, 0), 1)
	Variable mY = mean(ys)
	Make/FREE/D/N=(n) tot = (ys[p] - mY)^2
	Variable ssTot = sum(tot), ssRes = sum(r2u)
	Redimension/D/N=6 stats
	stats[0] = chi2
	stats[1] = chi2/dof
	stats[2] = dof
	stats[3] = (ssTot > 0) ? 1 - ssRes/ssTot : NaN
	stats[4] = sqrt(ssRes/n)
	stats[5] = n
	return chi2
End

// Run FuncFit with the hold columns, fit range and options. Returns V_FitError.
//   weighting : "none" (default, as gedgfit) or "poisson"
//   useLimits : 0 = unconstrained Levenberg-Marquardt, like gedgfit's default
//               1 = apply gedgfit's fit limits as constraints
//   tol       : V_FitTol (gedgfit's default chi-square tolerance is 1e-8;
//               Igor's own default is 1e-3)
Function EDG_DoFit(base, xw, yw, nPeaks, xmin, xmax, weighting, useLimits, tol)
	String base, weighting
	Wave xw, yw
	Variable nPeaks, xmin, xmax, useLimits, tol
	if(nPeaks < 1 || nPeaks > kEDG_MaxPeaks)
		Abort "Number of peaks must be 1 to 12."
	endif
	EDG_Sync(base)
	Wave pw = $(EDG_Name(base, "P"))
	String hold = EDG_HoldString(base, nPeaks)
	Variable k, nFree = 0
	for(k=0; k<strlen(hold); k+=1)
		nFree += (cmpstr(hold[k], "0") == 0)
	endfor
	Make/O/D/N=(numpnts(yw)) $(EDG_Name(base, "FitMask"))
	Wave mask = $(EDG_Name(base, "FitMask"))
	EDG_RangeMask(xw, xmin, xmax, mask)
	if(nFree == 0)
		Abort "Every parameter is held fixed - nothing to refine."
	endif
	if(nFree > sum(mask))
		Abort num2istr(nFree) + " free parameters but only " + num2istr(sum(mask)) + " data points in the fit range."
	endif

	String extra = ""
	if(cmpstr(weighting, "poisson") == 0)
		Make/O/D $(EDG_Name(base, "FitSigma"))
		Wave sg = $(EDG_Name(base, "FitSigma"))
		EDG_PoissonSigma(yw, mask, sg)
		extra += " /W=" + GetWavesDataFolder(sg, 2) + " /I=1"
		if(WaveMax(yw) < 50)
			Print "Note: Poisson weighting assumes raw counts; these data peak below 50. Weighting \"none\" is usually right for normalised spectra."
		endif
	endif
	if(useLimits)
		EDG_MakeConstraints(base, nPeaks, xw, mask, hold)
		Wave/T C = $(EDG_Name(base, "Constraints"))
		if(numpnts(C) > 0)
			extra += " /C=" + GetWavesDataFolder(C, 2)
		endif
	endif

	Make/FREE/D st0
	Variable chiStart = EDG_Evaluate(pw, xw, yw, mask, nPeaks, weighting, nFree, st0)

	Variable/G V_FitError = 0
	Variable/G V_FitTol = tol
	Variable/G V_FitMaxIters = 500
	Variable/G V_FitNumIters = 0
	String cmd
	sprintf cmd, "FuncFit/N/M=2/L=%d/H=\"%s\" edg_fit%d %s %s /X=%s /M=%s /D%s", kEDG_FitCurvePoints, hold, nPeaks, GetWavesDataFolder(pw,2), GetWavesDataFolder(yw,2), GetWavesDataFolder(xw,2), GetWavesDataFolder(mask,2), extra
	Execute cmd
	if(V_FitError != 0)
		Printf "Fit failed (V_FitError = %d). Parameters left as they were before the fit.\r", V_FitError
		return V_FitError
	endif

	Wave/Z W_sigma, M_Covar
	Make/O/D/N=(numpnts(pw)) $(EDG_Name(base, "Sigma"))
	Wave sig = $(EDG_Name(base, "Sigma"))
	sig = NaN
	if(WaveExists(W_sigma) && numpnts(W_sigma) == numpnts(pw))
		sig = W_sigma[p]
		for(k=0; k<numpnts(pw); k+=1)
			if(cmpstr(hold[k], "1") == 0)
				sig[k] = NaN				// gedgfit reports held parameters as NaN
			endif
		endfor
	endif
	EDG_LabelParams(sig)
	if(WaveExists(M_Covar))
		Duplicate/O M_Covar, $(EDG_Name(base, "Covar"))
	endif
	String/G $(EDG_Name(base, "LastHold"))
	SVAR lh = $(EDG_Name(base, "LastHold"))
	lh = hold

	EDG_Sync(base)		// fit result -> tables
	Printf "Fit converged after %d iterations.\r", V_FitNumIters
	EDG_Report(base, xw, yw, nPeaks, xmin, xmax, weighting, chiStart)
	return 0
End

// Print a gedgfit-style report of the current parameters
Function EDG_Report(base, xw, yw, nPeaks, xmin, xmax, weighting, chiStart)
	String base, weighting
	Wave xw, yw
	Variable nPeaks, xmin, xmax, chiStart
	EDG_Sync(base)
	Wave pw = $(EDG_Name(base, "P"))
	Wave/Z sig = $(EDG_Name(base, "Sigma"))
	Wave/Z cov = $(EDG_Name(base, "Covar"))
	SVAR/Z lastHold = $(EDG_Name(base, "LastHold"))
	String hold = EDG_HoldString(base, nPeaks)
	Variable k, nFree = 0
	for(k=0; k<strlen(hold); k+=1)
		nFree += (cmpstr(hold[k], "0") == 0)
	endfor
	Make/FREE/D/N=(numpnts(yw)) mask
	EDG_RangeMask(xw, xmin, xmax, mask)
	Make/FREE/D st
	EDG_Evaluate(pw, xw, yw, mask, nPeaks, weighting, nFree, st)

	Print "------------------------------------------------------------"
	Printf "%s   %d peaks   weighting: %s\r", base, nPeaks, weighting
	if(numtype(chiStart) == 0)
		Printf "chi-square  %.8g -> %.8g  (%.3g%% lower)\r", chiStart, st[0], 100*(chiStart - st[0])/max(chiStart, 1e-300)
	else
		Printf "chi-square  %.8g\r", st[0]
	endif
	Printf "red. chi2   %.8g   (dof %d)\rR^2         %.8g\rRMS resid   %.8g\rpoints      %d\r", st[1], st[2], st[3], st[4], st[5]
	Printf "%-33s %14s %14s\r", "parameter", "value", "error"
	Variable i, f, b, sv
	String nm, flag
	for(k=0; k<kEDG_NGlobal; k+=1)
		sv = EDG_SigAt(sig, k)
		flag = SelectString(cmpstr(hold[k], "1") == 0, "", "  (held)")
		Printf "p[%-2d] %-28s %14.6g %14.6g%s\r", k, EDG_Describe(k), pw[k], sv, flag
	endfor
	Variable pkArea, aerr
	for(i=0; i<nPeaks; i+=1)
		b = EDG_PeakBase(i)
		for(f=0; f<kEDG_PerPeak; f+=1)
			sv = EDG_SigAt(sig, b+f)
			flag = SelectString(cmpstr(hold[b+f], "1") == 0, "", "  (held)")
			Printf "p[%-2d] %-28s %14.6g %14.6g%s\r", b+f, EDG_Describe(b+f), pw[b+f], sv, flag
		endfor
		pkArea = EDG_PeakArea(pw, i)
		aerr = NaN
		if(WaveExists(cov) && WaveExists(sig) && SVAR_Exists(lastHold))
			aerr = EDG_PeakAreaError(pw, i, cov, sig, lastHold)
		endif
		Printf "      %-28s %14.6g %14.6g\r", "Peak " + num2istr(i+1) + " area", pkArea, aerr
	endfor
	if(!EDG_MixesLinked(pw))
		Print "Peaks use their own Gaussian fractions (gedgfit behaviour). EDG_LinkGauss() sets them all to the step's."
	endif
	Print "------------------------------------------------------------"
End

static Function EDG_SigAt(sig, k)
	Wave/Z sig
	Variable k
	if(!WaveExists(sig) || k >= numpnts(sig))
		return NaN
	endif
	return sig[k]
End

''',
    "gedgfit_Workflow.ipf": r'''#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma IgorVersion=7.00

// ===========================================================================
//  gedgfit_Workflow.ipf
//
//  Edge-fit workflow using the gedgfit parameter layout, parameter table and
//  mathematics. Needs gedgfit_Model.ipf open at the same time.
//  Generic version of Cp2VCl2_CK_Apr2012_8CF_indep.ipf: the sample name is
//  not hard-coded. Open this file OR that one, not both.
//
//  BASE NAME
//    Every wave is named <base>_<suffix>, e.g. Cp2VCl2_Int. The base is the
//    global string root:gEDG_Base (set by gedgfit's Igor export, or by
//    SetBase("mysample")); without it the base is ksDefaultBase below,
//    which gedgfit sets to the sample name when it exports this file as
//    <sample>_<N>CF.ipf.
//
//  Data waves expected:  <base>_eV   (energy)
//                        <base>_Int  (normalised intensity)
//
//  TYPICAL SESSION (command line)
//    SetBase("Cp2VCl2")           choose the sample (not needed after a gedgfit export)
//    Derivs()                     smoothed 1st/2nd derivatives of <base>_Int
//                                 (Derivs(smooth=3) for other smoothing)
//    SetUp()                      parameter table, graph, component waves
//    SetUp(nPeaks=10)             ...or another peak count (1-12)
//    SetRange(284, 300)           fit range (or RangeFromCursors() with cursors A,B)
//    GuessPeaks()                 positions from the 2nd derivative + amplitudes
//    ...edit the "<base> parameters" table: values, and hold = 1 / 0...
//    Up()                         recompute components and residuals
//    FitIt()                      fit; options: FitIt(weighting="poisson"),
//                                 FitIt(useLimits=1), FitIt(tol=1e-3)
//    Report()                     chi-square, R^2, values, errors, peak areas
//    SP() / OldP()                store / recall a parameter set
//    ShowP()                      table of <base>_P with a description
//                                 column saying what each row is
//    LinkGauss()                  every peak fraction = step fraction (old Igor)
//    ImportGedgfitP()             load a _P.itx exported by gedgfit
//    ExportForGedgfit()           save the parameter wave as .itx for gedgfit
//    Wv_Plotter_Tot(), RSD_Plot_Tot(), RSD_Plot_Ind()   the figures
//                                 (fit_<base>_Int is the total fit, step +
//                                 peaks: recomputed by Up(), and overwritten
//                                 by Igor's FuncFit in FitIt())
//
//  PARAMETER ORDER: p[0] step Gaussian fraction, p[1] step amplitude,
//  p[2] step position, p[3] step half-width, then 6 per peak from p[4]:
//  amplitude, position, half-width, skew, L/W ratio, Gaussian fraction.
//
//  An old 53- or 63-point <base>_P, or one from an earlier version of these
//  files (step amplitude at p[75]), is converted automatically by SetUp; a
//  copy of the original is kept as <base>_P_old<N>.
// ===========================================================================

StrConstant ksDefaultBase = "Cp2VCl2"

Constant kDefaultNPeaks = 8
Constant kFirstPostEdgePeak = 6		// PostRSD = step + peaks 6..N (as before)
Constant kDefaultSmooth = 5			// gedgfit's default smoothing passes

// gedgfit's PEAK_COLORS, as Igor 16-bit RGB
StrConstant ksPeakRGB = "59110,51143,0;0,46260,0;0,53199,57568;65535,12079,41120;0,41120,23130;16191,32639,53456;65535,35980,6682;41120,27756,57568;35466,47288,0;57568,20560,20560;0,47288,41120;45232,41120,65535;"


// ---------------------------------------------------------------------------
//  Base name
// ---------------------------------------------------------------------------

// The base name all waves use: root:gEDG_Base, or the default
Function/S EDGBase()
	SVAR/Z b = root:gEDG_Base
	if(SVAR_Exists(b) && strlen(b) > 0)
		return b
	endif
	return ksDefaultBase
End

// Choose the sample, e.g. SetBase("Cp2VCl2")
Function SetBase(name)
	String name
	if(strlen(name) == 0 || cmpstr(CleanupName(name, 0), name) != 0)
		Abort "\"" + name + "\" is not a valid Igor wave-name stem (letters, digits and _ only, starting with a letter)."
	endif
	SVAR/Z b = root:gEDG_Base
	if(!SVAR_Exists(b))
		String/G root:gEDG_Base
	endif
	SVAR b2 = root:gEDG_Base
	b2 = name
	Printf "Base name set to %s (waves %s_eV, %s_Int, %s_P, ...).\r", name, name, name, name
End


// ---------------------------------------------------------------------------
//  Small helpers
// ---------------------------------------------------------------------------

static Function/WAVE BW(suffix)
	String suffix
	Wave/Z w = $(EDGBase() + "_" + suffix)
	return w
End

static Function GetNPeaks()
	NVAR/Z n = $(EDGBase() + "_nPk")
	if(!NVAR_Exists(n))
		return kDefaultNPeaks
	endif
	return n
End

static Function SetGlobalNum(suffix, v)
	String suffix
	Variable v
	String nm = EDGBase() + "_" + suffix
	NVAR/Z g = $nm
	if(!NVAR_Exists(g))
		Variable/G $nm
	endif
	NVAR g2 = $nm
	g2 = v
End

static Function GetGlobalNum(suffix, dflt)
	String suffix
	Variable dflt
	NVAR/Z g = $(EDGBase() + "_" + suffix)
	if(!NVAR_Exists(g))
		return dflt
	endif
	return g
End

static Function CheckData()
	Wave/Z dat = BW("Int"), ev = BW("eV")
	if(!WaveExists(dat) || !WaveExists(ev))
		Abort "Need waves " + EDGBase() + "_eV and " + EDGBase() + "_Int in the current data folder."
	endif
	if(numpnts(dat) != numpnts(ev))
		Abort EDGBase() + "_eV and " + EDGBase() + "_Int have different lengths."
	endif
End

static Function PeakRGB(i, which)		// i 1-based, which 0/1/2 = r/g/b
	Variable i, which
	String c = StringFromList(mod(i-1, 12), ksPeakRGB)
	return str2num(StringFromList(which, c, ","))
End

static Function StyleAxes()
	Label left "\\F'Arial'\\Z15Normalized Intensity";DelayUpdate
	Label bottom "\\F'Arial'\\Z15Energy (eV)"
	ModifyGraph mirror=2,minor=1,sep(left)=20,fSize=15,axThick=3,btLen=15,btThick=3;DelayUpdate
	ModifyGraph stLen(left)=7,stLen(bottom)=8,stThick=3,font="Arial"
	ModifyGraph gbrgb=(0,0,0)
End

// One wave per component and residual, matching the data length
static Function MakeComponentWaves(n)
	Variable n
	Wave dat = BW("Int")
	Variable i, np = numpnts(dat)
	String sfx = "Stp;TOT_RSD;RSDStp;PostRSD;"
	for(i=1; i<=n; i+=1)
		sfx += "Wv" + num2istr(i) + ";RSD" + num2istr(i) + ";"
	endfor
	for(i=0; i<ItemsInList(sfx); i+=1)
		Wave/Z w = BW(StringFromList(i, sfx))
		if(!WaveExists(w) || numpnts(w) != np)
			Make/O/D/N=(np) $(EDGBase() + "_" + StringFromList(i, sfx))
		endif
	endfor
End


// The total-fit curve fit_<base>_Int: the wave Igor's FuncFit /D writes, so
// a fit overwrites it in place. It is a waveform over the fit range with its
// own x scaling (plotted without "vs"). Made here if it does not exist yet.
static Function/WAVE FitCurve()
	Wave dat = BW("Int"), ev = BW("eV")
	String nm = "fit_" + NameOfWave(dat)
	Wave/Z fc = $nm
	if(!WaveExists(fc))
		Variable lo = GetGlobalNum("xmin", NaN), hi = GetGlobalNum("xmax", NaN)
		if(numtype(lo) != 0)
			lo = WaveMin(ev)
		endif
		if(numtype(hi) != 0)
			hi = WaveMax(ev)
		endif
		Make/O/D/N=(kEDG_FitCurvePoints) $nm
		Wave fc = $nm
		SetScale/I x lo, hi, "", fc
	endif
	return fc
End


// ---------------------------------------------------------------------------
//  Derivatives (gedgfit Tools > Derivative viewer)
//  Type "Derivs()"  or  "derivPlot(<base>_Int, <base>_eV, 5)"
// ---------------------------------------------------------------------------

Function derivPlot(dat, eVDat, smoothParam)
	Wave dat, eVDat
	Variable smoothParam
	Make/O/D/N=(numpnts(dat)) $(EDGBase() + "_Smth"), $(EDGBase() + "_DRV1_Smth"), $(EDGBase() + "_DRV2"), ZeroVec
	Wave ys = BW("Smth"), d1 = BW("DRV1_Smth"), d2 = BW("DRV2")
	Wave zv = ZeroVec
	zv = 0
	// smoothed spectrum, smoothed dy/dE, smoothed d2y/dE2 - exactly as gedgfit
	EDG_Derivatives(eVDat, dat, smoothParam, ys, d1, d2)
	String n1 = NameOfWave(d1), n2 = NameOfWave(d2)
	Display dat, d1, d2, zv vs eVDat as EDGBase() + "_DRV"
	ModifyGraph rgb($n1)=(3,52428,1)
	ModifyGraph rgb(ZeroVec)=(65535,65535,65535)
	ModifyGraph lsize=1
	ModifyGraph lstyle($n1)=1
	ModifyGraph mode($n2)=4,marker($n2)=19,msize($n2)=2
	ModifyGraph rgb($n2)=(16385,16388,65535)
	ModifyGraph mode($n1)=3,marker($n1)=1
	Legend/C/N=text0/F=0/B=(0,0,0)/G=(65535,65535,65535)
	StyleAxes()
	SetAxis/A
End


// derivPlot on the current sample's waves
Function Derivs([smooth])
	Variable smooth
	if(ParamIsDefault(smooth))
		smooth = kDefaultSmooth
	endif
	CheckData()
	Wave dat = BW("Int"), ev = BW("eV")
	derivPlot(dat, ev, smooth)
End


// ---------------------------------------------------------------------------
//  Setup
// ---------------------------------------------------------------------------

Function SetUp([nPeaks])
	Variable nPeaks
	CheckData()
	if(ParamIsDefault(nPeaks))
		nPeaks = GetNPeaks()
	endif
	if(nPeaks < 1 || nPeaks > 12)
		Abort "nPeaks must be 1 to 12."
	endif
	SetGlobalNum("nPk", nPeaks)
	SetGlobalNum("xmin", GetGlobalNum("xmin", NaN))		// fit range; NaN = open end
	SetGlobalNum("xmax", GetGlobalNum("xmax", NaN))

	// parameter wave (converted from the old layout if necessary) + tables
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Wave/Z prev0 = BW("Prev_P")
	if(!WaveExists(prev0))
		Duplicate/O pw, $(EDGBase() + "_Prev_P")
	else
		EDG_ToCurrentLayout(prev0, 1)
	endif

	Wave dat = BW("Int"), ev = BW("eV")
	Edit ev, dat as EDGBase() + " data"
	ShowP()
	EDG_ShowParamTable(EDGBase())

	MakeComponentWaves(nPeaks)
	Up()									// computes fit_<base>_Int before it is drawn

	// the spectrum with its total fit (step + peaks), kept current by Up()
	Wave fitw = FitCurve()
	Display dat vs ev as EDGBase() + " spectrum"
	String gwin = WinName(0, 1)
	StyleAxes()
	String dn = NameOfWave(dat), fn = NameOfWave(fitw)
	ModifyGraph/W=$gwin mode($dn)=4, marker($dn)=51, msize($dn)=3, opaque($dn)=1
	ModifyGraph/W=$gwin rgb($dn)=(65535,65535,65535)
	AppendToGraph/W=$gwin fitw
	ModifyGraph/W=$gwin mode($fn)=0, lsize($fn)=2, rgb($fn)=(54998,10023,10280)
	Legend/W=$gwin/C/N=text0/F=0/S=3/B=(0,0,0)/G=(65535,65535,65535)/A=MC
	Printf "%s set up for %d peaks. Edit the table '%s_Params' (hold: 1 = held), then Up() or FitIt().\r", EDGBase(), nPeaks, EDGBase()
End

// Table of the parameter wave with a column saying what each row is,
// beside the stored set (Prev_P) and the fit errors (Sigma)
Function ShowP()
	EDG_Sync(EDGBase())
	EDG_MakeDescWave(EDGBase())
	Wave pw = BW("P")
	Wave/T desc = BW("P_Desc")
	Wave/Z prev0 = BW("Prev_P")
	if(!WaveExists(prev0))
		Duplicate/O pw, $(EDGBase() + "_Prev_P")
	endif
	Wave/Z sig0 = BW("Sigma")
	if(!WaveExists(sig0) || numpnts(sig0) != numpnts(pw))
		Make/O/D/N=(numpnts(pw)) $(EDGBase() + "_Sigma")
		Wave sig1 = BW("Sigma")
		sig1 = NaN
	endif
	Wave prev = BW("Prev_P"), sig = BW("Sigma")
	String win = EDGBase() + "_PTable"
	if(WinType(win) == 2)
		DoWindow/F $win
		return 0
	endif
	Edit/K=1/N=$win desc, pw, prev, sig as EDGBase() + " parameter wave"
	ModifyTable width(desc)=190, alignment(desc)=0
	ModifyTable format(pw)=3, digits(pw)=6, format(prev)=3, digits(prev)=6
End

// Change the number of peaks (gedgfit "Number of peaks" spinbox)
Function SetNPeaks(n)
	Variable n
	CheckData()
	if(n < 1 || n > 12)
		Abort "Number of peaks must be 1 to 12."
	endif
	SetGlobalNum("nPk", n)
	MakeComponentWaves(n)
	Up()
	Printf "%d peaks active (edg_fit%d).\r", n, n
End

// Fit range in eV; pass NaN for an open end (gedgfit "Fit range")
Function SetRange(xmin, xmax)
	Variable xmin, xmax
	SetGlobalNum("xmin", xmin)
	SetGlobalNum("xmax", xmax)
	Printf "Fit range %g to %g eV.\r", xmin, xmax
End

// Fit range from cursors A and B on the top graph
Function RangeFromCursors()
	if(strlen(CsrInfo(A)) == 0 || strlen(CsrInfo(B)) == 0)
		Abort "Place cursors A and B on the top graph first."
	endif
	SetRange(min(hcsr(A), hcsr(B)), max(hcsr(A), hcsr(B)))
End


// ---------------------------------------------------------------------------
//  Update components and residuals
// ---------------------------------------------------------------------------

Function Up()
	CheckData()
	EDG_Sync(EDGBase())
	Variable n = GetNPeaks(), i
	MakeComponentWaves(n)
	Wave pw = BW("P"), ev = BW("eV"), dat = BW("Int")
	Wave stp = BW("Stp"), tot = BW("TOT_RSD"), rstp = BW("RSDStp"), post = BW("PostRSD")
	Wave fitw = FitCurve()

	stp = EDG_StepComp(pw, ev[p])
	Duplicate/FREE stp, model
	for(i=1; i<=n; i+=1)
		Wave wv = BW("Wv" + num2istr(i))
		wv = EDG_PeakComp(pw, ev[p], i-1)
		model += wv[p]
	endfor

	fitw = EDG_Total(pw, x, n)						// total fit over its own x range

	//For Residuals
	tot = model[p] - dat[p]							// (all components + step) - data
	for(i=1; i<=n; i+=1)
		Wave wv2 = BW("Wv" + num2istr(i))
		Wave rsd = BW("RSD" + num2istr(i))
		rsd = dat[p] - (model[p] - wv2[p])			// data - everything except peak i
	endfor
	rstp = dat[p] - (model[p] - stp[p])				// data - everything except the step
	post = stp[p]
	for(i=kFirstPostEdgePeak; i<=n; i+=1)
		Wave wv3 = BW("Wv" + num2istr(i))
		post += wv3[p]
	endfor
End

// gedgfit "Guess positions": peaks at the 2nd-derivative minima inside the
// fit range, then amplitudes peeled off the data above the step
Function GuessPeaks([passes])
	Variable passes
	if(ParamIsDefault(passes))
		passes = kDefaultSmooth
	endif
	CheckData()
	EDG_Sync(EDGBase())
	Variable n = GetNPeaks(), i, b, nf
	Wave pw = BW("P"), ev = BW("eV"), dat = BW("Int")
	Make/FREE/D/N=(numpnts(ev)) mask
	EDG_RangeMask(ev, GetGlobalNum("xmin", NaN), GetGlobalNum("xmax", NaN), mask)
	Extract/FREE ev, xs, mask[p] != 0
	Extract/FREE dat, ys, mask[p] != 0
	Make/FREE/D pos
	nf = EDG_SuggestPeaks(xs, ys, n, passes, pos)
	if(nf == 0)
		Print "No clear 2nd-derivative minima found."
		return 0
	endif
	for(i=0; i<min(n, nf); i+=1)
		b = EDG_PeakBase(i)
		pw[b+1] = EDG_Round(pos[i], 4)
		if(pw[b+2] <= 0)
			pw[b+2] = 0.5
		endif
		if(pw[b+4] <= 0)
			pw[b+4] = 1
		endif
	endfor
	if(pw[3] <= 0)						// step half-width
		pw[3] = 0.5
	endif
	if(pw[2] == 0)						// step position
		pw[2] = EDG_Round(mean(xs), 5)
	endif
	EDG_AutoAmplitudes(pw, xs, ys, n)
	Up()
	Printf "Placed %d peaks from the 2nd derivative.\r", min(n, nf)
End


// ---------------------------------------------------------------------------
//  Fitting (replaces Analysis > Curve Fitting, which still works on
//  <base>_P with edg_fitN if you prefer the dialog)
// ---------------------------------------------------------------------------

Function FitIt([xmin, xmax, weighting, useLimits, tol])
	Variable xmin, xmax, useLimits, tol
	String weighting
	CheckData()
	if(!ParamIsDefault(xmin) || !ParamIsDefault(xmax))
		SetRange(ParamIsDefault(xmin) ? GetGlobalNum("xmin", NaN) : xmin, ParamIsDefault(xmax) ? GetGlobalNum("xmax", NaN) : xmax)
	endif
	if(ParamIsDefault(weighting))
		weighting = "none"
	endif
	if(ParamIsDefault(tol))
		tol = 1e-8
	endif
	Wave ev = BW("eV"), dat = BW("Int")
	Variable err = EDG_DoFit(EDGBase(), ev, dat, GetNPeaks(), GetGlobalNum("xmin", NaN), GetGlobalNum("xmax", NaN), weighting, useLimits, tol)
	Up()
	return err
End

Function Report([weighting])
	String weighting
	if(ParamIsDefault(weighting))
		weighting = "none"
	endif
	CheckData()
	Wave ev = BW("eV"), dat = BW("Int")
	EDG_Report(EDGBase(), ev, dat, GetNPeaks(), GetGlobalNum("xmin", NaN), GetGlobalNum("xmax", NaN), weighting, NaN)
End

// gedgfit "Link all Gauss fractions to the step (Igor behaviour)"
Function LinkGauss()
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	EDG_LinkGauss(pw)
	Up()
	Printf "All peak Gaussian fractions set to the step's (%g).\r", pw[0]
End


// ---------------------------------------------------------------------------
//  Store / recall parameters (gedgfit Store / Recall params)
// ---------------------------------------------------------------------------

Function SP()
//Saves current parameters
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Duplicate/O pw, $(EDGBase() + "_Prev_P")
End

Function OldP()
//Brings back old parameters
	Wave/Z prev = BW("Prev_P")
	if(!WaveExists(prev))
		Abort "No stored parameters - run SP() first."
	endif
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Duplicate/FREE prev, src
	EDG_ToCurrentLayout(src, pw[1])
	pw = src[p]
	Up()
End


// ---------------------------------------------------------------------------
//  Exchange with gedgfit
// ---------------------------------------------------------------------------

// Load a parameter wave saved by gedgfit (File > Export parameter wave).
// gedgfit's 75-point wave has no step amplitude, so it is re-indexed into
// this layout (p[1] keeps its current value); a 63-point original-Igor
// wave is converted too; a 76-point wave from these procedures goes in as is.
Function ImportGedgfitP()
	CheckData()
	EDG_Sync(EDGBase())
	// Load into a scratch folder: the file's wave may have the same name as
	// <base>_P, and loading over it would destroy what is being converted.
	DFREF here = GetDataFolderDFR()
	NewDataFolder/O/S root:gedgfit_import
	KillWaves/A/Z
	LoadWave/T/O/Q
	Variable loaded = V_flag
	String names = S_waveNames
	SetDataFolder here
	if(loaded == 0)
		KillDataFolder/Z root:gedgfit_import
		return 0
	endif
	// the parameter wave: the first whose length is a parameter-wave length
	Variable i, n
	String nm, pick = ""
	for(i=0; i<ItemsInList(names); i+=1)
		nm = StringFromList(i, names)
		Wave/Z w = $("root:gedgfit_import:" + PossiblyQuoteName(nm))
		if(WaveExists(w) && WaveDims(w) == 1 && WaveType(w) != 0)	// numeric only
			n = numpnts(w)
			if(n == 75 || n == 76 || (n >= 8 && n <= 63 && mod(n - 3, 5) == 0))
				pick = nm
				break
			endif
		endif
	endfor
	if(strlen(pick) == 0)
		KillDataFolder/Z root:gedgfit_import
		Abort "No parameter wave (53/63/75/76 points) in that file."
	endif
	Wave src = $("root:gedgfit_import:" + PossiblyQuoteName(pick))
	Duplicate/FREE src, cv
	n = numpnts(src)
	KillDataFolder/Z root:gedgfit_import
	Wave pw = BW("P")
	String what = EDG_ToCurrentLayout(cv, pw[1])
	pw = cv[p]
	Up()
	Printf "Loaded %s (%d points) into %s%s.\r", pick, n, NameOfWave(pw), SelectString(strlen(what) > 0, "", ", converted from the " + what)
End

// Save the parameters as an Igor Text file in gedgfit's own 75-point order
// (step amplitude removed), for File > Import Igor parameter wave. Every
// point is labelled, and <base>_P75_Desc describing each row is saved with it.
// gedgfit keeps the step amplitude in its "Step amplitude" box instead.
Function ExportForGedgfit()
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Make/O/D $(EDGBase() + "_P75")
	Wave g = BW("P75")
	EDG_ToGedgfitLayout(pw, g)
	EDG_LabelGedgfitLayout(g)						// a name on every point
	Make/O/T/N=(numpnts(g)) $(EDGBase() + "_P75_Desc")
	Wave/T gd = $(EDGBase() + "_P75_Desc")
	gd = "p[" + num2istr(p) + "]  " + EDG_DescribeGedgfit(p)
	Save/T/I g, gd as EDGBase() + "_P75.itx"
	if(pw[1] != 1)
		Printf "Note: step amplitude is %g. gedgfit does not read it from the wave - type it into its \"Step amplitude\" box.\r", pw[1]
	endif
End


// ---------------------------------------------------------------------------
//  Plotting tools for the basic data
// ---------------------------------------------------------------------------

Function Wv_Plotter_Tot()
	CheckData()
	Up()
	Variable n = GetNPeaks(), i
	Wave dat = BW("Int"), ev = BW("eV")
	Display dat vs ev as EDGBase() + "_Waves"
	String nm
	for(i=1; i<=n; i+=1)
		Wave wv = BW("Wv" + num2istr(i))
		AppendToGraph wv vs ev
		nm = NameOfWave(wv)
		ModifyGraph rgb($nm)=(PeakRGB(i,0), PeakRGB(i,1), PeakRGB(i,2))
	endfor
	Wave stp = BW("Stp"), post = BW("PostRSD"), tot = BW("TOT_RSD")
	AppendToGraph stp, post, tot vs ev
	Wave fitw = FitCurve()
	AppendToGraph fitw
	String dn = NameOfWave(dat), sn = NameOfWave(stp), pn = NameOfWave(post), tn = NameOfWave(tot)
	String fn = NameOfWave(fitw)
	ModifyGraph mode($dn)=3,marker($dn)=8,msize($dn)=2
	ModifyGraph rgb($dn)=(65535,65535,65535)
	ModifyGraph rgb($sn)=(65535,49157,16385)
	ModifyGraph rgb($tn)=(51664,44236,58982)
	Legend/C/N=text0/F=0/S=3/B=(0,0,0)/G=(65535,65535,65535)/A=MC
	ModifyGraph lsize=1,lstyle($pn)=9
	ModifyGraph rgb($fn)=(54998,10023,10280), lsize($fn)=2	// total fit, red as in gedgfit
	ModifyGraph rgb($pn)=(39321,39319,1)
	StyleAxes()
End

Function RSD_Plot_Tot()
	CheckData()
	Up()
	Variable n = GetNPeaks(), i
	Wave dat = BW("Int"), ev = BW("eV"), tot = BW("TOT_RSD"), rstp = BW("RSDStp")
	Display dat, tot vs ev
	String nm
	for(i=1; i<=n; i+=1)
		Wave rsd = BW("RSD" + num2istr(i))
		AppendToGraph rsd vs ev
		nm = NameOfWave(rsd)
		ModifyGraph rgb($nm)=(PeakRGB(i,0), PeakRGB(i,1), PeakRGB(i,2))
	endfor
	AppendToGraph rstp vs ev
	String dn = NameOfWave(dat), tn = NameOfWave(tot), sn = NameOfWave(rstp)
	ModifyGraph rgb($dn)=(49151,65535,49151)
	ModifyGraph rgb($tn)=(52428,1,20971)
	ModifyGraph rgb($sn)=(16385,16388,65535)
	Legend/C/N=text0/F=0/S=3/B=(0,0,0)/G=(65535,65535,65535)/A=MC
	StyleAxes()
End

// Each peak against the intensity left for it by everything else
// (gedgfit's "Isolated peak" residual view), then the step
Function RSD_Plot_Ind()
	CheckData()
	Up()
	Variable n = GetNPeaks(), i
	Wave ev = BW("eV")
	String rn, wn
	for(i=1; i<=n; i+=1)
		Wave rsd = BW("RSD" + num2istr(i))
		Wave wv = BW("Wv" + num2istr(i))
		Display rsd vs ev
		AppendToGraph wv vs ev
		rn = NameOfWave(rsd)
		wn = NameOfWave(wv)
		ModifyGraph rgb($rn)=(PeakRGB(i,0), PeakRGB(i,1), PeakRGB(i,2))
		ModifyGraph rgb($wn)=(52428,34958,1)
		Legend/C/N=text0/F=0/S=3/A=MC
		StyleAxes()
	endfor
	Wave rstp = BW("RSDStp"), stp = BW("Stp")
	Display rstp vs ev
	AppendToGraph stp vs ev
	rn = NameOfWave(rstp)
	wn = NameOfWave(stp)
	ModifyGraph rgb($rn)=(16385,16388,65535)
	ModifyGraph rgb($wn)=(52428,34958,1)
	Legend/C/N=text0/F=0/S=3/A=MC
	StyleAxes()
End


// Old names from Cp2VCl2_CK_Apr2012_8CF.ipf, kept so existing habits work
Function Cp2VCl2_8CF_Wv_Plotter_Tot()
	Wv_Plotter_Tot()
End

Function Cp2VCl2_8CF_RSD_Plot_Tot()
	RSD_Plot_Tot()
End

Function Cp2VCl2_8CF_RSD_Plot_Ind()
	RSD_Plot_Ind()
End
''',
}


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        raise SystemExit(selftest())
    main()
