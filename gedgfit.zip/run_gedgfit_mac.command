#!/bin/bash
# ===========================================================================
#  run_gedgfit_mac.command - run gedgfit on a Mac without building an app
#
#  Double-click this file in Finder. The first time it installs what gedgfit
#  needs into a private folder here (.venv-mac, about 300 MB, a minute or
#  two); after that it just starts gedgfit.
#
#  If macOS says it cannot be opened: right-click it > Open, or in Terminal
#      chmod +x run_gedgfit_mac.command
#  Needs Python 3 from https://www.python.org/downloads/macos/
#  (or set PYTHON=/path/to/python3 before running it from Terminal).
# ===========================================================================
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
VENV=".venv-mac"

if ! command -v "$PY" >/dev/null 2>&1; then
    echo "Python 3 was not found. Install it from"
    echo "  https://www.python.org/downloads/macos/"
    echo "then double-click this file again."
    read -r -p "Press Return to close." _
    exit 1
fi

if ! "$PY" -c "import tkinter, sys; sys.exit(0 if tkinter.TkVersion >= 8.6 else 1)" 2>/dev/null; then
    echo "This Python has no usable Tk 8.6 (Apple's built-in Python has the"
    echo "outdated Tk 8.5). Install Python from"
    echo "  https://www.python.org/downloads/macos/"
    echo "(its installer includes a current Tk) and double-click this file again."
    read -r -p "Press Return to close." _
    exit 1
fi

if [[ ! -x "$VENV/bin/python" ]] || ! "$VENV/bin/python" -c "import numpy, scipy, matplotlib, igor2, tkinterdnd2" 2>/dev/null; then
    echo "First run: installing what gedgfit needs into $VENV ..."
    "$PY" -m venv "$VENV"
    "$VENV/bin/python" -m pip install --quiet --upgrade pip
    "$VENV/bin/python" -m pip install --quiet -r requirements.txt
fi

exec "$VENV/bin/python" gedgfit.py "$@"
