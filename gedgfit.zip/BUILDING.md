# Building gedgfit

- **Windows:** `build_windows.bat` makes `gedgfit.exe` (this section).
- **Mac:** `build_mac.sh` makes `gedgfit.app` ([Building the Mac app](#building-the-mac-app)).

Each must be built on its own system; PyInstaller does not cross-compile.

# Building the Windows executable

The result is a standalone `gedgfit.exe`. It needs nothing installed on the
machine that runs it — no Python, no SciPy — so you can copy it to a beamline
laptop or hand it to a colleague.

## Files

Keep these four in one folder:

```
gedgfit.py      the program
gedgfit.spec    the packaging recipe
build_windows.bat    the build script
icon.ico             the application icon
```

## One-time setup

Install Python 3.9 or newer from
[python.org/downloads/windows](https://www.python.org/downloads/windows/).
**Tick "Add python.exe to PATH"** on the first screen of the installer — that
checkbox is the single most common reason this build fails.

Nothing else is needed. The batch file installs NumPy, SciPy, Matplotlib and
PyInstaller by itself.

## Build

Double-click **`build_windows.bat`**.

It creates a `build_env` folder, installs the packages into it, checks the
script imports, then packages it. First run takes roughly five minutes, mostly
downloading SciPy; later runs take about one.

The build deliberately uses its own virtual environment. That keeps your normal
Python installation untouched and stops unrelated packages from being swept into
the executable and inflating it.

When it finishes you have:

```
dist\gedgfit.exe        about 90 MB
```

Double-click it. That single file is the whole program.

If you prefer the command line:

```bat
pip install numpy scipy matplotlib pyinstaller igor2 tkinterdnd2
pyinstaller gedgfit.spec --noconfirm
```

## Startup speed

The build now defaults to the fast configuration. Three things were done to it,
measured on one machine with a warm cache, time from launch to window:

| build | size | startup |
|---|---|---|
| one file, untrimmed, SciPy loaded eagerly | 80 MB | 5.8 s |
| one file, trimmed, SciPy loaded lazily | 73 MB | 4.5 s |
| **one folder, trimmed, SciPy lazy** | 187 MB folder | **2.1 s** |

**One folder instead of one file** is most of it. A one-file executable unpacks
its entire payload to a temp folder on *every* launch; a folder build just runs.
That alone is roughly twice as fast. `ONEFILE = False` in the spec, which is now
the default.

**Trimming the bundle.** SciPy was a third of the payload and most of it is
never reached — the program only uses `optimize`, `special`, `linalg`, `sparse`,
`spatial`, `fft` and `constants`. The rest is excluded in the spec, along with
setuptools and a few other stowaways.

**Loading SciPy lazily.** Importing `scipy.optimize` costs about 0.4 s and
nothing needs it until you press Fit — the model, plot, file readers and
derivative tools are pure NumPy. The error function now comes from the standard
library's `math.erf`, which agrees with SciPy's to one unit in the last place.
SciPy is imported on the first fit instead, where you already expect the program
to be busy.

### What else is worth doing, on Windows specifically

**Add a Microsoft Defender exclusion** for the folder you run it from. Defender
scans the executable and, for a one-file build, everything it unpacks, on every
launch. On some machines this dominates everything above. Windows Security ▸
Virus & threat protection ▸ Manage settings ▸ Exclusions ▸ Add a folder.

**Do not run it from OneDrive, a network share, or a USB stick.** A synced
folder may have to fetch files on demand, which can add seconds. Copy it to a
local disk.

**Ignore the first launch after building or copying.** It is always slower —
cold file cache, and the antivirus scanning it properly for the first time.
Judge speed from the second run onward.

If you must ship a single file and the wait bothers people, PyInstaller can add
a splash image that appears during unpacking. It does not make anything faster,
but the program stops looking like it failed to start.

### Verifying a trimmed build

Excluding modules can break things that only surface when used, because SciPy
loads much of itself lazily — a smaller executable that opens a window is not
proof that fitting still works. Run:

```
gedgfit.exe --selftest
```

It checks the model against known values, runs a real fit with all three
optimisers and both error conventions, exercises the derivative finder and the
Igor parameter-wave round trip, then reports PASS or FAIL in a dialog and writes
`gedgfit_selftest.txt`. Run it after any change to the excludes.

## One file or one folder

`gedgfit.spec` opens with:

```python
ONEFILE = False
```

| | starts | ships as |
|---|---|---|
| `False` (default) | ~2 s | a `dist\gedgfit\` folder |
| `True` | ~4.5 s, unpacks to a temp folder each launch | one `.exe` |

Set it to `True` only when handing the program to someone as a single file
matters more than the wait. Otherwise keep the folder together and run the
`.exe` inside it; zip the folder to pass it on.

## Things that commonly go wrong

**A very new Python.** If pip reports "no matching distribution found", or
PyInstaller installs but won't run, your Python is ahead of what one of the
packages supports yet. Install Python 3.12 or 3.13, delete the `build_env`
folder, and run the script again — it will rebuild the environment against
whichever Python it finds first.

**"Python was not found"** — PATH wasn't set during installation. Re-run the
Python installer, choose Modify, and enable "Add python.exe to PATH". Or use the
`py` launcher, which the batch file tries first.

**Antivirus quarantines the .exe.** PyInstaller output gets flagged by
heuristics fairly often, because self-extracting executables look like packers.
It is a false positive. Add an exclusion for the folder, or build with
`ONEFILE = False`, which is flagged far less. The spec already disables UPX
compression, which is the usual aggravating factor. If you need to distribute it
widely, code-signing is the real fix.

**Windows SmartScreen warns on first run.** Expected for an unsigned executable.
More info → Run anyway.

**The build succeeds but the program won't start.** Set `console=True` in
`gedgfit.spec` and rebuild — you'll get a console window showing the error.
Also check for `gedgfit_error.log`, written next to the exe or in your user
folder; the program logs any unhandled error there and shows a dialog rather
than closing silently.

**"Failed to execute script"** with a missing module. Add the module name to the
`hidden` list in the spec and rebuild. One case is already handled there:
Matplotlib's toolbar loads `PIL._tkinter_finder` dynamically, which PyInstaller
cannot see, and the program crashes on startup without it.

# Building the Mac app

The result is `gedgfit.app`, which needs nothing installed on the Mac that
runs it.

## One-time setup

Install Python 3.9 or newer from
[python.org/downloads/macos](https://www.python.org/downloads/macos/). Use that
installer rather than Apple's built-in `python3`: Apple's comes with Tk 8.5,
which draws the interface badly and cannot do drag and drop. (Homebrew Python
also works after `brew install python-tk`.)

## Build

In Terminal, in this folder:

```
./build_mac.sh
```

(If it says "permission denied", run `chmod +x build_mac.sh` once.) To use a
particular Python: `PYTHON=/usr/local/bin/python3.12 ./build_mac.sh`.

The script checks the Python and its Tk, builds in its own environment
(`.venv-mac-build`, leaving your Python untouched), runs the self-test on the
finished app, and zips it. You get:

```
dist/gedgfit.app                the application
dist/gedgfit-mac-arm64.zip      the same, zipped to send (x86_64 on Intel)
```

The app runs on the kind of Mac it was built on: Apple Silicon (arm64) or
Intel (x86_64). An Intel build also runs on Apple Silicon through Rosetta;
for a native build on both, build once on each.

## Opening it on another Mac

The app is signed ad hoc, not with an Apple Developer certificate, so macOS
blocks the first launch of a copy that was downloaded or sent. Allow it once:

- macOS 15 Sequoia and later: try to open it, then **System Settings ▸ Privacy
  & Security**, scroll down, **Open Anyway**.
- Earlier versions: right-click the app ▸ **Open** ▸ **Open**.
- Or in Terminal: `xattr -dr com.apple.quarantine /path/to/gedgfit.app`

Send the `.zip` the script made rather than zipping the app yourself with a
tool that might drop the bundle's permissions; Finder's **Compress** is fine
too.

## On the Mac

- Shortcuts use Command: ⌘O open, ⌘F fit, ⌘U update; ⌘Q quits from the
  gedgfit menu.
- Files and folders can be dropped on the window, or on gedgfit's Dock icon,
  to rebuild a fit. gedgfit also appears under **Open With** for Igor files,
  sessions and data files, without becoming their default application.
- The error log and self-test report go to `~/Library/Logs`
  (`gedgfit_error.log`, `gedgfit_selftest.txt`).
- Updated `.ipf` procedure files placed next to `gedgfit.app` are used
  instead of the built-in copies, as next to the `.exe` on Windows.
- Self-test of a built app: `dist/gedgfit.app/Contents/MacOS/gedgfit --selftest`

## Building for Linux

The same spec works on Linux and gives a `dist/gedgfit/` folder.

## Running without building

The script works as a plain Python program anywhere. On a Mac the simplest
way is to double-click **`run_gedgfit_mac.command`**: the first time it
installs what gedgfit needs into `.venv-mac` beside it, after that it just
starts gedgfit. By hand:

```
pip install numpy scipy matplotlib igor2 tkinterdnd2
python gedgfit.py
```

On Debian/Ubuntu you also need `sudo apt install python3-tk`; on Homebrew
Python, `brew install python-tk`.
