#pragma rtGlobals=3		// Use modern global access method and strict wave access.
#pragma IgorVersion=7.00

// ===========================================================================
//  gedgfit_Workflow.ipf
//
//  Edge-fit workflow using the gedgfit parameter layout, parameter table and
//  mathematics. Needs gedgfit_Model.ipf open at the same time.
//  Generic version of Cp2VCl2_CK_Apr2012_8CF_indep.ipf: the sample name is
//  not hard-coded. Open this file OR that one, not both.
//
//  BASE NAME
//    Every wave is named <base>_<suffix>, e.g. Cp2VCl2_Int. The base is the
//    global string root:gEDG_Base (set by gedgfit's Igor export, or by
//    SetBase("mysample")); without it the base is ksDefaultBase below,
//    which gedgfit sets to the sample name when it exports this file as
//    <sample>_<N>CF.ipf.
//
//  Data waves expected:  <base>_eV   (energy)
//                        <base>_Int  (normalised intensity)
//
//  TYPICAL SESSION (command line)
//    SetBase("Cp2VCl2")           choose the sample (not needed after a gedgfit export)
//    Derivs()                     smoothed 1st/2nd derivatives of <base>_Int
//                                 (Derivs(smooth=3) for other smoothing)
//    SetUp()                      parameter table, graph, component waves
//    SetUp(nPeaks=10)             ...or another peak count (1-12)
//    SetRange(284, 300)           fit range (or RangeFromCursors() with cursors A,B)
//    GuessPeaks()                 positions from the 2nd derivative + amplitudes
//    ...edit the "<base> parameters" table: values, and hold = 1 / 0...
//    Up()                         recompute components and residuals
//    FitIt()                      fit; options: FitIt(weighting="poisson"),
//                                 FitIt(useLimits=1), FitIt(tol=1e-3)
//    Report()                     chi-square, R^2, values, errors, peak areas
//    SP() / OldP()                store / recall a parameter set
//    ShowP()                      table of <base>_P with a description
//                                 column saying what each row is
//    LinkGauss()                  every peak fraction = step fraction (old Igor)
//    ImportGedgfitP()             load a _P.itx exported by gedgfit
//    ExportForGedgfit()           save the parameter wave as .itx for gedgfit
//    Wv_Plotter_Tot(), RSD_Plot_Tot(), RSD_Plot_Ind()   the figures
//                                 (fit_<base>_Int is the total fit, step +
//                                 peaks: recomputed by Up(), and overwritten
//                                 by Igor's FuncFit in FitIt())
//
//  PARAMETER ORDER: p[0] step Gaussian fraction, p[1] step amplitude,
//  p[2] step position, p[3] step half-width, then 6 per peak from p[4]:
//  amplitude, position, half-width, skew, L/W ratio, Gaussian fraction.
//
//  An old 53- or 63-point <base>_P, or one from an earlier version of these
//  files (step amplitude at p[75]), is converted automatically by SetUp; a
//  copy of the original is kept as <base>_P_old<N>.
// ===========================================================================

StrConstant ksDefaultBase = "Cp2VCl2"

Constant kDefaultNPeaks = 8
Constant kFirstPostEdgePeak = 6		// PostRSD = step + peaks 6..N (as before)
Constant kDefaultSmooth = 5			// gedgfit's default smoothing passes

// gedgfit's PEAK_COLORS, as Igor 16-bit RGB
StrConstant ksPeakRGB = "59110,51143,0;0,46260,0;0,53199,57568;65535,12079,41120;0,41120,23130;16191,32639,53456;65535,35980,6682;41120,27756,57568;35466,47288,0;57568,20560,20560;0,47288,41120;45232,41120,65535;"


// ---------------------------------------------------------------------------
//  Base name
// ---------------------------------------------------------------------------

// The base name all waves use: root:gEDG_Base, or the default
Function/S EDGBase()
	SVAR/Z b = root:gEDG_Base
	if(SVAR_Exists(b) && strlen(b) > 0)
		return b
	endif
	return ksDefaultBase
End

// Choose the sample, e.g. SetBase("Cp2VCl2")
Function SetBase(name)
	String name
	if(strlen(name) == 0 || cmpstr(CleanupName(name, 0), name) != 0)
		Abort "\"" + name + "\" is not a valid Igor wave-name stem (letters, digits and _ only, starting with a letter)."
	endif
	SVAR/Z b = root:gEDG_Base
	if(!SVAR_Exists(b))
		String/G root:gEDG_Base
	endif
	SVAR b2 = root:gEDG_Base
	b2 = name
	Printf "Base name set to %s (waves %s_eV, %s_Int, %s_P, ...).\r", name, name, name, name
End


// ---------------------------------------------------------------------------
//  Small helpers
// ---------------------------------------------------------------------------

static Function/WAVE BW(suffix)
	String suffix
	Wave/Z w = $(EDGBase() + "_" + suffix)
	return w
End

static Function GetNPeaks()
	NVAR/Z n = $(EDGBase() + "_nPk")
	if(!NVAR_Exists(n))
		return kDefaultNPeaks
	endif
	return n
End

static Function SetGlobalNum(suffix, v)
	String suffix
	Variable v
	String nm = EDGBase() + "_" + suffix
	NVAR/Z g = $nm
	if(!NVAR_Exists(g))
		Variable/G $nm
	endif
	NVAR g2 = $nm
	g2 = v
End

static Function GetGlobalNum(suffix, dflt)
	String suffix
	Variable dflt
	NVAR/Z g = $(EDGBase() + "_" + suffix)
	if(!NVAR_Exists(g))
		return dflt
	endif
	return g
End

static Function CheckData()
	Wave/Z dat = BW("Int"), ev = BW("eV")
	if(!WaveExists(dat) || !WaveExists(ev))
		Abort "Need waves " + EDGBase() + "_eV and " + EDGBase() + "_Int in the current data folder."
	endif
	if(numpnts(dat) != numpnts(ev))
		Abort EDGBase() + "_eV and " + EDGBase() + "_Int have different lengths."
	endif
End

static Function PeakRGB(i, which)		// i 1-based, which 0/1/2 = r/g/b
	Variable i, which
	String c = StringFromList(mod(i-1, 12), ksPeakRGB)
	return str2num(StringFromList(which, c, ","))
End

static Function StyleAxes()
	Label left "\\F'Arial'\\Z15Normalized Intensity";DelayUpdate
	Label bottom "\\F'Arial'\\Z15Energy (eV)"
	ModifyGraph mirror=2,minor=1,sep(left)=20,fSize=15,axThick=3,btLen=15,btThick=3;DelayUpdate
	ModifyGraph stLen(left)=7,stLen(bottom)=8,stThick=3,font="Arial"
	ModifyGraph gbrgb=(0,0,0)
End

// One wave per component and residual, matching the data length
static Function MakeComponentWaves(n)
	Variable n
	Wave dat = BW("Int")
	Variable i, np = numpnts(dat)
	String sfx = "Stp;TOT_RSD;RSDStp;PostRSD;"
	for(i=1; i<=n; i+=1)
		sfx += "Wv" + num2istr(i) + ";RSD" + num2istr(i) + ";"
	endfor
	for(i=0; i<ItemsInList(sfx); i+=1)
		Wave/Z w = BW(StringFromList(i, sfx))
		if(!WaveExists(w) || numpnts(w) != np)
			Make/O/D/N=(np) $(EDGBase() + "_" + StringFromList(i, sfx))
		endif
	endfor
End


// The total-fit curve fit_<base>_Int: the wave Igor's FuncFit /D writes, so
// a fit overwrites it in place. It is a waveform over the fit range with its
// own x scaling (plotted without "vs"). Made here if it does not exist yet.
static Function/WAVE FitCurve()
	Wave dat = BW("Int"), ev = BW("eV")
	String nm = "fit_" + NameOfWave(dat)
	Wave/Z fc = $nm
	if(!WaveExists(fc))
		Variable lo = GetGlobalNum("xmin", NaN), hi = GetGlobalNum("xmax", NaN)
		if(numtype(lo) != 0)
			lo = WaveMin(ev)
		endif
		if(numtype(hi) != 0)
			hi = WaveMax(ev)
		endif
		Make/O/D/N=(kEDG_FitCurvePoints) $nm
		Wave fc = $nm
		SetScale/I x lo, hi, "", fc
	endif
	return fc
End


// ---------------------------------------------------------------------------
//  Derivatives (gedgfit Tools > Derivative viewer)
//  Type "Derivs()"  or  "derivPlot(<base>_Int, <base>_eV, 5)"
// ---------------------------------------------------------------------------

Function derivPlot(dat, eVDat, smoothParam)
	Wave dat, eVDat
	Variable smoothParam
	Make/O/D/N=(numpnts(dat)) $(EDGBase() + "_Smth"), $(EDGBase() + "_DRV1_Smth"), $(EDGBase() + "_DRV2"), ZeroVec
	Wave ys = BW("Smth"), d1 = BW("DRV1_Smth"), d2 = BW("DRV2")
	Wave zv = ZeroVec
	zv = 0
	// smoothed spectrum, smoothed dy/dE, smoothed d2y/dE2 - exactly as gedgfit
	EDG_Derivatives(eVDat, dat, smoothParam, ys, d1, d2)
	String n1 = NameOfWave(d1), n2 = NameOfWave(d2)
	Display dat, d1, d2, zv vs eVDat as EDGBase() + "_DRV"
	ModifyGraph rgb($n1)=(3,52428,1)
	ModifyGraph rgb(ZeroVec)=(65535,65535,65535)
	ModifyGraph lsize=1
	ModifyGraph lstyle($n1)=1
	ModifyGraph mode($n2)=4,marker($n2)=19,msize($n2)=2
	ModifyGraph rgb($n2)=(16385,16388,65535)
	ModifyGraph mode($n1)=3,marker($n1)=1
	Legend/C/N=text0/F=0/B=(0,0,0)/G=(65535,65535,65535)
	StyleAxes()
	SetAxis/A
End


// derivPlot on the current sample's waves
Function Derivs([smooth])
	Variable smooth
	if(ParamIsDefault(smooth))
		smooth = kDefaultSmooth
	endif
	CheckData()
	Wave dat = BW("Int"), ev = BW("eV")
	derivPlot(dat, ev, smooth)
End


// ---------------------------------------------------------------------------
//  Setup
// ---------------------------------------------------------------------------

Function SetUp([nPeaks])
	Variable nPeaks
	CheckData()
	if(ParamIsDefault(nPeaks))
		nPeaks = GetNPeaks()
	endif
	if(nPeaks < 1 || nPeaks > 12)
		Abort "nPeaks must be 1 to 12."
	endif
	SetGlobalNum("nPk", nPeaks)
	SetGlobalNum("xmin", GetGlobalNum("xmin", NaN))		// fit range; NaN = open end
	SetGlobalNum("xmax", GetGlobalNum("xmax", NaN))

	// parameter wave (converted from the old layout if necessary) + tables
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Wave/Z prev0 = BW("Prev_P")
	if(!WaveExists(prev0))
		Duplicate/O pw, $(EDGBase() + "_Prev_P")
	else
		EDG_ToCurrentLayout(prev0, 1)
	endif

	Wave dat = BW("Int"), ev = BW("eV")
	Edit ev, dat as EDGBase() + " data"
	ShowP()
	EDG_ShowParamTable(EDGBase())

	MakeComponentWaves(nPeaks)
	Up()									// computes fit_<base>_Int before it is drawn

	// the spectrum with its total fit (step + peaks), kept current by Up()
	Wave fitw = FitCurve()
	Display dat vs ev as EDGBase() + " spectrum"
	String gwin = WinName(0, 1)
	StyleAxes()
	String dn = NameOfWave(dat), fn = NameOfWave(fitw)
	ModifyGraph/W=$gwin mode($dn)=4, marker($dn)=51, msize($dn)=3, opaque($dn)=1
	ModifyGraph/W=$gwin rgb($dn)=(65535,65535,65535)
	AppendToGraph/W=$gwin fitw
	ModifyGraph/W=$gwin mode($fn)=0, lsize($fn)=2, rgb($fn)=(54998,10023,10280)
	Legend/W=$gwin/C/N=text0/F=0/S=3/B=(0,0,0)/G=(65535,65535,65535)/A=MC
	Printf "%s set up for %d peaks. Edit the table '%s_Params' (hold: 1 = held), then Up() or FitIt().\r", EDGBase(), nPeaks, EDGBase()
End

// Table of the parameter wave with a column saying what each row is,
// beside the stored set (Prev_P) and the fit errors (Sigma)
Function ShowP()
	EDG_Sync(EDGBase())
	EDG_MakeDescWave(EDGBase())
	Wave pw = BW("P")
	Wave/T desc = BW("P_Desc")
	Wave/Z prev0 = BW("Prev_P")
	if(!WaveExists(prev0))
		Duplicate/O pw, $(EDGBase() + "_Prev_P")
	endif
	Wave/Z sig0 = BW("Sigma")
	if(!WaveExists(sig0) || numpnts(sig0) != numpnts(pw))
		Make/O/D/N=(numpnts(pw)) $(EDGBase() + "_Sigma")
		Wave sig1 = BW("Sigma")
		sig1 = NaN
	endif
	Wave prev = BW("Prev_P"), sig = BW("Sigma")
	String win = EDGBase() + "_PTable"
	if(WinType(win) == 2)
		DoWindow/F $win
		return 0
	endif
	Edit/K=1/N=$win desc, pw, prev, sig as EDGBase() + " parameter wave"
	ModifyTable width(desc)=190, alignment(desc)=0
	ModifyTable format(pw)=3, digits(pw)=6, format(prev)=3, digits(prev)=6
End

// Change the number of peaks (gedgfit "Number of peaks" spinbox)
Function SetNPeaks(n)
	Variable n
	CheckData()
	if(n < 1 || n > 12)
		Abort "Number of peaks must be 1 to 12."
	endif
	SetGlobalNum("nPk", n)
	MakeComponentWaves(n)
	Up()
	Printf "%d peaks active (edg_fit%d).\r", n, n
End

// Fit range in eV; pass NaN for an open end (gedgfit "Fit range")
Function SetRange(xmin, xmax)
	Variable xmin, xmax
	SetGlobalNum("xmin", xmin)
	SetGlobalNum("xmax", xmax)
	Printf "Fit range %g to %g eV.\r", xmin, xmax
End

// Fit range from cursors A and B on the top graph
Function RangeFromCursors()
	if(strlen(CsrInfo(A)) == 0 || strlen(CsrInfo(B)) == 0)
		Abort "Place cursors A and B on the top graph first."
	endif
	SetRange(min(hcsr(A), hcsr(B)), max(hcsr(A), hcsr(B)))
End


// ---------------------------------------------------------------------------
//  Update components and residuals
// ---------------------------------------------------------------------------

Function Up()
	CheckData()
	EDG_Sync(EDGBase())
	Variable n = GetNPeaks(), i
	MakeComponentWaves(n)
	Wave pw = BW("P"), ev = BW("eV"), dat = BW("Int")
	Wave stp = BW("Stp"), tot = BW("TOT_RSD"), rstp = BW("RSDStp"), post = BW("PostRSD")
	Wave fitw = FitCurve()

	stp = EDG_StepComp(pw, ev[p])
	Duplicate/FREE stp, model
	for(i=1; i<=n; i+=1)
		Wave wv = BW("Wv" + num2istr(i))
		wv = EDG_PeakComp(pw, ev[p], i-1)
		model += wv[p]
	endfor

	fitw = EDG_Total(pw, x, n)						// total fit over its own x range

	//For Residuals
	tot = model[p] - dat[p]							// (all components + step) - data
	for(i=1; i<=n; i+=1)
		Wave wv2 = BW("Wv" + num2istr(i))
		Wave rsd = BW("RSD" + num2istr(i))
		rsd = dat[p] - (model[p] - wv2[p])			// data - everything except peak i
	endfor
	rstp = dat[p] - (model[p] - stp[p])				// data - everything except the step
	post = stp[p]
	for(i=kFirstPostEdgePeak; i<=n; i+=1)
		Wave wv3 = BW("Wv" + num2istr(i))
		post += wv3[p]
	endfor
End

// gedgfit "Guess positions": peaks at the 2nd-derivative minima inside the
// fit range, then amplitudes peeled off the data above the step
Function GuessPeaks([passes])
	Variable passes
	if(ParamIsDefault(passes))
		passes = kDefaultSmooth
	endif
	CheckData()
	EDG_Sync(EDGBase())
	Variable n = GetNPeaks(), i, b, nf
	Wave pw = BW("P"), ev = BW("eV"), dat = BW("Int")
	Make/FREE/D/N=(numpnts(ev)) mask
	EDG_RangeMask(ev, GetGlobalNum("xmin", NaN), GetGlobalNum("xmax", NaN), mask)
	Extract/FREE ev, xs, mask[p] != 0
	Extract/FREE dat, ys, mask[p] != 0
	Make/FREE/D pos
	nf = EDG_SuggestPeaks(xs, ys, n, passes, pos)
	if(nf == 0)
		Print "No clear 2nd-derivative minima found."
		return 0
	endif
	for(i=0; i<min(n, nf); i+=1)
		b = EDG_PeakBase(i)
		pw[b+1] = EDG_Round(pos[i], 4)
		if(pw[b+2] <= 0)
			pw[b+2] = 0.5
		endif
		if(pw[b+4] <= 0)
			pw[b+4] = 1
		endif
	endfor
	if(pw[3] <= 0)						// step half-width
		pw[3] = 0.5
	endif
	if(pw[2] == 0)						// step position
		pw[2] = EDG_Round(mean(xs), 5)
	endif
	EDG_AutoAmplitudes(pw, xs, ys, n)
	Up()
	Printf "Placed %d peaks from the 2nd derivative.\r", min(n, nf)
End


// ---------------------------------------------------------------------------
//  Fitting (replaces Analysis > Curve Fitting, which still works on
//  <base>_P with edg_fitN if you prefer the dialog)
// ---------------------------------------------------------------------------

Function FitIt([xmin, xmax, weighting, useLimits, tol])
	Variable xmin, xmax, useLimits, tol
	String weighting
	CheckData()
	if(!ParamIsDefault(xmin) || !ParamIsDefault(xmax))
		SetRange(ParamIsDefault(xmin) ? GetGlobalNum("xmin", NaN) : xmin, ParamIsDefault(xmax) ? GetGlobalNum("xmax", NaN) : xmax)
	endif
	if(ParamIsDefault(weighting))
		weighting = "none"
	endif
	if(ParamIsDefault(tol))
		tol = 1e-8
	endif
	Wave ev = BW("eV"), dat = BW("Int")
	Variable err = EDG_DoFit(EDGBase(), ev, dat, GetNPeaks(), GetGlobalNum("xmin", NaN), GetGlobalNum("xmax", NaN), weighting, useLimits, tol)
	Up()
	return err
End

Function Report([weighting])
	String weighting
	if(ParamIsDefault(weighting))
		weighting = "none"
	endif
	CheckData()
	Wave ev = BW("eV"), dat = BW("Int")
	EDG_Report(EDGBase(), ev, dat, GetNPeaks(), GetGlobalNum("xmin", NaN), GetGlobalNum("xmax", NaN), weighting, NaN)
End

// gedgfit "Link all Gauss fractions to the step (Igor behaviour)"
Function LinkGauss()
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	EDG_LinkGauss(pw)
	Up()
	Printf "All peak Gaussian fractions set to the step's (%g).\r", pw[0]
End


// ---------------------------------------------------------------------------
//  Store / recall parameters (gedgfit Store / Recall params)
// ---------------------------------------------------------------------------

Function SP()
//Saves current parameters
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Duplicate/O pw, $(EDGBase() + "_Prev_P")
End

Function OldP()
//Brings back old parameters
	Wave/Z prev = BW("Prev_P")
	if(!WaveExists(prev))
		Abort "No stored parameters - run SP() first."
	endif
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Duplicate/FREE prev, src
	EDG_ToCurrentLayout(src, pw[1])
	pw = src[p]
	Up()
End


// ---------------------------------------------------------------------------
//  Exchange with gedgfit
// ---------------------------------------------------------------------------

// Load a parameter wave saved by gedgfit (File > Export parameter wave).
// gedgfit's 75-point wave has no step amplitude, so it is re-indexed into
// this layout (p[1] keeps its current value); a 63-point original-Igor
// wave is converted too; a 76-point wave from these procedures goes in as is.
Function ImportGedgfitP()
	CheckData()
	EDG_Sync(EDGBase())
	// Load into a scratch folder: the file's wave may have the same name as
	// <base>_P, and loading over it would destroy what is being converted.
	DFREF here = GetDataFolderDFR()
	NewDataFolder/O/S root:gedgfit_import
	KillWaves/A/Z
	LoadWave/T/O/Q
	Variable loaded = V_flag
	String names = S_waveNames
	SetDataFolder here
	if(loaded == 0)
		KillDataFolder/Z root:gedgfit_import
		return 0
	endif
	// the parameter wave: the first whose length is a parameter-wave length
	Variable i, n
	String nm, pick = ""
	for(i=0; i<ItemsInList(names); i+=1)
		nm = StringFromList(i, names)
		Wave/Z w = $("root:gedgfit_import:" + PossiblyQuoteName(nm))
		if(WaveExists(w) && WaveDims(w) == 1 && WaveType(w) != 0)	// numeric only
			n = numpnts(w)
			if(n == 75 || n == 76 || (n >= 8 && n <= 63 && mod(n - 3, 5) == 0))
				pick = nm
				break
			endif
		endif
	endfor
	if(strlen(pick) == 0)
		KillDataFolder/Z root:gedgfit_import
		Abort "No parameter wave (53/63/75/76 points) in that file."
	endif
	Wave src = $("root:gedgfit_import:" + PossiblyQuoteName(pick))
	Duplicate/FREE src, cv
	n = numpnts(src)
	KillDataFolder/Z root:gedgfit_import
	Wave pw = BW("P")
	String what = EDG_ToCurrentLayout(cv, pw[1])
	pw = cv[p]
	Up()
	Printf "Loaded %s (%d points) into %s%s.\r", pick, n, NameOfWave(pw), SelectString(strlen(what) > 0, "", ", converted from the " + what)
End

// Save the parameters as an Igor Text file in gedgfit's own 75-point order
// (step amplitude removed), for File > Import Igor parameter wave. Every
// point is labelled, and <base>_P75_Desc describing each row is saved with it.
// gedgfit keeps the step amplitude in its "Step amplitude" box instead.
Function ExportForGedgfit()
	EDG_Sync(EDGBase())
	Wave pw = BW("P")
	Make/O/D $(EDGBase() + "_P75")
	Wave g = BW("P75")
	EDG_ToGedgfitLayout(pw, g)
	EDG_LabelGedgfitLayout(g)						// a name on every point
	Make/O/T/N=(numpnts(g)) $(EDGBase() + "_P75_Desc")
	Wave/T gd = $(EDGBase() + "_P75_Desc")
	gd = "p[" + num2istr(p) + "]  " + EDG_DescribeGedgfit(p)
	Save/T/I g, gd as EDGBase() + "_P75.itx"
	if(pw[1] != 1)
		Printf "Note: step amplitude is %g. gedgfit does not read it from the wave - type it into its \"Step amplitude\" box.\r", pw[1]
	endif
End


// ---------------------------------------------------------------------------
//  Plotting tools for the basic data
// ---------------------------------------------------------------------------

Function Wv_Plotter_Tot()
	CheckData()
	Up()
	Variable n = GetNPeaks(), i
	Wave dat = BW("Int"), ev = BW("eV")
	Display dat vs ev as EDGBase() + "_Waves"
	String nm
	for(i=1; i<=n; i+=1)
		Wave wv = BW("Wv" + num2istr(i))
		AppendToGraph wv vs ev
		nm = NameOfWave(wv)
		ModifyGraph rgb($nm)=(PeakRGB(i,0), PeakRGB(i,1), PeakRGB(i,2))
	endfor
	Wave stp = BW("Stp"), post = BW("PostRSD"), tot = BW("TOT_RSD")
	AppendToGraph stp, post, tot vs ev
	Wave fitw = FitCurve()
	AppendToGraph fitw
	String dn = NameOfWave(dat), sn = NameOfWave(stp), pn = NameOfWave(post), tn = NameOfWave(tot)
	String fn = NameOfWave(fitw)
	ModifyGraph mode($dn)=3,marker($dn)=8,msize($dn)=2
	ModifyGraph rgb($dn)=(65535,65535,65535)
	ModifyGraph rgb($sn)=(65535,49157,16385)
	ModifyGraph rgb($tn)=(51664,44236,58982)
	Legend/C/N=text0/F=0/S=3/B=(0,0,0)/G=(65535,65535,65535)/A=MC
	ModifyGraph lsize=1,lstyle($pn)=9
	ModifyGraph rgb($fn)=(54998,10023,10280), lsize($fn)=2	// total fit, red as in gedgfit
	ModifyGraph rgb($pn)=(39321,39319,1)
	StyleAxes()
End

Function RSD_Plot_Tot()
	CheckData()
	Up()
	Variable n = GetNPeaks(), i
	Wave dat = BW("Int"), ev = BW("eV"), tot = BW("TOT_RSD"), rstp = BW("RSDStp")
	Display dat, tot vs ev
	String nm
	for(i=1; i<=n; i+=1)
		Wave rsd = BW("RSD" + num2istr(i))
		AppendToGraph rsd vs ev
		nm = NameOfWave(rsd)
		ModifyGraph rgb($nm)=(PeakRGB(i,0), PeakRGB(i,1), PeakRGB(i,2))
	endfor
	AppendToGraph rstp vs ev
	String dn = NameOfWave(dat), tn = NameOfWave(tot), sn = NameOfWave(rstp)
	ModifyGraph rgb($dn)=(49151,65535,49151)
	ModifyGraph rgb($tn)=(52428,1,20971)
	ModifyGraph rgb($sn)=(16385,16388,65535)
	Legend/C/N=text0/F=0/S=3/B=(0,0,0)/G=(65535,65535,65535)/A=MC
	StyleAxes()
End

// Each peak against the intensity left for it by everything else
// (gedgfit's "Isolated peak" residual view), then the step
Function RSD_Plot_Ind()
	CheckData()
	Up()
	Variable n = GetNPeaks(), i
	Wave ev = BW("eV")
	String rn, wn
	for(i=1; i<=n; i+=1)
		Wave rsd = BW("RSD" + num2istr(i))
		Wave wv = BW("Wv" + num2istr(i))
		Display rsd vs ev
		AppendToGraph wv vs ev
		rn = NameOfWave(rsd)
		wn = NameOfWave(wv)
		ModifyGraph rgb($rn)=(PeakRGB(i,0), PeakRGB(i,1), PeakRGB(i,2))
		ModifyGraph rgb($wn)=(52428,34958,1)
		Legend/C/N=text0/F=0/S=3/A=MC
		StyleAxes()
	endfor
	Wave rstp = BW("RSDStp"), stp = BW("Stp")
	Display rstp vs ev
	AppendToGraph stp vs ev
	rn = NameOfWave(rstp)
	wn = NameOfWave(stp)
	ModifyGraph rgb($rn)=(16385,16388,65535)
	ModifyGraph rgb($wn)=(52428,34958,1)
	Legend/C/N=text0/F=0/S=3/A=MC
	StyleAxes()
End


// Old names from Cp2VCl2_CK_Apr2012_8CF.ipf, kept so existing habits work
Function Cp2VCl2_8CF_Wv_Plotter_Tot()
	Wv_Plotter_Tot()
End

Function Cp2VCl2_8CF_RSD_Plot_Tot()
	RSD_Plot_Tot()
End

Function Cp2VCl2_8CF_RSD_Plot_Ind()
	RSD_Plot_Ind()
End
