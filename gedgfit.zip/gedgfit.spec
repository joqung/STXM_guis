# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller build recipe for gedgfit.

    pyinstaller gedgfit.spec --noconfirm

On macOS this builds dist/gedgfit.app (use build_mac.sh, which also sets
up the Python environment and runs the self-test). On Windows:

Set ONEFILE below to choose the output shape:
    False  (default) a dist\\gedgfit\\ folder holding the exe and its
           libraries. Starts about 2.7x faster, because a one-file build has
           to unpack its whole payload to a temp folder on every single
           launch. Keep the folder together; zip it to pass it on.
    True   a single gedgfit.exe. Easier to hand to someone, slower every
           time it runs.

Measured on the same machine, warm cache:
    one-file,   untrimmed, eager scipy    80 MB    5.8 s to window
    one-file,   trimmed,   lazy scipy     73 MB    4.5 s
    one-folder, trimmed,   lazy scipy    187 MB    2.1 s
"""

import os
import sys

IS_MAC = sys.platform == "darwin"
APP_VERSION = "2.0"
ONEFILE = False             # Windows only; a Mac .app is always a folder

block_cipher = None

# Modules PyInstaller's static analysis can miss. Matplotlib and SciPy ship
# hooks that cover most of it; these are the stragglers.
hidden = [
    "matplotlib.backends.backend_tkagg",
    "matplotlib.backends.backend_agg",
    "matplotlib.backends._backend_tk",
    "scipy.optimize",
    "scipy.special",
    "scipy._lib.messagestream",
    "tkinter.filedialog",
    "tkinter.messagebox",
    # matplotlib's navigation toolbar draws its buttons through Pillow, and
    # this Tk bridge module is loaded dynamically, so PyInstaller cannot see
    # it. Without it the toolbar raises ModuleNotFoundError at startup.
    "PIL.ImageTk",
    "PIL._tkinter_finder",
    # Reading Igor .pxp / .ibw files (imported lazily, so not seen statically)
    "igor2", "igor2.packed", "igor2.binarywave", "igor2.record",
    "igor2.struct", "igor2.util",
    # Drag and drop
    "tkinterdnd2", "tkinterdnd2.TkinterDnD",
]

# tkinterdnd2 drives a native Tk extension (tkdnd) that ships as data files
# inside the package; without them drag and drop silently does nothing.
from PyInstaller.utils.hooks import collect_data_files, collect_submodules
dnd_datas = collect_data_files("tkinterdnd2")
hidden += collect_submodules("igor2")

# Trimming these keeps the executable to a sensible size. None of them are used.
excluded = [
    "PyQt5", "PyQt6", "PySide2", "PySide6", "wx",
    "matplotlib.backends.backend_qtagg",
    "matplotlib.backends.backend_qt5agg",
    "matplotlib.backends.backend_webagg",
    "matplotlib.backends.backend_gtk3agg",
    "matplotlib.backends.backend_wxagg",
    "IPython", "jupyter", "notebook", "nbconvert", "nbformat",
    "pandas", "sympy", "pytest", "sphinx", "docutils",
    "PIL.ImageQt", "tornado", "zmq", "cv2", "numba", "sqlalchemy",
    "setuptools", "pkg_resources", "yaml", "pydoc_data",
]

# SciPy is over a third of the payload and most of it is never reached. Only
# optimize, special, linalg, sparse, spatial, fft and constants get imported;
# the rest is dead weight that still has to be unpacked on every launch of a
# one-file build. Set TRIM_SCIPY = False if you extend the program to use any
# of these, and verify any change with:  gedgfit --selftest
TRIM_SCIPY = True
if TRIM_SCIPY:
    excluded += [
        "scipy.stats", "scipy.io", "scipy.signal", "scipy.interpolate",
        "scipy.integrate", "scipy.ndimage", "scipy.cluster", "scipy.fftpack",
        "scipy.odr", "scipy.differentiate", "scipy.datasets", "scipy.misc",
    ]

_icon = "icon.icns" if IS_MAC else "icon.ico"
icon_file = _icon if os.path.exists(_icon) else None

a = Analysis(
    ["gedgfit.py"],
    pathex=[],
    binaries=[],
    datas=dnd_datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excluded,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

common = dict(
    name="gedgfit",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,              # UPX often trips antivirus heuristics; not worth it
    console=False,          # no black console window behind the interface
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=icon_file,
)

if IS_MAC:
    # A one-folder build wrapped as gedgfit.app. PyInstaller signs it ad hoc,
    # which Apple Silicon requires for anything to run at all.
    exe = EXE(pyz, a.scripts, [], exclude_binaries=True, **common)
    coll = COLLECT(exe, a.binaries, a.zipfiles, a.datas,
                   strip=False, upx=False, name="gedgfit")
    # Files gedgfit reads. Rank "Alternate": it appears under Open With and
    # accepts them dropped on its Dock icon, but never becomes the default
    # application for them.
    _types = [
        ("Igor experiment", ["pxp", "pxt", "uxp"]),
        ("Igor wave", ["ibw", "bwav"]),
        ("Igor text", ["itx", "awav"]),
        ("gedgfit session", ["json"]),
        ("Spectrum data", ["txt", "dat", "csv", "xy", "asc", "tsv", "prn"]),
    ]
    doc_types = [{"CFBundleTypeName": n, "CFBundleTypeRole": "Viewer",
                  "LSHandlerRank": "Alternate", "CFBundleTypeExtensions": e}
                 for n, e in _types]
    doc_types.append({"CFBundleTypeName": "Folder", "CFBundleTypeRole": "Viewer",
                      "LSHandlerRank": "Alternate",
                      "LSItemContentTypes": ["public.folder"]})
    app = BUNDLE(
        coll,
        name="gedgfit.app",
        icon=icon_file,
        bundle_identifier="org.gedgfit.gedgfit",
        version=APP_VERSION,
        info_plist={
            "CFBundleName": "gedgfit",
            "CFBundleDisplayName": "gedgfit",
            "CFBundleShortVersionString": APP_VERSION,
            "CFBundleVersion": APP_VERSION,
            "NSHighResolutionCapable": True,     # sharp text on Retina screens
            "LSMinimumSystemVersion": "10.13",
            "CFBundleDocumentTypes": doc_types,
            "NSHumanReadableCopyright": "gedgfit - XAS edge fitting",
        },
    )
elif ONEFILE:
    exe = EXE(pyz, a.scripts, a.binaries, a.zipfiles, a.datas, [],
              runtime_tmpdir=None, **common)
else:
    exe = EXE(pyz, a.scripts, [], exclude_binaries=True, **common)
    coll = COLLECT(exe, a.binaries, a.zipfiles, a.datas,
                   strip=False, upx=False, name="gedgfit")
