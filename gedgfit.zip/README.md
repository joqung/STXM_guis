# gedgfit

A single-file Python port of two Igor Pro procedure files, with a GUI.

## Files in this folder

| file | what it is |
|---|---|
| `gedgfit.py` | the whole program: model, fitting engine, GUI |
| `gedgfit.spec` | PyInstaller recipe for the Windows and Mac builds |
| `build_windows.bat` | double-click this to build the Windows `.exe` |
| `build_mac.sh` | run this in Terminal to build the Mac `gedgfit.app` |
| `run_gedgfit_mac.command` | double-click to run on a Mac without building |
| `icon.ico`, `icon.icns` | application icons (Windows, Mac), used at build time |
| `requirements.txt` | package versions, if you install by hand |
| `BUILDING.md` | build instructions, startup speed, troubleshooting |
| `README.md` | this file: what the port does and how it maps to the `.ipf` files |
| `gedgfit_Model.ipf`, `gedgfit_Workflow.ipf` | the Igor procedures (also embedded in the program; copies here override) |

Keep the files together in one folder for the builds to work.

**To build the Windows `.exe`: double-click `build_windows.bat`.**
**To build the Mac app: run `./build_mac.sh` in Terminal.** See
[BUILDING.md](BUILDING.md) for the details and for what to do when Windows or
macOS complains. Either result is self-contained and needs no Python installed
on the machine that runs it. On a Mac you can also skip building and
double-click `run_gedgfit_mac.command`.

To run it as a script instead:

```
pip install numpy scipy matplotlib igor2 tkinterdnd2
python gedgfit.py
```

On Debian/Ubuntu also `sudo apt install python3-tk`; on Homebrew Python,
`brew install python-tk`. It opens on a synthetic C K-edge so you can try the
controls before loading data.

---

## What the two Igor files do

**`EDG_Fit12_SGM_modified.ipf` — the model.** An absorption edge built from a
step plus up to twelve peaks, all sharing one Gaussian/Lorentzian mixing
parameter:

```
step(x) = ½ + m·½erf((x−E₀)√ln2 / W) + (1−m)·(1/π)atan((x−E₀)/W)

w_eff   = W + (x−E)·skew                     linear width skew
G(x)    = exp(−ln2·(x−E)² / (w_eff·R)²)      R = Gaussian/Lorentzian width ratio
L(x)    = w_eff² / (w_eff² + (x−E)²)
peak(x) = A·(m·G + (1−m)·L)
```

`edg_fit1 … edg_fit12` are cumulative — `edg_fit8` is the step plus peaks 1–8 —
so you pick the function matching your peak count. `Plot_step` and
`Plot_wave1…12` return the same terms individually for plotting. Parameters live
in one flat wave: `p[0]` mix, `p[1]` step position, `p[2]` step half-width, then
five per peak (amplitude, position, half-width, skew, L/W ratio).

**`Cp2VCl2_CK_Apr2012_8CF.ipf` — the workflow** wrapped around that model, with
the wave names hard-coded to one sample:

- `derivPlot` — smooths the spectrum and takes 1st and 2nd derivatives, the
  usual way of locating overlapping transitions on a rising edge
- `SetUp` — makes the parameter wave and one wave per component
- `Up` — recalculates every component and the residuals
- `SP` / `OldP` — store and recall a parameter set
- the `_Plotter_` / `_RSD_Plot_` functions — the black-background figures

Its residual bookkeeping is worth spelling out, because the GUI reproduces it:

| Igor wave | meaning |
|---|---|
| `TOT_RSD` | (all components + step) − data |
| `RSD_i` | data − (everything except peak *i*) — the intensity left for peak *i* |
| `PostRSD` | sum of the post-edge components |

Plotting `RSD_i` against peak *i* is how you judge one component when the others
overlap it. That is the lower-panel "Isolated peak" mode.

---

## The port

The model is reproduced exactly. `gedgfit.py` was checked against a literal,
independent transcription of every Igor function: `edg_fit1` through `edg_fit12`,
`Plot_step` and `Plot_wave1…12` all agree to 4×10⁻¹⁶, and the `Up()` residual
identities hold to machine precision.

Parameter numbering is unchanged, so a 43-, 53- or 63-element Igor `_P` wave
imports 1:1 (File ▸ Import Igor parameter wave), and File ▸ Export writes a
`.itx` you can drop straight back into Igor.

What replaces the hard-coded Igor parts:

| Igor | Here |
|---|---|
| one function per sample name | load any 2-column file; pick the columns |
| `make/n=53`, `Duplicate` chains | handled internally |
| choosing `edg_fit8` by hand | "Number of peaks" spinbox |
| `Analysis ▸ Curve Fitting` | **FIT** button, `scipy.least_squares` |
| `SP` / `OldP` | **Store / Recall params** |
| `derivPlot` | Tools ▸ Derivative viewer |
| `Up` + plotter functions | the plot updates live |

Reads plain text, CSV, tab/space-delimited and Igor Text (`.itx`) — comment
lines and a header row are handled.

### Beyond the original

- **Dark interface throughout** — panels, menus, the fit log and the plot. The
  Matplotlib toolbar icons are re-rendered light rather than left as black
  glyphs on a dark bar. The plot alone can be switched to white for publication
  figures, from the Display group.
- **Zoom-to-rectangle armed at startup**, so dragging on the plot zooms straight
  away. An Igor-style crosshair follows the pointer: dashed lines spanning the
  full width and height of the axes, a short solid cross on the exact point,
  and a live energy/intensity readout in the status bar. The vertical line is
  echoed in the residual panel, which shares the energy axis. Drawn by
  blitting, so it stays responsive with twelve components on screen.
- **Resizing is debounced.** Matplotlib binds the window's resize event
  straight to a full re-render, so dragging a window edge fires dozens of
  redraws a second and the interface stutters. Here the events are coalesced
  and only the last is acted on, once the drag has been still for 120 ms:
  measured over 24 resize steps that is 24 redraws down to 0, and the drag
  itself about 23x faster.
- **Bounded fitting with per-parameter holds.** Every parameter has a hold
  checkbox; limits are editable under Tools ▸ Fit limits. Skew and L/W ratio are
  held by default, which is what you want unless the data really demands an
  asymmetric line shape — freeing all five parameters on eight overlapping peaks
  is badly under-determined.
- **Standard errors** on each refined parameter from the Jacobian, plus χ², reduced χ², R², and an integrated area per peak.
- **The report says whether the fit did anything**: chi-square before and after,
  the percentage improvement and the evaluation count. It distinguishes a fit
  that was already at a minimum from one the tolerance halted after two steps.
- **Starting-point help.** "Guess positions" places peaks at the 2nd-derivative
  minima; "Click to place" sets them by clicking the plot; amplitudes are then
  estimated by peeling intensity off the data above the step.
- **Fit range** by typing or by dragging on the plot; excluded regions are shaded.
- **The view is yours.** Zoom in on a shoulder and it stays there through
  fitting, parameter edits and panel switches — only loading data or the
  Autoscale button rescales. Autoscale also becomes the toolbar's new Home.
- **Peaks reorder by dragging** the row number in the peak table. Values and
  hold flags travel together, and the total model is unchanged by a reorder.
- **Sessions** save to JSON — data path, parameters, holds, limits, range.
- **Export** components to CSV (data, total, step, each peak, residual, each
  isolated residual), the report to text, the figure to PNG/PDF/SVG.

**Per-peak Gaussian fractions.** Igor's `edg_fitN` uses one `param[0]` for the
step and every peak at once, so changing the edge shape changes all the line
shapes with it. Here `p[0]` governs the step alone and each peak carries its own
fraction, in a column of the peak table. The extra values live after the 63 Igor
parameters, so indices 0-62 are untouched and parameter waves still round-trip.
Loading an Igor wave sets every peak to `p[0]`, reproducing Igor exactly, and a
button relinks them at any time. Exporting a wave whose fractions differ warns
you, because `edg_fitN` cannot express it.

One further extension: a **step amplitude**, held at 1.0 by default. Igor
hard-wires the edge jump to 1 because the data is normalised first. Free it if
you are fitting un-normalised data. It sits outside the 63-element vector so
Igor compatibility is unaffected.

### Export to Igor (data + procedures)

**File ▸ Export to Igor: data + procedures** writes three files into the
folder you choose, named in the original Igor convention (here for sample
`Cp2VCl2` with 8 peaks):

| file | contents |
|---|---|
| `Cp2VCl2_8CF.itx` | the data and the complete parameter state |
| `EDG_Fit12_SGM_JQN_modified.ipf` | the model, the same file for every dataset |
| `Cp2VCl2_8CF.ipf` | the workflow (SetUp, Up, FitIt, Report, plots, ...), set to this sample |

Inside every exported `.itx` the waves are named after the sample alone,
without the `_8CF`: `Cp2VCl2_eV`, `Cp2VCl2_Int`, `Cp2VCl2_P`, `Cp2VCl2_Prev_P`,
`Cp2VCl2_Step`, `Cp2VCl2_Peaks`, and the total fit (step + all peaks) twice,
plus the fit errors if the parameters are the fitted ones:

- `fit_Cp2VCl2_Int` is the live total fit, drawn in red. It is written the
  way Igor's own fit writes it (evenly spaced over the fit range, with x
  scaling), so running a fit in Igor overwrites it in place rather than adding
  a second curve, and `Up()` recomputes it whenever the parameters change.
- `Cp2VCl2_Fit` is gedgfit's total fit at every data point, a record of the
  fit as it was exported. The Igor procedures never read, change or plot it,
  so it stays available for comparison after you refit in Igor. The peak count is kept separately, in `Cp2VCl2_nPk`.

Open the `.itx` in Igor Pro 7+ (double-click, or File ▸ Open File ▸ Igor Text).
It opens the two procedure files from the same folder first, then loads the
waves, then compiles and runs `derivPlot` (with the smoothing set in the
derivative viewer), `SetUp()`, `Wv_Plotter_Tot()` and `RSD_Plot_Tot()`.
`RSD_Plot_Ind()` is still available from the command line. File ▸ Save
Experiment As then makes a packed `.pxp`.

Keep the three files together. Every sample's workflow file defines the same
functions, so open one sample's export per Igor experiment, and close any
other copies of these procedures first.

In Igor the parameter wave has 76 points with the step amplitude at p[1]:
`[mix, step amp, E0, W0, peak1 ×6, …]`. `ShowP()` shows it with a column
describing every row.

**Names.** The *Sample name* box in the Data panel sets every export. File
names are `<sample name>_<N>CF...`, where N is the number of peaks
(`Cp2VCl2_8CF.itx`, `Cp2VCl2_8CF_session.json`, `Cp2VCl2_8CF_report.txt`);
wave names are `<sample name>_...`. The box fills itself from the data file
name until you type your own, and is saved in sessions. Characters Igor does
not allow in wave names become `_`.

In this folder the procedures are `gedgfit_Model.ipf` and
`gedgfit_Workflow.ipf`; they are embedded in the program and only take the
names above when exported. A copy of either placed beside the program (or the
`.exe`) is used instead, so they can be updated without rebuilding.

### Sessions keep their data

A saved session (`.json`) holds the parameters, holds, settings and the data
it was fitted on: the energy and intensity columns are stored inside it,
along with the data file's path. Loading a session looks for the data in
this order and the status bar says which was used:

1. the data file at its original path;
2. the data file next to the session (a folder that was moved, copied,
   zipped or sent to someone else);
3. when dropped onto the window together, a dropped file of the same name;
4. the copy stored in the session.

So a session on its own always reopens with its data. Sessions saved by
earlier versions of gedgfit don't contain a copy; if their data file can't be
found you get a warning instead of a silent parameters-only load.

### Rebuilding a fit from files (drag and drop)

Drop files or whole folders anywhere on the window — or use **File ▸ Rebuild
fit from files / folder** — and gedgfit reads everything it recognises and
rebuilds the fit: data, parameters, hold flags, peak count, fit range,
stored parameter set and sample name.

| what you drop | what is used |
|---|---|
| Igor packed experiment `.pxp` | every data folder is searched |
| Igor binary waves `.ibw` | all `.ibw` files in that folder, together |
| Igor Text `.itx` | including gedgfit's own Igor exports |
| gedgfit session `.json` | everything; if its data file isn't on this computer, a file of the same name among the dropped files is used |
| data `.txt .dat .csv .xy .asc` | as spectra; a single column of 53/63/75/76 numbers is taken as a parameter wave |

In Igor data it looks for the workflow's naming: `<base>_eV` and `<base>_Int`
for the spectrum and `<base>_P` for the parameters, plus, when present,
`<base>_Prev_P`, the `<base>_Step` / `<base>_Peaks` hold tables and the
`<base>_nPk`, `_xmin`, `_xmax` globals. Every parameter-wave layout is
recognised: the original EDG_Fit12 waves (`make/n=53`, 63, …, with every peak
fraction linked to p[0]), gedgfit's 75-point wave, and the 76-point Igor
layout. Where Igor did not record something, gedgfit infers it: the peak count
from the highest non-zero amplitude, and the fit range from the span of
Igor's `fit_<base>_Int` curve. Holds not stored in Igor keep gedgfit's
defaults. Data not named `_eV`/`_Int` is still found if one wave's name says
energy.

When several fits are found — a folder of samples, or an experiment holding
more than one — a list opens to choose from, the most complete first. The fit
report box then says where each piece came from.

Reading `.pxp`/`.ibw` needs the `igor2` package and drag and drop needs
`tkinterdnd2`; the Windows build includes both. Without them the rest of the
program works, and the File ▸ Rebuild items still read everything else.



Three algorithms, selectable per fit:

| | bounds | notes |
|---|---|---|
| **Levenberg–Marquardt** | ignored | MINPACK, the same algorithm as Igor's `FuncFit`. Unconstrained, exactly as `FuncFit` is unless you hand it a constraint wave. This is the default. |
| **Trust region reflective** | honoured | Steadier on badly scaled or strongly correlated problems, which describes most multi-peak edges. |
| **Dogbox** | honoured | Often quicker than trf when few parameters sit near a limit. |

Held parameters work under all three. Holding removes a parameter from the free
vector rather than pinning it with bounds, so it survives the unconstrained
method. When LM drops your limits, the report says so.

### Weighting

`none` gives every point equal say, which is right when the noise is roughly
constant across the spectrum. That is the usual situation for edge-jump
normalised data, and it is what your Igor procedure used.

`poisson` weights by 1/sqrt(y), appropriate when the noise scales as the square
root of the signal — raw photon counts from a counting detector. It is not
appropriate for normalised data: dividing by I0 and the edge jump scales the
counting statistics away, so 1/sqrt(y) is no longer the true 1/sigma. The
program warns when you select it on data that peaks below 50.

The variance is floored at a thousandth of the data range, because a point that
happens to record zero counts would otherwise get an unbounded weight and a
handful of such pixels would dominate the whole fit.

### Parameter errors

Both conventions start from the same covariance matrix, `C = (JᵀJ)⁻¹`, computed
by SVD on the weighted Jacobian. They differ only in whether the noise level is
inferred from the fit or taken from your weights.

**Residual scatter** (default) multiplies `C` by the reduced χ², i.e. treats the
scatter of the residuals as the measurement error. This is what Igor reports for
an unweighted fit, and matches `scipy.optimize.curve_fit` with
`absolute_sigma=False`. It assumes the model is right: a systematically poor fit
inflates the error bars instead of exposing itself.

**Trust the weights** uses `C` as it stands, treating the weights as genuine
1/σ. This is the convention for a fit weighted by real uncertainties, as Igor
does when given a weighting wave. It is only meaningful with a weighting set —
with weighting "none" every weight is 1, so the numbers assume unit-variance
intensities. The program warns you when you ask for this combination.

Both were checked against `curve_fit` (`absolute_sigma=False` and `True`) and
agree to about 1 part in 10⁵. The two differ from each other by exactly
√(reduced χ²), which is the arithmetic identity relating them.

The report also flags a rank-deficient Jacobian (two components that the data
cannot tell apart) and any parameter that came to rest on a limit, where the
quoted error is meaningless.

### Where files go

Nothing is written without you choosing a location. Every export opens a Save
dialog that starts in the last folder you saved to, or the folder your data came
from if you haven't saved yet, with a name built from the data file — load
`Cp2VCl2_CK_run3.csv` and the exports offer `Cp2VCl2_CK_run3_components.csv`,
`_report.txt`, `_fit.png`, `_P.itx`, `_session.json`. The status bar shows the
full path after each write.

The two files the program writes on its own are `gedgfit_error.log` if
something goes wrong and `gedgfit_selftest.txt` when you run `--selftest`. On
Windows they go beside the executable, or in your user folder if that isn't
writable; on a Mac, in `~/Library/Logs`.

### Windows and Mac behaviour

On a Mac the shortcuts use Command (⌘O, ⌘F, ⌘U, ⌘Q), files can also be
dropped on the Dock icon, and the interface is sized in points with Retina
scaling left to macOS. Igor exports written on a Mac give Igor the folder in
its own colon-separated form, with the disk name filled in by Igor itself, so
they open their procedure files as on Windows.

On Windows:

The program is DPI-aware, so it stays sharp on high-resolution laptop screens
and sizes itself to your monitor rather than assuming a large display. A
windowed build has no console to print to, so any unhandled error is written to
`gedgfit_error.log` next to the executable and shown in a dialog, instead
of the window vanishing without explanation.

### Scripting

The file is also importable, so batch work doesn't need the GUI:

```python
import gedgfit as X
import numpy as np

names, data = X.read_columns("sample.itx")
x, y = data[:, 0], data[:, 1]

p = X.default_params()
p[0], p[1], p[2] = 0.5, 289.0, 0.8            # mix, step position, step width
for i, (a, c, w) in enumerate([(0.5, 285.1, 0.35), (0.3, 286.6, 0.45)]):
    b = X.peak_base(i)
    p[b:b+5] = [a, c, w, 0.0, 1.0]            # A, E, W, skew, R

fixed = np.zeros(X.FULL_LEN, bool)
for i in range(2):                             # hold skew and L/W ratio
    fixed[X.peak_base(i) + 3] = True
    fixed[X.peak_base(i) + 4] = True

res = X.fit_spectrum(x, y, p, n_peaks=2, fixed_mask=fixed)
print(res.r2, res.p[X.peak_base(0) + 1], res.errors[X.peak_base(0) + 1])
```

---

## A caution on the fit

Eight overlapping components on a step can reproduce almost any curve, so a good
R² is weak evidence on its own. The isolated-residual view exists for exactly
this reason: it shows whether each peak is accounting for real structure or
absorbing its neighbours' intensity. Constrain what you can justify
independently — widths from instrumental resolution, positions from the 2nd
derivative — and refine as few parameters as the data will carry.
