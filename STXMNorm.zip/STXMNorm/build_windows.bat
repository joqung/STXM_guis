@echo off
rem ---------------------------------------------------------------------
rem build_windows.bat - build STXMNorm.exe
rem
rem Put this next to main.py, build_exe.py and STXMNorm.spec, then
rem double-click it, or run it from a command prompt to see the output.
rem
rem There is deliberately almost nothing in this file. All it does is
rem find a Python and hand over to build_exe.py, which does the real
rem work and writes build_log.txt. Batch files are a poor place to put
rem logic that can fail.
rem ---------------------------------------------------------------------

setlocal

rem --- options: set any of these to 1 -----------------------------------
set DEBUG=0
set ONEDIR=0
set NOVENV=0
set PLAIN=0
set NOTEST=0

set OPTS=
if "%DEBUG%"=="1"  set OPTS=%OPTS% --debug
if "%ONEDIR%"=="1" set OPTS=%OPTS% --onedir
if "%NOVENV%"=="1" set OPTS=%OPTS% --no-venv
if "%PLAIN%"=="1"  set OPTS=%OPTS% --plain
if "%NOTEST%"=="1" set OPTS=%OPTS% --no-test

rem anything typed on the command line is passed through as well
set OPTS=%OPTS% %*

cd /d "%~dp0"

rem --- find a Python ----------------------------------------------------
set PY=
where py >nul 2>nul && set PY=py -3
if not defined PY where python >nul 2>nul && set PY=python

if not defined PY (
    echo.
    echo Could not find Python on this machine.
    echo.
    echo Install Python 3.10-3.12 from https://www.python.org/downloads/
    echo and tick "Add python.exe to PATH" in the installer.
    echo.
    pause
    exit /b 1
)

echo Using: %PY%
%PY% --version

echo.
echo Building %CD%\STXMNorm.exe ...
echo (this takes a few minutes the first time; progress goes to build_log.txt)
echo.

%PY% build_exe.py %OPTS%
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
    echo ============================================================
    echo  BUILD OK   dist\STXMNorm.exe
    echo ============================================================
) else (
    echo ============================================================
    echo  BUILD FAILED - see build_log.txt in this folder
    echo ============================================================
)

rem keep the window open when double-clicked
echo.
pause
exit /b %RC%
