# STXMNorm

One program for normalizing ratioed STXM/XAS spectra, with the two
normalization philosophies you had in separate programs available as a
toggle.

Unifies:

- `xas_mledge` / XASNorm — Ln M-edge and TM L-edge STXM normalization
  (itself already a unification of two Igor Pro procedure sets)
- `norm2poly` — the Penner-Hahn group's McMaster-scaled background
  removal (`norm2poly.m`, Tsu-Chien Weng, 1998)

Fitting is deliberately left out for now.

---

## 1. Why this is a toggle and not a merge

XASNorm's README makes a specific claim about the two Igor procedures it
unified: they compute the *same thing*. The Cp2VCl2 route's initial
single-point scaling multiplies by a constant, every later step is linear
or divides by a fit of the scaled data, so it cancels exactly — verified
to 3e-15. They differed in interface and default model, not in algebra.
One pipeline with the real choices exposed as settings covered both.

**norm2poly is not like that.** It is a different calculation answering a
different question.

```
EDGE STEP  (Branson / Cp2VCl2 / Athena lineage)

    pre  = fit(pre-edge window)            Victoreen, line or polynomial
    sub  = I - pre
    post = fit(post-edge window of sub)
    norm = sub / post(E_norm)

Two fits, in sequence.


McMASTER  (norm2poly, Penner-Hahn 1998)

    y ~ c0*mu_McMaster + c1*P0(x) + c2*P1(x) + ... + cn*Pn(x)
    norm = (y - polynomial part) * span_mu / c0 + mid_mu

One fit, over the union of both windows.
```

Three differences that are real, not cosmetic:

**Sequential vs simultaneous.** Edge step commits to a pre-edge fit and
then fits the residual, so a pre-edge error propagates in full. McMaster
lets background and edge step trade off inside one solve — more forgiving
of a marginal pre-edge window, but it cannot show you a pre-edge fit that
is independent of the edge-step estimate. You lose a diagnostic to gain
robustness.

**Empirical vs theoretical edge step.** Edge step reads the step off your
own data. McMaster takes its shape and size from a 1969 table and fits
only the amplitude, so the result carries physical units — and carries
the table's errors too.

**Scale.** "Edge jump = 1" and "cm²/g" are not convertible without the
element, the table, and the assumption that your sample's atomic
absorption matches it.

A fourth, smaller one: Victoreen (A·E⁻³ + B·E⁻⁴) is a physical
parameterisation of atomic absorption; Legendre polynomials on [−1,1] are
a well-conditioned but purely empirical basis. Note the polynomial is
fitted *only over the two windows* yet evaluated across the whole scan,
so a high order can swing between them. Orders 1–3 are usual.

So the program toggles. What is shared — and what makes it feel like one
program rather than two bolted together — is everything around the solve:

```
import ─▶ ratio to I₀ ─▶ bin ─▶ calibrate ─▶ [ENGINE] ─▶ interpolate
       ─▶ average ─▶ export
```

Both engines consume the same `UnifiedParams` and return the same
`EngineResult`, so every surrounding stage is written once.

**The four window edges are shared and persist across a toggle.**
`pre_lo/pre_hi` and `post_lo/post_hi` mean the same thing to both
engines, so switching is a one-click comparison rather than a re-setup.
This is checked by a test (`window edges survive an engine toggle`).

---

## 2. The soft X-ray limit — read this one

**McMaster's tabulation stops at the M1 edge.** For a lanthanide that is
around 1.5 keV. Ln M4,5 white lines sit near 900–1000 eV, *below* the
table, so the McMaster engine cannot run on them at all. The same goes
for actinide N4,5 edges.

Measured from the table as shipped:

| element | McMaster floor (M1) | typical STXM edge | McMaster usable? |
|---|---|---|---|
| Ti | 59 eV | L2,3 454 eV | yes |
| V | 67 eV | L2,3 512 eV | yes |
| Mn | 84 eV | L2,3 639 eV | yes |
| Fe | 94 eV | L2,3 707 eV | yes |
| Cu | 120 eV | L2,3 932 eV | yes |
| Pr | **1508 eV** | M4,5 931 eV | **no** |
| Nd | **1575 eV** | M4,5 980 eV | **no** |
| U | **5549 eV** | N4,5 ~740 eV | **no** |

If your work is Ln M-edge STXM, the edge-step engine is not merely
preferable — it is the only one available. The program says so in plain
words rather than raising:

```
scan starts at 915.0 eV but McMaster's tabulation for Pr stops at the
M1 edge, 1508 eV. The McMaster engine cannot run here -- use the
edge-step engine, which needs no reference table.
```

Transition-metal L2,3 edges *are* inside the table, because McMaster
tabulates L3. But below that L3 edge there is no measurement at all.
`element.mat` stores an **all-zero `post_M` block for every element from
H to Cu**, and `mcmaster()` evaluates that as `exp(polyval(0, log E))` =
1 barn at every energy below L3. So the sub-edge "cross-section" is a
constant placeholder. For V it comes out at **2.5 cm²/g at 505 eV**,
where the truth is thousands:

```
    505.0 eV           2.5 cm2/g      <- extrapolated M-shell fit
    511.9 eV           2.5 cm2/g
    512.2 eV       20849.9 cm2/g      <- L3 edge
    519.5 eV       20166.1 cm2/g
    520.0 eV       28368.7 cm2/g      <- L2 edge
```

The algorithm zeroes the template's pre-edge before fitting — it fits a
line through the template over the pre-edge window and subtracts it, which
sends a near-constant to zero — so the solve stays self-consistent and the
*shape* is fine. What it means is that the absolute scale is the L-shell
jump measured from a placeholder baseline, with the sample's real
sub-edge absorption omitted. The program says so in the fit report. Treat cm²/g at these energies as
indicative, prefer Henke/CXRO for soft X-ray cross-sections, and use the
"edge jump = 1" output scale if you only want shape. The program attaches
this warning automatically below 1 keV.

Above roughly 3 keV — K edges of the 3d metals, the regime norm2poly was
written for — none of this applies and the McMaster scale is on solid
ground.

---

## 3. Using it

Layout follows XASNorm: numbered tabs across the middle, log along the
bottom, drag-on-the-plot to set fit windows. The scan list and the
parameter panel are tabbed together in the left dock, so the plots get
the full width. Dark is the default theme; View remembers your choice.

**Sample name** sits at the top of the settings panel. It heads every
export's provenance, names the per-scan files, and gives the averaged
spectrum its name: **`<sample>_Norm_Avg`** — the convention the Igor
procedures used (`Cp2VCl2_Norm_Avg_L`). That one name drives the
suggested filename, the column heading in the text export and the Igor
wave names, so they cannot drift apart. It is sanitized for use in a
filename (path separators and the characters Windows forbids become
underscores) and falls back to `Sample` if cleared. It also appears in
the window title.

The scan list sits on the left and the normalization settings on the
right, both visible at once; the log is confined to the centre column so
the two docks keep their height.

At the top of the settings panel, **Editing** chooses what they apply to:
*All scans*, or one named scan. The list rebuilds itself whenever scans
are imported or removed, and picking a scan there also selects it for
display — so normalizing one spectrum at a time is just working down the
list.

The **Scans** dock has two sections. *Data* lists the imported scans;
*I₀* lists the I₀ attached to each. The tick beside each name controls
only whether that trace is drawn — whether a scan contributes to the
average is a separate decision made in the table on tab 3, so you can
hide a noisy scan to see the others without silently dropping it from
the result. **All** / **None** toggle a whole section.

Tab 1 draws the data over its I₀ on a shared energy axis, so zooming one
zooms the other and features line up vertically.

Hovering over any plot draws a vertical guide at that energy in **every**
panel of the figure and snaps a marker to the nearest plotted sample and
reads out both the cursor position and that sample's exact values, top
right. It is drawn by blitting rather than a redraw — 1.5 ms a move
against 66 ms for a full redraw — so it keeps up with the mouse.

Every plot carries the matplotlib toolbar: pan, **box zoom**, back /
forward through zoom history, and home to reset, plus **A** (autoscale),
**+** and **−** buttons that step the view in and out about its centre
without needing a drag. Zoom starts active on
tabs 1 and 3. On the Normalization tab a drag sets a fit window instead,
because a live span selector and rubber-band zoom would both consume the
same drag — pick **Zoom only** in the row above the plot to get zoom
back.

**A saved session (`.stxmnorm`) can be dropped anywhere on the
interface** — the plots, the docks, the log, the tab bar — and it opens,
asking first if scans are already loaded. Session and spectrum
extensions are deliberately disjoint, so a session dropped on the scan
list is still opened as a session and a spectrum dropped on the window
is refused rather than misread.

**Drag and drop** works on both sections of the Scans dock. Drop
spectrum files on *Data* to import them, or drop a file onto a scan in
the *I₀* section to attach it as that scan's I₀ — dropping on empty
space uses the selected scan, and several files at once are attached down
the list in order. Folders are accepted: the spectra inside are picked up
and anything else is ignored. A dropped two-column file is imported
without asking about columns, since there is nothing to decide; a wider
file still opens the column picker.

Note the log when an I₀ is attached. If the intensity is detected as raw
transmission rather than optical density, your data will be **divided**
by that I₀ — and aXis2000 output is already ratioed, so doing that to an
aXis2000 file would ratio it twice. The I₀ list marks which case each
scan is in.

1. **File ▸ Import scans** — aXis2000 `.txt` (`%` header, whitespace) and
   `.xas` (`*` header with a `Key: value` metadata block, tab-delimited)
   are read directly, as is generic delimited text. The column picker
   shows each column's range so you can confirm which is energy. If your
   data is already ratioed — as aXis2000 output normally is — just import
   it.
2. **Process ▸ Set edge from element** seeds all four windows from the
   nominal edge pair, or **Suggest windows from data** guesses from the
   scan range. Both are starting points; drag on the plot to refine.
3. **Process ▸ Energy calibration** (Ctrl+E) shifts the energy axis so a
   known feature lands where it should: enter the measured and expected
   positions, see the resulting shift before committing, and apply it to
   one scan or all. **Process ▸ Bin scan** (Ctrl+B) averages every N
   points, trading resolution for signal to noise. Both are
   non-destructive — the raw arrays are untouched, and **Reset shift and
   binning** returns to the imported data. Both are applied before the
   fits and before averaging, so the fit windows keep their meaning, and
   the shift is applied *after* binning so calibration is never undone by
   re-binning. The results table shows the shift and bin factor in use.

   Calibrate before averaging: shifting after scans are on a common grid
   mixes grids, the same warning the Igor procedure carried.

4. **Choose the engine** at the top of the parameter dock. The
   description under the selector says what that engine does; hovering
   gives the longer version. Window edges carry over.
5. **Normalization tab** — the pre-edge window is shaded **orange** and
   the post-edge window **blue**, with matching edge lines and matching
   fit curves. The drag-mode buttons above the plot carry the same
   colours, so the key sits in the controls rather than taking up legend
   space. Exclusions are red and hatched.

   **Normalize to** offers three scales. *Edge jump = 1* is the classic
   choice and the only one tied to how much of the element is present.
   *Area = 1* and *Peak = 1* over a stated window need no edge step at
   all, which is what makes them usable where the continuum jump is
   small or unmeasurable — lanthanide M₄,₅ edges especially. On a Eu
   M₄,₅ scan whose edge step swung **9×** under a ±2 eV window nudge and
   changed sign in 28% of them, the area over the resonances moved
   **0.13×** and never changed sign. Area is the steadier of the two,
   since a single point sets the peak. Neither gives an absolute
   concentration; both let you compare shapes and ratios. **From edge
   A/B** sets the window from the markers found on the Analysis tab.

   The fit report carries a **Stability** line: how far the edge step
   moves when all four windows are nudged by ±2 eV. An edge step that
   swings by more than its own size, or changes sign, is not a
   measurement — no background model rescues it, and the normalized
   amplitude means nothing. On real data this reads 0.2× for a sound fit
   and 5× or more for a fragile one.

   **Power law (A/Eⁿ)** lets you set the exponent, with a **Fit n**
   button that regresses log(OD) on log(E) over the pre-edge window. This
   exists because n = 3 is an assumption worth testing rather than
   accepting: on a Ce M₄,₅ scan, moving n by ±0.3 moved the edge step by
   ±10%, which dominates every other uncertainty in the fit. If an
   absolute edge step matters, quote that sensitivity. Note that on a
   short, flat pre-edge the fitted n is poorly constrained and can come
   out unphysical — the button says so rather than applying it.

   **Victoreen, 1 term (A/E³)** is available alongside the two-term form.
   It is the physically correct shape for a smooth continuum between
   edges, and often the only one a short, flat, noisy pre-edge can
   support: on a Ce M₄,₅ scan whose 15 eV pre-edge decays by 5% against
   1.5% scatter, the two-term fit moved the edge step 12× when one point
   was dropped, while the one-term form stayed within 4% across every
   window tried.

   Drag on the plot to set the pre-edge window
   (Igor's A/B), the post-edge window (C/D), or an exclusion; or pick
   **Zoom only** to use the drag for rubber-band zoom. The radio buttons
   above the plot say which one a drag sets. Everything
   re-normalizes immediately. The fit report shows coefficients,
   uncertainties, R² and warnings.
6. **To compare the two engines**, set the McMaster output scale to
   "edge jump = 1" and toggle the engine. The windows stay put, so the
   only thing that changes is the arithmetic. (`engines.compare_engines()`
   runs both in one call for scripting.)
   When the unconstrained pre-edge fit gives a **negative edge step**,
   the fit is redone with the leading term alone and the scan is marked
   **"would invert"** in the results table, with a summary naming every
   affected scan. The correction is recorded rather than only logged at
   the moment it happens, because a spectrum that needed rescuing is one
   whose pre-edge window should be looked at.

   A note on why: constraining the coefficients is *regularisation, not
   physics*. Victoreen's formula is μ/ρ = Cλ³ − Dλ⁴, so the E⁻⁴
   coefficient is negative by construction; an earlier version of this
   program described a negative coefficient as unphysical, which was
   wrong. What goes wrong on a short pre-edge is that the two-parameter
   fit is underdetermined and its turning point, at E = 4D/3A, can land
   inside the scan. Constraining drives the fit to its leading term,
   which is what the data can support.

   The results table carries the same diagnostics per scan: the
   **divisor** actually used, its size as a **% of that scan's pre-edge
   level** (edge mode only — an area is in OD·eV and has no business
   being compared with an OD), and its **stability**, red above 1×. On
   the Eu set this reads 24.0% / 0.2× for a sound scan against −0.3% /
   490.9× for one that had drifted.

   Across scans, the program also checks that each edge step is a
   similar fraction of its own pre-edge level. Scans of the same material
   at the same edge should agree; one that does not — or whose step has
   the opposite sign — almost always has a measurement problem rather
   than a fitting one, and is named in the log.

7. **Normalized + average tab** — untick a scan in the table to drop it.
   **Energy grid** defaults to *Native*, which keeps the first included
   scan's own energies clipped to the range every scan covers. This
   matters: an XAS scan is sampled unevenly on purpose, and resampling
   onto even steps throws that away. On the C K-edge data here, 99
   measured points between 283 and 290 eV became 16 on a uniform grid,
   the π* lost height and shifted 0.07 eV, and the 288.6 eV feature
   shifted 0.16 eV. norm2poly defaults to native for the same reason.
   *Uniform* is still available. **Show points** marks every point of the
   averaged spectrum, and a line beneath the controls reports the grid:
   how many points, the range of steps, and — where the sampling is
   finest — how many points the grid has against how many the densest
   contributing scan had. If the average is coarser than the data there,
   it says so in red. On the C K-edge set that reads *"around 280.0 eV
   the finest scan has 49 points, the grid has 48"* for Native and
   *"...the grid has 13"* for Uniform.

   **Range** decides how far the average extends. *Overlap of all scans*
   is the default and keeps every point an average of the same spectra.
   *Full range of reference* uses the chosen scan's own range instead, so
   a long scan is not truncated just because one short scan is included.
   Points beyond the overlap are then averaged over **fewer** scans —
   legitimate, since NaNs are ignored per point and the standard error
   widens to match, but the mean there is over a different set of
   spectra. Those points are shaded red on the plot and counted in the
   line beneath, and the log says how many. **Reference** chooses whose
   energy axis the average is built on.

   **Interpolation** is cubic spline
   (Igor's `Interpolate2 /I=3`) or linear, used only where a scan's
   energies differ from the grid.
   The table shows each scan's fitted edge step, which is how you spot a
   bad one.
8. **Analysis tab** — the normalized spectrum over its 1st and 2nd
   derivatives. **Find peaks** locates the maxima from the derivatives
   and sets edge A and edge B to the two strongest (on the V L2,3 test
   data it returns 515.73 and 522.84 eV, against the Cp2VCl2 procedure's
   515.74 and 522.88). **Compute areas** then integrates both edges and
   the continuum and reports white-line intensity and branching ratio.

   It works on output from either engine. The two ratios are ratios of
   areas, so switching between cm²/g and edge jump = 1 leaves them
   *exactly* unchanged. Switching engine changes them slightly, because a
   different background was removed — 0.4641 against 0.4626 on the real V
   data, 0.3% apart. The integrated areas themselves carry the units of
   whichever scale is in use. It analyses the average when one exists,
   otherwise the selected scan.

   Derivatives follow Igor's `derivPlot`, as the STXM fitting GUI does:
   **smoothing passes** of a binomial kernel, then differentiate, smooth,
   differentiate, smooth. Both derivatives are scaled to unit amplitude,
   since only their zero crossings and turning points matter. The
   smoothed curve is drawn over the measured points — if it stops
   following them, the smoothing is too heavy and the derivatives
   describe the filter rather than the data. (An earlier version used a
   single Savitzky-Golay pass; it left near-edge noise almost untouched
   and the second derivative oscillated hard enough to hide the
   transitions.) **Clear peaks** removes edge A and B and
   their markers; the markers are excluded from autoscaling, so a stale
   edge energy can no longer stretch the view.

10. **File ▸ Export every scan** opens a list rather than writing
    immediately. Each row can be unticked, renamed, and given its own
    format — text, CSV or Igor Text — and the extension always follows
    the format, so a file renamed `foo.csv` but set to Igor is written as
    `foo.itx`. It warns before overwriting and refuses if two rows would
    write to the same file.

12. **File ▸ Close session** empties the project so a new sample can be
    started without restarting the program.

    Every file dialog opens in the folder of the most recently imported
    file, since exports usually belong beside the data.

13. **File ▸ Export** — headers record the engine, both windows, and every
   engine-specific setting used.

Averaging across engines is detected: if included scans used different
engines or output scales, everything is rescaled to edge jump = 1 first
and the log says so.

**Help ▸ How the two engines differ** has the whole discussion in-app.

---

## 4. Building a Windows executable

    double-click build_windows.bat

See `BUILD.md`. The build driver creates its own environment, freezes the
app with `STXMNorm.spec`, and then **runs both self-tests on the
executable it just built**, refusing to call the build a success if
either fails. Result: `dist\STXMNorm.exe`, about 110 MB, no install
needed on the target machine.

That verification step earned its keep immediately. Two exclusions in the
first draft of the spec produced an executable that built perfectly and
crashed on startup; `BUILD.md` lists them and the rest of the traps.

## 5. Running it from source

```bash
pip install -r requirements.txt
python main.py
```

```bash
python main.py --self-test        # 10 numerical checks
python main.py --self-test-gui    # builds the whole interface and paints it
python main.py --version
```

The self-test covers both lineages and the claims made above:

```
  pass  linear models are recovered exactly
  pass  Legendre recurrence matches numpy
  pass  McMaster reproduces a tabulated edge jump
  pass  edge-step engine puts the post-edge at 1
  pass  the cosmetic pre-scale still cancels exactly
  pass  McMaster fit recovers known coefficients to machine precision
  pass  McMaster refuses a lanthanide M4,5 scan with an explanation
  pass  edge-step engine handles what McMaster cannot
  pass  the two engines agree on shape to within a few percent
  pass  window edges survive an engine toggle
```

Two of those are worth a note.

*"McMaster fit recovers known coefficients to machine precision"* is
norm2poly's own round-trip check. The background has to be **in the model
space** for it to be exact. A quadratic in energy is not: McMaster's
cross-section is exp(poly(log E)), so even a pure multiple of μ plus a
quadratic leaves a ~4e-4 residual. The invariant that actually holds is
that a signal built from the design matrix comes back with its
coefficients intact, at orders 1 through 4. (`n2p_compute` fits the
*unified* y, so the recovered coefficients are `c_true / span_y`, except
the constant term which also absorbs `-mid_y / span_y`. The test corrects
for this rather than papering over it.)

*"the cosmetic pre-scale still cancels exactly"* re-verifies XASNorm's
own claim through the new engine wrapper — 1e-12 on test data.

---

## 6. Layout

```
main.py                 entry point; --self-test, --self-test-gui, --version
BUILD.md                how to build the Windows executable
build_windows.bat       double-click build entry point
build_exe.py            build driver: venv, freeze, verify, diagnose
STXMNorm.spec          what to include, exclude and prune
stxmnorm/engines.py    the unification layer: UnifiedParams,
                        EngineResult, both engines, compare_engines
stxmnorm/core.py       edge-step arithmetic (from XASNorm, unchanged)
stxmnorm/mcmaster.py   McMaster tables + n2p_compute (from norm2poly,
                        numerically unchanged, split out of the GUI)
stxmnorm/dataio.py     loading, Project model, export, sessions
stxmnorm/edges.py      nominal edge table for seeding windows
stxmnorm/theme.py      light/dark
stxmnorm/app.py        PySide6 interface
stxmnorm/selftest.py   11 numerical checks, plus the GUI self-test
stxmnorm.ico           application icon
```

`engines.py` has no GUI dependency, so batch work is straightforward:

```python
from stxmnorm import engines, dataio

lc = dataio.load_columns("VL_S1.txt")
p = engines.UnifiedParams(engine="edgestep",
                          pre_lo=506, pre_hi=511.5,
                          post_lo=535, post_hi=558,
                          pre_model="linear", norm_energy=545)
r = engines.normalize(lc.column(0), lc.column(1), p)
print(r.report)

both = engines.compare_engines(lc.column(0), lc.column(1), p)
```

`compare_engines` returns an `EngineResult` per engine, or a string
explaining why that engine could not run — so a half-failure (common at
Ln M-edges) is data, not an exception.

---

## 7. Verification on real data

Run against five ratioed aXis2000 exports plus `Cp2VCl2_VL_Apr2012_NormData.txt`,
which is the **normalized output of the original Igor procedure** and
therefore a ground-truth target. See `real_data_check.png`.

### The reference file identifies itself

`Cp2VCl2_Mean` sits on exactly scan 66's energy grid — 203 points,
including both deglitching gaps (517.864 → 518.168 and 525.464 →
525.768). So 66 is `Cp2VCl2_S1` and the mean was placed on its axis. The
column picker reads the file's reversed column order (`Cp2VCl2_Mean`,
`Cp2VCl2_S1_eV`) correctly without being told.

### What normalization Igor used

Regressing the reference on `(y, 1, E)` gives a residual of 3.6e-2
against a signal scatter of 1.39 — 2.6%. So the reference **is** a linear
pre-edge removal followed by a single scale factor, to within the noise
reduction you would expect from averaging several scans. The implied
pre-edge line is `0.7912 − 1.0746e−3·E`, which brackets the
least-squares lines over 505–512 and 505–512.75. Implied edge step
0.0808.

This settles a puzzle: with a *flat* baseline both V scans give
peak/step ≈ 12.6, but the reference says 7.33. The whole factor of 1.7 is
the pre-edge **slope**, extrapolated 32 eV across the edge.

### Reproduction, and a caution about the original recipe

Igor's recipe (linear pre-edge over 505–512.75, linear post-edge,
single-point normalization) reproduces the reference shape to a
correlation of **0.99962**, with the post-edge landing at 0.9929 against
the reference's 0.9923. Peak positions match: L3 515.7 eV, L2 522.9 eV —
the `Cp2VCl2_S1_L3max=515.74` / `L2max=522.88` constants in your Igor
file.

But the amplitude is unstable, and the program says so unprompted:

```
S1_66: pre-edge: evaluated 32.2 eV outside a 7.8 eV fit window (4.2x extrapolation)
edge steps vary by 13.7% across scans (median 0.06723, S1_66 is 0.07641);
check the pre-edge model and windows before averaging
```

Scans 66 and 69 are repeats of the same compound, so they must agree.
They do not, under a linear pre-edge:

| pre-edge model | window | peak 66 | peak 69 | repeats disagree by |
|---|---|---|---|---|
| linear | 505–511 | 6.23 | 7.01 | 11.8% |
| linear | 505–512.75 | 7.60 | 8.37 | 9.6% |
| linear | 506–512.75 | 7.98 | 8.03 | 0.7% |
| linear | 505–513 | 8.64 | 9.25 | 6.8% |
| **Victoreen** | **505–512.75** | **6.70** | **6.87** | **2.4%** |
| Victoreen | 505–511 | 6.67 | 6.83 | 2.4% |
| Victoreen | 506–512.75 | 6.71 | 6.89 | 2.6% |
| Victoreen | 505–513 | 6.72 | 6.88 | 2.3% |
| quadratic | any | ~1.0 | ~1.0 | extrapolation collapses |

A linear pre-edge over a 7.8 eV window extrapolated 32 eV swings the L3
peak from 6.2 to 9.2 — a 48% range — depending on where you put the
window by a couple of eV. **Victoreen gives 6.7–6.9 across every window
tried, with repeats agreeing to 2.4%.** It lands about 7% below Igor's
7.33, which is what you would expect: the linear extrapolation slightly
over-subtracts, inflating the step... and inflating the peak.

If you want to reproduce old numbers, use the linear pre-edge and the
exact window. If you want a number that does not move when you nudge the
window, use Victoreen. Panels (a) and (b) of `real_data_check.png` show
the difference.

### C K-edge — a second Igor reference

`Cp2VCl2_CK_Apr2012_NormData.txt` (`Cp2VCl2_Norm_Avg_L`) sits on exactly
scan 11's grid — 273 points, including the gaps at 281.47→281.61 and
287.35→287.49. Its post-edge is *not* flat at 1: it decays from 1.25 at
298 eV to 0.31 at 379.5 eV, so no flattening was applied, and it crosses
1.0 at about 295 eV.

Unlike the V file, this one cannot be reproduced exactly, and the reason
is worth stating precisely rather than tuning around.

The regression test that identified the V model gives a 10% residual here
for **every** one of the three scans (11: 10.2%, 53: 10.0%, 57: 10.6%) —
and that test already allows any linear baseline and any scale, so no
linear pre-edge normalization of any supplied scan is the reference.
Regressing on all three at once plus a free baseline — five free
parameters — still leaves 9.3%. The weights come out positive and
near-equal (1.09, 1.18, 0.94), which says the reference *is* an average
of this kind of data; there are simply regions in it that were not
supplied.

A normalization-free check confirms it. The ratio I(286.9)/I(298), which
is independent of thickness and of the edge step entirely, is 0.795 in
all three scans but 0.747 in the reference. A positive-weighted average
cannot fall below the minimum of its members, so the average contains
regions with lower ratios than any of these three.

What does agree is everything that should:

- π* peak energy 284.41 eV in the reference and in scans 11 and 57
  (284.48 in scan 53, one grid point away)
- reference pre-edge over 262–282 eV sits at −0.0014
- our three-scan mean against the reference: **correlation 0.991**,
  rms 0.056 on a signal spanning 0 to 1.25, π* 0.513 vs 0.499

Right panel of `igor_reference_check.png`. Recipe: Victoreen pre-edge
260–283 eV, quadratic post-edge 310–379.5 eV, normalized at 300 eV.

### C K-edge, repeat consistency

Scans 11, 53 and 57 normalize cleanly with a Victoreen pre-edge over
262–282 eV, post-edge 310–379 eV, normalized at 320 eV. Pre-edges sit on
zero, post-edges on one, and the near-edge structure overlays — panel (d).

Residual amplitude differences of 15–18% at the 285 eV π* are **not** a
normalization artefact. Thickness-free fingerprint ratios computed
straight from the raw data, before any normalization, differ by the same
amount:

| scan | raw pre-edge OD | I(285)/I(288.5) | I(285)/I(292) |
|---|---|---|---|
| 11 | 0.315 | 0.428 | 0.339 |
| 53 | 0.290 | 0.462 | 0.343 |
| 57 | 0.205 | 0.491 | 0.373 |

Those ratios are independent of thickness and of the normalization
entirely, so the three OD selections are genuinely different carbon
speciation, and are not expected to normalize onto each other.

### Two guards added as a result

Carbon exposed a failure mode the synthetic tests could not. McMaster
puts the C K edge at **295.0 eV**; the real one is at 284.2 eV, and the
steepest rise in scan 11 is at 287.2 eV. The McMaster engine fits the
*amplitude* of a template whose step position is fixed by the table, so a
step 8 eV out of place gets fitted against a flat region while the
polynomial absorbs the difference — and it would have returned a
confident, wrong answer. It now refuses:

```
McMaster puts the C K edge at 295.0 eV, but the steepest rise in this
scan is at 287.2 eV -- 7.8 eV away. ... Use the edge-step engine, which
takes the edge position from your data.
```

`mcmaster_edge_offset` finds the data's edge from the steepest rise of a
lightly smoothed spectrum resampled onto a uniform grid (these files have
several step sizes, so the raw derivative is biased). It refuses above
5 eV displacement and warns above 1.5 eV. On V it warns (tabulated L3
512.1 eV vs measured rise 515.2 eV) and proceeds.

`mcmaster_placeholder_floor` reports the all-zero `post_M` block
described in §2 for the 29 affected elements (H–Cu).

## 8. Fidelity to the MATLAB originals

Checked against `element.mat`, `McMaster.m`, `zymbol.m`, `legpoly.m`,
`unify.m` and `norm2poly.m`. Three self-tests keep it that way.

| | result |
|---|---|
| `element.mat` table | **4042 numbers across 94 elements, exact match** |
| `McMaster.m` | identical to floating point (max rel. diff 4.6e-16) over 35 000 energies, 87 elements, including exactly on the edge boundaries and through the L-jump divisions; both `cm²/g` and `barns/atom` |
| `zymbol.m` | all 109 symbols round-trip, case-insensitive as in MATLAB |
| `legpoly.m` | coefficients bit-identical, orders 0–12 |
| `unify.m` | bit-identical, including passing a constant column through untouched |
| `norm2poly.m` | bit-identical **when window boundaries fall on measured points**; see below |

Two deliberate departures, both found by this comparison.

**Window selection.** `norm2poly.m` picks its windows by index arithmetic
rather than by a mask:

```matlab
pre1 = length(x(x<=pre_edge1));   x_1 = x(pre1:pre2);
```

`pre1` is the index of the last point *at or below* the boundary, so when
a boundary falls between samples the fit silently includes one point from
outside the window. On the C K-edge data with the post-edge window
starting at 299.3 eV that is 55 points rather than 54, and it moves the
normalized result by **1.6%**. The window is used as written here. Pass
`matlab_edges=True` to `n2p_compute` to reproduce the MATLAB exactly —
verified bit-identical at orders 1, 2 and 3.

**The reference curve.** `norm2poly.m` picks the sub-edge points by
cross-section, `mu < mu(end)`, which assumes exactly one edge in the
scan. That is fine for a K edge — it agrees with splitting on the
pre-edge window to about 0.03% — but on a V L2,3 scan over 505–560 eV the
L3 plateau (~20500 cm²/g) lies below the L2 tail at the last point
(~23800), so the test swallows the whole L3 region as pre-edge and fits
the baseline across the edge. norm2poly is a K-edge program; its default
windows are `K_edge ± 20/80 eV`, so this never arose there. The pre-edge
window is used instead, which is correct at both K and L edges.

### The Igor procedures

Checked against `Branson_Unified_Normalization_Procedure.ipf` and the two
`Cp2VCl2_STXM_Apr12_VL` files, transcribed and compared numerically.

Confirmed identical: Victoreen is `A·E⁻³ + B·E⁻⁴`; Igor's `CurveFit
poly 3` is a **quadratic** (three coefficients), which is what
`quadratic` means here; the post-edge is a line fitted to the
*pre-subtracted* residual and evaluated over the whole wave; the mask
excludes points from the post-edge fit only. The Cp2VCl2 route is
`sPointNorm` → linear pre-edge → linear post-edge, and its initial
single-point scaling cancels, as documented in §1.

Two departures found, both now settled:

**The Victoreen fit is unconstrained in Igor.** `FuncFit Victoreen` puts
no bound on B. This program used to constrain the coefficients to be
non-negative by default, on the reasoning that a negative B sends
`A/E³ + B/E⁴` negative at low energy. On the real V L-edge data the fit
wants B ≈ −3.6×10⁹ and **still stays positive across the whole scan**, so
the constraint prevented nothing and moved the edge step by **2.1%**
(0.0873 against Igor's 0.0854). The default is now unconstrained, matching
Igor. The constraint is still available, and the fit is now checked for
going negative over the range it is actually used on — which is the case
the constraint was meant to guard.

The constraint is not simply off, though: it is off *unless Igor's own
answer is unusable*. An unconstrained `A/E³ + B/E⁴` with B < 0 is
`(A·E − |B|)/E⁴`, which can **rise** with energy — an absorption
background that increases. On a 1110–1233 eV scan with an 11.5 eV
pre-edge window that gave B = −1.3×10¹², a background rising from 0.2044
to 0.2121, an edge step of −0.040, and a normalized spectrum entirely
upside down. So when the edge step comes out negative with a Victoreen
pre-edge, the fit is redone with the coefficients constrained, and the
report says so. Setting **Pre-edge model** and the constraint explicitly
still overrides this. A wider pre-edge window is the real fix in that
situation — an 11.5 eV window extrapolated 109 eV is a 9.5× reach.

Both behaviours are exposed in **Edge-step settings**:

- **Pre-edge constraint** — *Auto* (the default: Igor's unconstrained fit,
  refitted with a constraint only if the edge step comes out negative),
  *Never (as Igor Pro)*, or *Always non-negative*.
- **Strict Igor Pro compatibility** — forces *Never* together with the
  grid-snapped edge step below, and disables both so it is visible what
  is being applied. Use it to reproduce old results; it will hand you an
  inverted spectrum in the cases where Igor does, which is the point.

**Igor reads the edge step at a grid point.** `normalizeSpectrum()`
divides by `postFit[energy2index(eV, normEnergy)]` — the first *measured
point* at or above the normalization energy — rather than evaluating the
fit there. `sPointNormToLineFitNP()` does the same. Worth 0.01% on the V
data and 0.17% on the coarser C K-edge grid. The default here evaluates
the fit analytically, because snapping ties the answer to the sampling:
scans 66 and 69 have different grids, so Igor normalizes them at slightly
different energies before averaging them together. Pass
`snap_norm_energy=True`, or tick **Read edge step at a measured point**,
to reproduce Igor exactly — verified to 2×10⁻¹⁴ on both files.

## 9. Limits and caveats

- Verified against one Igor reference output (V L2,3) and five ratioed
  aXis2000 exports; see §6. No Ln M-edge real data has been through it
  yet, so that path is still only synthetically tested.
- Reads column text. No HDF5, no `.ncb`/`.xim` stacks, no aXis2000
  binaries — export to text first.
- 1-D spectra, not image stacks.
- Peak fitting is not carried over.
- The McMaster engine inherits norm2poly's `_FIX_URANIUM` quirk:
  `element.mat` stores `post_L[1] = -207237` for uranium where Th and Pu
  sit near −2.1, almost certainly a misplaced decimal. It is reproduced
  as stored. U is unusable under McMaster at STXM energies anyway.
- The edge table (`edges.py`) is nominal binding energies for seeding
  windows only. Not calibration standards, no chemical shift. Calibrate
  against your own measured reference.
