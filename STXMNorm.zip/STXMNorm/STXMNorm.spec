# -*- mode: python ; coding: utf-8 -*-
"""
STXMNorm.spec -- PyInstaller build for the STXMNorm GUI.

    pyinstaller STXMNorm.spec

or, preferably, let build_exe.py drive it:

    python build_exe.py

Everything cut here is something the program never touches. The numerics
are left alone: numpy, scipy, their BLAS/LAPACK kernels and the whole
McMaster table stay exactly as they are, because that is where the
arithmetic lives and none of it is negotiable.

PySide6 is the reason this build is large. Qt ships a web engine, a QML
runtime, a 3D renderer, multimedia, charts and a SQL layer, and
PyInstaller collects the lot by association. Excluding them roughly
halves the executable. What must NOT be cut is the Qt platform plugin
(qwindows.dll), the style plugin, the image-format plugins used for
toolbar icons, and opengl32sw.dll -- the software OpenGL fallback that
some remote-desktop and VM sessions depend on.

After any change here, rebuild and run BOTH self-tests:

    STXMNorm.exe --self-test        the arithmetic
    STXMNorm.exe --self-test-gui    the interface

The second is the one that catches over-pruning: a missing plugin, font
or icon fails when a window paints and nowhere else.
"""

import importlib.util
import os

APPNAME = "STXMNorm"
SOURCE = "main.py"

# Onedir by default. A onefile build unpacks the whole 110 MB payload to
# a temp directory on every single launch, measured at 2.0 s against
# 0.25 s for the folder -- paid every time the program is opened. The
# folder is the smoother thing to use; onefile is the tidier thing to
# hand someone. Flip this, or pass --onefile / --onedir to build_exe.py,
# which sets STXMNORM_ONEFILE below.
ONEFILE = False
_env = os.environ.get("STXMNORM_ONEFILE")
if _env is not None:
    ONEFILE = _env.strip().lower() in ("1", "true", "yes", "on")

CONSOLE = False    # True temporarily if you need to see a traceback
AGGRESSIVE = True  # binary/data pruning below; False for a bigger, safer build


# ---------------------------------------------------------------- modules
EXCLUDES = [
    # other GUI toolkits, dragged in by matplotlib's backend list
    "tkinter", "PyQt5", "PyQt6", "PySide2", "wx", "gi", "kivy",
    "matplotlib.backends.backend_wx",
    "matplotlib.backends.backend_webagg",
    "matplotlib.backends.backend_nbagg",
    "matplotlib.backends.backend_gtk3",
    "matplotlib.backends.backend_gtk4",
    "matplotlib.backends.backend_tkagg",
    "matplotlib.backends.backend_tkcairo",

    # Qt subsystems a 2-D plotting GUI never opens
    "PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets",
    "PySide6.QtWebEngineQuick", "PySide6.QtWebChannel", "PySide6.QtWebSockets",
    "PySide6.QtQuick", "PySide6.QtQuick3D", "PySide6.QtQuickWidgets",
    "PySide6.QtQml", "PySide6.QtQmlModels",
    "PySide6.Qt3DCore", "PySide6.Qt3DRender", "PySide6.Qt3DInput",
    "PySide6.Qt3DLogic", "PySide6.Qt3DAnimation", "PySide6.Qt3DExtras",
    "PySide6.QtMultimedia", "PySide6.QtMultimediaWidgets",
    "PySide6.QtCharts", "PySide6.QtDataVisualization", "PySide6.QtGraphs",
    "PySide6.QtBluetooth", "PySide6.QtNfc", "PySide6.QtPositioning",
    "PySide6.QtSensors", "PySide6.QtSerialPort", "PySide6.QtSerialBus",
    "PySide6.QtTest", "PySide6.QtSql", "PySide6.QtHelp",
    "PySide6.QtDesigner", "PySide6.QtUiTools",
    "PySide6.QtPdf", "PySide6.QtPdfWidgets",
    "PySide6.QtSpatialAudio", "PySide6.QtTextToSpeech",
    "PySide6.QtRemoteObjects", "PySide6.QtScxml", "PySide6.QtStateMachine",
    "PySide6.QtHttpServer", "PySide6.QtNetworkAuth",

    # notebook / dev / test machinery
    "IPython", "jupyter", "notebook", "tornado", "pytest", "nose",
    "lib2to3",

    # data stacks we do not use
    "pandas", "sympy", "PIL.ImageQt", "PIL.ImageShow", "PIL.ImageTk",

    # NOTE: do NOT exclude 'unittest' or 'doctest'. pyparsing, which
    # matplotlib needs, imports unittest at import time.
    #
    # NOTE: do NOT exclude ANY 'numpy.*' submodule -- not testing, not
    # f2py, not distutils. They look like dead weight, but
    # scipy._lib.array_api_compat.numpy clones numpy's namespace at import
    # and walks its submodules while doing it, so excluding any of them
    # makes `from scipy.interpolate import CubicSpline` fail at startup
    # with ModuleNotFoundError. The build succeeds; the executable does
    # not run. This is exactly what --self-test is for.
    #
    # NOTE: do NOT exclude 'setuptools', 'pkg_resources' or 'distutils'
    # here. PyInstaller's own hooks import them during the build.
    #
    # NOTE: do NOT exclude 'ssl', '_hashlib' or 'sqlite3' even though this
    # program never opens a socket or a database. Unlike the tkinter build
    # they were pruned from, Qt's network stack links against them and
    # QtNetwork is a dependency of the platform plugin on some Qt builds.
    # Removing them trades a couple of MB for a class of failure that only
    # shows up on the end user's machine.
]


# PyInstaller's static analysis misses things scipy and matplotlib import
# dynamically. Private submodule paths move between releases, so each
# name is checked before being passed on -- a stale entry otherwise
# prints an alarming "Hidden import not found" that has nothing to do
# with whether the build succeeded.
def _present(names):
    keep = []
    for name in names:
        try:
            if importlib.util.find_spec(name) is not None:
                keep.append(name)
        except (ImportError, ValueError, AttributeError):
            pass
    return keep


HIDDEN = _present([
    "matplotlib.backends.backend_qtagg",
    "matplotlib.backends.backend_agg",
    "scipy.optimize",
    "scipy.optimize._nnls",
    "scipy.interpolate",
    "scipy.signal",
    "stxmnorm.app",
    "stxmnorm.core",
    "stxmnorm.dataio",
    "stxmnorm.edges",
    "stxmnorm.engines",
    "stxmnorm.mcmaster",
    "stxmnorm.selftest",
    "stxmnorm.theme",
])


# ------------------------------------------------------- binaries to drop
# The Qt6*.dll files matching the excluded modules above. Excluding a
# Python module stops the import but does not stop PyInstaller collecting
# the DLL it would have loaded, so they are named again here.
DROP_BINARIES = [
    "qt6webengine", "qt6webchannel", "qt6websockets", "qt6webview",
    "qt6quick", "qt6qml", "qt6qmlmodels", "qt6qmlworkerscript",
    "qt63d", "qt6multimedia", "qt6charts", "qt6datavisualization",
    "qt6graphs", "qt6bluetooth", "qt6nfc", "qt6positioning",
    "qt6sensors", "qt6serialport", "qt6serialbus", "qt6test",
    "qt6sql", "qt6help", "qt6designer", "qt6uitools",
    "qt6pdf", "qt6spatialaudio", "qt6texttospeech",
    "qt6remoteobjects", "qt6scxml", "qt6statemachine",
    "qt6httpserver", "qt6networkauth",
    "qtwebengineprocess", "icudtl.dat",
    # Pillow's lazily imported codec plugins: it wraps each import in
    # try/except ImportError, so their absence costs only those formats.
    # libtiff, libjpeg, libopenjp2, liblcms2, libfreetype and libharfbuzz
    # are NOT here -- they are linked into PIL._imaging and removing them
    # stops Pillow, and therefore matplotlib, importing at all.
    "_avif", "libavif", "libaom", "libdav1d", "librav1e", "libsvtav1",
    "libyuv", "_webp", "libwebp", "libsharpyuv",
]

# Things that look prunable and are not, recorded so nobody adds them:
#   Qt6Core, Qt6Gui, Qt6Widgets     the application
#   Qt6Network, Qt6OpenGL, Qt6DBus  linked by the above or by plugins
#   opengl32sw.dll    software OpenGL; remote desktop and VMs need it
#   d3dcompiler_*.dll ANGLE's shader compiler, used by the same fallback
#   platforms/qwindows.dll          without it Qt aborts at startup
#   styles/, imageformats/          window chrome and toolbar icons

# ---------------------------------------------------------- data to drop
DROP_DATA = [
    "mpl-data/sample_data",        # example images and csvs
    "mpl-data/fonts/afm",          # PostScript metrics, for ps output
    "mpl-data/fonts/pdfcorefonts",
    "pyside6/qml",                 # the whole QML module tree
    "pyside6/translations",        # Qt UI translations; the app is English
    "pyside6/examples",
    "/tests/", "/testing/",
]

# The app renders DejaVu Sans only, so the maths font families and the
# serif/mono variants can go.
DROP_FONTS = ["cmb10", "cmex10", "cmmi10", "cmr10", "cmss10", "cmsy10",
              "cmtt10", "stix", "dejavuserif", "dejavusansmono",
              "dejavusansdisplay", "dejavuserifdisplay"]


def _norm(p):
    return str(p).replace("\\", "/").lower()


def prune(entries, patterns, label):
    kept, dropped, saved = [], 0, 0
    for entry in entries:
        dest, src = entry[0], entry[1]
        n = _norm(dest)
        hit = any(p in n for p in patterns)
        if not hit and "mpl-data/fonts/ttf" in n:
            hit = any(f in n for f in DROP_FONTS)
        # matplotlib's toolbar icons ship as png + pdf + svg; only the
        # png versions are ever loaded
        if not hit and "mpl-data/images" in n and not n.endswith(".png"):
            hit = True
        if hit:
            dropped += 1
            try:
                saved += os.path.getsize(src)
            except (OSError, TypeError):
                pass
        else:
            kept.append(entry)
    print("  pruned %d %s entries, %.1f MB before compression"
          % (dropped, label, saved / 1048576.0))
    return kept


_kw = dict(
    pathex=[],
    binaries=[],
    datas=([("stxmnorm.ico", ".")] if os.path.exists("stxmnorm.ico") else []),
    hiddenimports=HIDDEN,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=EXCLUDES,
    noarchive=False,
)

# optimize= strips docstrings and asserts from the bytecode, but it only
# exists in PyInstaller 6.7 and newer. On anything older, build without
# it rather than dying with a TypeError.
try:
    a = Analysis([SOURCE], optimize=2, **_kw)
except TypeError:
    print("  note: this PyInstaller has no optimize= option, carrying on")
    a = Analysis([SOURCE], **_kw)

if AGGRESSIVE:
    print("--- STXMNorm.spec: pruning ---")
    a.binaries = prune(a.binaries, DROP_BINARIES, "binary")
    a.datas = prune(a.datas, DROP_DATA, "data")
else:
    print("--- STXMNorm.spec: AGGRESSIVE = False, nothing pruned ---")

pyz = PYZ(a.pure)

_exe_kw = dict(
    name=APPNAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,           # see BUILD.md: saves ~0.1%, upsets antivirus
    upx_exclude=[],
    console=CONSOLE,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="stxmnorm.ico",   # multi-resolution, 256 down to 16 px
)

if ONEFILE:
    exe = EXE(pyz, a.scripts, a.binaries, a.datas, [],
              runtime_tmpdir=None, **_exe_kw)
else:
    exe = EXE(pyz, a.scripts, [], exclude_binaries=True, **_exe_kw)
    coll = COLLECT(exe, a.binaries, a.datas,
                   strip=False, upx=False, upx_exclude=[], name=APPNAME)
