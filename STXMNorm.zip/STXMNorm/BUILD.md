# Building STXMNorm.exe

PyInstaller does not cross-compile. **A Windows executable must be built
on Windows.** The same files build a native binary on Linux or macOS if
you want one.

## Quick version

1. Install Python from python.org, ticking **"Add python.exe to PATH"**
   in the installer. 3.10 through 3.14 all work; 3.14 has been built and
   tested on Windows 10.
2. Put the project folder somewhere short, like `C:\STXMNorm`.
3. Double-click **`build_windows.bat`**.

Five to fifteen minutes later you get **`dist\STXMNorm\STXMNorm.exe`**,
which runs on any 64-bit Windows 10/11 machine with nothing installed.
Hand the whole `dist\STXMNorm` folder over, zipped, to give it to
someone else.

The batch file only finds a Python and hands over to `build_exe.py`,
which does the real work. Everything it does goes into `build_log.txt`.

## What the build does

`build_exe.py`:

1. Creates a private environment in `.venv-build` and installs numpy,
   scipy, matplotlib, PySide6 and PyInstaller into it. Nothing is added
   to your system Python.
2. Deletes stale `build/` and `dist/` directories — the most common
   source of confusing failures.
3. Runs PyInstaller against `STXMNorm.spec`.
4. **Runs both self-tests on the executable it just built** and refuses
   to call the build a success if either fails.
5. On a spec failure, retries with plain flags to at least get you a
   working (larger) executable.

Step 4 is not decoration. Two of the exclusions in the first draft of
`STXMNorm.spec` produced an executable that built perfectly and then
crashed on startup. See "Traps" below.

## Options

Edit the variables at the top of `build_windows.bat`, or pass the flags
directly to `build_exe.py`:

| flag | effect |
|---|---|
| `--debug` | console build, so a crash shows its traceback |
| `--onedir` | a folder that starts instantly (**the default**) |
| `--onefile` | one portable .exe, ~110 MB, ~1.8 s slower to start |
| `--no-venv` | build with the current Python instead of `.venv-build` |
| `--plain` | ignore the spec, use plain flags |
| `--no-test` | skip the post-build self-tests |

`--debug` cannot override the spec. For a console build through the spec,
set `CONSOLE = True` in `STXMNorm.spec`.

**Onedir is the default, on purpose.** A onefile build unpacks its whole
payload to a temp directory on *every single launch*. Measured here:

| build | startup | on disk |
|---|---|---|
| onedir | **0.25 s** | 300 MB folder |
| onefile | 2.01 s | 110 MB single file |

Two seconds every time you open the program, against a folder instead of
a file. If you would rather have the single file — it is tidier to email,
and the 110 MB compresses better — use `--onefile`, or set
`ONEFILE = True` in the spec. `build_exe.py` passes the choice to the
spec through `STXMNORM_ONEFILE`, so the flags work either way.

## Verifying a build

```
STXMNorm.exe --self-test        the arithmetic: 10 numerical checks
STXMNorm.exe --self-test-gui    the interface: builds it and paints it
```

The first exits non-zero if the maths stops matching. The second is the
one that catches an over-pruned build: it constructs the main window,
loads two synthetic scans, normalizes them with **both** engines, renders
all four tabs, exercises the span selector, exports an average, and
forces a real paint. A missing Qt platform plugin, font or toolbar icon
fails there and nowhere else.

Because a `--windowed` build has no console, the GUI test also writes
`stxmnorm_guitest.log` next to the executable.

On a Linux machine with no display the GUI test falls back to Qt's
offscreen plugin and says so. **That fallback is deliberately Linux-only.**
On Windows, failure to load the native plugin means `qwindows.dll` is
missing from the build, which is precisely the fault the test exists to
catch, so it stays fatal there.

## What the spec prunes, and what it must not

`STXMNorm.spec` cuts about 32 MB before compression: 26 MB of binaries
and 6 MB of data. Set `AGGRESSIVE = False` to disable all of it if you
suspect the pruning has broken something.

**Cut:** Qt's web engine, QML runtime, 3D renderer, multimedia, charts,
SQL, PDF, Bluetooth, sensors and serial port; matplotlib's sample data,
PostScript font metrics, maths font families and non-PNG toolbar icons;
Pillow's AVIF and WebP codec plugins; Qt translations.

**Must stay, and why:**

| kept | reason |
|---|---|
| `platforms/qwindows.dll` | without it Qt aborts at startup |
| `styles/`, `imageformats/` | window chrome and toolbar icons |
| `opengl32sw.dll` | software OpenGL; remote desktop and VMs need it |
| `d3dcompiler_*.dll` | ANGLE's shader compiler, same fallback path |
| `Qt6Network`, `Qt6DBus`, `Qt6OpenGL` | linked by Qt6Gui or by plugins |
| `ssl`, `_hashlib`, `sqlite3` | Qt's network stack links them even though this program never opens a socket |
| `libtiff`, `libjpeg`, `libfreetype`, `libharfbuzz` | linked into `PIL._imaging`; removing them stops matplotlib importing at all |
| `unittest`, `doctest` | pyparsing, which matplotlib needs, imports unittest at import time |
| numpy, scipy, OpenBLAS, the McMaster table | the arithmetic. Never touch these |

## Traps

These all cost a build cycle to find. They are listed so they cost you
nothing.

**Do not exclude any `numpy.*` submodule.** Not `numpy.testing`, not
`numpy.f2py`, not `numpy.distutils`. They look like obvious dead weight
in a frozen application. But `scipy._lib.array_api_compat.numpy` clones
numpy's namespace at import and walks its submodules while doing it, so
excluding any of them makes `from scipy.interpolate import CubicSpline`
fail at startup with `ModuleNotFoundError`. The build succeeds and the
executable does not run.

**Do not exclude `distutils`, `setuptools` or `pkg_resources`.**
PyInstaller's own hooks import them during the build, and excluding them
kills the build with:

```
ValueError: Target module "distutils" already imported as
ExcludedModule('distutils',)
```

**A failed spec build used to eat the spec.** When PyInstaller is invoked
as `pyinstaller --name STXMNorm main.py`, it writes its own
`STXMNorm.spec` into the working directory, overwriting yours. The old
fallback path did exactly that, replacing a carefully commented spec with
a 44-line default and destroying the error message that explained why the
spec build failed in the first place. `build_exe.py` now passes
`--specpath` to a temporary directory for any plain build, and separately
keeps a byte-for-byte copy of the spec and restores it if anything
modifies it.

**UPX is off on purpose.** It saves a fraction of a percent on a build
this size — most of the bulk is already-compressed Qt libraries — and
UPX-packed executables are a reliable way to get flagged by antivirus
software. Not worth it.

**A build can fail on console encoding alone.** The Windows console is
cp1252, which has no subscript zero, and one `I₀` in a status line was
enough to raise `UnicodeEncodeError` and fail a build in which every test
had passed — the UTF-8 log file held the line correctly; only the `print`
died. Both suites now reconfigure stdout to UTF-8 where they can and fall
back to a replaced character where they cannot, so reporting can never
fail a run. If you add output of your own, use `selftest._emit` rather
than `print`.

**"Hidden import not found" warnings are usually harmless.** The spec
checks each hidden import with `importlib.util.find_spec` before passing
it on, so its own list is clean. The warnings you still see come from
PyInstaller's bundled scipy and numpy hooks naming private submodules
that moved between releases. They do not indicate a failed build — the
self-tests tell you that.

## If it fails

`build_exe.py` prints the last 30 lines of `build_log.txt` and names the
most likely cause. It recognises: a running copy of the exe holding the
file, an over-excluded module, a missing Qt platform plugin, a
too-long path, a full disk, a Python too new for the wheels, and a
half-built `.venv-build`.

Things worth trying, in order:

1. Close any running `STXMNorm.exe`, then build again.
2. Delete `.venv-build`, `build` and `dist`, then build again.
3. Move the folder to `C:\STXMNorm` — deep paths break PyInstaller.
4. Set `AGGRESSIVE = False` in the spec.
5. Build with `--debug` and run the exe from a command prompt to see the
   traceback.
6. Add the project folder to your antivirus exclusions. Real-time
   scanners intercept PyInstaller's temp files and produce errors that
   look like permission problems.

## Icon

`stxmnorm.ico` holds six sizes from 256 down to 16 px. The spec points
`icon=` at it for the executable and bundles it as a data file so the
window and taskbar icon work too. Replace the file to change it; nothing
else needs editing.

## Antivirus

Unsigned PyInstaller executables are frequently flagged, because malware
authors use PyInstaller too. Nothing about your build is wrong. If you
are distributing this to colleagues, either hand over the `--onedir`
folder in a zip, or buy a code-signing certificate. Submitting a false
positive to your vendor also works, slowly.

## Performance notes

Three things in the application itself were changed for the same reason,
and they matter more than the packaging:

- **scipy is imported lazily.** It costs ~0.7 s to import, more than
  numpy, matplotlib and PySide6 combined, and none of the three things
  this program uses it for is on the path a normalization takes. It is
  now imported where it is used, and warmed in the background 50 ms after
  the window appears, so the first normalization does not stall.
- **The plot layout is solved once, not on every draw.**
  `constrained_layout` re-solves margins on each redraw (~60 ms); it is
  now frozen after the first draw and re-solved only when a label
  changes.
- **Redraws keep the axes configuration.** `ax.clear()` also resets the
  tick locators, so `minorticks_on()` had to run again every time
  (~100 ms for two panels). Artists are removed individually instead.
  A side effect worth having: your zoom now survives a parameter change.

Together: the Normalization tab redraws in **66 ms instead of 471 ms**.
Parameter changes are also coalesced, so holding an arrow key on a spin
box does one recompute when it settles rather than one per keystroke.

## Files

```
build_windows.bat   double-click entry point; finds Python, calls build_exe.py
build_exe.py        the real build driver: venv, build, verify, diagnose
STXMNorm.spec      what to include, exclude and prune
requirements.txt    runtime dependencies
stxmnorm.ico       application icon, 256/128/64/48/32/16 px
build_log.txt       written on every run
```
