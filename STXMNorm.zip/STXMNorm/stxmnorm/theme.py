"""
theme.py -- light and dark appearance for XASNorm.

Three things have to change together or the result is unreadable:

1. Qt widget chrome (windows, tables, docks, dialogs).
2. Matplotlib canvases, which default to a white figure with black text
   and would otherwise sit on the dark window as a glaring white slab.
3. The data colours themselves. A curve at #111111 is invisible on a dark
   axis, and the mid-tone scan colours chosen for white lose contrast.
   Each theme therefore carries its own cycle rather than the palette
   being a filter applied to one fixed set.

Modules ask for colours through ``theme.T`` at draw time, never by
importing a colour constant, so switching themes and redrawing is enough.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Theme:
    name: str
    dark: bool

    # --- window chrome ---
    bg: str              # window background
    surface: str         # inputs, tables, text areas
    surface_alt: str     # alternating rows, headers
    border: str
    text: str
    text_dim: str        # secondary labels, placeholder plot text
    accent: str          # selection
    accent_text: str

    # --- semantic status ---
    ok: str
    warn: str
    error: str
    note_bg: str         # callout background (edge-table disclaimer)
    note_fg: str

    # --- plot surfaces ---
    fig_bg: str
    ax_bg: str
    axis: str            # spines and ticks
    guide: str           # zero/unity reference lines

    # --- normalization curves ---
    data: str
    pre: str
    post: str
    sub: str
    norm: str
    excl: str
    band: str            # window shading, s.e.m. band

    # --- derivative / peak-fit curves ---
    deriv1: str
    deriv2: str
    residual: str
    edge_a: str
    edge_b: str

    scan_cycle: tuple[str, ...] = field(default=())
    peak_cycle: tuple[str, ...] = field(default=())

    def scan_color(self, i: int) -> str:
        return self.scan_cycle[i % len(self.scan_cycle)]

    def peak_color(self, i: int) -> str:
        return self.peak_cycle[i % len(self.peak_cycle)]


LIGHT = Theme(
    name="light", dark=False,
    bg="#f0f0f0", surface="#ffffff", surface_alt="#f6f6f6",
    border="#c4c4c4", text="#1a1a1a", text_dim="#888888",
    accent="#2874a6", accent_text="#ffffff",
    ok="#2e7d32", warn="#b8860b", error="#c0392b",
    note_bg="#fff6e0", note_fg="#8a5a00",
    fig_bg="#ffffff", ax_bg="#ffffff", axis="#1a1a1a", guide="#bbbbbb",
    data="#777777", pre="#e08214", post="#3b7dd8", sub="#2e8b3d",
    norm="#111111", excl="#d94f4f", band="#4a90d9",
    deriv1="#b8860b", deriv2="#c2185b", residual="#c0392b",
    edge_a="#1f4e79", edge_b="#c0392b",
    scan_cycle=("#1f4e79", "#2e8b3d", "#c0392b", "#7d3c98", "#b8860b",
                "#0e6b6b", "#c2185b", "#5d6d7e", "#8b4513", "#2874a6"),
    peak_cycle=("#2e8b3d", "#c0392b", "#7d3c98", "#b8860b", "#0e6b6b",
                "#c2185b", "#8b4513", "#2874a6"),
)

DARK = Theme(
    name="dark", dark=True,
    bg="#1e1f22", surface="#2b2d31", surface_alt="#26282c",
    border="#3f4247", text="#e8e8e8", text_dim="#9aa0a6",
    accent="#4a90d9", accent_text="#ffffff",
    ok="#6ec177", warn="#e0b341", error="#f2766b",
    note_bg="#3a3218", note_fg="#e8c06a",
    fig_bg="#1e1f22", ax_bg="#232528", axis="#c8ccd0", guide="#55595e",
    data="#9aa0a6", pre="#f0a04b", post="#6fa8dc", sub="#7fd18a",
    norm="#f2f2f2", excl="#f2766b", band="#6fa8dc",
    deriv1="#e8c06a", deriv2="#ef8bb8", residual="#f2766b",
    edge_a="#6fa8dc", edge_b="#f2766b",
    scan_cycle=("#6fa8dc", "#7fd18a", "#f2766b", "#c792ea", "#e8c06a",
                "#4dd0c4", "#ef8bb8", "#a8b4c0", "#d69b6a", "#64b5f6"),
    peak_cycle=("#7fd18a", "#f2766b", "#c792ea", "#e8c06a", "#4dd0c4",
                "#ef8bb8", "#d69b6a", "#6fa8dc"),
)

THEMES = {"light": LIGHT, "dark": DARK}

#: The active theme. Modules read colours from this at draw time.
T: Theme = LIGHT


def set_theme(name: str) -> Theme:
    global T
    T = THEMES.get(name, LIGHT)
    return T


def stylesheet(t: Theme) -> str:
    """Qt stylesheet for the dark theme -- deliberately minimal.

    Almost all colouring is done by the palette (see ``palette``). This
    only covers chrome that the palette cannot express: the tab
    underline, dock titles, header sections, scrollbar shape.

    The omissions matter. Setting any stylesheet rule on a widget class
    switches that class to stylesheet-based painting, and Qt then expects
    the stylesheet to draw every sub-control itself. A broad
    ``QWidget {{ background-color: ... }}`` rule therefore silently
    removes checkbox ticks, radio dots and combo-box arrows, because
    nothing was told to draw them. Styling sub-controls by hand with CSS
    borders renders inconsistently -- arrows come out as solid blocks --
    so widgets with sub-controls are left alone here and coloured through
    the palette instead.
    """
    if not t.dark:
        return ""
    return f"""
    QGroupBox {{
        border: 1px solid {t.border};
        border-radius: 4px;
        margin-top: 9px;
        padding-top: 6px;
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 8px;
        padding: 0 4px;
        color: {t.text_dim};
    }}

    QHeaderView::section {{
        background-color: {t.surface_alt};
        color: {t.text};
        border: none;
        border-right: 1px solid {t.border};
        border-bottom: 1px solid {t.border};
        padding: 4px;
    }}

    QTabWidget::pane {{ border: 1px solid {t.border}; top: -1px; }}
    QTabBar::tab {{
        background: {t.surface_alt};
        color: {t.text_dim};
        border: 1px solid {t.border};
        border-bottom: none;
        padding: 6px 14px;
    }}
    QTabBar::tab:selected {{
        background: {t.surface};
        color: {t.text};
        border-bottom: 2px solid {t.accent};
    }}
    QTabBar::tab:hover {{ color: {t.text}; }}

    QDockWidget::title {{
        background: {t.surface_alt};
        padding: 5px;
        border-bottom: 1px solid {t.border};
    }}

    QScrollBar:vertical {{ background: {t.bg}; border: none; width: 12px; }}
    QScrollBar:horizontal {{ background: {t.bg}; border: none; height: 12px; }}
    QScrollBar::handle {{
        background: {t.border};
        border-radius: 5px;
        min-height: 24px;
        min-width: 24px;
    }}
    QScrollBar::handle:hover {{ background: {t.text_dim}; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
    QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}

    QSplitter::handle {{ background: {t.border}; }}
    QStatusBar {{ background-color: {t.surface_alt}; color: {t.text_dim}; }}
    QStatusBar::item {{ border: none; }}
    """


def palette(t: Theme):
    """A QPalette for the Fusion style.

    Qt draws combo-box arrows, spin-box arrows, checkboxes and radio
    buttons itself, from palette roles. Recolouring those through a
    stylesheet means hand-drawing each one with CSS borders, which Qt
    renders inconsistently -- they come out as solid blocks. Setting the
    palette instead lets Fusion draw its normal controls in the right
    colours, which is both more reliable and more native-looking.
    """
    from PySide6.QtGui import QPalette, QColor

    p = QPalette()
    bg, surface, text, dim = (QColor(t.bg), QColor(t.surface),
                              QColor(t.text), QColor(t.text_dim))
    p.setColor(QPalette.Window, bg)
    p.setColor(QPalette.WindowText, text)
    p.setColor(QPalette.Base, surface)
    p.setColor(QPalette.AlternateBase, QColor(t.surface_alt))
    p.setColor(QPalette.Text, text)
    p.setColor(QPalette.Button, QColor(t.surface))
    p.setColor(QPalette.ButtonText, text)
    p.setColor(QPalette.BrightText, QColor("#ff5555"))
    p.setColor(QPalette.Highlight, QColor(t.accent))
    p.setColor(QPalette.HighlightedText, QColor(t.accent_text))
    p.setColor(QPalette.ToolTipBase, surface)
    p.setColor(QPalette.ToolTipText, text)
    p.setColor(QPalette.PlaceholderText, dim)
    p.setColor(QPalette.Link, QColor(t.accent))
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText):
        p.setColor(QPalette.Disabled, role, dim)
    return p


def matplotlib_rc(t: Theme) -> dict:
    """rcParams so newly created figures start in the right colours."""
    return {
        "figure.facecolor": t.fig_bg,
        "figure.edgecolor": t.fig_bg,
        "axes.facecolor": t.ax_bg,
        "axes.edgecolor": t.axis,
        "axes.labelcolor": t.text,
        "axes.titlecolor": t.text,
        "xtick.color": t.axis,
        "ytick.color": t.axis,
        "xtick.labelcolor": t.text,
        "ytick.labelcolor": t.text,
        "text.color": t.text,
        "grid.color": t.guide,
        "legend.facecolor": t.ax_bg,
        "legend.edgecolor": t.border,
        "savefig.facecolor": t.fig_bg,
        "savefig.edgecolor": t.fig_bg,
    }


_DEFAULT_STYLE = None
_DEFAULT_PALETTE = None


def apply(app, name: str) -> Theme:
    """Switch theme: style, palette, stylesheet and matplotlib rcParams.

    Callers still have to redraw existing figures, since rcParams only
    affect figures created afterwards.
    """
    global _DEFAULT_STYLE, _DEFAULT_PALETTE
    import matplotlib

    t = set_theme(name)
    matplotlib.rcParams.update(matplotlib_rc(t))
    if app is None:
        return t

    if _DEFAULT_STYLE is None:
        _DEFAULT_STYLE = app.style().objectName()
        _DEFAULT_PALETTE = app.palette()

    if t.dark:
        app.setStyle("Fusion")
        app.setPalette(palette(t))
    else:
        app.setStyle(_DEFAULT_STYLE)
        app.setPalette(_DEFAULT_PALETTE)
    app.setStyleSheet(stylesheet(t))
    return t
