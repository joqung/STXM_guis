"""
peakfit_tab.py -- the Peak fitting tab.

Kept separate from app.py because it is a self-contained editor: a table
of components and their parameters, a plot of the fit and its residual,
and a text report.
"""

from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView, QPlainTextEdit,
    QAbstractItemView, QMessageBox, QSplitter, QGroupBox, QFormLayout,
    QDoubleSpinBox, QSpinBox, QMenu,
)

from . import core, peakfit as pf, theme

class EnergyBox(QDoubleSpinBox):
    def __init__(self, value=0.0, step=0.5):
        super().__init__()
        self.setDecimals(3)
        self.setRange(-1e6, 1e6)
        self.setSingleStep(step)
        self.setValue(value)
        self.setSuffix(" eV")
        self.setKeyboardTracking(False)
        self.setMinimumWidth(105)


class PeakFitTab(QWidget):
    """Interactive lineshape fitting of a normalized spectrum."""

    def __init__(self, get_spectrum, log, plot_panel_factory, parent=None):
        super().__init__(parent)
        self._get_spectrum = get_spectrum      # () -> (energy, intensity, label)
        self._log = log
        self.model = pf.PeakModel()
        self.report: pf.FitReport | None = None
        self._updating = False

        self.plot = plot_panel_factory(2, 1, 5.2, True)

        # --- controls ---------------------------------------------------
        self.shape = QComboBox()
        for key in ("pseudo_voigt", "gaussian", "lorentzian"):
            self.shape.addItem(pf.KIND_LABELS[key], key)
        self.step_kind = QComboBox()
        self.step_kind.addItem("Arctangent step", "arctan_step")
        self.step_kind.addItem("Error-function step", "erf_step")
        self.step_kind.addItem("No step", "")

        self.fit_lo, self.fit_hi = EnergyBox(), EnergyBox()
        self.n_peaks = QSpinBox()
        self.n_peaks.setRange(1, 8)
        self.n_peaks.setValue(2)
        self.smooth = QSpinBox()
        self.smooth.setRange(3, 99)
        self.smooth.setSingleStep(2)
        self.smooth.setValue(7)
        self.minimiser = QComboBox()
        self.minimiser.addItem("Trust region (bounded)", "trf")
        self.minimiser.addItem("Levenberg-Marquardt (as Igor)", "lm")
        self.minimiser.setToolTip(
            "Which least-squares algorithm refines the parameters.\n\n"
            "Igor's FuncFit is Levenberg-Marquardt. Choose it to reproduce "
            "an old Igor fit.\n\n"
            "LM cannot take bounds, so selecting it drops them \u2014 "
            "including the guard that keeps peak centres inside the fitted "
            "window. A model with more peaks than the data supports can "
            "then converge with a peak at an absurd energy. Trust region "
            "is the default for that reason.")

        self.stage = QCheckBox("Hold centres for a first pass")
        self.stage.setChecked(True)
        self.stage.setToolTip(
            'Reproduces the Igor recipe FuncFit/H="010010" followed by a\n'
            "free pass. Helps when starting centres are good but\n"
            "amplitudes are not.")

        self.igor_mode = QCheckBox("Igor twoPsV (two peaks, \u03b7 = 0.5)")
        self.igor_mode.setToolTip(
            "Configure the model exactly as the Cp2VCl2 Igor procedure's\n"
            "fitTwoPeaksPsV does: two pseudo-Voigt peaks with eta held at\n"
            "0.5, no step and no baseline, centres held for a first pass.\n\n"
            "Igor's twoPsV is a/2*(Gaussian + Lorentzian), which is this\n"
            "shape at eta = 0.5 -- verified identical to 1e-16.\n\n"
            "The remaining difference is the minimiser: Igor's FuncFit is\n"
            "Levenberg-Marquardt, this uses scipy's curve_fit. On a\n"
            "well-conditioned fit they agree; on a poor one they can land\n"
            "in different places.")
        self.igor_mode.toggled.connect(self._igor_mode_toggled)
        # Without these the combos only affected the NEXT peak added --
        # changing the shape appeared to do nothing at all, because the
        # existing components kept their old kind and nothing redrew.
        self.shape.currentIndexChanged.connect(self._shape_changed)
        self.step_kind.currentIndexChanged.connect(self._step_changed)

        seed_btn = QPushButton("Seed from derivative")
        seed_btn.setToolTip("Locate maxima with the derivative and build a "
                            "starting model at those energies.")
        seed_btn.clicked.connect(self.seed_from_derivative)
        add_peak = QPushButton("Add peak")
        add_peak.clicked.connect(self.add_peak)
        add_step = QPushButton("Add step/baseline")
        add_step.clicked.connect(self._add_step_menu)
        remove_btn = QPushButton("Remove component")
        remove_btn.clicked.connect(self.remove_component)
        self.fit_btn = QPushButton("Fit")
        self.fit_btn.setDefault(True)
        self.fit_btn.clicked.connect(self.run_fit)
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear)

        setup = QGroupBox("Starting model")
        sf = QFormLayout(setup)
        sf.addRow("Peak shape", self.shape)
        sf.addRow("Edge step", self.step_kind)
        sf.addRow("Peaks to seed", self.n_peaks)
        sf.addRow("Derivative smoothing", self.smooth)
        sf.addRow(self.igor_mode)
        sf.addRow(seed_btn)

        rng = QGroupBox("Fit range")
        rf = QFormLayout(rng)
        rf.addRow("From", self.fit_lo)
        rf.addRow("To", self.fit_hi)
        rf.addRow("Minimiser", self.minimiser)
        rf.addRow(self.stage)

        # --- parameter table --------------------------------------------
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Component", "Parameter", "Value", "Hold", "Min", "Max"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.itemChanged.connect(self._table_edited)

        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setStyleSheet(
            f"font-family: Consolas, monospace; color: {theme.T.text};")

        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.addWidget(setup)
        ll.addWidget(rng)
        btns = QHBoxLayout()
        for b in (add_peak, add_step, remove_btn):
            btns.addWidget(b)
        ll.addLayout(btns)
        ll.addWidget(self.table, 1)
        run = QHBoxLayout()
        run.addWidget(self.fit_btn)
        run.addWidget(clear_btn)
        ll.addLayout(run)

        right = QSplitter(Qt.Vertical)
        right.addWidget(self.plot)
        right.addWidget(self.text)
        right.setSizes([620, 240])

        split = QSplitter(Qt.Horizontal)
        split.addWidget(left)
        split.addWidget(right)
        split.setSizes([430, 900])

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(split)

    # -- model building ---------------------------------------------------
    def _spectrum(self):
        e, y, label = self._get_spectrum()
        if e is None:
            QMessageBox.information(
                self, "Peak fitting",
                "Normalize at least one scan first — peak fitting works on "
                "the normalized spectrum (or the average, when there is one).")
            return None, None, ""
        return e, y, label

    def _shape_changed(self, *_):
        """Convert existing peaks to the chosen shape and redraw."""
        if self._updating:
            return
        kind = self.shape.currentData()
        changed = 0
        for c in self.model.components:
            if not c.is_peak or c.kind == kind:
                continue
            c.kind = kind
            for name in c.param_names:
                c.values.setdefault(name, c._default(name))
            c.fixed = {n for n in c.fixed if n in c.param_names}
            c.bounds = {n: b for n, b in c.bounds.items()
                        if n in c.param_names}
            if c.label in pf.KIND_LABELS.values():
                c.label = pf.KIND_LABELS[kind]
            changed += 1
        if changed:
            self._log(f"converted {changed} peak"
                      f"{'s' if changed != 1 else ''} to "
                      f"{pf.KIND_LABELS[kind]}")
            self.refresh_table()
            self.refresh_plot()

    def _step_changed(self, *_):
        """Add, convert or drop the edge-step component, and redraw."""
        if self._updating:
            return
        kind = self.step_kind.currentData()
        steps = [c for c in self.model.components
                 if c.kind in ("arctan_step", "erf_step")]
        if not kind:
            if steps:
                self.model.components = [c for c in self.model.components
                                         if c not in steps]
                self._log("removed the edge step")
        elif steps:
            for c in steps:
                if c.kind != kind:
                    c.kind = kind
                    for name in c.param_names:
                        c.values.setdefault(name, c._default(name))
                    if c.label in pf.KIND_LABELS.values():
                        c.label = pf.KIND_LABELS[kind]
            self._log(f"edge step is now {pf.KIND_LABELS[kind]}")
        else:
            x, y, _ = self._spectrum()
            if x is not None and len(x):
                peaks = [c for c in self.model.components if c.is_peak]
                centre = (min(c.values["center"] for c in peaks) if peaks
                          else float(np.median(x)))
                self.model.add(kind, height=float(np.nanmax(y)) * 0.1,
                               center=centre, width=1.0)
                self._log(f"added an {pf.KIND_LABELS[kind]}")
        self.refresh_table()
        self.refresh_plot()

    def _igor_mode_toggled(self, on):
        """Pin the starting model to Igor's two-peak recipe.

        The controls it owns are disabled rather than hidden, showing
        what is being applied instead of silently disagreeing with the
        result.
        """
        if on:
            self._updating = True
            try:
                self.shape.setCurrentIndex(
                    max(self.shape.findData("pseudo_voigt"), 0))
                self.step_kind.setCurrentIndex(
                    max(self.step_kind.findData(""), 0))
                self.n_peaks.setValue(2)
                self.stage.setChecked(True)
            finally:
                self._updating = False
        for w in (self.shape, self.step_kind, self.n_peaks, self.stage):
            w.setEnabled(not on)
        if on:
            self._log("Igor twoPsV mode: two pseudo-Voigt peaks, eta held "
                      "at 0.5, no step or baseline, centres held for a "
                      "first pass")
            self._apply_igor_to_model()
            self.refresh_table()
            self.refresh_plot()

    def _apply_igor_to_model(self):
        """Drop anything Igor's recipe does not have, and hold eta."""
        keep = [c for c in self.model.components if c.is_peak][:2]
        for c in keep:
            if c.kind != "pseudo_voigt":
                c.kind = "pseudo_voigt"
                for name in c.param_names:
                    c.values.setdefault(name, c._default(name))
            c.values["eta"] = 0.5
            c.fixed.add("eta")
        self.model.components = keep

    def seed_from_derivative(self):
        e, y, _ = self._spectrum()
        if e is None:
            return
        if not self.fit_lo.value() and not self.fit_hi.value():
            self.fit_lo.setValue(float(e.min()))
            self.fit_hi.setValue(float(e.max()))
        lo, hi = sorted((self.fit_lo.value(), self.fit_hi.value()))
        m = (e >= lo) & (e <= hi)
        if m.sum() < 5:
            m = np.ones_like(e, dtype=bool)

        d1, d2 = core.derivatives(e[m], y[m], window=self.smooth.value())
        found = core.find_peaks_from_derivative(e[m], d1, d2)
        if found.size == 0:
            return self._log("No maxima found; adjust the smoothing width.",
                             "warn")
        heights = np.interp(found, e, y)
        keep = sorted(found[np.argsort(heights)[::-1][:self.n_peaks.value()]])

        self.model = pf.guess_peaks(
            e, y, keep, shape=self.shape.currentData(),
            with_step=bool(self.step_kind.currentData()),
            step_kind=self.step_kind.currentData() or "arctan_step")
        self._log("Seeded " + ", ".join(f"{c:.2f}" for c in keep) + " eV")
        self.report = None
        if self.igor_mode.isChecked():
            self._apply_igor_to_model()
        self.refresh_table()
        self.refresh_plot()

    def add_peak(self):
        e, y, _ = self._spectrum()
        if e is None:
            return
        lo, hi = sorted((self.fit_lo.value() or float(e.min()),
                         self.fit_hi.value() or float(e.max())))
        centre = (lo + hi) / 2.0
        n = sum(1 for c in self.model.components if c.is_peak) + 1
        kind = self.shape.currentData()
        vals = dict(amplitude=max(float(np.interp(centre, e, y)), 1e-3),
                    center=centre, fwhm=max((hi - lo) / 20.0, 0.3))
        if kind == "pseudo_voigt":
            vals["eta"] = 0.5
        self.model.add(kind, label=f"Peak {n}", **vals)
        self.report = None
        self.refresh_table()
        self.refresh_plot()

    def _add_step_menu(self):
        menu = QMenu(self)
        for kind in ("arctan_step", "erf_step", "linear", "constant"):
            act = menu.addAction(pf.KIND_LABELS[kind])
            act.triggered.connect(lambda _=False, k=kind: self._add_baseline(k))
        menu.exec(self.sender().mapToGlobal(self.sender().rect().bottomLeft()))

    def _add_baseline(self, kind):
        e, y, _ = self._spectrum()
        if e is None:
            return
        lo, hi = sorted((self.fit_lo.value() or float(e.min()),
                         self.fit_hi.value() or float(e.max())))
        if kind in ("arctan_step", "erf_step"):
            tail = y[e >= hi - (hi - lo) * 0.2]
            self.model.add(kind, height=float(np.nanmedian(tail)) if tail.size else 1.0,
                           center=(lo + hi) / 2.0, width=max((hi - lo) / 10.0, 0.5))
        elif kind == "linear":
            self.model.add(kind, slope=0.0, intercept=float(np.nanmedian(y)))
        else:
            self.model.add(kind, level=float(np.nanmedian(y)))
        self.report = None
        self.refresh_table()
        self.refresh_plot()

    def remove_component(self):
        rows = {i.row() for i in self.table.selectedIndexes()}
        if not rows:
            return
        targets = sorted({self.table.item(r, 0).data(Qt.UserRole)
                          for r in rows if self.table.item(r, 0)}, reverse=True)
        for idx in targets:
            if 0 <= idx < len(self.model.components):
                del self.model.components[idx]
        self.report = None
        self.refresh_table()
        self.refresh_plot()

    def clear(self):
        self.model = pf.PeakModel()
        self.report = None
        self.text.setPlainText("")
        self.refresh_table()
        self.refresh_plot()

    # -- fitting ----------------------------------------------------------
    def run_fit(self):
        e, y, label = self._spectrum()
        if e is None:
            return
        if not self.model.components:
            return QMessageBox.information(
                self, "Peak fitting",
                "Build a starting model first — 'Seed from derivative' is "
                "usually the quickest way.")
        lo = self.fit_lo.value() or float(e.min())
        hi = self.fit_hi.value() or float(e.max())
        try:
            self.report = self.model.fit(e, y, lo, hi,
                                         stage_centers=self.stage.isChecked(),
            method=self.minimiser.currentData())
        except Exception as exc:
            self.report = None
            self.refresh_plot()
            return QMessageBox.warning(self, "Fit failed", str(exc))

        self.text.setPlainText(f"{label}\n\n" + self.report.describe())
        self._log(f"Peak fit: R² = {self.report.r_squared:.5f}, "
                  f"{self.report.n_free} free parameters")
        for line in self.report.message.splitlines():
            if line.strip():
                self._log(f"peak fit: {line.strip()}", "warn")
        self.refresh_table()
        self.refresh_plot()

    # -- table ------------------------------------------------------------
    def refresh_table(self):
        self._updating = True
        rows = [(i, c, n) for i, c in enumerate(self.model.components)
                for n in c.param_names]
        self.table.setRowCount(len(rows))
        errs = self.report.stderr if self.report else None
        for r, (ci, comp, name) in enumerate(rows):
            colour = self._colour_for(ci)
            first = QTableWidgetItem(comp.label if name == comp.param_names[0] else "")
            first.setData(Qt.UserRole, ci)
            first.setForeground(QColor(colour))
            first.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 0, first)

            pname = QTableWidgetItem(name)
            pname.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 1, pname)

            text = f"{comp.values[name]:.5g}"
            if errs and name in errs[ci] and np.isfinite(errs[ci][name]):
                text += f"  ± {errs[ci][name]:.3g}"
            self.table.setItem(r, 2, QTableWidgetItem(text))

            hold = QTableWidgetItem()
            hold.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            hold.setCheckState(Qt.Checked if name in comp.fixed else Qt.Unchecked)
            self.table.setItem(r, 3, hold)

            lo_b, hi_b = comp.bounds.get(name, (None, None))
            self.table.setItem(r, 4, QTableWidgetItem(
                "" if lo_b is None else f"{lo_b:g}"))
            self.table.setItem(r, 5, QTableWidgetItem(
                "" if hi_b is None else f"{hi_b:g}"))
        self.table.resizeColumnsToContents()
        # Stretch the Value column, not the label column: component names
        # ("Edge step", "Peak 1") must stay readable when the panel is narrow.
        head = self.table.horizontalHeader()
        head.setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setColumnWidth(0, max(self.table.columnWidth(0), 78))
        self._updating = False

    def _table_edited(self, item):
        if self._updating:
            return
        row, col = item.row(), item.column()
        anchor = None
        for r in range(row, -1, -1):
            it = self.table.item(r, 0)
            if it and it.data(Qt.UserRole) is not None:
                anchor = it.data(Qt.UserRole)
                break
        if anchor is None or anchor >= len(self.model.components):
            return
        comp = self.model.components[anchor]
        name_item = self.table.item(row, 1)
        if not name_item:
            return
        name = name_item.text()
        try:
            if col == 2:
                comp.values[name] = float(item.text().split("±")[0].strip())
            elif col == 3:
                if item.checkState() == Qt.Checked:
                    comp.fixed.add(name)
                else:
                    comp.fixed.discard(name)
            elif col in (4, 5):
                lo_b, hi_b = comp.bounds.get(name, comp.default_bounds(name))
                txt = item.text().strip()
                val = float(txt) if txt else (-np.inf if col == 4 else np.inf)
                comp.bounds[name] = (val, hi_b) if col == 4 else (lo_b, val)
        except ValueError:
            self.refresh_table()
            return
        self.report = None
        self.refresh_plot()

    def _colour_for(self, index: int) -> str:
        peaks = [i for i, c in enumerate(self.model.components) if c.is_peak]
        if index in peaks:
            return theme.T.peak_color(peaks.index(index))
        return theme.T.post

    # -- plotting ---------------------------------------------------------
    def refresh_plot(self):
        ax, ax_r = self.plot.axes
        ax.clear()
        ax_r.clear()
        e, y, label = self._get_spectrum()
        if e is None:
            ax.text(0.5, 0.5, "Normalize a scan to enable peak fitting",
                    ha="center", va="center", transform=ax.transAxes, color=theme.T.text_dim)
            self.plot.style(ax, "", "Normalized intensity")
            self.plot.style(ax_r, "Energy (eV)", "Residual")
            return self.plot.draw()

        ax.plot(e, y, lw=1.0, color=theme.T.data, label="normalized",
                zorder=1)

        if self.model.components:
            total = self.model.evaluate(e)
            for i, comp in enumerate(self.model.components):
                ax.plot(e, comp.evaluate(e), lw=1.1, ls="--",
                        color=self._colour_for(i), label=comp.label, zorder=2)
            ax.plot(e, total, lw=1.8, color=theme.T.norm, label="sum", zorder=3)
            ax_r.plot(e, y - total, lw=1.0, color=theme.T.residual)
            ax_r.axhline(0, lw=0.8, color=theme.T.axis)

        lo = self.fit_lo.value()
        hi = self.fit_hi.value()
        if hi > lo:
            for a in (ax, ax_r):
                a.axvspan(lo, hi, color=theme.T.band, alpha=0.08, zorder=0)

        ax.set_title(label, fontsize=10)
        ax.legend(frameon=False, fontsize=8, ncol=2)
        self.plot.style(ax, "", "Normalized intensity")
        self.plot.style(ax_r, "Energy (eV)", "Residual")
        self.plot.draw()

    # -- persistence ------------------------------------------------------
    def to_list(self):
        return self.model.to_list()

    def from_list(self, data):
        self.model = pf.PeakModel.from_list(data or [])
        self.report = None
        self.refresh_table()
        self.refresh_plot()
