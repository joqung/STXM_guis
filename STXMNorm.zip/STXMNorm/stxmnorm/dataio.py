"""
dataio.py -- loading, project state and export for XASNorm.

Replaces the Igor ``LoadWave/A/O/G/B=columnNames`` calls plus the
``compoundName + "_S" + num2str(i) + "_eV"`` naming convention.  In the
Igor procedures the scan count and compound name were ``constant``
declarations at the top of the procedure file, so adding a scan meant
editing and recompiling the procedure.  Here scans are objects in a list.
"""

from __future__ import annotations

import csv
import io
import json
import pathlib
from dataclasses import dataclass, field, asdict
from typing import Sequence

import numpy as np

from . import core, engines

TEXT_SUFFIXES = {".txt", ".dat", ".csv", ".tsv", ".xas", ".asc", ".prn", ""}

#: Characters that begin a comment line in the exports this reads.
#: "%" is aXis2000's 1-D .txt export, "*" its .xas export.
COMMENT_PREFIXES = ("#", "!", ";", "%", "*")


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

@dataclass
class LoadedColumns:
    """Whatever numeric columns were found in a file."""

    path: pathlib.Path
    headers: list[str]
    data: np.ndarray           # shape (n_points, n_columns)
    comment_lines: list[str] = field(default_factory=list)
    metadata: dict[str, str] = field(default_factory=dict)

    @property
    def n_columns(self) -> int:
        return self.data.shape[1] if self.data.size else 0

    def column(self, index: int) -> np.ndarray:
        return self.data[:, index].astype(float)


def _split_with(line: str, delim: str | None) -> list[str]:
    if delim is None:
        return line.split()
    return [c.strip() for c in next(csv.reader([line], delimiter=delim))]


def _all_numeric(fields: Sequence[str]) -> bool:
    """True if every field parses as a number, whatever the count."""
    if not fields:
        return False
    for f in fields:
        try:
            float(f)
        except ValueError:
            return False
    return True


def _numeric_row(fields: Sequence[str]) -> bool:
    if len(fields) < 2:
        return False
    for f in fields:
        try:
            float(f)
        except ValueError:
            return False
    return True


def _sniff_delimiter(lines: Sequence[str]) -> str | None:
    """Pick the delimiter that yields the most consistent numeric rows.

    Counting raw occurrences is not enough: a comment line such as
    "# STXM export, aXis2000" contains a comma, which would misclassify a
    space-delimited file.  Scoring by how many lines actually parse as
    numeric rows is immune to that.
    """
    best, best_score = None, (-1, 0)
    for delim in (None, ",", "\t", ";", "|"):
        widths: dict[int, int] = {}
        good = 0
        for line in lines:
            if not line.strip() or line.lstrip().startswith(COMMENT_PREFIXES):
                continue
            try:
                fields = _split_with(line, delim)
            except csv.Error:
                continue
            if _numeric_row(fields):
                good += 1
                widths[len(fields)] = widths.get(len(fields), 0) + 1
        if not good:
            continue
        # prefer many rows, and a single dominant column count
        dominant = max(widths.values()) if widths else 0
        score = (dominant, max(widths, default=0))
        if score > best_score:
            best, best_score = delim, score
    return best


def load_columns(path: str | pathlib.Path, max_header_scan: int = 60
                 ) -> LoadedColumns:
    """Read a column text file, tolerating headers and mixed delimiters.

    Handles the usual STXM/aXis2000 exports: two-column energy/intensity
    ASCII with or without a header line, comma- tab- or space-separated,
    and files that begin with ``#`` or instrument metadata.
    """
    path = pathlib.Path(path)
    # utf-8-sig, not utf-8: a byte-order mark left by Excel or Notepad
    # otherwise sticks to the first character of the file, so the opening
    # data row fails to parse as a number and is silently dropped. One
    # missing point at the start of a scan is easy to never notice.
    raw = path.read_text(encoding="utf-8-sig", errors="replace")
    lines = raw.splitlines()

    delim = _sniff_delimiter(lines)

    def split(line: str) -> list[str]:
        try:
            return _split_with(line, delim)
        except csv.Error:
            return []

    numeric = _numeric_row

    first_data = None
    for i, line in enumerate(lines):
        if not line.strip() or line.lstrip().startswith(COMMENT_PREFIXES):
            continue
        if numeric(split(line)):
            first_data = i
            break
    if first_data is None:
        # A one-column file parses fine as numbers but has no energy axis,
        # and "no numeric data" is then simply wrong and sends people
        # looking for the wrong problem.
        lone = [ln for ln in lines
                if ln.strip() and not ln.lstrip().startswith(COMMENT_PREFIXES)
                and _all_numeric(split(ln))]
        if lone:
            raise ValueError(
                f"{path.name} has only one column of numbers. A scan needs "
                "an energy column and an intensity column.")
        raise ValueError(f"No numeric data rows found in {path.name}")

    comments = [ln for ln in lines[:first_data] if ln.strip()]

    rows = []
    width = len(split(lines[first_data]))
    for line in lines[first_data:]:
        if not line.strip() or line.lstrip().startswith(COMMENT_PREFIXES):
            continue
        fields = split(line)
        if not numeric(fields):
            continue
        vals = [float(f) for f in fields[:width]]
        if len(vals) == width:
            rows.append(vals)
    if not rows:
        raise ValueError(f"No parsable numeric rows in {path.name}")

    data = np.asarray(rows, dtype=float)

    headers: list[str] = []
    if comments:
        cand = split(comments[-1].lstrip("#!;% ").strip())
        if len(cand) == width and not numeric(cand):
            headers = cand
    if not headers:
        headers = ["Energy" if i == 0 else f"Column {i + 1}"
                   for i in range(width)]

    return LoadedColumns(path=path, headers=headers, data=data,
                         comment_lines=comments,
                         metadata=parse_metadata(comments))


def parse_metadata(comment_lines: Sequence[str]) -> dict[str, str]:
    """Pull "Key: value" pairs out of an aXis2000 header.

    A .xas export carries a block of fields -- Formula, Common name, Edge,
    Acquisition mode, Write date -- worth keeping: they can fill in the
    compound name without retyping, and they belong in the provenance
    header of anything exported later.
    """
    meta: dict[str, str] = {}
    for line in comment_lines:
        body = line.lstrip("".join(COMMENT_PREFIXES) + " \t").rstrip()
        if not body or set(body) <= set("-=_ ") or ":" not in body:
            continue
        key, _, value = body.partition(":")
        key, value = key.strip(), value.strip()
        if key and value and len(key) < 40:
            meta[key] = value
    return meta


def guess_columns(lc: LoadedColumns) -> tuple[int, int]:
    """Guess which columns hold energy and intensity.

    Energy is the first monotonic column whose values sit in a plausible
    soft/tender X-ray range; intensity is the next column after it.
    """
    energy_idx = 0
    for i in range(lc.n_columns):
        col = lc.column(i)
        if col.size < 2:
            continue
        monotonic = np.all(np.diff(col) > 0) or np.all(np.diff(col) < 0)
        span = np.nanmax(col) - np.nanmin(col)
        if monotonic and 50.0 < np.nanmedian(np.abs(col)) < 25000.0 and span > 0:
            energy_idx = i
            break
    intensity_idx = energy_idx + 1 if lc.n_columns > energy_idx + 1 else 0
    if intensity_idx == energy_idx:
        intensity_idx = min(1, lc.n_columns - 1)
    return energy_idx, intensity_idx


# ---------------------------------------------------------------------------
# Project model
# ---------------------------------------------------------------------------

#: What the imported intensity column already is.
#:   "od"           -- already ratioed absorbance / optical density.
#:                     An attached I0 is reference only; nothing is divided.
#:   "transmission" -- raw transmitted counts; absorbance is -ln(I/I0).
#:   "ratio"        -- raw counts to be divided by I0 without a log
#:                     (fluorescence yield, or an I/I0 ratio).
INTENSITY_KINDS = {
    "od": "Already ratioed (absorbance / OD)",
    "transmission": "Raw transmission  ->  -ln(I / I0)",
    "ratio": "Raw counts  ->  I / I0  (no log)",
}


def detect_intensity_kind(intensity, i0_intensity) -> str:
    """Guess whether a spectrum still needs dividing by I0.

    An aXis2000 1-D export is normally already ratioed: values of order
    1, against raw I0 counts of order 10^2-10^5. Taking -ln(I/I0) of such
    data produces a large positive number and flips the spectrum upside
    down, which is a confusing failure because it still looks like a
    plausible spectrum. Comparing magnitudes catches it: if the two are
    orders of magnitude apart, the data was ratioed already.
    """
    y = np.asarray(intensity, dtype=float)
    y = y[np.isfinite(y)]
    if y.size == 0:
        return "od"
    med = float(np.median(np.abs(y)))
    if i0_intensity is None:
        return "od" if med < 20.0 else "transmission"
    i0 = np.asarray(i0_intensity, dtype=float)
    i0 = i0[np.isfinite(i0)]
    if i0.size == 0 or med == 0:
        return "od"
    ratio = float(np.median(np.abs(i0))) / med
    # Raw transmission sits within an order of magnitude of I0.
    # Already-ratioed data is hundreds to thousands of times smaller.
    return "od" if ratio > 25.0 else "transmission"


@dataclass
class Scan:
    """One measured spectrum plus its per-scan processing settings."""

    name: str
    energy_raw: np.ndarray
    intensity_raw: np.ndarray
    source: str = ""
    i0_energy: np.ndarray | None = None
    i0_intensity: np.ndarray | None = None
    intensity_kind: str = "od"
    use_i0: bool = False          # legacy sessions; superseded by intensity_kind
    optical_density: bool = True
    shift: float = 0.0
    bin_factor: int = 1
    include: bool = True
    #: shown in the Data plot. Display only -- independent of `include`,
    #: which decides whether a scan contributes to the average.
    show: bool = True
    #: shown in the I0 plot. Only meaningful when an I0 is attached.
    show_i0: bool = True
    params: engines.UnifiedParams | None = None   # None -> use project defaults
    # filled in by recompute()
    energy: np.ndarray | None = None
    intensity: np.ndarray | None = None
    norm: engines.EngineResult | None = None
    error: str = ""

    def preprocess(self) -> tuple[np.ndarray, np.ndarray]:
        """Apply I0 ratio, binning and energy shift, in that order.

        Order matters and matches the Igor workflow: ratioing happens on
        the native grid, binning before calibration (``runAutoBin`` then
        ``runShiftAll``), and the shift last so calibration is never
        undone by rebinning.
        """
        e = np.asarray(self.energy_raw, dtype=float)
        y = np.asarray(self.intensity_raw, dtype=float)

        # An attached I0 is reference data unless the intensity column is
        # explicitly raw. Dividing already-ratioed data inverts it.
        if self.intensity_kind != "od" and self.i0_energy is not None:
            y = core.ratio_i0(
                e, y, self.i0_energy, self.i0_intensity,
                optical_density=(self.intensity_kind == "transmission"))

        if self.bin_factor > 1:
            e, y = core.rebin(e, y, self.bin_factor)

        e = e + self.shift
        return e, y

    def summary(self) -> str:
        n = np.size(self.energy_raw)
        e0, e1 = float(np.nanmin(self.energy_raw)), float(np.nanmax(self.energy_raw))
        bits = [f"{n} pts", f"{e0:.1f}-{e1:.1f} eV"]
        if self.shift:
            bits.append(f"shift {self.shift:+.3f} eV")
        if self.bin_factor > 1:
            bits.append(f"bin x{self.bin_factor}")
        if self.intensity_kind == "transmission":
            bits.append("-ln(I/I0)")
        elif self.intensity_kind == "ratio":
            bits.append("I/I0")
        elif self.i0_energy is not None:
            bits.append("I0 loaded (reference only)")
        return ", ".join(bits)


@dataclass
class Project:
    """A whole normalization session."""

    compound: str = "Sample"
    scans: list[Scan] = field(default_factory=list)
    defaults: engines.UnifiedParams = field(
        default_factory=engines.UnifiedParams)
    reference_index: int | None = None
    #: "native" keeps a measured scan's own energies; "uniform" resamples
    #: onto even steps. Native by default -- see core.common_grid.
    grid_mode: str = "native"
    #: True keeps the average to the range every scan covers. False uses
    #: the reference scan's full range, so points outside the overlap are
    #: averaged over fewer scans -- see average_n.
    grid_clip: bool = True
    #: "cubic" (Igor Interpolate2 /I=3) or "linear"
    interp_mode: str = "cubic"     # Branson scanWithIdealPoints
    grid_points: int | None = None
    edge_a: float = 0.0
    edge_b: float = 0.0
    edge_label: str = "L2,3"
    element: str = ""
    peak_model: list = field(default_factory=list)
    # results
    grid: np.ndarray | None = None
    stack: list[np.ndarray] = field(default_factory=list)
    average: np.ndarray | None = None
    average_sem: np.ndarray | None = None
    #: how many scans contribute at each grid point
    average_n: np.ndarray | None = None
    log: list[str] = field(default_factory=list)

    # -- processing ------------------------------------------------------
    def params_for(self, scan: Scan) -> engines.UnifiedParams:
        return scan.params if scan.params is not None else self.defaults

    def recompute(self) -> list[str]:
        """Normalize every scan and rebuild the average. Returns messages."""
        messages: list[str] = []
        for scan in self.scans:
            scan.error = ""
            scan.norm = None
            try:
                e, y = scan.preprocess()
                scan.energy, scan.intensity = e, y
                p = self.params_for(scan)
                if p.pre_hi <= p.pre_lo or p.post_hi <= p.post_lo:
                    scan.error = "fit windows not set"
                    continue
                scan.norm = engines.normalize(e, y, p)
                # Diagnostics worth seeing next to the number itself.
                # Cheap enough here (a handful of extra fits) and only for
                # the engine where they mean anything.
                m = (e >= min(p.pre_lo, p.pre_hi)) & (e <= max(p.pre_lo,
                                                               p.pre_hi))
                lvl = float(np.nanmean(y[m])) if m.any() else float("nan")
                scan.norm.detail["pre_level"] = lvl
                scan.norm.detail["step_fraction"] = (
                    scan.norm.edge_step / lvl
                    if (lvl and p.scale_mode == "edge") else float("nan"))
                if p.engine == "edgestep":
                    try:
                        st = core.edge_step_stability(
                            e, y, p.to_norm_params(), n=7)
                        scan.norm.detail["stability"] = (
                            st["ratio"] if st else None)
                        scan.norm.detail["sign_flips"] = (
                            st["sign_flips"] if st else None)
                    except Exception:                # noqa: BLE001
                        scan.norm.detail["stability"] = None
                for w in scan.norm.warnings:
                    messages.append(f"{scan.name}: {w}")
            except Exception as exc:
                scan.error = str(exc)
                messages.append(f"{scan.name}: {exc}")

        self._check_edge_step_consistency(messages)
        self._rebuild_average(messages)
        return messages

    def _check_edge_step_consistency(self, messages: list[str],
                                     tolerance: float = 0.05) -> None:
        """Flag scans whose fitted edge step is an outlier.

        Repeat scans of the same sample should give the same edge step to
        within counting statistics.  A scan that does not usually means the
        pre-edge model is extrapolating badly, the sample thickness drifted,
        or the fit windows do not suit that scan.  Neither Igor procedure
        checked this -- the edge step was computed, used and discarded --
        so a bad scan could silently pull the average.
        """
        steps = [(s.name, s.norm.edge_step) for s in self.scans
                 if s.include and s.norm is not None]
        if len(steps) < 2:
            return
        values = np.array([v for _, v in steps])
        median = float(np.median(values))
        if median == 0 or not np.isfinite(median):
            return
        spread = float(np.max(np.abs(values - median)) / abs(median))
        if spread <= tolerance:
            return
        worst = max(steps, key=lambda kv: abs(kv[1] - median))
        messages.append(
            f"edge steps vary by {spread:.1%} across scans "
            f"(median {median:.4g}, {worst[0]} is {worst[1]:.4g}); "
            "check the pre-edge model and windows before averaging"
        )

    def _rebuild_average(self, messages: list[str]) -> None:
        usable = [s for s in self.scans
                  if s.include and s.norm is not None and not s.error]
        self.grid = None
        self.stack = []
        self.average = None
        self.average_sem = None
        self.average_n = None
        if not usable:
            return

        energies = [s.norm.energy for s in usable]
        ref = None
        if self.reference_index is not None:
            for i, s in enumerate(usable):
                if self.scans.index(s) == self.reference_index:
                    ref = i
                    break
        try:
            self.grid = core.common_grid(energies, reference=ref,
                                         n_points=self.grid_points,
                                         mode=self.grid_mode,
                                         clip=self.grid_clip)
        except ValueError as exc:
            messages.append(f"grid: {exc}")
            return

        # Averaging across engines only makes sense on a common scale.  If
        # every included scan used the same engine and output scale, the
        # native values are kept (so an all-McMaster project averages in
        # cm^2/g); otherwise everything is put on edge-jump-=-1 first.
        # Same material, same edge: the step should be a similar fraction
        # of the pre-edge level in every scan. A scan that is far out of
        # line has a measurement problem, not a fitting problem -- seen on
        # a Eu M4,5 set where one scan gave 0.7% where its siblings gave
        # 19-24%, because it had drifted during acquisition.
        ratios = []
        for s in usable:
            if s.norm.detail.get("scale_mode", "edge") != "edge":
                ratios.append(None)
                continue
            p_ = self.params_for(s)
            m = ((s.energy >= p_.pre_lo) & (s.energy <= p_.pre_hi)
                 if s.energy is not None else None)
            if m is None or not m.any():
                ratios.append(None)
                continue
            lvl = float(np.nanmean(s.intensity[m]))
            ratios.append(s.norm.edge_step / lvl if lvl else None)
        good = [r for r in ratios if r is not None and np.isfinite(r)]
        if len(good) >= 3:
            med = float(np.median(good))
            if med:
                # A step of the wrong sign is out of line whatever its
                # size, so it is caught separately from the 3x test.
                odd = [(s.name, r) for s, r in zip(usable, ratios)
                       if r is not None and np.isfinite(r)
                       and (r * med < 0 or abs(r / med) > 3.0
                            or abs(r / med) < 1 / 3.0)]
                for name, r in odd:
                    messages.append(
                        f"{name}: its edge step is {100 * r:.1f}% of its "
                        f"pre-edge level, against {100 * med:.1f}% for the "
                        "others. Scans of the same material should agree; "
                        "this one probably has a measurement problem "
                        "rather than a fitting one.")

        # Anything that needed correcting is named together, so it is one
        # line to read rather than a warning buried per scan.
        fixed = [s.name for s in usable if s.norm.detail.get("rescued")]
        if fixed:
            messages.append(
                f"corrected {len(fixed)} scan"
                f"{'s' if len(fixed) != 1 else ''} that would otherwise have "
                f"normalized upside down: {', '.join(fixed)}. The "
                "unconstrained pre-edge fit gave a negative edge step, so "
                "the leading term alone was used. Check the pre-edge window "
                "on these.")

        keys = {(s.norm.engine, s.norm.detail.get("scale", "")) for s in usable}
        mixed = len(keys) > 1
        if mixed:
            messages.append(
                "scans were normalized with different engines or output "
                "scales; the average is formed after rescaling each to "
                "edge jump = 1")
        self.stack = [core.interpolate_to_grid(
                          s.norm.energy,
                          s.norm.unit_jump() if mixed else s.norm.normalized,
                          self.grid, kind=self.interp_mode)
                      for s in usable]
        coverage = np.mean([np.mean(np.isfinite(s)) for s in self.stack])
        if coverage < 0.999:
            messages.append(
                f"scans overlap on only {coverage:.1%} of the common grid; "
                "points outside a scan's measured range are excluded from "
                "the average rather than extrapolated"
            )
        self.average, self.average_sem = core.average_spectra(self.stack)
        arr = np.vstack([np.asarray(v, float) for v in self.stack])
        self.average_n = np.sum(np.isfinite(arr), axis=0)
        if self.average_n.size and int(self.average_n.min()) < len(self.stack):
            short = int(np.sum(self.average_n < len(self.stack)))
            messages.append(
                f"the averaging range extends beyond the overlap: "
                f"{short} of {self.average_n.size} points are averaged over "
                f"fewer than {len(self.stack)} scans (as few as "
                f"{int(self.average_n.min())}). The standard error widens "
                "there, but the mean is over a different set of scans.")

    def averaged_scan_names(self) -> list[str]:
        return [s.name for s in self.scans
                if s.include and s.norm is not None and not s.error]

    # -- persistence -----------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "format": "xasnorm-session",
            "version": 1,
            "compound": self.compound,
            "element": self.element,
            "edge_label": self.edge_label,
            "edge_a": self.edge_a,
            "edge_b": self.edge_b,
            "reference_index": self.reference_index,
            "grid_mode": self.grid_mode,
            "grid_clip": self.grid_clip,
            "interp_mode": self.interp_mode,
            "grid_points": self.grid_points,
            "defaults": self.defaults.to_dict(),
            "peak_model": self.peak_model,
            "scans": [
                {
                    "name": s.name,
                    "source": s.source,
                    "energy_raw": np.asarray(s.energy_raw).tolist(),
                    "intensity_raw": np.asarray(s.intensity_raw).tolist(),
                    "i0_energy": (None if s.i0_energy is None
                                  else np.asarray(s.i0_energy).tolist()),
                    "i0_intensity": (None if s.i0_intensity is None
                                     else np.asarray(s.i0_intensity).tolist()),
                    "intensity_kind": s.intensity_kind,
                    "use_i0": s.use_i0,
                    "optical_density": s.optical_density,
                    "shift": s.shift,
                    "bin_factor": s.bin_factor,
                    "include": s.include,
                    "show": s.show,
                    "show_i0": s.show_i0,
                    "params": None if s.params is None else s.params.to_dict(),
                }
                for s in self.scans
            ],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Project":
        if d.get("format") != "xasnorm-session":
            raise ValueError("Not an XASNorm session file")
        proj = cls(
            compound=d.get("compound", "Sample"),
            element=d.get("element", ""),
            edge_label=d.get("edge_label", "L2,3"),
            edge_a=d.get("edge_a", 0.0),
            edge_b=d.get("edge_b", 0.0),
            reference_index=d.get("reference_index"),
            grid_mode=d.get("grid_mode", "native"),
            grid_clip=d.get("grid_clip", True),
            interp_mode=d.get("interp_mode", "cubic"),
            grid_points=d.get("grid_points"),
            defaults=engines.UnifiedParams.from_dict(d.get("defaults", {})),
            peak_model=d.get("peak_model", []),
        )
        for sd in d.get("scans", []):
            proj.scans.append(Scan(
                name=sd["name"],
                source=sd.get("source", ""),
                energy_raw=np.asarray(sd["energy_raw"], dtype=float),
                intensity_raw=np.asarray(sd["intensity_raw"], dtype=float),
                i0_energy=(None if sd.get("i0_energy") is None
                           else np.asarray(sd["i0_energy"], dtype=float)),
                i0_intensity=(None if sd.get("i0_intensity") is None
                              else np.asarray(sd["i0_intensity"], dtype=float)),
                intensity_kind=sd.get(
                    "intensity_kind",
                    # sessions written before this field existed
                    ("transmission" if sd.get("use_i0") else "od")),
                use_i0=sd.get("use_i0", False),
                optical_density=sd.get("optical_density", True),
                shift=sd.get("shift", 0.0),
                bin_factor=sd.get("bin_factor", 1),
                include=sd.get("include", True),
                show=sd.get("show", True),
                show_i0=sd.get("show_i0", True),
                params=(None if sd.get("params") is None
                        else engines.UnifiedParams.from_dict(sd["params"])),
            ))
        return proj

    def save(self, path: str | pathlib.Path) -> None:
        pathlib.Path(path).write_text(
            json.dumps(self.to_dict(), indent=1), encoding="utf-8")

    @classmethod
    def load(cls, path: str | pathlib.Path) -> "Project":
        return cls.from_dict(json.loads(
            pathlib.Path(path).read_text(encoding="utf-8")))


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def igor_name(text: str, used: set[str] | None = None) -> str:
    """Turn a scan name into a legal Igor wave name.

    Igor allows letters, digits and underscore, must not start with a
    digit, and is limited to 31 characters. Names are made unique within
    the file, because Igor silently overwrites a wave of the same name on
    load.
    """
    out = "".join(c if (c.isalnum() or c == "_") else "_" for c in text)
    if not out or out[0].isdigit():
        out = "w" + out
    out = out[:31]
    if used is None:
        return out
    base, k = out, 1
    while out in used:
        suffix = f"_{k}"
        out = base[:31 - len(suffix)] + suffix
        k += 1
    used.add(out)
    return out


def export_igor_text(project: "Project", path: str | pathlib.Path,
                     scans: "list[Scan] | None" = None,
                     include_average: bool = True) -> None:
    """Write an Igor Text (.itx) file: every normalized scan, plus the
    average and its standard error if there is one.

    Igor loads this with Data > Load Waves > Load Igor Text. Each scan
    becomes an energy/intensity wave pair rather than one shared axis,
    because scans need not sit on a common grid -- only the average does.
    The energy scale is attached with SetScale so Igor labels axes in eV,
    and the provenance goes into a wave note, where it stays attached to
    the data inside the experiment file.
    """
    path = pathlib.Path(path)
    used: set[str] = set()
    # _provenance returns lines; an Igor wave note is one string in which
    # \r separates lines, and a literal quote would end it early
    lines = _provenance(project)
    if isinstance(lines, str):
        lines = lines.splitlines()
    note = "\\r".join(str(x).replace("\\", "/").replace('"', "'")
                      for x in lines)

    with open(path, "w", encoding="utf-8", newline="\r\n") as fh:
        fh.write("IGOR\n")

        for scan in (project.scans if scans is None else scans):
            if scan.norm is None:
                continue
            # Reserve room for the _e / _n suffix before truncating.
            # Appending then cutting to 31 gave two identical names for a
            # long scan name, and Igor silently overwrites a wave whose
            # name it already has.
            base = igor_name(scan.name)[:29]
            ex = igor_name(base + "_e", used)
            yx = igor_name(base + "_n", used)
            fh.write(f"WAVES/D\t{ex}, {yx}\nBEGIN\n")
            for a, b in zip(scan.norm.energy, scan.norm.normalized):
                fh.write(f"\t{a:.6f}\t{b:.8g}\n")
            fh.write("END\n")
            fh.write(f'X SetScale d 0,0,"eV", {ex}\n')
            fh.write(f'X Note {yx}, "{note}"\n')

        if (include_average and project.average is not None
                and project.grid is not None):
            good = np.isfinite(project.average)
            sem = project.average_sem
            # Truncate the *sample* part, never the suffix: naming the
            # wave after its sample and then cutting to 31 characters
            # threw away the "_Norm_Avg" that says what it is.
            suffix = "_Norm_Avg"
            room = 31 - len(suffix) - len("_sem")
            stem = igor_name(safe_sample_name(project.compound))[:room]
            ecol = igor_name(stem + suffix + "_eV", used)
            ncol = igor_name(stem + suffix, used)
            scol = (igor_name(stem + suffix + "_sem", used)
                    if sem is not None else None)
            cols = [ecol, ncol] + ([scol] if scol else [])
            fh.write("WAVES/D\t" + ", ".join(cols) + "\nBEGIN\n")
            for i in np.nonzero(good)[0]:
                row = f"\t{project.grid[i]:.6f}\t{project.average[i]:.8g}"
                if sem is not None:
                    row += f"\t{sem[i]:.8g}"
                fh.write(row + "\n")
            fh.write("END\n")
            fh.write(f'X SetScale d 0,0,"eV", {ecol}\n')
            fh.write(f'X Note {ncol}, "{note}"\n')


def _provenance(project: Project, scan: Scan | None = None) -> list[str]:
    """Header lines recording exactly how a spectrum was produced."""
    p = project.params_for(scan) if scan else project.defaults
    lines = [
        "Produced by STXMNorm",
        f"Sample: {project.compound}",
    ]
    if project.element:
        lines.append(f"Edge: {project.element} {project.edge_label} "
                     f"({project.edge_a:g} / {project.edge_b:g} eV nominal)")
    if scan is not None:
        lines.append(f"Scan: {scan.name}   [{scan.source}]")
        lines.append(f"Preprocessing: {scan.summary()}")
    else:
        lines.append("Scans averaged: " + ", ".join(project.averaged_scan_names()))
    lines.append(f"Engine: {engines.ENGINES[p.engine][0]}")
    lines.append(f"Pre-edge window:  {p.pre_lo:g}-{p.pre_hi:g} eV")
    lines.append(f"Post-edge window: {p.post_lo:g}-{p.post_hi:g} eV")
    if p.engine == "edgestep":
        lines += [
            f"Pre-edge model:  "
            f"{core.FIT_MODELS[core.model_base(p.pre_model)][0]}"
            + (f" (n = {core.power_exponent(p.pre_model):.2f})"
               if p.pre_model.startswith("power") else ""),
            f"Post-edge model: "
            f"{core.FIT_MODELS[core.model_base(p.post_model)][0]}",
            f"Normalization energy: {p.norm_energy:g} eV",
        ]
        if p.exclude:
            lines.append("Post-edge exclusions: " +
                         "; ".join(f"{a:g}-{b:g}" for a, b in p.exclude))
        if p.flatten:
            lines.append("Flattening: on")
    else:
        lines += [
            f"Reference element: {p.element}",
            f"Legendre polynomial order: {p.poly_order}",
            f"Edge: {p.edge}" + (f" at {p.e0:g} eV" if p.e0 else ""),
            ("Output: divided by the edge jump" if p.norm_to_one
             else "Output: absolute cm^2/g"),
            "Cross-sections: McMaster May 1969 compilation",
        ]
        if scan is not None and scan.norm is not None:
            C = scan.norm.detail.get("C")
            if C:
                lines.append("Fit coefficients: " +
                             " ".join(f"c{i}={v:.6g}" for i, v in enumerate(C)))
            lines.append(f"Edge jump: {scan.norm.edge_step:.6g} cm^2/g"
                         + ("  (entered by hand)" if p.edge_step else
                            "  (McMaster value at the last scan point)"))
    if scan is not None and scan.norm is not None:
        lines.append(f"Edge step: {scan.norm.edge_step:.6g}")
    return lines


def write_xy(path, x, y, header_lines, columns=("Energy_eV", "Normalized"),
             extra=None, delimiter="\t") -> None:
    """Write a spectrum as delimited text with a commented header.

    Igor's ``Save/J/M="\\r\\n"`` produced a bare two-column file with no
    record of how it was made.  The header here is what makes an exported
    spectrum reproducible months later.
    """
    path = pathlib.Path(path)
    cols = [np.asarray(x, dtype=float), np.asarray(y, dtype=float)]
    names = list(columns)
    for name, arr in (extra or {}).items():
        names.append(name)
        cols.append(np.asarray(arr, dtype=float))

    buf = io.StringIO()
    for line in header_lines:
        buf.write(f"# {line}\n")
    buf.write("# " + delimiter.join(names) + "\n")
    for row in zip(*cols):
        buf.write(delimiter.join(f"{v:.8g}" for v in row) + "\n")
    path.write_text(buf.getvalue(), encoding="utf-8", newline="\r\n")


#: characters Windows forbids in a filename, plus the path separators
_BAD_NAME_CHARS = '<>:"/\\|?*'


def safe_sample_name(text: str) -> str:
    """A sample name that is safe to put in a filename.

    The name ends up in file names, so a stray "/" would silently create
    a directory -- or fail -- rather than naming the file. Illegal
    characters become underscores, runs of whitespace collapse, and an
    empty result falls back to "Sample".
    """
    name = " ".join(str(text or "").split())
    for ch in _BAD_NAME_CHARS:
        name = name.replace(ch, "_")
    name = name.strip(" .")            # Windows dislikes both at the end
    return name or "Sample"


def average_name(project: "Project") -> str:
    """Name for the averaged spectrum: ``<sample>_Norm_Avg``.

    Matches the Igor convention the reference files use
    (``Cp2VCl2_Norm_Avg_L``). One definition, used for the suggested
    filename, the column heading and the Igor wave names, so they cannot
    drift apart.
    """
    return f"{safe_sample_name(project.compound)}_Norm_Avg"


def export_average(project: Project, path) -> None:
    if project.average is None:
        raise ValueError("Nothing to export: no scans have been normalized.")
    extra = {}
    if project.average_sem is not None and len(project.stack) > 1:
        extra["StdErr"] = project.average_sem
    write_xy(path, project.grid, project.average,
             _provenance(project),
             ("Energy_eV", average_name(project)), extra)


def export_scan(project: Project, scan: Scan, path,
                include_intermediates: bool = False,
                delimiter: str = "\t") -> None:
    if scan.norm is None:
        raise ValueError(f"{scan.name} has not been normalized.")
    r = scan.norm
    extra = {}
    if include_intermediates:
        extra = {"Raw": r.raw, "PreEdgeFit": r.pre_fit,
                 "PreSubtracted": r.pre_subtracted, "PostEdgeFit": r.post_fit}
    write_xy(path, r.energy, r.normalized,
             _provenance(project, scan), ("Energy_eV", "Normalized"), extra,
             delimiter=delimiter)


#: the per-scan export formats offered in the export dialog
SCAN_FORMATS = {
    "txt": ("Text (tab)", ".txt"),
    "csv": ("CSV (comma)", ".csv"),
    "itx": ("Igor Text", ".itx"),
}


def export_scan_as(project: Project, scan: Scan, path, fmt: str = "txt",
                   include_intermediates: bool = False) -> None:
    """Write one scan in whichever format was chosen for it."""
    if fmt == "itx":
        export_igor_text(project, path, scans=[scan], include_average=False)
    else:
        export_scan(project, scan, path, include_intermediates,
                    delimiter="," if fmt == "csv" else "\t")


def export_all_normalized(project: Project, directory,
                          include_intermediates: bool = False) -> list[str]:
    """One file per normalized scan -- Igor ``exportAllNorm``."""
    directory = pathlib.Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    written = []
    for scan in project.scans:
        if scan.norm is None:
            continue
        safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in scan.name)
        path = directory / f"{project.compound}_{safe}_Norm.txt"
        export_scan(project, scan, path, include_intermediates)
        written.append(str(path))
    return written


def export_stack_csv(project: Project, path) -> None:
    """All normalized scans plus the average on the common grid, one CSV."""
    if project.grid is None:
        raise ValueError("Nothing to export: no common grid has been built.")
    names = project.averaged_scan_names()
    cols = [project.grid] + list(project.stack) + [project.average]
    header = ["Energy_eV"] + names + ["Average"]
    buf = io.StringIO()
    for line in _provenance(project):
        buf.write(f"# {line}\n")
    buf.write(",".join(header) + "\n")
    for row in zip(*cols):
        buf.write(",".join("" if not np.isfinite(v) else f"{v:.8g}"
                           for v in row) + "\n")
    pathlib.Path(path).write_text(buf.getvalue(), encoding="utf-8", newline="\r\n")
