"""
core.py -- numerical engine for XASNorm.

This module is a direct, unified reimplementation of the two Igor Pro
workflows supplied by the user:

  * Branson_Unified_Normalization_Procedure.ipf
  * Cp2VCl2_STXM_Apr12_VL_{NormProc,General_Procs}.ipf

Both procedures implement the *same* normalization algebra:

    mu_pre   = fit(pre-edge region)            # Victoreen or polynomial
    mu_sub   = I - mu_pre                      # pre-edge removal
    mu_post  = fit(post-edge region of mu_sub)  # linear or polynomial
    edgestep = mu_post(E_norm)                  # single-point edge step
    mu_norm  = mu_sub / edgestep

The Cp2VCl2 route additionally applies an initial single-point scaling
(``sPointNorm``) before the pre-edge fit.  Because every subsequent
operation is linear and the final step divides by a fit of the *scaled*
data, that pre-scaling cancels exactly.  It is therefore offered here as
a cosmetic option only (``initial_spoint_energy``) and does not change
the normalized result.

Design notes
------------
* Every fit model used by either procedure -- Victoreen (A*E^-3 + B*E^-4),
  line, and Igor's "poly 3" / "poly 4" -- is **linear in its coefficients**.
  They are therefore all solved by one linear least-squares routine, with
  no initial guesses and no convergence failures.  (The original
  ``vicFit2pre`` used ``FuncFit`` with hard-coded starting values of
  1e5 / 1e7, which is fragile at Ln M-edge energies.)
* Fits are evaluated analytically at E_norm rather than at the nearest
  grid index, removing the grid-quantization error present in the Igor
  ``energy2index`` / ``energyToIndex`` helpers.
* A post-edge exclusion mask (Igor's ``createNEdgeMask`` / ``maskWave``)
  is generalised to an arbitrary list of excluded energy windows.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field, replace
from typing import Iterable, Sequence

import numpy as np
from numpy.polynomial import Polynomial
# scipy costs about 0.7 s to import -- more than numpy, matplotlib and
# PySide6 together -- and none of the three things this module uses it
# for is on the path a normalization actually takes: CubicSpline only
# when resampling with kind="cubic", savgol_filter only in `derivatives`,
# nnls only when a fit needs the non-negativity constraint. Importing it
# where it is used keeps it out of startup for everyone who never hits
# those branches.

__all__ = [
    "FitResult",
    "FIT_MODELS",
    "fit_region",
    "evaluate_model",
    "normalize_scan",
    "NormResult",
    "rebin",
    "interpolate_to_grid",
    "ratio_i0",
    "derivatives",
    "area_xy",
    "line_through_region",
    "edge_areas",
    "EdgeAreaResult",
    "suggest_area_windows",
    "find_peaks_from_derivative",
    "region_mask",
    "NormParams",
    "average_spectra",
    "common_grid",
]


# ---------------------------------------------------------------------------
# Fit models
# ---------------------------------------------------------------------------

#: model key -> (human label, number of coefficients, Igor equivalent)
FIT_MODELS = {
    "constant": ("Constant", 1, "average"),
    "linear": ("Linear", 2, "CurveFit line"),
    "quadratic": ("Quadratic (3 coeff)", 3, "CurveFit poly 3"),
    "cubic": ("Cubic (4 coeff)", 4, "CurveFit poly 4"),
    # One free parameter. The physically correct form for a smooth
    # continuum between edges, and the only one a short, flat, noisy
    # pre-edge can actually support: on a Ce M4,5 scan whose 15 eV
    # pre-edge decays by 5% against 1.5% scatter, the two-parameter
    # Victoreen moved the edge step 12x when one point was dropped, while
    # this stayed within 4% across every window tried.
    "victoreen_a": ("Victoreen, 1 term  A/E^3", 1, "-"),
    # A/E^-n with n chosen or fitted. The exponent rides inside the model
    # string as "power:2.70", so a FitResult stays self-describing: it can
    # be evaluated, reported and round-tripped later without carrying the
    # exponent separately. Forcing n = 3 is an assumption worth being able
    # to test -- on a real Ce M4,5 scan, moving n by +/-0.3 moved the edge
    # step by +/-10%, which dominates every other uncertainty in the fit.
    "power": ("Power law  A/E^n", 1, "-"),
    "victoreen": ("Victoreen  A/E^3 + B/E^4", 2, "FuncFit Victoreen"),
    "modified_victoreen": ("Modified Victoreen  C + A/E^3 + B/E^4", 3, "-"),
}

POLY_DEGREE = {"constant": 0, "linear": 1, "quadratic": 2, "cubic": 3}


@dataclass
class FitResult:
    """Coefficients and diagnostics for one region fit."""

    model: str
    coefficients: np.ndarray          # raw-energy-space coefficients
    stderr: np.ndarray                # 1-sigma uncertainties
    n_points: int                     # points actually used (after masking)
    rss: float                        # residual sum of squares
    r_squared: float
    e_range: tuple[float, float]
    condition: float = float("nan")   # condition number of the design matrix
    constrained: bool = False         # non-negative solution was used
    warnings: list[str] = field(default_factory=list)

    def __call__(self, energy: np.ndarray) -> np.ndarray:
        return evaluate_model(self.model, self.coefficients, energy)

    def describe(self) -> str:
        label = FIT_MODELS[model_base(self.model)][0]
        if self.model.startswith('power'):
            label += f"  (n = {power_exponent(self.model):.2f})"
        names = _coef_names(self.model)
        head = (f"{label}   ({self.n_points} pts, "
                f"{self.e_range[0]:.2f}-{self.e_range[1]:.2f} eV, "
                f"R^2 = {self.r_squared:.6f})")
        if self.constrained:
            head += "  [non-negative]"
        lines = [head]
        for name, c, s in zip(names, self.coefficients, self.stderr):
            lines.append(f"    {name:>4s} = {c: .6g}  +/- {s:.3g}")
        lines += [f"    ! {m}" for m in self.warnings]
        return "\n".join(lines)


def _coef_names(model: str) -> list[str]:
    if model.startswith("power") or model == "victoreen_a":
        return ["A"]
    if model == "victoreen":
        return ["A", "B"]
    if model == "modified_victoreen":
        return ["C", "A", "B"]
    return [f"c{i}" for i in range(FIT_MODELS[model_base(model)][1])]


def power_exponent(model: str, default: float = 3.0) -> float:
    """The n in a "power:n" model string."""
    if isinstance(model, str) and model.startswith("power"):
        _, _, tail = model.partition(":")
        try:
            return float(tail)
        except ValueError:
            return default
    return default


def model_base(model: str) -> str:
    """The FIT_MODELS key for a model string that may carry a parameter."""
    return "power" if isinstance(model, str) and model.startswith("power") \
        else model


def fit_power_exponent(energy, intensity, lo: float, hi: float) -> float:
    """Estimate n from a window by regressing log(y) on log(E).

    A starting point for the exponent box, not a substitute for judgement:
    over a short, flat, noisy pre-edge the estimate is poorly constrained.
    """
    e = np.asarray(energy, float)
    y = np.asarray(intensity, float)
    m = (e >= min(lo, hi)) & (e <= max(lo, hi)) & (y > 0) & np.isfinite(y)
    if m.sum() < 3:
        raise ValueError("need at least 3 positive points in the window")
    return float(-np.polyfit(np.log(e[m]), np.log(y[m]), 1)[0])


def _design_matrix(model: str, energy: np.ndarray, scale: float) -> np.ndarray:
    """Basis functions evaluated at ``energy``.

    ``scale`` is a reference energy used only to condition the problem;
    coefficients are converted back to raw energy space afterwards.
    """
    e = np.asarray(energy, dtype=float)
    if model in POLY_DEGREE:
        t = e / scale
        return np.vander(t, POLY_DEGREE[model] + 1, increasing=True)
    if model.startswith("power"):
        return (e / scale)[:, None] ** -power_exponent(model)
    if model == "victoreen_a":
        return (e / scale)[:, None] ** -3.0
    if model == "victoreen":
        t = e / scale
        return np.column_stack([t ** -3.0, t ** -4.0])
    if model == "modified_victoreen":
        t = e / scale
        return np.column_stack([np.ones_like(t), t ** -3.0, t ** -4.0])
    raise ValueError(f"unknown fit model {model!r}")


def _to_raw_space(model: str, coef: np.ndarray, scale: float) -> np.ndarray:
    """Convert coefficients fitted in the scaled variable back to raw eV."""
    if model in POLY_DEGREE:
        # f = sum c_i (E/s)^i  ->  sum (c_i / s^i) E^i
        return np.array([c / scale ** i for i, c in enumerate(coef)])
    if model.startswith("power"):
        return np.array([coef[0] * scale ** power_exponent(model)])
    if model == "victoreen_a":
        return np.array([coef[0] * scale ** 3])
    if model == "victoreen":
        # f = c0 (E/s)^-3 + c1 (E/s)^-4 = c0 s^3 E^-3 + c1 s^4 E^-4
        return np.array([coef[0] * scale ** 3, coef[1] * scale ** 4])
    if model == "modified_victoreen":
        return np.array([coef[0], coef[1] * scale ** 3, coef[2] * scale ** 4])
    raise ValueError(model)


def evaluate_model(model: str, coef: Sequence[float], energy) -> np.ndarray:
    """Evaluate a model with **raw-energy-space** coefficients."""
    e = np.asarray(energy, dtype=float)
    coef = np.asarray(coef, dtype=float)
    if model in POLY_DEGREE:
        return Polynomial(coef)(e)
    if model.startswith("power"):
        return coef[0] * e ** -power_exponent(model)
    if model == "victoreen_a":
        return coef[0] * e ** -3.0
    if model == "victoreen":
        return coef[0] * e ** -3.0 + coef[1] * e ** -4.0
    if model == "modified_victoreen":
        return coef[0] + coef[1] * e ** -3.0 + coef[2] * e ** -4.0
    raise ValueError(model)


def region_mask(
    energy: np.ndarray,
    lo: float,
    hi: float,
    exclude: Iterable[tuple[float, float]] | None = None,
) -> np.ndarray:
    """Boolean mask for [lo, hi] minus any excluded windows.

    Generalises Igor's ``createNEdgeMask``, which zeroed two fixed
    cursor-bounded windows in a 0/1 wave passed to ``CurveFit /M=``.
    """
    e = np.asarray(energy, dtype=float)
    m = (e >= min(lo, hi)) & (e <= max(lo, hi)) & np.isfinite(e)
    if exclude:
        for a, b in exclude:
            m &= ~((e >= min(a, b)) & (e <= max(a, b)))
    return m


def fit_region(
    energy: np.ndarray,
    intensity: np.ndarray,
    lo: float,
    hi: float,
    model: str = "linear",
    exclude: Iterable[tuple[float, float]] | None = None,
    nonnegative: bool | None = None,
    extrapolate_to: float | None = None,
) -> FitResult:
    """Least-squares fit of ``model`` over an energy window.

    Every supported model is linear in its coefficients, so one solve
    covers Victoreen, line and polynomial cases alike -- no initial
    guesses, no convergence failures.

    ``nonnegative`` constrains the coefficients to be >= 0.  This matters
    for Victoreen fits: over a typical 5-15 eV pre-edge window the E^-3
    and E^-4 basis functions are collinear to about 1%, so the
    unconstrained solve happily returns large cancelling coefficients of
    opposite sign.  Those fit the window but diverge when extrapolated
    across the edge, silently over-subtracting the post-edge region.  An
    X-ray absorption background has A, B >= 0, so imposing that keeps the
    extrapolation physical.  Defaults to True for Victoreen models and
    False otherwise.

    ``extrapolate_to`` is an energy the fit will be evaluated at later
    (typically the normalization energy); supplying it enables a warning
    when the extrapolation reaches far outside the fitted window.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    m = region_mask(e, lo, hi, exclude) & np.isfinite(y)
    n = int(m.sum())
    need = FIT_MODELS[model_base(model)][1]
    if n < need:
        raise ValueError(
            f"{FIT_MODELS[model_base(model)][0]} needs at least {need} points; "
            f"the window {lo:.2f}-{hi:.2f} eV contains {n}."
        )

    if nonnegative is None:
        # Off, because Igor's `FuncFit Victoreen` is unconstrained and this
        # is what reproduces it. Defaulting it on for Victoreen looked
        # prudent -- a negative B makes A/E^3 + B/E^4 go negative at low
        # enough energy -- but on real V L-edge data the unconstrained fit
        # wants B < 0 and still stays positive across the whole scan, so
        # the constraint prevented nothing and shifted the edge step by
        # 2.1%. The check below warns in the case that actually matters.
        nonnegative = False

    ef, yf = e[m], y[m]
    scale = float(np.mean(np.abs(ef))) or 1.0
    A = _design_matrix(model, ef, scale)
    warn: list[str] = []

    try:
        cond = float(np.linalg.cond(A))
    except np.linalg.LinAlgError:           # pragma: no cover
        cond = float("nan")

    coef_free, *_ = np.linalg.lstsq(A, yf, rcond=None)
    constrained = False
    coef_s = coef_free
    if nonnegative and np.any(coef_free < 0):
        from scipy.optimize import nnls
        coef_s, _ = nnls(A, yf)
        constrained = True
        warn.append(
            "unconstrained fit gave a negative coefficient; solved with a "
            "non-negativity constraint. This is regularisation, not "
            "physics: Victoreen's formula is C*lambda^3 - D*lambda^4, so "
            "the E^-4 coefficient is negative by construction. "
            "Constraining it drives the fit towards its leading term, "
            "which is what a short or noisy pre-edge can actually support"
        )

    resid = yf - A @ coef_s
    rss = float(resid @ resid)
    dof = max(n - len(coef_s), 1)
    try:
        cov_s = np.linalg.pinv(A.T @ A) * (rss / dof)
        stderr_s = np.sqrt(np.clip(np.diag(cov_s), 0.0, None))
    except np.linalg.LinAlgError:          # pragma: no cover
        stderr_s = np.full_like(coef_s, np.nan)

    coef = _to_raw_space(model, coef_s, scale)
    stderr = np.abs(_to_raw_space(model, stderr_s, scale))

    if not constrained and extrapolate_to is not None:
        # The reason a non-negativity option exists: say so when it is
        # real, rather than silently changing the fit. This has to use the
        # raw-space coefficients -- an earlier version evaluated the
        # *scaled* ones against raw energies and cried wolf on a post-edge
        # line that was positive everywhere.
        span = np.linspace(min(lo, float(extrapolate_to)),
                           max(hi, float(extrapolate_to)), 64)
        if np.any(evaluate_model(model, coef, span) < 0):
            first = float(span[np.argmax(evaluate_model(model, coef, span) < 0)])
            warn.append(
                f"the fit goes negative at {first:.1f} eV, inside the range "
                "it is used over; consider a different model")
    if model == "modified_victoreen":
        stderr[0] = stderr_s[0]

    tss = float(((yf - yf.mean()) ** 2).sum())
    r2 = 1.0 - rss / tss if tss > 0 else float("nan")

    if np.isfinite(r2) and r2 < 0:
        warn.append(
            "R^2 is negative: this fit describes the window worse than a "
            "flat line through its mean. Check the model choice and that the "
            "window really is background."
        )

    span = float(ef.max() - ef.min())
    if model in ("victoreen", "modified_victoreen") and span < 5.0:
        warn.append(f"Victoreen window is only {span:.1f} eV wide; "
                    "E^-3 and E^-4 are nearly indistinguishable over that "
                    "range -- consider a linear pre-edge instead")
    if model == "cubic" and n < 4 * FIT_MODELS[model_base(model)][1]:
        warn.append("cubic fit over few points is prone to wild extrapolation")
    if extrapolate_to is not None and span > 0:
        reach = max(ef.min() - extrapolate_to, extrapolate_to - ef.max(), 0.0)
        if reach > 3.0 * span:
            warn.append(
                f"evaluated {reach:.1f} eV outside a {span:.1f} eV fit window "
                f"({reach / span:.1f}x extrapolation)"
            )

    return FitResult(
        model=model,
        coefficients=coef,
        stderr=stderr,
        n_points=n,
        rss=rss,
        r_squared=r2,
        e_range=(float(ef.min()), float(ef.max())),
        condition=cond,
        constrained=constrained,
        warnings=warn,
    )


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------

@dataclass
class NormParams:
    """Everything needed to normalize one spectrum."""

    pre_lo: float = 0.0
    pre_hi: float = 0.0
    pre_model: str = "victoreen"
    post_lo: float = 0.0
    post_hi: float = 0.0
    post_model: str = "linear"
    norm_energy: float = 0.0
    exclude: list[tuple[float, float]] = field(default_factory=list)
    flatten: bool = False
    initial_spoint_energy: float | None = None   # Cp2VCl2 cosmetic pre-scale
    nonnegative_pre: bool | None = None          # None = auto (off; see fit_region)
    #: What the background-subtracted spectrum is divided by.
    #:   "edge" -- the post-edge fit at norm_energy (the classic edge jump)
    #:   "area" -- the integrated area over [scale_lo, scale_hi]
    #:   "peak" -- the largest value in that window
    #: Area and peak need no edge step at all, which is the point: at a
    #: lanthanide M4,5 edge the continuum step is small and sometimes
    #: unmeasurable, while the resonance area is well determined.
    scale_mode: str = "edge"
    scale_lo: float = 0.0
    scale_hi: float = 0.0
    #: Igor's normalizeSpectrum() divides by postFit[energy2index(E, e0)],
    #: the first *measured point* at or above the normalization energy,
    #: rather than evaluating the fit at e0 itself. True reproduces that.
    #: Default False: snapping ties the result to the sampling, and two
    #: scans on different grids -- which is normal -- then get normalized
    #: at slightly different energies before being averaged together.
    snap_norm_energy: bool = False

    def to_dict(self) -> dict:
        return {
            "pre_lo": self.pre_lo, "pre_hi": self.pre_hi,
            "pre_model": self.pre_model,
            "post_lo": self.post_lo, "post_hi": self.post_hi,
            "post_model": self.post_model,
            "norm_energy": self.norm_energy,
            "exclude": [list(x) for x in self.exclude],
            "flatten": self.flatten,
            "initial_spoint_energy": self.initial_spoint_energy,
            "nonnegative_pre": self.nonnegative_pre,
            "snap_norm_energy": self.snap_norm_energy,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "NormParams":
        d = dict(d)
        d["exclude"] = [tuple(x) for x in d.get("exclude", [])]
        return cls(**d)


@dataclass
class NormResult:
    energy: np.ndarray
    raw: np.ndarray               # input to normalization (post-ratio/bin/shift)
    pre_fit: np.ndarray
    pre_subtracted: np.ndarray
    post_fit: np.ndarray          # fitted to pre_subtracted
    normalized: np.ndarray
    edge_step: float
    pre_result: FitResult
    post_result: FitResult
    #: what the spectrum was actually divided by (the edge step unless a
    #: peak or area scale was chosen)
    divisor: float = 0.0
    scale_label: str = "edge jump = 1"
    #: problems found after both fits -- chiefly a degenerate edge step,
    #: which neither individual fit can see
    step_warnings: list[str] = field(default_factory=list)
    #: energy at which the post-edge fit was evaluated
    norm_energy: float = 0.0
    #: the unconstrained pre-edge fit gave a negative edge step and the
    #: fit was redone constrained. The result is usable but it is not what
    #: the data said on its own, so it is carried, not just logged.
    rescued: bool = False

    @property
    def warnings(self) -> list[str]:
        return ([f"pre-edge: {m}" for m in self.pre_result.warnings]
                + [f"post-edge: {m}" for m in self.post_result.warnings]
                + list(self.step_warnings))

    def report(self) -> str:
        return (
            "Pre-edge:  " + self.pre_result.describe().replace("\n", "\n  ") +
            "\nPost-edge: " + self.post_result.describe().replace("\n", "\n  ") +
            f"\nEdge step at {self.norm_energy:.2f} eV: "
            f"{self.edge_step:.6g}"
        )


def edge_step_stability(energy, intensity, p: "NormParams",
                       delta: float = 2.0, n: int = 9) -> dict | None:
    """How much the edge step moves when the windows wobble by +/-delta eV.

    The single most useful number this program can put in front of you,
    and the one it was missing. An edge step is only meaningful if it
    survives a small change of window; when it does not, no choice of
    background model rescues it and the normalized amplitude means
    nothing.

    Two real cases from the same set of Eu/Ce M4,5 scans: one where the
    step moved by 78x its own median (the scan turned out to have drifted
    during acquisition), and one where a two-parameter Victoreen on a
    15 eV pre-edge moved it 12x when a single point was dropped.

    Returns None if too few of the trials succeed to say anything.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    rng = np.random.default_rng(12345)          # fixed: a report must not
    steps = []                                  # change when you reread it
    offsets = [np.zeros(4)] + [rng.uniform(-delta, delta, 4)
                               for _ in range(max(n - 1, 0))]
    for d in offsets:
        q = replace(p, pre_lo=p.pre_lo + d[0], pre_hi=p.pre_hi + d[1],
                    post_lo=p.post_lo + d[2], post_hi=p.post_hi + d[3])
        try:
            # the divisor, not the edge step: under an area or peak
            # scale the edge step is not what the spectrum is divided by,
            # and reporting its stability would describe a number nobody
            # is using
            steps.append(normalize_scan(e, y, q).divisor)
        except Exception:                        # noqa: BLE001
            pass
    if len(steps) < max(3, n // 2):
        return None
    a = np.asarray(steps, float)
    med = float(np.median(a))
    spread = float(a.max() - a.min())
    return {"median": med, "min": float(a.min()), "max": float(a.max()),
            "spread": spread,
            "ratio": (spread / abs(med)) if med else float("inf"),
            "sign_flips": float(np.mean(np.sign(a) != np.sign(med))),
            "n": len(a), "delta": float(delta)}


def normalize_scan(
    energy: np.ndarray,
    intensity: np.ndarray,
    p: NormParams,
) -> NormResult:
    """Unified pre-edge removal + post-edge single-point normalization.

    Reproduces ``normalizeAll``/``normalizeOne`` (Branson) and
    ``masterNormalizeNP`` (Cp2VCl2) in one routine.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)

    # Sort once, here. The fits themselves cope with unordered input, but
    # the result was handed back on the unsorted axis, so everything
    # downstream that assumes monotonic energy -- np.interp when
    # averaging, the plotted line, the hover cursor's nearest-point
    # search -- misbehaved without complaint.
    if e.size == y.size and e.size > 1 and np.any(np.diff(e) < 0):
        order = np.argsort(e, kind="stable")
        e, y = e[order], y[order]

    # Optional Cp2VCl2-style pre-scale.  Mathematically cancels, kept so
    # intermediate curves match the Igor plots if the user wants them to.
    if p.initial_spoint_energy is not None:
        ref = float(np.interp(p.initial_spoint_energy, e, y))
        if ref != 0 and np.isfinite(ref):
            y = y / ref

    def _solve(nonneg):
        """Pre-edge fit, subtraction, post-edge fit and the edge step."""
        pre_ = fit_region(e, y, p.pre_lo, p.pre_hi, p.pre_model,
                          nonnegative=nonneg,
                          extrapolate_to=float(np.nanmax(e)))
        sub_ = y - pre_(e)
        post_ = fit_region(e, sub_, p.post_lo, p.post_hi, p.post_model,
                           exclude=p.exclude, nonnegative=False,
                           extrapolate_to=p.norm_energy)
        curve_ = post_(e)
        if p.snap_norm_energy:
            # Igor: energy2index() counts points below e0, giving the
            # first index at or above it, and the fit is read there.
            i = min(max(int(np.sum(e < p.norm_energy)), 0), e.size - 1)
            step_ = float(curve_[i])
        else:
            step_ = float(evaluate_model(post_.model, post_.coefficients,
                                         np.array([p.norm_energy]))[0])
        return pre_, sub_, post_, curve_, step_

    pre, sub, post, post_curve, edge_step = _solve(p.nonnegative_pre)
    pre_curve = pre(e)
    rescued = False

    # Igor's FuncFit Victoreen is unconstrained, and matching it is the
    # default. But an unconstrained A/E^3 + B/E^4 with B < 0 is
    # (A*E - |B|)/E^4, which can *rise* with energy -- an absorption
    # background that increases, which is unphysical and drives the edge
    # step negative, turning the whole spectrum upside down. Seen on a
    # 1110-1233 eV scan whose pre-edge window was only 11.5 eV wide:
    # B = -1.3e12, background rising from 0.2044 to 0.2121, edge step
    # -0.040.
    #
    # So: use Igor's answer when it is usable, and fall back to the
    # constrained fit when it is not. An explicit nonnegative_pre=True or
    # False still wins.
    if (p.nonnegative_pre is None and edge_step <= 0
            and model_base(p.pre_model) in ("victoreen",
                                            "modified_victoreen",
                                            "victoreen_a", "power")):
        alt = _solve(True)
        if alt[4] > 0:
            pre, sub, post, post_curve, edge_step = alt
            pre_curve = pre(e)
            rescued = True

    step_warnings: list[str] = []
    if rescued:
        step_warnings.append(
            "the unconstrained pre-edge fit gave a negative edge step, "
            "which would have inverted the spectrum; refitted with the "
            "coefficients constrained to be non-negative. Igor does not "
            "constrain this fit, so the result differs from it here. A "
            "wider pre-edge window is the real fix.")
    span = float(np.nanmax(sub) - np.nanmin(sub)) if sub.size else 0.0
    uses_step = p.scale_mode == "edge"
    if uses_step and (not np.isfinite(edge_step) or edge_step == 0):
        raise ValueError(
            f"Edge step evaluated at {p.norm_energy:g} eV is {edge_step!r}. "
            "Check the post-edge window and normalization energy.")
    if uses_step and span > 0 and abs(edge_step) < 1e-6 * span:
        raise ValueError(
            f"Edge step at {p.norm_energy:g} eV is {edge_step:.3g}, which is "
            f"negligible next to the {span:.3g} spread of the data. "
            "Normalizing by it would scale the spectrum by about "
            f"{span / abs(edge_step):.0g}. Check that the post-edge window "
            "is above the edge and the pre-edge window below it.")
    if uses_step and edge_step < 0:
        step_warnings.append(
            f"the edge step is negative ({edge_step:.4g}), so the "
            "normalized spectrum is upside down. The post-edge fit sits "
            "below the pre-edge fit at the normalization energy, which "
            "usually means a window is misplaced or the pre-edge model is "
            "extrapolating badly.")
    if uses_step and span > 0 and abs(edge_step) < 0.02 * span:
        step_warnings.append(
            f"the edge step ({edge_step:.4g}) is under 2% of the data "
            f"spread ({span:.4g}); the normalized scale is very sensitive "
            "to the window placement here.")

    divisor, scale_label = edge_step, "edge jump = 1"
    if p.scale_mode in ("area", "peak"):
        lo_s, hi_s = sorted((float(p.scale_lo), float(p.scale_hi)))
        m = (e >= lo_s) & (e <= hi_s) & np.isfinite(sub)
        if m.sum() < 2:
            raise ValueError(
                f"The {p.scale_mode} window {lo_s:g}-{hi_s:g} eV contains "
                f"{int(m.sum())} points. Set it over the feature you want "
                "to normalize to.")
        if p.scale_mode == "area":
            divisor = float(np.trapezoid(sub[m], e[m]))
            scale_label = f"area = 1 over {lo_s:g}-{hi_s:g} eV"
        else:
            divisor = float(np.nanmax(sub[m]))
            scale_label = f"peak = 1 in {lo_s:g}-{hi_s:g} eV"
        if not np.isfinite(divisor) or divisor == 0:
            raise ValueError(
                f"The {p.scale_mode} over {lo_s:g}-{hi_s:g} eV is "
                f"{divisor!r}; nothing to normalize to.")
        if divisor < 0:
            step_warnings.append(
                f"the {p.scale_mode} over {lo_s:g}-{hi_s:g} eV is negative; "
                "the window is probably below the background rather than "
                "on a feature")

    norm = sub / divisor

    if p.flatten:
        # Athena-style flattening: remove residual post-edge curvature above
        # E_norm.  Not part of either Igor procedure; off by default.
        above = e >= p.norm_energy
        corr = np.ones_like(e)
        with np.errstate(divide="ignore", invalid="ignore"):
            corr[above] = divisor / post_curve[above]
        corr[~np.isfinite(corr)] = 1.0
        norm = norm * corr

    return NormResult(
        energy=e, raw=y,
        pre_fit=pre_curve, pre_subtracted=sub,
        post_fit=post_curve, normalized=norm,
        edge_step=edge_step, divisor=divisor, scale_label=scale_label,
        pre_result=pre, post_result=post,
        step_warnings=step_warnings, norm_energy=float(p.norm_energy),
        rescued=rescued,
    )


# ---------------------------------------------------------------------------
# Pre-processing
# ---------------------------------------------------------------------------

def ratio_i0(
    energy: np.ndarray, intensity: np.ndarray,
    i0_energy: np.ndarray, i0_intensity: np.ndarray,
    optical_density: bool = True,
) -> np.ndarray:
    """Divide a transmission scan by I0, interpolating I0 onto the scan grid.

    Igor's ``I0Normalize`` assumed identical point counts and did a
    point-by-point divide.  Here I0 is interpolated, so mismatched grids
    (common when I0 is collected separately at a STXM) are handled.

    With ``optical_density`` the result is -ln(I/I0), i.e. absorbance.
    Set it False to return the bare I/I0 ratio.
    """
    i0 = np.interp(energy, i0_energy, i0_intensity,
                   left=np.nan, right=np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.asarray(intensity, dtype=float) / i0
        if optical_density:
            out = -np.log(ratio)
        else:
            out = ratio
    out[~np.isfinite(out)] = np.nan
    return out


def rebin(energy: np.ndarray, intensity: np.ndarray, factor: int
          ) -> tuple[np.ndarray, np.ndarray]:
    """Average every ``factor`` consecutive points.

    Bins are aligned to the **high-energy end**, matching Igor's
    ``autoBinData`` (which walked backwards and inserted at index 0), so
    any partial bin lands at the low-energy end.  The Igor version could
    index past the start of the wave; this one cannot.
    """
    factor = int(factor)
    if factor <= 1:
        return np.asarray(energy, float).copy(), np.asarray(intensity, float).copy()

    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    n = e.size
    rem = n % factor
    edges = list(range(rem, n + 1, factor))
    starts = ([0] if rem else []) + edges[:-1]
    stops = ([rem] if rem else []) + edges[1:]

    eb = np.array([np.nanmean(e[a:b]) for a, b in zip(starts, stops)])
    yb = np.array([np.nanmean(y[a:b]) for a, b in zip(starts, stops)])
    return eb, yb


def interpolate_to_grid(
    energy: np.ndarray, intensity: np.ndarray, grid: np.ndarray,
    kind: str = "cubic",
) -> np.ndarray:
    """Resample onto a common grid (Igor ``Interpolate2 /I=3`` = cubic spline).

    Points outside the measured range are returned as NaN rather than
    extrapolated, so a short scan cannot silently invent data.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    ok = np.isfinite(e) & np.isfinite(y)
    e, y = e[ok], y[ok]
    order = np.argsort(e)
    e, y = e[order], y[order]
    e, idx = np.unique(e, return_index=True)
    y = y[idx]

    g = np.asarray(grid, dtype=float)
    out = np.full(g.shape, np.nan)
    inside = (g >= e[0]) & (g <= e[-1])
    if kind == "cubic" and e.size >= 4:
        from scipy.interpolate import CubicSpline
        out[inside] = CubicSpline(e, y, extrapolate=False)(g[inside])
    else:
        out[inside] = np.interp(g[inside], e, y)
    return out


def common_grid(energies: Sequence[np.ndarray], reference: int | None = None,
                n_points: int | None = None, mode: str = "native",
                clip: bool = True) -> np.ndarray:
    """Build the shared energy axis used for averaging.

    ``mode="native"`` (the default) keeps a measured scan's own energies,
    clipped to the range every scan covers -- ``reference`` picks which
    one, otherwise the first. ``mode="uniform"`` builds evenly spaced
    points across the overlap instead.

    Native is the default because an XAS scan is deliberately sampled
    unevenly: fine across the edge, coarse in the pre-edge and far
    post-edge. A uniform grid throws that away. On a real C K-edge scan
    here, 99 measured points between 283 and 290 eV -- the whole near-edge
    region -- collapsed to 16, which visibly smooths the averaged
    spectrum. norm2poly defaults to native for the same reason.
    """
    if mode not in ("native", "uniform"):
        raise ValueError(f"unknown grid mode {mode!r}")
    if clip:
        # the range every scan covers
        lo = max(float(np.nanmin(e)) for e in energies)
        hi = min(float(np.nanmax(e)) for e in energies)
        if hi <= lo:
            raise ValueError("the scans do not overlap in energy")
    else:
        # the reference scan's own range, even where others do not reach.
        # Legitimate -- average_spectra ignores NaN per point and widens
        # the standard error accordingly -- but the result outside the
        # overlap is an average of FEWER scans, so the caller must say so.
        ref = np.asarray(energies[reference or 0], dtype=float)
        lo, hi = float(np.nanmin(ref)), float(np.nanmax(ref))

    if mode == "native":
        g = np.sort(np.asarray(energies[reference or 0], dtype=float))
        g = g[(g >= lo - 1e-9) & (g <= hi + 1e-9)]
        if g.size < 2:
            raise ValueError("the scans barely overlap")
        return g

    if not n_points:
        n_points = max(int(np.median([np.size(e) for e in energies])), 2)
    return np.linspace(lo, hi, n_points)


def average_spectra(stack: Sequence[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    """Mean and standard error across scans sharing one grid.

    NaNs (out-of-range points after interpolation) are ignored per point,
    which the Igor averaging loops did not handle.
    """
    arr = np.vstack([np.asarray(s, dtype=float) for s in stack])
    n = np.sum(np.isfinite(arr), axis=0)
    with np.errstate(invalid="ignore"), warnings.catch_warnings():
        # points covered by a single scan legitimately have no spread
        warnings.simplefilter("ignore", RuntimeWarning)
        mean = np.nanmean(arr, axis=0)
        sd = (np.nanstd(arr, axis=0, ddof=1) if arr.shape[0] > 1
              else np.zeros(arr.shape[1]))
    sd = np.where(n > 1, sd, 0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        sem = sd / np.sqrt(np.maximum(n, 1))
    return mean, sem


# ---------------------------------------------------------------------------
# Analysis (from the Cp2VCl2 procedure)
# ---------------------------------------------------------------------------

def binomial_smooth(y: np.ndarray, passes: int = 1) -> np.ndarray:
    """Igor's ``Smooth`` with a binomial kernel, applied ``passes`` times.

    One pass is the [1 2 1]/4 kernel. Repeating it is how Igor widens the
    smoothing, and the repeated convolution tends to a Gaussian, so the
    result is far better behaved than a single wide boxcar.

    Works in point space, not energy space, exactly as Igor does. On an
    XAS scan that is the right thing: the fine steps across the edge are
    where the noise is, and they get proportionally more smoothing.
    """
    v = np.asarray(y, dtype=float).copy()
    n = v.size
    if n < 3 or passes <= 0:
        return v
    for _ in range(int(passes)):
        pad = np.concatenate(([v[0]], v, [v[-1]]))      # edges held flat
        v = 0.25 * pad[:-2] + 0.5 * pad[1:-1] + 0.25 * pad[2:]
    return v


def derivatives(energy: np.ndarray, intensity: np.ndarray,
                passes: int = 5, window: int | None = None,
                polyorder: int = 3, method: str = "binomial"
                ) -> tuple[np.ndarray, np.ndarray]:
    """First and second derivatives for locating transitions.

    ``method="binomial"`` (the default) reproduces Igor's ``derivPlot``:
    smooth, differentiate, smooth, differentiate, smooth. That is what the
    STXM fitting GUI does, and on real near-edge data it is markedly
    cleaner than what this function used to do.

    The earlier implementation used a single Savitzky-Golay pass, on the
    grounds that it smooths and differentiates together. That is true and
    it is fine on evenly sampled data, but a fixed short window leaves
    near-edge noise almost untouched, and the second derivative of a
    lightly smoothed spectrum oscillates hard enough to hide the
    transitions it is meant to reveal. Chained binomial passes converge
    towards a Gaussian and suppress that. ``method="savgol"`` keeps the
    old behaviour.

    Differentiation is against the energy axis itself, so an irregular
    grid -- which every STXM scan has -- is handled without resampling.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    if e.size < 3:
        z = np.zeros_like(y)
        return z, z

    if method == "binomial":
        sm = binomial_smooth(y, passes)
        d1 = binomial_smooth(np.gradient(sm, e), passes)
        d2 = binomial_smooth(np.gradient(d1, e), passes)
        return d1, d2

    n = y.size
    window = int(window or 7)
    if window % 2 == 0:
        window += 1
    window = max(polyorder + 2 + (polyorder % 2),
                 min(window, n if n % 2 else n - 1))
    if window <= polyorder:
        polyorder = max(1, window - 2)

    from scipy.signal import savgol_filter

    step = np.diff(e)
    uniform = np.allclose(step, step[0], rtol=1e-3) if step.size else True
    if uniform:
        h = float(np.mean(step)) if step.size else 1.0
        d1 = savgol_filter(y, window, polyorder, deriv=1, delta=h)
        d2 = savgol_filter(y, window, polyorder, deriv=2, delta=h)
    else:
        g = np.linspace(e[0], e[-1], n)
        h = float(g[1] - g[0])
        yi = np.interp(g, e, y)
        d1 = np.interp(e, g, savgol_filter(yi, window, polyorder,
                                           deriv=1, delta=h))
        d2 = np.interp(e, g, savgol_filter(yi, window, polyorder,
                                           deriv=2, delta=h))
    return d1, d2


def smoothed_curve(energy: np.ndarray, intensity: np.ndarray,
                   passes: int = 5) -> np.ndarray:
    """The smoothed spectrum the derivatives are taken from.

    Worth plotting over the measured points: if it does not follow them,
    the smoothing is too heavy and the derivatives are describing the
    filter rather than the data.
    """
    return binomial_smooth(intensity, passes)


def find_peaks_from_derivative(energy: np.ndarray, d1: np.ndarray,
                               d2: np.ndarray) -> np.ndarray:
    """Energies where d1 crosses zero downward (i.e. local maxima)."""
    e = np.asarray(energy, dtype=float)
    sign = np.sign(d1)
    cross = np.where((sign[:-1] > 0) & (sign[1:] <= 0))[0]
    out = []
    for i in cross:
        denom = d1[i] - d1[i + 1]
        frac = d1[i] / denom if denom != 0 else 0.0
        out.append(e[i] + frac * (e[i + 1] - e[i]))
    return np.array(out)


def area_xy(energy: np.ndarray, intensity: np.ndarray,
            lo: float, hi: float) -> float:
    """Trapezoidal area between two energies, interpolating at the limits.

    Equivalent to Igor's ``areaXY``.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    lo, hi = min(lo, hi), max(lo, hi)
    inside = (e > lo) & (e < hi)
    xs = np.concatenate(([lo], e[inside], [hi]))
    ys = np.concatenate(([np.interp(lo, e, y)], y[inside], [np.interp(hi, e, y)]))
    return float(np.trapezoid(ys, xs))


def line_through_region(energy: np.ndarray, intensity: np.ndarray,
                        lo: float, hi: float) -> FitResult:
    """Straight line over a window -- Igor ``FitMidLine`` / ``FitEndLine``."""
    return fit_region(energy, intensity, lo, hi, "linear")


@dataclass
class EdgeAreaResult:
    edge_a: float           # e.g. L3 / M5 integrated intensity
    edge_b: float           # e.g. L2 / M4 integrated intensity
    continuum: float
    white_line: float       # (A + B) / continuum
    branching_ratio: float  # A / (A + B)
    windows: dict[str, tuple[float, float]]
    warnings: list[str] = field(default_factory=list)

    def report(self, label_a="A", label_b="B") -> str:
        w = self.windows
        out = [
            f"{label_a} area        = {self.edge_a: .5g}"
            f"   [{w['a'][0]:.2f}-{w['a'][1]:.2f} eV]",
            f"{label_b} area        = {self.edge_b: .5g}"
            f"   [{w['b'][0]:.2f}-{w['b'][1]:.2f} eV]",
            f"Continuum area = {self.continuum: .5g}"
            f"   [{w['continuum'][0]:.2f}-{w['continuum'][1]:.2f} eV]",
            f"White-line intensity  ({label_a}+{label_b})/cont "
            f"= {self.white_line: .5g}",
            f"Branching ratio       {label_a}/({label_a}+{label_b}) "
            f"= {self.branching_ratio: .5g}",
        ]
        out += [f"! {m}" for m in self.warnings]
        return "\n".join(out)


def suggest_area_windows(
    e_a: float, e_b: float, e_min: float, e_max: float,
    half_width: float | None = None,
) -> dict[str, tuple[float, float]]:
    """Propose integration windows from the two edge maxima.

    The Cp2VCl2 procedure hard-coded +/-20 eV edge windows and a continuum
    running from L3+30 to L3+85 eV.  Those numbers require an edge
    separation of roughly 100 eV; applied to the V L2,3 constants in the
    same file (separation 7.1 eV) they overlap and reverse.  Here the
    windows are derived from the *actual* separation and clipped to the
    measured range.
    """
    sep = abs(e_b - e_a)
    if half_width is None:
        half_width = max(min(sep * 0.45, 20.0), 2.0)
    split = 0.5 * (e_a + e_b)          # valley between the two edges
    a = (max(e_a - half_width, e_min), min(split, e_max))
    b = (max(split, e_min), min(e_b + half_width, e_max))
    c_lo = min(e_b + half_width * 1.5, e_max)
    c_hi = min(max(c_lo + max(sep, 20.0) * 1.5, c_lo + 15.0), e_max)
    return {"a": a, "b": b, "continuum": (c_lo, c_hi)}


def edge_areas(
    energy: np.ndarray,
    normalized: np.ndarray,
    e_a: float,
    e_b: float,
    *,
    window_a: tuple[float, float],
    window_b: tuple[float, float],
    window_continuum: tuple[float, float],
    midline: FitResult | None = None,
    endline: FitResult | None = None,
) -> EdgeAreaResult:
    """Integrated edge intensities, white-line intensity and branching ratio.

    Generalises ``CalculateAreas`` from the Cp2VCl2 procedure.  ``e_a`` and
    ``e_b`` are whichever spin-orbit pair applies -- L3/L2 for a transition
    metal, M5/M4 for a lanthanide, N5/N4 for an actinide -- and all three
    integration windows are given explicitly rather than as fixed offsets.

    ``midline`` is the baseline fitted to the plateau between the two edges
    and ``endline`` the baseline above the second edge; the intensity above
    each is what is integrated.  Below the first edge the data are already
    pre-edge subtracted, so the baseline there is zero.  When both are
    omitted the raw integrated areas are returned.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(normalized, dtype=float)
    warn: list[str] = []

    e_min, e_max = float(np.nanmin(e)), float(np.nanmax(e))
    for name, (lo, hi) in (("edge A", window_a), ("edge B", window_b),
                           ("continuum", window_continuum)):
        if hi <= lo:
            warn.append(f"{name} window is reversed or empty "
                        f"({lo:.2f} -> {hi:.2f} eV)")
        if lo < e_min - 1e-9 or hi > e_max + 1e-9:
            warn.append(f"{name} window {lo:.2f}-{hi:.2f} eV extends beyond "
                        f"the measured range {e_min:.2f}-{e_max:.2f} eV")
    if window_a[1] > window_b[0] + 1e-9:
        warn.append("edge A and edge B windows overlap")

    def baseline_area(fit, lo, hi):
        return 0.0 if fit is None else area_xy(e, fit(e), lo, hi)

    # Edge A: no baseline below its maximum (pre-edge already removed),
    # midline baseline above it.
    a_lo, a_hi = window_a
    cut_a = min(max(e_a, a_lo), a_hi)
    area_a = (area_xy(e, y, a_lo, cut_a)
              + area_xy(e, y, cut_a, a_hi)
              - baseline_area(midline, cut_a, a_hi))

    # Edge B: midline baseline below its maximum, endline above it.
    b_lo, b_hi = window_b
    cut_b = min(max(e_b, b_lo), b_hi)
    area_b = (area_xy(e, y, b_lo, cut_b) - baseline_area(midline, b_lo, cut_b)
              + area_xy(e, y, cut_b, b_hi) - baseline_area(endline, cut_b, b_hi))

    cont = area_xy(e, y, *window_continuum)

    total = area_a + area_b
    wl = total / cont if cont else float("nan")
    br = area_a / total if total else float("nan")
    return EdgeAreaResult(
        edge_a=area_a, edge_b=area_b, continuum=cont,
        white_line=wl, branching_ratio=br,
        windows={"a": tuple(window_a), "b": tuple(window_b),
                 "continuum": tuple(window_continuum)},
        warnings=warn,
    )
