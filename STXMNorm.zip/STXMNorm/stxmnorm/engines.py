"""
engines.py -- one interface over two genuinely different normalizations.

Background
----------
XASNorm unified two Igor procedures that turned out to be *algebraically
identical*: the difference was interface and default model, so one
pipeline with exposed settings covered both.  That trick does not work
here.  The edge-step route and the McMaster route answer different
questions:

  edge-step (Branson / Cp2VCl2 / Athena lineage)
      pre  = fit(pre-edge window)            empirical: Victoreen or poly
      sub  = I - pre
      post = fit(post-edge window of sub)
      norm = sub / post(E_norm)
      -> dimensionless, edge jump defined as 1, no reference to theory,
         no element identity required.

  McMaster (norm2poly / Penner-Hahn lineage)
      y ~ c0*mu_McMaster + sum_j c_j P_j(x)   ONE simultaneous solve over
                                              the union of both windows
      norm = (y - poly part) * span_mu / c0 + mid_mu
      -> absolute cm^2/g on the McMaster atomic scale; needs the element,
         and needs McMaster to tabulate an edge inside the scan.

Three real differences, not cosmetic ones:

1. **Sequential vs simultaneous.**  Edge-step fits the pre-edge, commits
   to it, then fits the post-edge of the residual.  A pre-edge error
   propagates in full.  McMaster fits background and edge step together,
   so the two trade off against each other in one solve -- more robust to
   a marginal pre-edge window, but it cannot show you a pre-edge fit that
   is independent of the edge-step estimate.

2. **Empirical vs theoretical edge step.**  Edge-step reads the step off
   your own data (value of the post-edge fit at E_norm).  McMaster takes
   the *shape and size* of the step from a 1969 table and fits only its
   amplitude, so the result carries physical units -- and carries the
   table's errors too.

3. **Scale.**  "Edge jump = 1" vs "cm^2/g".  These are not convertible
   without the element, the McMaster table, and the assumption that the
   sample's atomic absorption matches it.

So: **toggle, not merge.**  What *is* shared, and is what makes the
workflow feel like one program, is everything around the solve -- import
of aXis2000 ratioed files, the four window edges, drag-to-set on the
plot, I0 handling, binning, calibration, averaging, export.  Both engines
consume the same ``UnifiedParams`` and return the same ``EngineResult``,
so every surrounding stage is written once.

The window edges deliberately persist across a toggle.  pre_lo/pre_hi and
post_lo/post_hi mean the same thing to both engines, so switching is a
one-click comparison rather than a re-setup.

Soft X-ray caveat
-----------------
McMaster's tabulation stops at the M1 edge.  For lanthanides that is
around 1.5 keV, so Ln M4,5 white lines at 900-1000 eV -- the main reason
this program exists -- fall below the table entirely and the McMaster
engine simply cannot run.  Transition-metal L2,3 edges (Ti 454, V 512,
Mn 639, Fe 707, Cu 932 eV) *are* inside it, because McMaster tabulates
L3.  But below that L3 edge the table is an extrapolation of the M-shell
fit stretched over a factor of ~7 in energy, and it returns a few cm^2/g
where the true value is thousands.  The algorithm zeroes the template's
pre-edge before fitting, so this does not corrupt the solve -- but it
does mean the absolute scale rests on a jump magnitude the table is not
really qualified to supply at these energies.  ``mcmaster_caveat``
returns the appropriate warning and the GUI shows it in the fit report.
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Sequence

import numpy as np

from . import core, mcmaster

__all__ = [
    "ENGINES", "UnifiedParams", "EngineResult",
    "normalize", "compare_engines", "mcmaster_caveat",
    "mcmaster_energy_range", "MCMASTER_EDGES",
    "mcmaster_edge_energies", "mcmaster_default_windows",
    "mcmaster_placeholder_floor", "mcmaster_window_check",
]


ENGINES = {
    "edgestep": (
        "Edge step  (normalize to edge jump = 1)",
        "Sequential: fit and subtract the pre-edge, fit the post-edge of "
        "the residual, divide by its value at the normalization energy. "
        "Empirical, element-agnostic, works at any energy.",
    ),
    "mcmaster": (
        "McMaster  (normalize to absolute cm\u00b2/g)",
        "Simultaneous: one least-squares solve fits a Legendre polynomial "
        "background and the amplitude of the tabulated McMaster edge step "
        "together, over both windows at once. Needs the element, and needs "
        "McMaster to tabulate an edge inside the scan.",
    ),
}

# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

@dataclass
class UnifiedParams:
    """Settings for either engine.

    The four window edges are shared deliberately: they mean the same
    thing to both engines, so toggling engine keeps the workflow intact.
    Engine-specific fields are ignored by the engine they do not belong
    to, and are kept (not cleared) so toggling back is lossless.
    """

    engine: str = "edgestep"

    # --- shared by both engines -------------------------------------
    pre_lo: float = 0.0
    pre_hi: float = 0.0
    post_lo: float = 0.0
    post_hi: float = 0.0

    # --- edge-step engine only --------------------------------------
    pre_model: str = "victoreen"
    post_model: str = "linear"
    norm_energy: float = 0.0
    exclude: list[tuple[float, float]] = field(default_factory=list)
    flatten: bool = False
    spoint: bool = False               # cosmetic Cp2VCl2 pre-scale
    #: None = auto (Igor's unconstrained fit, with a constrained retry if
    #: it inverts the spectrum); True = always constrain; False = never
    nonnegative_pre: bool | None = None
    #: "edge" | "area" | "peak" -- what the spectrum is divided by.
    #: Area and peak need no edge step, which is what makes them usable
    #: where the continuum jump is small or unmeasurable.
    scale_mode: str = "edge"
    scale_lo: float = 0.0
    scale_hi: float = 0.0
    #: reproduce Igor's grid-snapped edge step (see core.NormParams)
    snap_norm_energy: bool = False
    #: Strict Igor Pro reproduction: never constrain the pre-edge fit and
    #: read the edge step at a measured point. Overrides the two settings
    #: above while it is on, so an old result can be reproduced exactly
    #: without having to remember which switches that needs.
    igor_strict: bool = False

    # --- McMaster engine only ---------------------------------------
    element: str = ""                  # symbol, e.g. "V"
    edge: str = "K"                    # which tabulated edge: K, L1..L3, M1
    e0: float = 0.0                    # edge energy in eV; 0 -> from the table
    poly_order: int = 2                # Legendre order n_th
    #: edge jump used by "Normalize to 1". None -> mu_ref at the last
    #: scan point, which is norm2poly's definition.
    edge_step: float | None = None
    norm_to_one: bool = False          # show divided by the edge jump

    # ---------------------------------------------------------------
    def to_norm_params(self) -> core.NormParams:
        """Project onto the edge-step engine's parameter object."""
        return core.NormParams(
            pre_lo=self.pre_lo, pre_hi=self.pre_hi, pre_model=self.pre_model,
            post_lo=self.post_lo, post_hi=self.post_hi,
            post_model=self.post_model,
            norm_energy=self.norm_energy,
            exclude=list(self.exclude),
            flatten=self.flatten,
            initial_spoint_energy=(self.norm_energy if self.spoint else None),
            nonnegative_pre=(False if self.igor_strict
                             else self.nonnegative_pre),
            snap_norm_energy=self.snap_norm_energy or self.igor_strict,
            scale_mode=self.scale_mode, scale_lo=self.scale_lo,
            scale_hi=self.scale_hi,
        )

    def to_dict(self) -> dict:
        d = asdict(self)
        d["exclude"] = [list(x) for x in self.exclude]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "UnifiedParams":
        d = dict(d)
        d["exclude"] = [tuple(x) for x in d.get("exclude", [])]
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class EngineResult:
    """What every engine returns, so the GUI draws one way for both."""

    engine: str
    energy: np.ndarray
    raw: np.ndarray                 # input to the solve (post ratio/bin/shift)
    background: np.ndarray          # what gets subtracted from raw
    normalized: np.ndarray
    edge_step: float                # in the units of `raw`
    units: str                      # y-label for the normalized panel
    report: str
    warnings: list[str] = field(default_factory=list)

    #: extra curves for the raw panel: (label, y, style-hint)
    overlays: list[tuple[str, np.ndarray, str]] = field(default_factory=list)
    #: curve to draw alongside the normalized data, e.g. the McMaster
    #: reference the fit is matching: (label, y)
    reference: tuple[str, np.ndarray] | None = None
    #: engine-specific detail, kept for export provenance
    detail: dict = field(default_factory=dict)

    def unit_jump(self) -> np.ndarray:
        """Normalized data rescaled so the edge jump is 1.

        Lets the two engines be overlaid, averaged and exported together.
        For the edge-step engine this is already the case.
        """
        if self.engine == "edgestep" or self.detail.get("norm_to_one"):
            return self.normalized
        step = self.edge_step
        if step and np.isfinite(step):
            return self.normalized / step
        return self.normalized


# ---------------------------------------------------------------------------
# Engine 1 -- edge step
# ---------------------------------------------------------------------------

def _run_edgestep(energy, intensity, p: UnifiedParams) -> EngineResult:
    r = core.normalize_scan(energy, intensity, p.to_norm_params())
    return EngineResult(
        engine="edgestep",
        energy=r.energy,
        raw=r.raw,
        background=r.pre_fit,
        normalized=r.normalized,
        edge_step=r.divisor,
        units=f"Normalized  ({r.scale_label})",
        report=r.report(),
        warnings=list(r.warnings),
        overlays=[
            ("pre-edge fit", r.pre_fit, "bg"),
            ("post-edge fit + pre-edge", r.post_fit + r.pre_fit, "post"),
        ],
        detail={
            "pre_model": p.pre_model, "post_model": p.post_model,
            "pre_coef": r.pre_result.coefficients.tolist(),
            "post_coef": r.post_result.coefficients.tolist(),
            "pre_r2": r.pre_result.r_squared,
            "post_r2": r.post_result.r_squared,
            "norm_energy": p.norm_energy,
            "rescued": bool(getattr(r, "rescued", False)),
            "scale_mode": p.scale_mode,
            "fitted_edge_step": r.edge_step,
        },
    )


# ---------------------------------------------------------------------------
# Engine 2 -- McMaster
# ---------------------------------------------------------------------------

def mcmaster_energy_range(symbol: str) -> tuple[float, float] | None:
    """(lowest, highest) energy in eV that ``mcmaster()`` will accept.

    The floor is the M1 edge; above it the table runs to 1 MeV.  Returns
    None if the element is not in the table at all.
    """
    try:
        Z = mcmaster.zymbol(symbol)
        if Z is None or Z in mcmaster.NO_DATA or not (1 <= Z <= 94):
            return None
        el = mcmaster.elements()[Z]
        return float(el.M_edge * 1000.0), 1.0e6
    except Exception:
        return None


def mcmaster_caveat(symbol: str, e_lo: float, e_hi: float) -> list[str]:
    """Warnings about using the McMaster table over [e_lo, e_hi] eV.

    Separated from the solve so the GUI can warn *before* the user
    commits to an engine that cannot run.
    """
    out: list[str] = []
    Z = mcmaster.zymbol(symbol)
    if Z is None:
        return [f"{symbol!r} is not an element symbol."]
    if Z in mcmaster.NO_DATA:
        return [f"McMaster did not tabulate {mcmaster.symbol_of(Z)}; "
                "use the edge-step engine."]
    if Z > 94:
        return ["McMaster stops at Z = 94."]

    el = mcmaster.elements()[Z]
    m1 = el.M_edge * 1000.0
    if e_lo < m1:
        out.append(
            f"scan starts at {e_lo:.1f} eV but McMaster's tabulation for "
            f"{mcmaster.symbol_of(Z)} stops at the M1 edge, {m1:.0f} eV. "
            "The McMaster engine cannot run here -- use the edge-step "
            "engine, which needs no reference table.")
        return out

    l3 = el.L_edge[2] * 1000.0
    k = el.K_edge * 1000.0
    edges_inside = [(name, ev) for name, ev in
                    (("M1", m1), ("L3", l3), ("L2", el.L_edge[1] * 1000.0),
                     ("L1", el.L_edge[0] * 1000.0), ("K", k))
                    if e_lo < ev < e_hi]
    if not edges_inside:
        out.append(
            "McMaster tabulates no absorption edge inside this scan "
            f"({e_lo:.1f}-{e_hi:.1f} eV), so the edge-step template is "
            "featureless and its amplitude c0 is not determined. Widen the "
            "scan or use the edge-step engine.")
    if e_hi < 1000.0:
        out.append(
            "below ~1 keV the McMaster compilation is an extrapolation and "
            "is widely regarded as unreliable; the sub-L3 values it returns "
            "here are orders of magnitude too small. The fit is still "
            "self-consistent (the template's pre-edge is zeroed before "
            "fitting) but treat the absolute cm\u00b2/g scale as indicative "
            "only, and prefer Henke/CXRO for soft X-ray cross-sections.")
    return out


#: edges McMaster tabulates, in the order norm2poly offers them
MCMASTER_EDGES = ("K", "L1", "L2", "L3", "M1")


def mcmaster_edge_energies(symbol: str) -> dict[str, float]:
    """Tabulated edge energies in eV, skipping ones McMaster leaves at 0."""
    Z = mcmaster.zymbol(symbol)
    if Z is None or Z in mcmaster.NO_DATA or not (1 <= Z <= 94):
        return {}
    el = mcmaster.elements()[Z]
    out = {"K": el.K_edge * 1000.0,
           "L1": el.L_edge[0] * 1000.0,
           "L2": el.L_edge[1] * 1000.0,
           "L3": el.L_edge[2] * 1000.0,
           "M1": el.M_edge * 1000.0}
    return {k: v for k, v in out.items() if v > 0}


def mcmaster_default_windows(e0: float, e_lo: float, e_hi: float
                             ) -> tuple[float, float, float, float]:
    """norm2poly's default_range(): windows placed around the edge.

    20 eV and 80 eV suit a hard X-ray scan several hundred eV wide. A soft
    X-ray edge is often measured over only 50 eV, where those gaps fall
    outside the scan entirely, so they scale down with it.
    """
    span = float(e_hi - e_lo)
    d1 = min(20.0, 0.10 * span)
    d2 = min(80.0, 0.20 * span)
    return (e_lo, e0 - d1, e0 + d2, e_hi)


def mcmaster_placeholder_floor(symbol: str) -> bool:
    """True when McMaster's sub-L3 photoabsorption for this element is a
    stored placeholder rather than a measurement.

    ``element.mat`` holds an all-zero ``post_M`` block for H through Cu.
    ``mcmaster()`` evaluates that as exp(polyval(0, log E)) = 1 barn at
    every energy below L3, so the "cross-section" there is a constant
    placeholder. It does not corrupt the solve -- ``n2p_compute`` fits a
    line through the template's pre-edge window and subtracts it, which
    sends a near-constant to zero -- but it does mean the edge step is
    measured from a placeholder baseline, and for an element whose scan
    lies *entirely* below its lowest real edge the template has no
    structure at all.
    """
    Z = mcmaster.zymbol(symbol)
    if Z is None or Z in mcmaster.NO_DATA or not (1 <= Z <= 94):
        return False
    return not np.any(mcmaster.elements()[Z].post_M)


def mcmaster_window_check(symbol: str, pre_hi: float, post_lo: float,
                          e_lo: float, e_hi: float,
                          pre_lo: float | None = None,
                          post_hi: float | None = None) -> list[str]:
    """Are the windows placed so the McMaster template is well defined?

    This is the condition that actually matters, and it is *not* whether
    the tabulated edge agrees with where the data's edge is.

    ``n2p_compute`` levels the template to zero across the pre-edge window
    and fits its amplitude against the post-edge window. So the template
    is well defined whenever a tabulated edge falls in the gap between the
    two windows: zero below, the real tabulated continuum above, and one
    free amplitude in between. Where the *sample's* own edge sits is
    irrelevant to that fit.

    Carbon is the case worth remembering. McMaster puts the C K edge at
    295.0 eV; the real one is at 284.2 eV. An earlier version of this
    program refused the fit on that 10.8 eV discrepancy, which was simply
    wrong -- with the windows at 260-282.9 and 299.3-379.5 the tabulated
    edge sits cleanly in the gap and the fit is sound. The mismatch shows
    up only in the *interpretation*: the McMaster reference curve steps at
    295 eV while your data steps at 284, which is visible on the plot and
    is the user's to judge.
    """
    out: list[str] = []
    edges = mcmaster_edge_energies(symbol)
    if not edges:
        return out

    # An edge *inside* either window is worse than one in neither. The
    # template is levelled by fitting a straight line across the pre-edge
    # window; if a tabulated edge sits in there the line is fitted across
    # a jump of several thousand cm^2/g, the extrapolation runs away, and
    # the edge step can come out negative -- which silently flips the sign
    # of everything downstream. Seen on V L2,3 with a pre-edge window
    # ending at 513.0 eV against a tabulated L3 of 512.1: edge step
    # -24512 cm^2/g and a white line of -2.8 where it should be +7.1.
    for name, (lo, hi) in (("pre-edge", (pre_lo, pre_hi)),
                           ("post-edge", (post_lo, post_hi))):
        if lo is None or hi is None:
            continue
        inside_win = {k: v for k, v in edges.items() if lo < v < hi}
        if inside_win:
            names = ", ".join(f"{k} at {v:.1f} eV" for k, v in
                              inside_win.items())
            out.append(
                f"the {name} window {lo:.1f}-{hi:.1f} eV contains a "
                f"tabulated edge ({names}). The template is levelled by a "
                "straight line across that window, so a jump inside it "
                "corrupts the fit and can give a negative edge step. Move "
                f"the window clear of it.")

    inside = {k: v for k, v in edges.items() if pre_hi < v < post_lo}
    if not inside:
        in_scan = {k: v for k, v in edges.items() if e_lo < v < e_hi}
        if in_scan:
            names = ", ".join(f"{k} {v:.1f} eV" for k, v in in_scan.items())
            out.append(
                f"no tabulated edge falls between the windows. "
                f"{mcmaster.symbol_of(mcmaster.zymbol(symbol))} has {names} "
                "inside the scan -- move the pre-edge window below one of "
                "them and the post-edge window above it, so the template "
                "has a step to fit.")
        else:
            out.append(
                "McMaster tabulates no absorption edge inside this scan, so "
                "the template is featureless and its amplitude is not "
                "determined. Use the edge-step engine.")
    return out


def _run_mcmaster(energy, intensity, p: UnifiedParams) -> EngineResult:
    e = np.asarray(energy, float)
    y = np.asarray(intensity, float)
    good = np.isfinite(e) & np.isfinite(y)
    e, y = e[good], y[good]

    if not p.element:
        raise ValueError(
            "The McMaster engine needs an element symbol -- it normalizes "
            "to that element's tabulated atomic cross-section. Set it in "
            "the parameter panel, or switch to the edge-step engine, which "
            "needs no element.")
    Z = mcmaster.zymbol(p.element)
    if Z is None:
        raise ValueError(f"{p.element!r} is not an element symbol.")

    warn = mcmaster_caveat(p.element, float(e.min()), float(e.max()))
    if warn and "cannot run here" in warn[0]:
        raise ValueError(warn[0])
    warn += mcmaster_window_check(p.element, p.pre_hi, p.post_lo,
                                  float(e.min()), float(e.max()),
                                  p.pre_lo, p.post_hi)

    res = mcmaster.n2p_compute(e, y, Z, int(p.poly_order),
                               (p.pre_lo, p.pre_hi, p.post_lo, p.post_hi))

    xabs = res.Xabs
    mu_ref = res.mu_ref
    el = mcmaster.elements()[Z]

    # norm2poly's edge jump: the McMaster reference at the last point of
    # the scan, i.e. the level the far post-edge is being matched to.
    auto_step = float(mu_ref[-1]) if mu_ref.size else float("nan")
    step = p.edge_step if p.edge_step else auto_step

    units = "\u03bc/\u03c1  (cm\u00b2/g)"
    if p.scale_mode in ("area", "peak"):
        lo_s, hi_s = sorted((float(p.scale_lo), float(p.scale_hi)))
        m = (e >= lo_s) & (e <= hi_s) & np.isfinite(xabs)
        if m.sum() < 2:
            raise ValueError(
                f"The {p.scale_mode} window {lo_s:g}-{hi_s:g} eV contains "
                f"{int(m.sum())} points.")
        d = (float(np.trapezoid(xabs[m], e[m])) if p.scale_mode == "area"
             else float(np.nanmax(xabs[m])))
        if not np.isfinite(d) or d == 0:
            raise ValueError(f"The {p.scale_mode} is {d!r}; nothing to "
                             "normalize to.")
        xabs = xabs / d
        mu_ref = mu_ref / d
        units = (f"Normalized  (area = 1 over {lo_s:g}-{hi_s:g} eV)"
                 if p.scale_mode == "area"
                 else f"Normalized  (peak = 1 in {lo_s:g}-{hi_s:g} eV)")
        step = d
    elif p.norm_to_one:
        if not (np.isfinite(step) and step != 0):
            raise ValueError("The edge jump must be a non-zero number.")
        xabs = xabs / step
        mu_ref = mu_ref / step
        units = "Normalized  (edge jump = 1)"

    # where the tabulated edge sits, for the plot and the report
    edges = mcmaster_edge_energies(p.element)
    e0 = p.e0 if p.e0 else edges.get(p.edge, 0.0)

    C = np.asarray(res.C, float)
    coef = "  ".join(f"c{i}={v:.5g}" for i, v in enumerate(C))
    report = (
        f"McMaster engine, {mcmaster.symbol_of(Z)} (Z={Z}) {p.edge} edge"
        + (f" at {e0:.1f} eV" if e0 else "")
        + f", Legendre order {p.poly_order}\n"
        f"  windows: pre {p.pre_lo:.2f}-{p.pre_hi:.2f} eV ({res.n1} pts), "
        f"post {p.post_lo:.2f}-{p.post_hi:.2f} eV ({res.n2} pts)\n"
        f"  one simultaneous solve over {res.n1 + res.n2} points\n"
        f"  {coef}\n"
        f"  edge-step amplitude c0 = {C[0]:.6g}   "
        f"(c0 = measured step / McMaster step)\n"
        f"  residual rms over both windows = {res.rms:.4g}\n"
        f"  McMaster step (\u03bc at {e[-1]:.1f} eV) = {auto_step:.1f} cm\u00b2/g"
        + ("   [edge jump entered by hand: "
           f"{step:.6g}]" if p.edge_step else "")
        + ("\n  displayed divided by the edge jump" if p.norm_to_one else "")
    )

    if abs(C[0]) < 1e-6:
        warn.append("c0 is essentially zero: the data carry no edge step "
                    "matching the McMaster template.")
    if C[0] < 0:
        warn.append("c0 is negative, meaning the fit found a step of the "
                    "wrong sign. Check the element and the windows.")
    if auto_step < 0:
        warn.append(
            f"the edge step came out negative ({auto_step:.1f} cm\u00b2/g), "
            "which flips the sign of the normalized spectrum. This almost "
            "always means a tabulated edge lies inside one of the fit "
            "windows.")
    if e0 and not (e.min() < e0 < e.max()):
        warn.append(f"the {p.edge} edge ({e0:.1f} eV) is outside this scan.")

    return EngineResult(
        engine="mcmaster",
        energy=e,
        raw=y,
        background=res.bg_raw,
        normalized=xabs,
        edge_step=float(step),
        units=units,
        report=report,
        warnings=warn,
        overlays=[("polynomial background", res.bg_raw, "bg")],
        reference=("McMaster", mu_ref),
        detail={
            "element": mcmaster.symbol_of(Z), "Z": Z,
            "poly_order": int(p.poly_order),
            "C": C.tolist(), "rms": float(res.rms),
            "mu_ref": mu_ref, "auto_edge_step": auto_step,
            "edge": p.edge, "e0": e0,
            "norm_to_one": bool(p.norm_to_one),
        },
    )


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_RUN = {"edgestep": _run_edgestep, "mcmaster": _run_mcmaster}


def normalize(energy, intensity, p: UnifiedParams) -> EngineResult:
    """Normalize with whichever engine ``p.engine`` selects."""
    try:
        fn = _RUN[p.engine]
    except KeyError:
        raise ValueError(f"unknown engine {p.engine!r}") from None
    return fn(energy, intensity, p)


def compare_engines(energy, intensity, p: UnifiedParams
                    ) -> dict[str, EngineResult | str]:
    """Run both engines on the same data and windows.

    Returns ``{"edgestep": EngineResult|str, "mcmaster": ...}`` where a
    string is the reason that engine could not run.  Used by the Compare
    tab, whose whole point is to make the difference between the two
    philosophies visible on your own data rather than described in a
    README.
    """
    out: dict[str, EngineResult | str] = {}
    for name in ("edgestep", "mcmaster"):
        q = UnifiedParams(**{**p.to_dict(), "engine": name})
        q.exclude = list(p.exclude)
        try:
            out[name] = normalize(energy, intensity, q)
        except Exception as ex:                      # noqa: BLE001
            out[name] = str(ex)
    return out
