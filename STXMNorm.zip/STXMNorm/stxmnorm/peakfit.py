"""
peakfit.py -- lineshape fitting for normalized XAS.

Generalises ``twoGauss`` / ``twoPsV`` and the ``fitTwoPeaks*`` wrappers from
``Cp2VCl2_STXM_Apr12_VL_General_Procs.ipf``.

Changes from the Igor originals
-------------------------------
* Any number of peaks, not exactly two.
* An edge step can be fitted alongside the peaks.  Neither Igor function
  had one, so the continuum step under an L3/L2 or M5/M4 pair had to be
  absorbed by the peak amplitudes, which inflates them.
* ``twoPsV`` hard-coded a 50/50 Gaussian/Lorentzian mix and wrote it as
  ``a/2*(G + L)``, so the reported amplitude was half the peak height.
  Here pseudo-Voigt uses the standard ``eta*L + (1-eta)*G`` form with both
  components normalised to unit height, so ``amplitude`` is the peak
  height and ``eta`` is refinable (or held at 0.5 to match the original).
* Igor ran ``FuncFit/H="010010"`` (centres held) and then a free pass.
  That two-stage recipe is available as ``stage_centers=True``, but any
  parameter can be held or bounded individually.
* Peak areas and their fractions are reported analytically, so a branching
  ratio comes from the fitted lineshapes rather than from trapezoidal
  integration between hand-placed limits.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Sequence

import numpy as np
from scipy.optimize import curve_fit

__all__ = [
    "Component", "PeakModel", "FitReport", "COMPONENT_KINDS",
    "gaussian", "lorentzian", "pseudo_voigt", "arctan_step", "erf_step",
    "guess_peaks",
]

_G_AREA = math.sqrt(math.pi / (4.0 * math.log(2.0)))   # 1.06447


# ---------------------------------------------------------------------------
# Lineshapes
# ---------------------------------------------------------------------------

def gaussian(x, amplitude, center, fwhm):
    """Unit-height Gaussian; ``amplitude`` is the peak height."""
    fwhm = max(float(fwhm), 1e-9)
    return amplitude * np.exp(-4.0 * math.log(2.0) * (x - center) ** 2 / fwhm ** 2)


def lorentzian(x, amplitude, center, fwhm):
    """Unit-height Lorentzian; ``amplitude`` is the peak height."""
    hw = max(float(fwhm), 1e-9) / 2.0
    return amplitude * hw ** 2 / ((x - center) ** 2 + hw ** 2)


def pseudo_voigt(x, amplitude, center, fwhm, eta):
    """eta * Lorentzian + (1 - eta) * Gaussian, both of unit height.

    eta = 0.5 reproduces Igor's ``twoPsV`` exactly. Igor writes it as
    ``a/2 * (Gaussian + Lorentzian)``, which is algebraically the same
    thing, and for the same ``a`` it gives the same peak height -- the
    two conventions agree. An earlier comment here claimed they differed
    by a factor of two; they do not, and halving the amplitude to
    "correct" for it introduces a 50% error.
    """
    eta = min(max(float(eta), 0.0), 1.0)
    return (eta * lorentzian(x, amplitude, center, fwhm)
            + (1.0 - eta) * gaussian(x, amplitude, center, fwhm))


def arctan_step(x, height, center, width):
    """Arctangent edge step rising from 0 to ``height``."""
    width = max(float(width), 1e-9)
    return height * (np.arctan((x - center) / (width / 2.0)) / math.pi + 0.5)


def erf_step(x, height, center, width):
    """Error-function edge step rising from 0 to ``height``."""
    from scipy.special import erf
    width = max(float(width), 1e-9)
    return height * 0.5 * (1.0 + erf((x - center)
                                     / (width / (2.0 * math.sqrt(math.log(2.0))))))


def _linear(x, slope, intercept):
    return slope * x + intercept


def _constant(x, level):
    return np.full_like(np.asarray(x, dtype=float), float(level))


#: kind -> (callable, parameter names, is a peak)
COMPONENT_KINDS: dict[str, tuple] = {
    "gaussian": (gaussian, ("amplitude", "center", "fwhm"), True),
    "lorentzian": (lorentzian, ("amplitude", "center", "fwhm"), True),
    "pseudo_voigt": (pseudo_voigt, ("amplitude", "center", "fwhm", "eta"), True),
    "arctan_step": (arctan_step, ("height", "center", "width"), False),
    "erf_step": (erf_step, ("height", "center", "width"), False),
    "linear": (_linear, ("slope", "intercept"), False),
    "constant": (_constant, ("level",), False),
}

KIND_LABELS = {
    "gaussian": "Gaussian",
    "lorentzian": "Lorentzian",
    "pseudo_voigt": "Pseudo-Voigt",
    "arctan_step": "Arctangent step",
    "erf_step": "Error-function step",
    "linear": "Linear baseline",
    "constant": "Constant baseline",
}


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

@dataclass
class Component:
    kind: str
    label: str = ""
    values: dict[str, float] = field(default_factory=dict)
    fixed: set[str] = field(default_factory=set)
    bounds: dict[str, tuple[float, float]] = field(default_factory=dict)

    def __post_init__(self):
        if self.kind not in COMPONENT_KINDS:
            raise ValueError(f"unknown component kind {self.kind!r}")
        for name in self.param_names:
            self.values.setdefault(name, self._default(name))
        if not self.label:
            self.label = KIND_LABELS[self.kind]

    @property
    def param_names(self) -> tuple[str, ...]:
        return COMPONENT_KINDS[self.kind][1]

    @property
    def is_peak(self) -> bool:
        return COMPONENT_KINDS[self.kind][2]

    def _default(self, name: str) -> float:
        return {"amplitude": 1.0, "height": 1.0, "center": 0.0, "fwhm": 1.0,
                "width": 1.0, "eta": 0.5, "slope": 0.0, "intercept": 0.0,
                "level": 0.0}[name]

    def default_bounds(self, name: str) -> tuple[float, float]:
        if name in self.bounds:
            return self.bounds[name]
        if name in ("amplitude", "height"):
            return (0.0, np.inf)
        if name in ("fwhm", "width"):
            return (1e-3, np.inf)
        if name == "eta":
            return (0.0, 1.0)
        return (-np.inf, np.inf)

    def evaluate(self, x) -> np.ndarray:
        fn = COMPONENT_KINDS[self.kind][0]
        return fn(np.asarray(x, dtype=float),
                  *[self.values[n] for n in self.param_names])

    def area(self) -> float:
        """Analytic integrated area; NaN for non-peak components.

        This is the integral over all energies, not the area inside the
        fit window.  Lorentzian tails are heavy: a Lorentzian of FWHM
        1.7 eV keeps about 3% of its area beyond +/-20 eV of the centre.
        For a branching ratio that is normally what you want -- the full
        oscillator strength of each transition -- but it is not the same
        number as trapezoidal integration between two limits, which is
        what Analysis / Compute areas reports.
        """
        if not self.is_peak:
            return float("nan")
        a = self.values["amplitude"]
        w = self.values["fwhm"]
        if self.kind == "gaussian":
            return a * w * _G_AREA
        if self.kind == "lorentzian":
            return a * math.pi * w / 2.0
        eta = self.values.get("eta", 0.5)
        return a * (eta * math.pi * w / 2.0 + (1.0 - eta) * w * _G_AREA)

    def to_dict(self) -> dict:
        return {"kind": self.kind, "label": self.label,
                "values": dict(self.values), "fixed": sorted(self.fixed),
                "bounds": {k: list(v) for k, v in self.bounds.items()}}

    @classmethod
    def from_dict(cls, d: dict) -> "Component":
        return cls(kind=d["kind"], label=d.get("label", ""),
                   values=dict(d.get("values", {})),
                   fixed=set(d.get("fixed", [])),
                   bounds={k: tuple(v) for k, v in d.get("bounds", {}).items()})


@dataclass
class FitReport:
    components: list[Component]
    energy: np.ndarray
    data: np.ndarray
    total: np.ndarray
    residual: np.ndarray
    curves: list[np.ndarray]
    stderr: list[dict[str, float]]
    areas: list[float]
    area_fractions: list[float]
    chi_square: float
    reduced_chi_square: float
    r_squared: float
    n_points: int
    n_free: int
    fit_range: tuple[float, float]
    message: str = ""

    def describe(self) -> str:
        lines = [
            f"Fitted {self.fit_range[0]:.2f}-{self.fit_range[1]:.2f} eV, "
            f"{self.n_points} points, {self.n_free} free parameters",
            f"R^2 = {self.r_squared:.6f}   reduced chi^2 = "
            f"{self.reduced_chi_square:.4g}",
            "",
        ]
        for comp, se, area, frac in zip(self.components, self.stderr,
                                        self.areas, self.area_fractions):
            lines.append(f"{comp.label}  [{KIND_LABELS[comp.kind]}]")
            for name in comp.param_names:
                val = comp.values[name]
                err = se.get(name, float("nan"))
                held = "  (held)" if name in comp.fixed else ""
                if np.isfinite(err):
                    lines.append(f"    {name:<10s} = {val: .6g}  +/- {err:.3g}{held}")
                else:
                    lines.append(f"    {name:<10s} = {val: .6g}{held}")
            if comp.is_peak:
                lines.append(f"    {'area':<10s} = {area: .6g}"
                             f"   ({frac:.1%} of total peak area)")
            lines.append("")
        peaks = [c for c in self.components if c.is_peak]
        if len(peaks) == 2:
            a, b = self.areas[self.components.index(peaks[0])], \
                self.areas[self.components.index(peaks[1])]
            if a + b:
                lines.append(f"Branching ratio  {peaks[0].label} / "
                             f"({peaks[0].label} + {peaks[1].label}) = "
                             f"{a / (a + b):.5f}")
        if self.message:
            lines.append(self.message)
        return "\n".join(lines).rstrip()


class PeakModel:
    """A sum of components fitted over an energy window."""

    def __init__(self, components: Sequence[Component] | None = None):
        self.components: list[Component] = list(components or [])

    # -- assembly ---------------------------------------------------------
    def add(self, kind: str, label: str = "", **values) -> Component:
        comp = Component(kind=kind, label=label, values=dict(values))
        self.components.append(comp)
        return comp

    def evaluate(self, x) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        total = np.zeros_like(x)
        for comp in self.components:
            total = total + comp.evaluate(x)
        return total

    # -- fitting ----------------------------------------------------------
    def _free_parameters(self) -> list[tuple[int, str]]:
        out = []
        for i, comp in enumerate(self.components):
            for name in comp.param_names:
                if name not in comp.fixed:
                    out.append((i, name))
        return out

    def fit(self, energy, intensity, lo: float | None = None,
            hi: float | None = None, stage_centers: bool = False,
            max_iterations: int = 20000, method: str = "trf") -> FitReport:
        """Least-squares refinement over [lo, hi].

        ``stage_centers`` reproduces the Igor recipe: one pass with every
        peak centre held, then a free pass.  It helps when the starting
        centres are good but the amplitudes are far off.

        ``method`` is "trf" (trust region, the default, honours bounds) or
        "lm" (Levenberg-Marquardt, what Igor's FuncFit uses). LM cannot
        take bounds at all, so choosing it drops them -- including the
        guard that keeps peak centres inside the fitted window. That is
        the price of reproducing an old Igor fit exactly, and it is why
        it is not the default.
        """
        e = np.asarray(energy, dtype=float)
        y = np.asarray(intensity, dtype=float)
        lo = float(np.nanmin(e)) if lo is None else float(lo)
        hi = float(np.nanmax(e)) if hi is None else float(hi)
        m = (e >= min(lo, hi)) & (e <= max(lo, hi)) & np.isfinite(y) & np.isfinite(e)
        if m.sum() < 3:
            raise ValueError(f"only {int(m.sum())} points in {lo:.2f}-{hi:.2f} eV")
        ex, yx = e[m], y[m]

        if not self.components:
            raise ValueError("no components to fit")

        cb = (float(ex.min()), float(ex.max()))

        message = ""
        if stage_centers:
            held = []
            for comp in self.components:
                if comp.is_peak and "center" not in comp.fixed:
                    comp.fixed.add("center")
                    held.append(comp)
            if held and self._free_parameters():
                try:
                    self._solve(ex, yx, max_iterations, center_bounds=cb,
                                method=method)
                except (RuntimeError, ValueError):
                    message = ("staged pass with centres held did not "
                               "converge; continued with the free fit")
            for comp in held:
                comp.fixed.discard("center")

        popt, perr, info = self._solve(ex, yx, max_iterations,
                                       center_bounds=cb, method=method)

        pinned = [f"{c.label} {n}" for c in self.components
                  for n in c.param_names
                  if n not in c.fixed and _at_bound(c, n, cb)]
        if pinned:
            info = ((info + "\n") if info else "") + (
                "parameters sitting on a bound: " + ", ".join(pinned) +
                " -- the model probably has more freedom than the data "
                "supports, or a starting value was far off")

        curves = [c.evaluate(e) for c in self.components]
        total = self.evaluate(e)
        resid_full = y - total
        resid = yx - self.evaluate(ex)
        n_free = len(self._free_parameters())
        dof = max(len(ex) - n_free, 1)
        chi2 = float(resid @ resid)
        tss = float(((yx - yx.mean()) ** 2).sum())
        r2 = 1.0 - chi2 / tss if tss > 0 else float("nan")

        areas = [c.area() for c in self.components]
        peak_total = sum(a for a, c in zip(areas, self.components)
                         if c.is_peak and np.isfinite(a))
        fractions = [(a / peak_total if (c.is_peak and peak_total) else float("nan"))
                     for a, c in zip(areas, self.components)]

        return FitReport(
            components=self.components, energy=e, data=y, total=total,
            residual=resid_full, curves=curves, stderr=perr, areas=areas,
            area_fractions=fractions, chi_square=chi2,
            reduced_chi_square=chi2 / dof, r_squared=r2, n_points=len(ex),
            n_free=n_free, fit_range=(float(ex.min()), float(ex.max())),
            message=(message + ("\n" if message and info else "") + info).strip(),
        )

    def _solve(self, ex, yx, max_iterations, center_bounds=None,
               method="trf"):
        free = self._free_parameters()
        if not free:
            raise ValueError("every parameter is held; nothing to refine")

        p0, lower, upper = [], [], []
        for ci, name in free:
            comp = self.components[ci]
            lo_b, hi_b = comp.default_bounds(name)
            # An unbounded centre can wander out of the data entirely when
            # a model has more peaks than the spectrum supports; the fit
            # then "converges" with a peak at an absurd energy. Keeping
            # centres inside the fitted window makes that impossible.
            if name == "center" and center_bounds and name not in comp.bounds:
                lo_b, hi_b = center_bounds
            # A width cannot exceed the window either.
            if name in ("fwhm", "width") and center_bounds and name not in comp.bounds:
                hi_b = min(hi_b, (center_bounds[1] - center_bounds[0]) * 2.0)
            val = float(comp.values[name])
            val = min(max(val, lo_b + 1e-12 if np.isfinite(lo_b) else val),
                      hi_b - 1e-12 if np.isfinite(hi_b) else val)
            p0.append(val)
            lower.append(lo_b)
            upper.append(hi_b)

        def model(x, *theta):
            for (ci, name), v in zip(free, theta):
                self.components[ci].values[name] = v
            return self.evaluate(x)

        info = ""
        try:
            # scipy warns when it cannot estimate the covariance; the
            # report already says so in plain words through `info`, and a
            # raw OptimizeWarning on the console helps nobody.
            import warnings as _w
            if method == "lm":
                # Levenberg-Marquardt, as Igor's FuncFit. It takes no
                # bounds, so the centre guard above is not applied.
                with _w.catch_warnings():
                    _w.simplefilter("ignore")
                    popt, pcov = curve_fit(model, ex, yx, p0=p0,
                                           maxfev=max_iterations,
                                           method="lm")
            else:
                with _w.catch_warnings():
                    _w.simplefilter("ignore")
                    popt, pcov = curve_fit(
                        model, ex, yx, p0=p0, bounds=(lower, upper),
                        maxfev=max_iterations, method="trf")
        except RuntimeError as exc:
            for (ci, name), v in zip(free, p0):
                self.components[ci].values[name] = v
            raise RuntimeError(f"fit did not converge: {exc}") from exc

        for (ci, name), v in zip(free, popt):
            self.components[ci].values[name] = float(v)

        with np.errstate(invalid="ignore"):
            diag = np.sqrt(np.clip(np.diag(pcov), 0.0, None)) \
                if pcov is not None else np.full(len(popt), np.nan)
        if pcov is None or not np.all(np.isfinite(diag)):
            info = ("uncertainties are unreliable: the parameters are "
                    "correlated or a bound is active")

        perr: list[dict[str, float]] = [dict() for _ in self.components]
        for (ci, name), err in zip(free, diag):
            perr[ci][name] = float(err)
        return popt, perr, info

    # -- persistence ------------------------------------------------------
    def to_list(self) -> list[dict]:
        return [c.to_dict() for c in self.components]

    @classmethod
    def from_list(cls, data: Sequence[dict]) -> "PeakModel":
        return cls([Component.from_dict(d) for d in data])


def _at_bound(comp: Component, name: str, cb, tol: float = 1e-6) -> bool:
    lo, hi = comp.default_bounds(name)
    if name == "center" and cb and name not in comp.bounds:
        lo, hi = cb
    if name in ("fwhm", "width") and cb and name not in comp.bounds:
        hi = min(hi, (cb[1] - cb[0]) * 2.0)
    v = comp.values[name]
    span = (hi - lo) if np.isfinite(hi - lo) else 1.0
    return ((np.isfinite(lo) and abs(v - lo) <= max(tol, abs(span) * tol))
            or (np.isfinite(hi) and abs(v - hi) <= max(tol, abs(span) * tol)))


# ---------------------------------------------------------------------------

def guess_peaks(energy, intensity, centers: Sequence[float],
                shape: str = "pseudo_voigt",
                with_step: bool = True,
                step_kind: str = "arctan_step") -> PeakModel:
    """Build a starting model from a list of approximate peak positions.

    Amplitudes are read off the data, widths are set from the spacing
    between neighbouring centres, and an optional edge step is placed at
    the first centre with its height taken from the post-edge level.
    """
    e = np.asarray(energy, dtype=float)
    y = np.asarray(intensity, dtype=float)
    centers = sorted(float(c) for c in centers)
    model = PeakModel()

    if with_step and centers:
        tail = y[e >= max(centers) + 3.0]
        height = float(np.nanmedian(tail)) if tail.size else float(np.nanmax(y) / 2)
        step = model.add(step_kind, label="Edge step",
                         height=max(height, 1e-6), center=centers[0],
                         width=max((centers[-1] - centers[0]) / 4.0, 1.0))
        baseline = step.evaluate(e)
    else:
        baseline = np.zeros_like(e)

    if len(centers) > 1:
        spacing = np.diff(centers)
        default_w = float(max(np.min(spacing) / 3.0, 0.5))
    else:
        default_w = 1.5

    for i, c in enumerate(centers, start=1):
        peak = float(np.interp(c, e, y) - np.interp(c, e, baseline))
        model.add(shape, label=f"Peak {i}",
                  amplitude=max(peak, 1e-6), center=c, fwhm=default_w,
                  **({"eta": 0.5} if shape == "pseudo_voigt" else {}))
    return model
