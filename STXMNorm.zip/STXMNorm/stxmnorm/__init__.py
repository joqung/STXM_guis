"""STXMNorm -- STXM/XAS normalization with two selectable engines."""
__version__ = "1.0"
