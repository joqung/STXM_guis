"""
app.py -- STXMNorm's interface.

Layout follows XASNorm: numbered tabs across the middle, a log along the
bottom, and drag-on-the-plot to set fit windows.  The scan list and the
parameter panel are tabbed together in the left dock, which gives the
plots the full width of the window.

The one structural addition is the **engine selector** at the top of the
parameter dock.  Engine-specific controls live in a QStackedWidget below
the shared window boxes, so the four window edges stay put when you
toggle -- switching engine is a comparison, not a re-setup.

Dark is the default theme; View remembers whichever you pick.
"""

from __future__ import annotations

import pathlib
import sys
import traceback

import matplotlib
matplotlib.use("QtAgg")

import numpy as np
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure
from matplotlib.widgets import SpanSelector

from PySide6.QtCore import Qt, QSettings, QTimer, Signal, QSize
from PySide6.QtGui import (QAction, QKeySequence, QColor, QPalette, QIcon,
                           QImage, QPainter, QPixmap)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox, QPushButton,
    QGroupBox, QTabWidget, QDockWidget, QPlainTextEdit, QFileDialog,
    QMessageBox, QListWidget, QListWidgetItem, QAbstractItemView, QSplitter,
    QTableWidget, QTableWidgetItem, QHeaderView, QRadioButton, QButtonGroup,
    QStackedWidget, QDialog, QDialogButtonBox, QLineEdit, QScrollArea,
)

from . import core, dataio, edges, engines, mcmaster, theme
from .peakfit_tab import PeakFitTab

APP_NAME = "STXMNorm"
APP_VERSION = "1.0"


# ---------------------------------------------------------------------------
# Small widgets
# ---------------------------------------------------------------------------

class EnergyBox(QDoubleSpinBox):
    """An eV entry that will not silently clamp a soft or hard X-ray value."""

    def __init__(self, value=0.0):
        super().__init__()
        self.setDecimals(3)
        self.setRange(-1e6, 1e6)
        self.setSingleStep(0.5)
        self.setSuffix(" eV")
        self.setValue(value)
        self.setKeyboardTracking(False)


class HoverCursor:
    """A readout that snaps to the nearest data point under the mouse.

    Drawn with blitting rather than a normal redraw. A full redraw of one
    of these panels costs about 66 ms; at that rate the marker would lag
    the mouse badly. Blitting restores a cached background and draws only
    the marker, which keeps a mouse-move under a millisecond.

    The marker artists carry a gid beginning with ``_cursor`` so the
    panel's own ``reset`` and ``settle`` can tell them apart from real
    data and leave them out of clearing and autoscaling.
    """

    GID = "_cursor"        # survives reset(); redrawn by the cursor itself
    MARK = "_mark"         # cleared by reset(); excluded from autoscale

    @staticmethod
    def is_decoration(artist):
        return artist.get_gid() in (HoverCursor.GID, HoverCursor.MARK)

    def __init__(self, panel):
        self.panel = panel
        self.background = None
        self.markers = {}
        self.vlines = {}
        c = panel.canvas
        self._cids = [
            c.mpl_connect("motion_notify_event", self.on_move),
            c.mpl_connect("axes_leave_event", self.on_leave),
            c.mpl_connect("figure_leave_event", self.on_leave),
            c.mpl_connect("draw_event", self.on_draw),
        ]

    # -- artists --------------------------------------------------------
    def _vline(self, ax):
        v = self.vlines.get(id(ax))
        if v is None or v.axes is not ax:
            v = ax.axvline(np.nan, lw=0.8, ls="-", alpha=0.55,
                           color=theme.T.guide, animated=True, zorder=19)
            v.set_gid(self.GID)
            self.vlines[id(ax)] = v
        return v

    def _marker(self, ax):
        m = self.markers.get(id(ax))
        if m is None or m.axes is not ax:
            m, = ax.plot([], [], marker="o", ms=7, mfc="none", mew=1.6,
                         ls="none", animated=True, zorder=20)
            m.set_gid(self.GID)
            self.markers[id(ax)] = m
        return m

    def on_draw(self, _event=None):
        """Cache the clean background after every real draw."""
        try:
            self.background = self.panel.canvas.copy_from_bbox(
                self.panel.figure.bbox)
        except Exception:                            # noqa: BLE001
            self.background = None

    def on_leave(self, _event=None):
        """Hide the cursor and drop its artists.

        Blanking them was not enough. An animated artist is skipped when
        it is painted, but simply having the marker and the guide line in
        the axes doubled the cost of every ordinary redraw -- 123 ms
        against 67 ms on a two-panel figure -- because the axes still
        walks and transforms them. They are cheap to rebuild on the next
        mouse move, so they only exist while the pointer is over the plot.
        """
        had = bool(self.markers or self.vlines)
        for art in list(self.markers.values()) + list(self.vlines.values()):
            try:
                art.remove()
            except (ValueError, NotImplementedError):
                pass
        self.markers.clear()
        self.vlines.clear()
        self.panel.set_readout("")
        if had and self.background is not None:
            self._blit()

    # -- the snap -------------------------------------------------------
    @staticmethod
    def _nearest(ax, event):
        """Nearest plotted point to the mouse, measured on screen.

        Screen distance rather than data distance, because the two axes
        have wildly different units -- eV against cm^2/g -- and a data
        metric would be dominated by whichever happens to be larger.
        """
        best = None
        for line in ax.lines:
            if line.get_gid() == HoverCursor.GID or not line.get_visible():
                continue
            xd = np.asarray(line.get_xdata(), float)
            yd = np.asarray(line.get_ydata(), float)
            if xd.size == 0 or xd.size != yd.size:
                continue
            good = np.isfinite(xd) & np.isfinite(yd)
            if not good.any():
                continue
            xd, yd = xd[good], yd[good]
            # narrow by x first: a spectrum has many points and
            # transforming all of them on every mouse move is wasteful
            i = int(np.argmin(np.abs(xd - event.xdata)))
            lo, hi = max(0, i - 6), min(xd.size, i + 7)
            pts = ax.transData.transform(np.column_stack([xd[lo:hi],
                                                          yd[lo:hi]]))
            d = np.hypot(pts[:, 0] - event.x, pts[:, 1] - event.y)
            j = int(np.argmin(d))
            if best is None or d[j] < best[0]:
                best = (float(d[j]), float(xd[lo + j]), float(yd[lo + j]),
                        line)
        return best

    def on_move(self, event):
        ax = event.inaxes
        if ax is None or event.xdata is None:
            return self.on_leave()
        if self.background is None:
            # draw(), not draw_idle(): a deferred repaint may not have
            # happened yet, and capturing the buffer before it does would
            # cache a stale background for every later blit.
            try:
                self.panel.canvas.draw()
            except Exception:                        # noqa: BLE001
                pass
            self.on_draw()
            if self.background is None:
                return

        best = self._nearest(ax, event)
        for key, m in self.markers.items():
            if key != id(ax):
                m.set_data([], [])

        # The vertical line is drawn in EVERY panel of the figure at the
        # same energy. On the analysis tab that is the point: it ties a
        # feature in the spectrum to the zero crossing or minimum that
        # marks it in the derivatives below.
        xline = event.xdata if best is None else best[1]
        for a in self.panel._all_axes():
            self._vline(a).set_xdata([xline, xline])

        if best is None:
            self._marker(ax).set_data([], [])
            self.panel.set_readout(
                f"cursor  {event.xdata:.3f}, {event.ydata:.4g}")
        else:
            _d, px, py, line = best
            m = self._marker(ax)
            m.set_data([px], [py])
            m.set_markeredgecolor(line.get_color())
            label = line.get_label()
            name = "" if label.startswith("_") else f"{label}:  "
            self.panel.set_readout(
                f"cursor  {event.xdata:.3f}, {event.ydata:.4g}"
                f"     \u2502     {name}{px:.3f}, {py:.6g}")
        self._blit()

    def _blit(self):
        c = self.panel.canvas
        if self.background is None:
            return
        try:
            c.restore_region(self.background)
            for art in list(self.vlines.values()) + list(self.markers.values()):
                if art.axes is not None:
                    art.axes.draw_artist(art)
            c.blit(self.panel.figure.bbox)
        except Exception:                            # noqa: BLE001
            pass


class PlotPanel(QWidget):
    """A matplotlib figure with a navigation toolbar."""

    def __init__(self, nrows=1, ncols=1, height=4.6, sharex=False):
        super().__init__()
        self._layout_frozen = False
        self._styled = {}
        self.figure = Figure(figsize=(7.5, height), dpi=100,
                             constrained_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.axes = self.figure.subplots(nrows, ncols, sharex=sharex)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        tb = NavToolbar(self.canvas, self)
        tb.setIconSize(QSize(20, 20))
        self.toolbar = tb

        self.readout = QLabel("")
        self.readout.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.readout.setStyleSheet("font-family: Consolas, monospace;"
                                   "font-size: 11px;")
        bar = QHBoxLayout()
        bar.setContentsMargins(0, 0, 6, 0)
        bar.addWidget(tb)
        bar.addStretch(1)
        bar.addWidget(self.readout)
        lay.addLayout(bar)
        lay.addWidget(self.canvas)

        # Rubber-band zoom needs a drag and a target; these step the view
        # in and out about the centre, which is what you want when you are
        # just looking around.
        for text, tip, factor in (("\u2212", "Zoom out", 1.0 / 0.7),
                                  ("+", "Zoom in", 0.7)):
            b = QPushButton(text)
            b.setFixedWidth(26)
            b.setToolTip(tip)
            b.clicked.connect(lambda _c=False, f=factor: self.zoom_by(f))
            bar.insertWidget(1, b)
        b = QPushButton("A")
        b.setFixedWidth(26)
        b.setToolTip("Autoscale to fit the data")
        b.clicked.connect(self.autoscale)
        bar.insertWidget(1, b)

        self.cursor = HoverCursor(self)
        self.retheme()

    def _all_axes(self):
        return (list(self.axes) if isinstance(self.axes, np.ndarray)
                else [self.axes])

    def zoom_by(self, factor):
        """Scale the view about its centre.

        Shared axes are handled once each. These panels use sharex, so
        setting the limit on one axes already moves the other; looping
        over both applied the factor twice and zoomed by 0.49 instead of
        0.7.
        """
        def _scale(getter, setter):
            lo, hi = getter()
            mid = 0.5 * (lo + hi)
            half = 0.5 * (hi - lo) * factor
            setter(mid - half, mid + half)

        done_x, done_y = set(), set()
        for ax in self._all_axes():
            if id(ax) not in done_x:
                _scale(ax.get_xlim, ax.set_xlim)
                for sib in ax.get_shared_x_axes().get_siblings(ax):
                    done_x.add(id(sib))
            if id(ax) not in done_y:
                _scale(ax.get_ylim, ax.set_ylim)
                for sib in ax.get_shared_y_axes().get_siblings(ax):
                    done_y.add(id(sib))
            ax.set_autoscale_on(False)
        try:
            self.toolbar.push_current()
        except Exception:                            # noqa: BLE001
            pass
        self.draw()

    def autoscale(self):
        """Fit every axes to its data and forget the zoom history.

        The history goes too: after the data underneath has changed, its
        stored views describe something that is no longer there, so Home
        would take you back to a blank plot.
        """
        for ax in self._all_axes():
            ax.set_autoscale_on(True)
            try:
                ax.relim(visible_only=False)
            except TypeError:
                ax.relim()
            ax.autoscale_view()
        try:
            self.toolbar.update()
        except Exception:                            # noqa: BLE001
            pass
        self.draw()

    def set_readout(self, text):
        self.readout.setText(text)

    def _recolor_toolbar(self):
        """Repaint matplotlib's toolbar icons in the theme's text colour.

        The bundled icons are near-black PNGs with an alpha channel. On a
        dark background they are all but invisible, which is why the
        toolbar was hard to read. Every opaque pixel is replaced with the
        text colour, keeping the alpha so the shapes stay smooth.
        """
        colour = QColor(theme.T.text)
        for action in self.toolbar.actions():
            icon = action.icon()
            if icon.isNull():
                continue
            src = action.property("_stxm_icon")
            if src is None:
                src = icon.pixmap(QSize(24, 24)).toImage()
                action.setProperty("_stxm_icon", src)
            img = QImage(src).convertToFormat(QImage.Format_ARGB32)
            tinted = QImage(img.size(), QImage.Format_ARGB32)
            tinted.fill(Qt.transparent)
            painter = QPainter(tinted)
            painter.drawImage(0, 0, img)
            painter.setCompositionMode(QPainter.CompositionMode_SourceIn)
            painter.fillRect(tinted.rect(), colour)
            painter.end()
            action.setIcon(QIcon(QPixmap.fromImage(tinted)))

    def retheme(self):
        self._styled.clear()       # colours must be reapplied
        self.request_layout()
        self._recolor_toolbar()
        t = theme.T
        self.figure.set_facecolor(t.fig_bg)
        self.canvas.setStyleSheet(f"background-color: {t.fig_bg};")
        self.readout.setStyleSheet(
            f"font-family: Consolas, monospace; font-size: 11px; "
            f"color: {t.text_dim};")
        pal = self.toolbar.palette()
        pal.setColor(QPalette.WindowText, QColor(t.text))
        pal.setColor(QPalette.ButtonText, QColor(t.text))
        self.toolbar.setPalette(pal)
        self.toolbar.setStyleSheet(
            f"QToolBar {{ background: {t.bg}; border: none; }}"
            f"QToolButton {{ background: transparent; border: none; "
            f"padding: 3px; }}"
            f"QToolButton:hover {{ background: {t.surface_alt}; }}"
            f"QLabel {{ color: {t.text}; }}")
        self.canvas.draw_idle()

    def enable_zoom(self, on: bool = True):
        """Put the navigation toolbar into (or out of) rubber-band zoom.

        Matplotlib exposes this only as a toggle, so the current mode is
        checked first to avoid turning it back off.
        """
        try:
            active = str(getattr(self.toolbar, "mode", "")) == "zoom rect"
            if active != bool(on):
                self.toolbar.zoom()
        except Exception:                            # noqa: BLE001
            pass

    def ax(self, i=0):
        """Axes `i` of this panel.

        Raises rather than aliasing: a single-axes panel asked for ax(1)
        used to hand back ax(0), so a panel built with the wrong nrows
        drew everything on top of itself and looked like a plotting bug
        instead of a construction one.
        """
        if not isinstance(self.axes, np.ndarray):
            if i != 0:
                raise IndexError(
                    f"this PlotPanel has one axes; ax({i}) requested. "
                    "Build it with nrows=2 if you want two.")
            return self.axes
        return self.axes[i]

    def style(self, ax, xlabel="Energy (eV)", ylabel=""):
        """Apply the theme to an axes.

        Split into the cheap part (colours, labels) and the expensive part
        (tick locators and spine setup, ~50 ms per axes). Since `reset`
        no longer wipes the axes configuration, the expensive part only
        has to run when the axes is new or the theme changed.
        """
        t = theme.T
        key = (id(ax), t.name)
        self.figure.set_facecolor(t.fig_bg)
        ax.set_facecolor(t.ax_bg)
        if self._styled.get(id(ax)) != (xlabel, ylabel):
            # a label changed, so the margins need re-solving
            self.request_layout()
        ax.set_xlabel(xlabel, color=t.text)
        ax.set_ylabel(ylabel, color=t.text)
        ax.title.set_color(t.text)

        if self._styled.get(key) != "done":
            ax.tick_params(direction="in", top=True, right=True, which="both",
                           colors=t.axis, labelcolor=t.text)
            ax.minorticks_on()
            for sp in ax.spines.values():
                sp.set_linewidth(1.1)
                sp.set_color(t.axis)
            self._styled[key] = "done"
        self._styled[id(ax)] = (xlabel, ylabel)
        leg = ax.get_legend()
        if leg is not None:
            for txt in leg.get_texts():
                txt.set_color(t.text)

    # -- layout ---------------------------------------------------------
    #
    # constrained_layout re-solves the margins on every single draw, which
    # costs about 60 ms per redraw here. The margins only actually change
    # when a label does, so it is solved once and then frozen.

    def request_layout(self):
        """Re-solve the margins on the next draw."""
        try:
            self.figure.set_layout_engine("constrained")
        except Exception:                            # noqa: BLE001
            pass
        self._layout_frozen = False

    def draw(self):
        # The cached blit background describes the figure as it was. Once
        # a redraw is requested it is out of date, and restoring it would
        # paint the previous curves back over the new ones. Dropping it
        # here means the next hover re-captures from a freshly rendered
        # canvas.
        cur = getattr(self, "cursor", None)
        if cur is not None:
            cur.background = None
        if self._layout_frozen:
            self.canvas.draw_idle()
            return
        self.canvas.draw()                # forces the layout solve
        try:
            self.figure.set_layout_engine("none")
            self._layout_frozen = True
        except Exception:                            # noqa: BLE001
            pass

    # -- clearing -------------------------------------------------------

    def user_navigated(self) -> bool:
        """True if the person has zoomed or panned away from the default.

        Read off the toolbar's navigation stack. Private API, so it is
        guarded: getting this wrong should cost a preserved zoom, not an
        exception.
        """
        try:
            return len(self.toolbar._nav_stack._elements) > 1
        except Exception:                            # noqa: BLE001
            return False

    def reset_view(self):
        """Forget any zoom and go back to autoscaling.

        Called when the data underneath changes -- import, removal, a new
        session -- because a view that made sense for the old data can be
        completely disjoint from the new. Zoom is active by default on
        some tabs, so a stray click on an *empty* plot is enough to push a
        view onto the navigation stack; without this, importing then drew
        the data correctly into a window looking at the wrong place, and
        the plot appeared blank.
        """
        axes = (self.axes if isinstance(self.axes, np.ndarray)
                else [self.axes])
        for ax in axes:
            for ln in list(ax.lines):
                if ln.get_gid() == HoverCursor.GID:
                    ln.set_data([], [])
            ax.set_autoscale_on(True)
            try:
                ax.relim(visible_only=False)
            except TypeError:
                ax.relim()
            ax.autoscale_view()
        try:
            self.toolbar.update()          # clears the navigation history
        except Exception:                            # noqa: BLE001
            pass

    def settle(self, ax):
        """Rescue a view that shows none of the data.

        The test is deliberately the blunt one: is *any* plotted point
        inside the current box? A deliberate zoom always shows something,
        so this cannot fire on one; a view left over from different data
        shows nothing, which is the case worth rescuing.

        An earlier version compared only the x overlap. That missed the
        common case entirely: toggling from the edge-step engine to
        McMaster takes the y values from about 1 to about 25000 while the
        energies stay put, so the x check passed and the plot went blank.
        Pressing Home did not help either, because the navigation stack
        still held the pre-toggle view -- hence the stack being cleared
        here along with the limits.
        """
        pts = [(np.asarray(l.get_xdata(), float),
                np.asarray(l.get_ydata(), float))
               for l in ax.lines if not HoverCursor.is_decoration(l)]
        pts = [(x, y) for x, y in pts if x.size and x.size == y.size]
        if not pts:
            return

        xlo, xhi = ax.get_xlim()
        ylo, yhi = ax.get_ylim()
        for x, y in pts:
            with np.errstate(invalid="ignore"):
                inside = ((x >= xlo) & (x <= xhi)
                          & (y >= ylo) & (y <= yhi))
            if bool(np.any(inside)):
                return                       # something is on screen

        self.autoscale()

    def reset(self, ax, keep_view=None):
        """Strip the drawn artists but keep the axes configuration.

        ``ax.clear()`` also resets the tick locators, so ``minorticks_on()``
        and ``tick_params()`` have to run again on every redraw -- about
        100 ms for a two-panel figure. Removing the artists instead keeps
        all of that in place.

        It also keeps the view: with ``ax.clear()`` every parameter nudge
        threw away whatever you had zoomed into, which made examining a
        white line while adjusting a window impossible.
        """
        if keep_view is None:
            keep_view = self.user_navigated()
        xlim, ylim = ax.get_xlim(), ax.get_ylim()

        for art in (list(ax.lines) + list(ax.collections) + list(ax.patches)
                    + list(ax.texts) + list(ax.images)):
            if art.get_gid() == HoverCursor.GID:
                continue          # the hover marker is not data, and the
                                  # cursor owns its lifetime
            try:
                art.remove()
            except (ValueError, NotImplementedError):
                pass
        leg = ax.get_legend()
        if leg is not None:
            leg.remove()
        try:
            ax.set_prop_cycle(None)
        except Exception:                            # noqa: BLE001
            pass

        if keep_view:
            ax.set_xlim(*xlim)
            ax.set_ylim(*ylim)
            ax.set_autoscale_on(False)
        else:
            ax.set_autoscale_on(True)
            try:
                ax.relim(visible_only=False)
            except TypeError:
                ax.relim()
            ax.autoscale_view()


# ---------------------------------------------------------------------------
# Import dialog
# ---------------------------------------------------------------------------

class ImportDialog(QDialog):
    """Pick which columns are energy and intensity."""

    def __init__(self, loaded: dataio.LoadedColumns, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Import {loaded.path.name}")
        self.loaded = loaded
        ex, ey = dataio.guess_columns(loaded)

        self.cx, self.cy = QComboBox(), QComboBox()
        for i in range(loaded.n_columns):
            col = loaded.column(i)
            name = loaded.headers[i] if i < len(loaded.headers) else f"col {i}"
            label = (f"{i}: {name}   "
                     f"[{np.nanmin(col):.4g} … {np.nanmax(col):.4g}]")
            self.cx.addItem(label, i)
            self.cy.addItem(label, i)
        self.cx.setCurrentIndex(ex)
        self.cy.setCurrentIndex(ey)

        form = QFormLayout()
        form.addRow("Energy column", self.cx)
        form.addRow("Intensity column", self.cy)
        if loaded.metadata:
            meta = "\n".join(f"{k}: {v}" for k, v in loaded.metadata.items())
            box = QPlainTextEdit(meta)
            box.setReadOnly(True)
            box.setMaximumHeight(110)
            form.addRow("File metadata", box)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(bb)

    def columns(self):
        return self.cx.currentData(), self.cy.currentData()


#: extensions a dropped file may plausibly be
SPECTRUM_SUFFIXES = (".txt", ".xas", ".dat", ".csv", ".tsv", ".asc", ".nor")
#: saved sessions. Deliberately disjoint from SPECTRUM_SUFFIXES, so a
#: session dropped on the scan list is not mistaken for a spectrum and a
#: spectrum dropped on the window is not mistaken for a session.
SESSION_SUFFIXES = (".stxmnorm", ".xasnorm")


def dropped_sessions(event) -> list:
    """Session files in a drag event, ignoring everything else."""
    md = event.mimeData()
    if not md.hasUrls():
        return []
    out = []
    for url in md.urls():
        if not url.isLocalFile():
            continue
        p = pathlib.Path(url.toLocalFile())
        if p.suffix.lower() in SESSION_SUFFIXES and p.is_file():
            out.append(p)
    return out


class FileDropList(QListWidget):
    """A list that accepts spectrum files dropped onto it.

    Emits ``filesDropped(paths, row)`` where ``row`` is the item the
    pointer was over, or -1 for empty space. The I0 list uses the row to
    decide which scan the file belongs to, so dropping an I0 straight
    onto its scan does the obvious thing.
    """

    filesDropped = Signal(list, int)
    sessionDropped = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)

    @staticmethod
    def _paths(event):
        md = event.mimeData()
        if not md.hasUrls():
            return []
        out = []
        for url in md.urls():
            if not url.isLocalFile():
                continue
            p = pathlib.Path(url.toLocalFile())
            # Directories and stray files are ignored rather than
            # refused: dragging a folder of mixed content should pick up
            # the spectra and quietly skip the rest.
            if p.is_dir():
                out += sorted(c for c in p.iterdir()
                              if c.suffix.lower() in SPECTRUM_SUFFIXES)
            elif p.suffix.lower() in SPECTRUM_SUFFIXES:
                out.append(p)
        return out

    def dragEnterEvent(self, event):
        if self._paths(event) or dropped_sessions(event):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if self._paths(event) or dropped_sessions(event):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        # A session dropped on a scan list is still a session. Handling it
        # here rather than relying on the event reaching the window means
        # the drop works over every part of the interface, including the
        # two lists that already accept spectra.
        sessions = dropped_sessions(event)
        if sessions:
            event.acceptProposedAction()
            self.sessionDropped.emit(str(sessions[0]))
            return
        paths = self._paths(event)
        if not paths:
            super().dropEvent(event)
            return
        pos = event.position().toPoint() if hasattr(event, "position") \
            else event.pos()
        item = self.itemAt(pos)
        event.acceptProposedAction()
        self.filesDropped.emit([str(p) for p in paths],
                               self.row(item) if item is not None else -1)


class ExportScansDialog(QDialog):
    """Choose which scans to export, under what names, in what formats.

    The previous behaviour wrote every normalized scan the moment a folder
    was picked, with names the program invented. This shows the list
    first: each row can be unticked, renamed, and given its own format,
    and the file extension follows the format so a renamed file is still
    what it claims to be.
    """

    def __init__(self, project, start_dir, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Export scans")
        self.resize(760, 420)
        self.project = project
        self.scans = [s for s in project.scans if s.norm is not None]

        self.folder = QLineEdit(str(start_dir))
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        frow = QHBoxLayout()
        frow.addWidget(self.folder)
        frow.addWidget(browse)

        self.table = QTableWidget(len(self.scans), 4)
        self.table.setHorizontalHeaderLabels(
            ["Export", "Scan", "File name", "Format"])
        self.table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        sample = dataio.safe_sample_name(project.compound)
        for i, sc in enumerate(self.scans):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked)
            self.table.setItem(i, 0, chk)
            name_item = QTableWidgetItem(sc.name)
            name_item.setFlags(Qt.ItemIsEnabled)
            self.table.setItem(i, 1, name_item)
            safe = "".join(c if c.isalnum() or c in "-_." else "_"
                           for c in sc.name)
            edit = QTableWidgetItem(f"{sample}_{safe}_Norm")
            self.table.setItem(i, 2, edit)
            combo = QComboBox()
            for key, (label, _ext) in dataio.SCAN_FORMATS.items():
                combo.addItem(label, key)
            self.table.setCellWidget(i, 3, combo)

        pick = QHBoxLayout()
        for label, state in (("All", Qt.Checked), ("None", Qt.Unchecked)):
            b = QPushButton(label)
            b.setMaximumWidth(64)
            b.clicked.connect(lambda _c=False, st=state: self._set_all(st))
            pick.addWidget(b)
        self.fmt_all = QComboBox()
        for key, (label, _ext) in dataio.SCAN_FORMATS.items():
            self.fmt_all.addItem(label, key)
        apply_fmt = QPushButton("Apply format to all")
        apply_fmt.clicked.connect(self._apply_format)
        pick.addStretch(1)
        pick.addWidget(self.fmt_all)
        pick.addWidget(apply_fmt)

        self.intermediates = QCheckBox(
            "Include raw, pre-edge fit and post-edge fit columns")
        self.intermediates.setToolTip(
            "Text and CSV only; the Igor export always writes the "
            "normalized wave alone.")

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Export")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Destination folder"))
        lay.addLayout(frow)
        lay.addWidget(self.table)
        lay.addLayout(pick)
        lay.addWidget(self.intermediates)
        lay.addWidget(bb)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Destination folder",
                                             self.folder.text())
        if d:
            self.folder.setText(d)

    def _set_all(self, state):
        for i in range(self.table.rowCount()):
            self.table.item(i, 0).setCheckState(state)

    def _apply_format(self):
        key = self.fmt_all.currentData()
        for i in range(self.table.rowCount()):
            combo = self.table.cellWidget(i, 3)
            for j in range(combo.count()):
                if combo.itemData(j) == key:
                    combo.setCurrentIndex(j)
                    break

    def jobs(self):
        """(scan, path, format) for every ticked row."""
        out = []
        folder = pathlib.Path(self.folder.text().strip() or ".")
        for i, sc in enumerate(self.scans):
            if self.table.item(i, 0).checkState() != Qt.Checked:
                continue
            fmt = self.table.cellWidget(i, 3).currentData()
            ext = dataio.SCAN_FORMATS[fmt][1]
            stem = (self.table.item(i, 2).text().strip()
                    or f"scan_{i + 1}")
            # the extension always matches the chosen format, whatever
            # the user typed, so a renamed file is still what it says
            if pathlib.Path(stem).suffix.lower() in (
                    e for _l, e in dataio.SCAN_FORMATS.values()):
                stem = pathlib.Path(stem).stem
            out.append((sc, folder / f"{stem}{ext}", fmt))
        return out


class CalibrationDialog(QDialog):
    """Measured vs expected peak position -> an energy shift.

    Igor's ``runShiftAll`` / ``runShiftOne``, with the resulting shift
    shown before you commit, and a choice of one scan or all.
    """

    def __init__(self, scan_names, current, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Energy calibration")
        self.measured = EnergyBox(0.0)
        self.expected = EnergyBox(0.0)
        self.measured.setSingleStep(0.1)
        self.expected.setSingleStep(0.1)
        self.shift_label = QLabel("shift = 0.000 eV")
        self.shift_label.setStyleSheet("font-weight: 600;")

        self.target = QComboBox()
        self.target.addItem("All scans (same shift)", -1)
        for i, n in enumerate(scan_names):
            self.target.addItem(f"Only {n}", i)
        self.target.setCurrentIndex(current + 1 if current >= 0 else 0)

        self.additive = QCheckBox("Add to the existing shift "
                                  "(otherwise replace it)")

        for box in (self.measured, self.expected):
            box.valueChanged.connect(self._update)

        form = QFormLayout()
        form.addRow("Measured peak position", self.measured)
        form.addRow("Expected peak position", self.expected)
        form.addRow("", self.shift_label)
        form.addRow("Apply to", self.target)
        form.addRow("", self.additive)
        note = QLabel(
            "Calibrate before averaging. The shift is applied to the "
            "energy axis before anything else reads it, so shifting after "
            "scans have been put on a common grid would mix grids \u2014 "
            "the same warning the Igor procedure carried.")
        note.setWordWrap(True)
        form.addRow(note)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(bb)

    def _update(self):
        self.shift_label.setText(f"shift = {self.shift():+.3f} eV")

    def shift(self) -> float:
        return self.expected.value() - self.measured.value()


# ---------------------------------------------------------------------------
# Parameter panel -- the engine toggle lives here
# ---------------------------------------------------------------------------

class ParameterPanel(QWidget):
    """Normalization settings for both engines.

    Shared window edges sit above a stack of engine-specific controls, so
    toggling the engine never disturbs the windows you already set.
    """

    default_windows_requested = Signal()
    use_fitted_step_requested = Signal()
    scope_changed = Signal()
    sample_changed = Signal(str)
    fit_exponent_requested = Signal()
    scale_window_requested = Signal()

    def __init__(self, on_change, parent=None):
        super().__init__(parent)
        self._on_change = on_change
        # Suppressed until the panel is fully built: the engine combo and
        # the spin boxes all emit while they are being wired up, and the
        # owner's slot cannot run before it holds a reference to us.
        self._loading = True

        # --- engine selector -------------------------------------------
        self.engine = QComboBox()
        for key, (label, tip) in engines.ENGINES.items():
            self.engine.addItem(label, key)
        # Without this a combo claims the width of its longest entry,
        # which pushed the whole parameter dock wider than the space it
        # had and clipped the right-hand side of the window.
        for cb in (self.engine,):
            cb.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            cb.setMinimumContentsLength(14)
        self.engine.setToolTip(
            "The two engines answer different questions and are not "
            "algebraically equivalent.\n\n"
            "Edge step: empirical, dimensionless, needs no element or "
            "reference table. Works at any energy, including Ln M-edges.\n\n"
            "McMaster: fits the background and the amplitude of a tabulated "
            "atomic edge step in one simultaneous solve, giving an absolute "
            "cm^2/g scale. Needs the element, and needs McMaster to "
            "tabulate an edge inside your scan.\n\n"
            "Window edges are shared, so switching engine is a one-click "
            "comparison.")
        self.engine_note = QLabel()
        self.engine_note.setWordWrap(True)
        self.engine_note.setStyleSheet("font-size: 11px;")

        eng_box = QGroupBox("Normalization engine")
        eb = QVBoxLayout(eng_box)
        eb.addWidget(self.engine)
        eb.addWidget(self.engine_note)

        # --- shared windows --------------------------------------------
        self.pre_lo, self.pre_hi = EnergyBox(), EnergyBox()
        self.post_lo, self.post_hi = EnergyBox(), EnergyBox()

        self.scale_mode = QComboBox()
        self.scale_mode.addItem("Edge jump = 1", "edge")
        self.scale_mode.addItem("Area = 1 over a window", "area")
        self.scale_mode.addItem("Peak = 1 in a window", "peak")
        self.scale_mode.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.scale_mode.setMinimumContentsLength(14)
        self.scale_mode.setToolTip(
            "What the background-subtracted spectrum is divided by.\n\n"
            "Edge jump is the classic choice and the only one tied to how "
            "much of the element is present.\n\n"
            "Area and Peak need no edge step at all. Use them where the "
            "continuum step is small or unmeasurable \u2014 lanthanide "
            "M4,5 edges especially. On a Eu M4,5 scan whose edge step "
            "swung 9x under a \u00b12 eV window nudge, the area over the "
            "resonances moved 0.13x. Area is the steadier of the two, "
            "since a single point sets the peak.\n\n"
            "Neither gives you an absolute concentration; both let you "
            "compare shapes and ratios.")
        self.scale_lo, self.scale_hi = EnergyBox(), EnergyBox()
        self.scale_from_edges = QPushButton("From edge A/B")
        self.scale_from_edges.setMaximumWidth(110)
        self.scale_from_edges.setToolTip(
            "Set the window from the two edges found on the Analysis tab, "
            "padded to cover both resonances.")
        self.scale_from_edges.clicked.connect(
            lambda: self.scale_window_requested.emit())

        win_box = QGroupBox("Fit windows  (shared by both engines)")
        wf = QFormLayout(win_box)
        wf.addRow("Pre-edge from", self.pre_lo)
        wf.addRow("Pre-edge to", self.pre_hi)
        wf.addRow("Post-edge from", self.post_lo)
        wf.addRow("Post-edge to", self.post_hi)
        wf.addRow(QLabel(""))
        wf.addRow("Normalize to", self.scale_mode)
        self._scale_rows = []
        for lbl, wid in (("  window from", self.scale_lo),
                         ("  window to", self.scale_hi)):
            wf.addRow(lbl, wid)
            self._scale_rows.append((wf.labelForField(wid), wid))
        wf.addRow("", self.scale_from_edges)
        self._scale_rows.append((None, self.scale_from_edges))
        win_box.setToolTip(
            "Igor's cursors A/B (pre-edge) and C/D (post-edge).\n"
            "Drag on the Normalization plot to set them.\n\n"
            "Both engines use the same four numbers, though they use them "
            "differently: the edge-step engine fits the two windows in "
            "sequence, the McMaster engine fits their union at once.")

        # --- engine-specific stack -------------------------------------
        self.stack = QStackedWidget()
        self.stack.addWidget(self._build_edgestep_page())
        self.stack.addWidget(self._build_mcmaster_page())

        # Which scan these settings belong to. The list is rebuilt from
        # the project whenever scans change, so it always matches what is
        # loaded. Picking a scan here both shows it and scopes every
        # setting below to it, which is what normalizing one spectrum at a
        # time actually needs -- the old "apply to selected" wording left
        # you guessing which scan was selected.
        self.sample = QLineEdit()
        self.sample.setPlaceholderText("Sample")
        self.sample.setToolTip(
            "The sample name. It heads every export's provenance block, "
            "names the per-scan files, and gives the averaged spectrum its "
            "name: <sample>_Norm_Avg, the convention the Igor procedures "
            "used.")
        self.sample.editingFinished.connect(
            lambda: self.sample_changed.emit(self.sample.text()))

        self.scope = QComboBox()
        self.scope.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.scope.setMinimumContentsLength(14)
        self.scope.setToolTip(
            "All scans: every setting below applies to the whole project.\n"
            "A named scan: the settings apply to that scan alone, and the "
            "plots follow it.")

        sample_box = QGroupBox("Sample")
        sf = QFormLayout(sample_box)
        sf.addRow("Name", self.sample)

        lay = QVBoxLayout(self)
        lay.addWidget(sample_box)
        lay.addWidget(QLabel("Editing"))
        lay.addWidget(self.scope)
        lay.addWidget(eng_box)
        lay.addWidget(win_box)
        lay.addWidget(self.stack)
        lay.addStretch(1)

        self.scale_mode.currentIndexChanged.connect(self._sync_scale_rows)
        self.scale_mode.currentIndexChanged.connect(self._changed)
        self.scale_lo.valueChanged.connect(self._changed)
        self.scale_hi.valueChanged.connect(self._changed)
        self.scope.currentIndexChanged.connect(self._scope_changed)
        self.engine.currentIndexChanged.connect(self._engine_changed)
        for w in (self.pre_lo, self.pre_hi, self.post_lo, self.post_hi):
            w.valueChanged.connect(self._changed)
        self._engine_changed()
        self._sync_scale_rows()
        self._loading = False

    # -- pages ----------------------------------------------------------
    def _build_edgestep_page(self):
        page = QWidget()
        self.pre_model = QComboBox()
        self.post_model = QComboBox()
        for key, (label, _n, _igor) in core.FIT_MODELS.items():
            self.pre_model.addItem(label, key)
            if key != "modified_victoreen":
                self.post_model.addItem(label, key)
        self.pre_model.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.pre_model.setMinimumContentsLength(14)
        self._set_combo(self.pre_model, "victoreen")
        self.post_model.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.post_model.setMinimumContentsLength(14)
        self._set_combo(self.post_model, "linear")

        self.norm_energy = EnergyBox()
        self.flatten = QCheckBox("Flatten post-edge")
        self.flatten.setToolTip(
            "Divides everything above the normalization energy by the "
            "post-edge fit, removing residual tilt.\n\n"
            "Not part of either original procedure. It changes integrated "
            "areas above the normalization energy, so leave it off to "
            "reproduce previous results.")
        self.pre_exponent = QDoubleSpinBox()
        self.pre_exponent.setRange(0.5, 6.0)
        self.pre_exponent.setSingleStep(0.1)
        self.pre_exponent.setDecimals(2)
        self.pre_exponent.setValue(3.0)
        self.pre_exponent.setKeyboardTracking(False)
        self.pre_exponent.setToolTip(
            "The n in A/E^n. Three is the Bragg-Pierce / Kramers value for "
            "photoabsorption between edges, and the leading term of "
            "Victoreen.\n\n"
            "Worth testing rather than assuming: on a Ce M4,5 scan, moving "
            "n by \u00b10.3 moved the edge step by \u00b110%, which "
            "dominates every other uncertainty in the fit. If the absolute "
            "edge step matters, quote that sensitivity.")
        self.fit_exponent_btn = QPushButton("Fit n")
        self.fit_exponent_btn.setMaximumWidth(56)
        self.fit_exponent_btn.setToolTip(
            "Estimate n from the pre-edge window by regressing log(OD) on "
            "log(E).\n\nA starting point, not an answer: over a short, "
            "flat, noisy pre-edge this estimate is poorly constrained and "
            "can come out negative.")
        self.fit_exponent_btn.clicked.connect(
            lambda: self.fit_exponent_requested.emit())
        exp_row = QHBoxLayout()
        exp_row.setContentsMargins(0, 0, 0, 0)
        exp_row.addWidget(self.pre_exponent)
        exp_row.addWidget(self.fit_exponent_btn)
        self._exp_row = QWidget()
        self._exp_row.setLayout(exp_row)

        self.pre_constraint = QComboBox()
        self.pre_constraint.addItem("Auto \u2014 constrain only if inverted",
                                    "auto")
        self.pre_constraint.addItem("Never (as Igor Pro)", "never")
        self.pre_constraint.addItem("Always non-negative", "always")
        self.pre_constraint.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.pre_constraint.setMinimumContentsLength(14)
        self.pre_constraint.setToolTip(
            "Whether the pre-edge coefficients may go negative.\n\n"
            "Igor's FuncFit Victoreen is unconstrained, and that is what "
            "Auto uses. But A/E^3 + B/E^4 with B < 0 is (A*E - |B|)/E^4, "
            "which can rise with energy \u2014 an absorption background "
            "that increases. When that drives the edge step negative and "
            "turns the spectrum upside down, Auto refits with the "
            "coefficients constrained and says so.\n\n"
            "Never reproduces Igor even when the result is unusable. "
            "Always constrains unconditionally, which departs from Igor by "
            "a couple of percent on data where the unconstrained fit was "
            "perfectly fine.")

        self.snap_box = QCheckBox("Read edge step at a measured point")
        self.snap_box.setToolTip(
            "Igor's normalizeSpectrum() divides by the post-edge fit read "
            "at the first measured point at or above the normalization "
            "energy, rather than evaluating the fit there.\n\n"
            "Worth up to ~0.2% on a coarse post-edge grid. Off by default "
            "because snapping ties the answer to the sampling: two scans "
            "on different grids then get normalized at slightly different "
            "energies before being averaged together.")

        self.igor_strict = QCheckBox("Strict Igor Pro compatibility")
        self.igor_strict.setToolTip(
            "Reproduce the Igor procedures exactly: never constrain the "
            "pre-edge fit, and read the edge step at a measured point.\n\n"
            "Use it to reproduce old results. It will hand you an inverted "
            "spectrum in the cases where Igor does, which is the point.")
        self.igor_strict.toggled.connect(self._igor_strict_toggled)

        self.spoint = QCheckBox("Pre-scale to 1 before fitting (cosmetic)")
        self.spoint.setToolTip(
            "sPointNorm() from masterNormalizeNP. It multiplies by a "
            "constant, and every later step is linear or divides by a fit "
            "of the scaled data, so it cancels exactly and the normalized "
            "result is unchanged. It only affects the raw and fit curves "
            "you see, which is useful for matching the original Igor plots.")

        self.exclusions = QListWidget()
        self.exclusions.setMaximumHeight(80)
        self.exclusions.setSelectionMode(QAbstractItemView.ExtendedSelection)
        add_excl = QPushButton("Add…")
        del_excl = QPushButton("Remove")
        add_excl.clicked.connect(self._add_exclusion)
        del_excl.clicked.connect(self._remove_exclusion)
        excl_row = QHBoxLayout()
        excl_row.addWidget(add_excl)
        excl_row.addWidget(del_excl)

        box = QGroupBox("Edge-step settings")
        f = QFormLayout(box)
        f.addRow("Pre-edge model", self.pre_model)
        f.addRow("Post-edge model", self.post_model)
        f.addRow("Normalize at", self.norm_energy)
        f.addRow("Exclusions", self.exclusions)
        f.addRow("", self._wrap(excl_row))
        self._exp_label = QLabel("Exponent n")
        f.addRow(self._exp_label, self._exp_row)
        f.addRow("Pre-edge constraint", self.pre_constraint)
        f.addRow(self.flatten)
        f.addRow(self.spoint)

        compat = QGroupBox("Igor Pro compatibility")
        cf = QVBoxLayout(compat)
        cf.addWidget(self.igor_strict)
        cf.addWidget(self.snap_box)
        lay_compat = compat

        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(box)
        lay.addWidget(lay_compat)

        self.pre_exponent.valueChanged.connect(self._changed)
        self.pre_constraint.currentIndexChanged.connect(self._changed)
        self.snap_box.toggled.connect(self._changed)
        self.pre_model.currentIndexChanged.connect(self._sync_exponent_row)
        self._sync_exponent_row()
        for w in (self.pre_model, self.post_model):
            w.currentIndexChanged.connect(self._changed)
        self.norm_energy.valueChanged.connect(self._changed)
        for w in (self.flatten, self.spoint):
            w.toggled.connect(self._changed)
        return page

    def _build_mcmaster_page(self):
        """Laid out like norm2poly: element and edge, then windows, then
        the edge jump and the normalize-to-1 toggle."""
        page = QWidget()

        self.element = QComboBox()
        self.element.setEditable(True)
        for z in range(1, 95):
            if z in mcmaster.NO_DATA:
                continue
            sym = mcmaster.symbol_of(z)
            self.element.addItem(f"{sym}  (Z={z})", sym)
        self.element.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.element.setMinimumContentsLength(10)
        self._set_combo(self.element, "V")
        self.element.setToolTip(
            "The element whose tabulated atomic cross-section sets the "
            "absolute scale. McMaster did not tabulate Po, At, Fr, Ra, Ac, "
            "Pa or Np, so they are absent from this list.")

        self.mc_edge = QComboBox()
        self.mc_edge.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.mc_edge.setMinimumContentsLength(10)
        self.mc_edge.setToolTip(
            "Which tabulated edge the windows should straddle. This picks "
            "the edge energy shown below; it does not change the fit, "
            "which uses the whole McMaster curve.")

        self.mc_e0 = EnergyBox()
        self.mc_e0.setToolTip(
            "Edge energy from the McMaster table, editable.\n\n"
            "Note this is the *tabulated* energy, which can differ from "
            "where your sample's edge actually is \u2014 McMaster puts the "
            "C K edge at 295.0 eV against a real 284.2 eV. That does not "
            "harm the fit: what matters is that this energy falls between "
            "your two windows.")

        self.mc_windows = QPushButton("Default windows from edge")
        self.mc_windows.setToolTip(
            "norm2poly's default_range(): pre-edge ending 20 eV below the "
            "edge and post-edge starting 80 eV above it, both scaled down "
            "for a narrow soft X-ray scan.")
        self.mc_windows.clicked.connect(self._mcmaster_default_windows)

        self.poly_order = QSpinBox()
        self.poly_order.setRange(0, 8)
        self.poly_order.setValue(2)
        self.poly_order.setToolTip(
            "Order of the Legendre polynomial background fitted alongside "
            "the edge step. norm2poly's n_th.\n\n"
            "The polynomial is evaluated over the whole scan but fitted "
            "only over the two windows, so a high order can swing wildly "
            "across the edge region in between. Order 1-3 is usual.")

        self.mc_step = QDoubleSpinBox()
        self.mc_step.setDecimals(4)
        self.mc_step.setRange(0.0, 1e12)
        self.mc_step.setSingleStep(100.0)
        self.mc_step.setKeyboardTracking(False)
        self.mc_step.setSpecialValueText("(from fit)")
        self.mc_step.setToolTip(
            "The tabulated cross-section the absolute scale is referred "
            "to, in cm\u00b2/g.\n\n"
            "This is a property of the ELEMENT, not of a scan: every scan "
            "of the same element shares it, and it is the same number for "
            "all of them. It converts units \u2014 it does not remove "
            "thickness. That is done by the fitted amplitude c0, "
            "separately and per scan.\n\n"
            "Left at zero it shows \u201c(from fit)\u201d and the program "
            "uses the McMaster reference at the last point of the scan, "
            "which is norm2poly's definition. Type a value to override it.")
        self.mc_step_use = QPushButton("Use fitted value")
        self.mc_step_use.clicked.connect(self._use_fitted_step)

        self.mc_norm1 = QPushButton("Normalize to 1")
        self.mc_norm1.setCheckable(True)
        self.mc_norm1.setToolTip(
            "Divide the result by the edge jump so the post-edge sits near "
            "1. A pure rescaling: the shape does not change, only the "
            "numbers on the axis and in what gets exported.")
        self.mc_norm1.toggled.connect(self._norm_to_one_toggled)

        box = QGroupBox("Element and edge")
        f = QFormLayout(box)
        f.addRow("Element", self.element)
        f.addRow("Edge", self.mc_edge)
        f.addRow("Edge energy", self.mc_e0)
        f.addRow(self.mc_windows)

        box2 = QGroupBox("Fit")
        f2 = QFormLayout(box2)
        f2.addRow("Legendre order", self.poly_order)

        box3 = QGroupBox("Absolute scale")
        f3 = QFormLayout(box3)
        f3.addRow("Reference \u03bc", self.mc_step)
        f3.addRow("", self.mc_step_use)
        f3.addRow(self.mc_norm1)

        self.mc_warn = QLabel()
        self.mc_warn.setWordWrap(True)
        self.mc_warn.setStyleSheet("font-size: 11px;")

        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(box)
        lay.addWidget(box2)
        lay.addWidget(box3)
        lay.addWidget(self.mc_warn)

        self.element.currentIndexChanged.connect(self._element_changed)
        self.element.editTextChanged.connect(self._element_changed)
        self.mc_edge.currentIndexChanged.connect(self._edge_changed)
        self.mc_e0.valueChanged.connect(self._changed)
        self.poly_order.valueChanged.connect(self._changed)
        self.mc_step.valueChanged.connect(self._changed)
        self._refill_edges()
        return page

    # -- McMaster page helpers ------------------------------------------
    def current_element(self) -> str:
        sym = self.element.currentData()
        if sym is None:
            txt = self.element.currentText().strip()
            sym = txt.split()[0] if txt else ""
        return sym

    def _refill_edges(self):
        """List only the edges McMaster actually tabulates for this element."""
        sym = self.current_element()
        edges = engines.mcmaster_edge_energies(sym)
        want = self.mc_edge.currentData()
        was = self._loading
        self._loading = True
        try:
            self.mc_edge.clear()
            for name in engines.MCMASTER_EDGES:
                if name in edges:
                    self.mc_edge.addItem(f"{name}   {edges[name]:.1f} eV", name)
            if want:
                self._set_combo(self.mc_edge, want)
            if self.mc_edge.currentIndex() < 0 and self.mc_edge.count():
                self.mc_edge.setCurrentIndex(0)
            key = self.mc_edge.currentData()
            if key in edges:
                self.mc_e0.setValue(edges[key])
        finally:
            self._loading = was

    def _element_changed(self, *_):
        self._refill_edges()
        self._changed()

    def _edge_changed(self, *_):
        edges = engines.mcmaster_edge_energies(self.current_element())
        key = self.mc_edge.currentData()
        if key in edges:
            was = self._loading
            self._loading = True
            try:
                self.mc_e0.setValue(edges[key])
            finally:
                self._loading = was
        self._changed()

    def _mcmaster_default_windows(self):
        self.default_windows_requested.emit()

    def _use_fitted_step(self):
        self.use_fitted_step_requested.emit()

    def _norm_to_one_toggled(self, on):
        self.mc_norm1.setText("Back to cm\u00b2/g" if on else "Normalize to 1")
        self._changed()

    # -- helpers ---    # -- helpers --------------------------------------------------------
    @staticmethod
    def _wrap(layout):
        w = QWidget()
        w.setLayout(layout)
        return w

    @staticmethod
    def _set_combo(combo, key):
        for i in range(combo.count()):
            if combo.itemData(i) == key:
                combo.setCurrentIndex(i)
                return

    def _sync_scale_rows(self, *_):
        on = self.scale_mode.currentData() in ("area", "peak")
        for lab, wid in getattr(self, "_scale_rows", []):
            if lab is not None:
                lab.setVisible(on)
            wid.setVisible(on)

    def refresh_scope(self, names, current):
        """Rebuild the scan list in the selector, keeping the choice."""
        want = self.scope.currentData()
        was = self._loading
        self._loading = True
        try:
            self.scope.clear()
            self.scope.addItem("All scans", "all")
            for i, n in enumerate(names):
                self.scope.addItem(f"   {n}", i)
            if want is not None:
                for i in range(self.scope.count()):
                    if self.scope.itemData(i) == want:
                        self.scope.setCurrentIndex(i)
                        break
            elif current is not None:
                self._set_combo(self.scope, current)
        finally:
            self._loading = was

    def _scope_changed(self, *_):
        self.scope_changed.emit()

    def _engine_changed(self, *_):
        key = self.engine.currentData()
        self.stack.setCurrentIndex(0 if key == "edgestep" else 1)
        self.engine_note.setText(engines.ENGINES[key][1])
        self._changed()

    def _changed(self, *_):
        if not self._loading:
            self._on_change()

    def _sync_exponent_row(self, *_):
        on = self.pre_model.currentData() == "power"
        self._exp_label.setVisible(on)
        self._exp_row.setVisible(on)

    def _igor_strict_toggled(self, on):
        """Strict mode owns the two compatibility settings while it is on.

        They are disabled rather than hidden, and set to what strict mode
        forces, so it is visible what is being applied instead of the
        controls silently disagreeing with the result.
        """
        was = self._loading
        self._loading = True
        try:
            if on:
                self._set_combo(self.pre_constraint, "never")
                self.snap_box.setChecked(True)
            self.pre_constraint.setEnabled(not on)
            self.snap_box.setEnabled(not on)
        finally:
            self._loading = was
        self._changed()

    def _add_exclusion(self):
        lo = self.post_lo.value()
        hi = min(self.post_hi.value(), lo + 5.0)
        self.exclusions.addItem(f"{lo:.2f} – {hi:.2f}")
        self._changed()

    def _remove_exclusion(self):
        for item in self.exclusions.selectedItems():
            self.exclusions.takeItem(self.exclusions.row(item))
        self._changed()

    def add_exclusion_range(self, lo, hi):
        self.exclusions.addItem(f"{lo:.2f} – {hi:.2f}")
        self._changed()

    def set_mcmaster_warning(self, text):
        t = theme.T
        self.mc_warn.setText(text)
        self.mc_warn.setStyleSheet(
            f"font-size: 11px; color: {t.error if text else t.text};")

    # -- value transfer -------------------------------------------------
    def values(self) -> engines.UnifiedParams:
        excl = []
        for i in range(self.exclusions.count()):
            a, b = self.exclusions.item(i).text().split("–")
            excl.append((float(a), float(b)))
        return engines.UnifiedParams(
            engine=self.engine.currentData(),
            pre_lo=self.pre_lo.value(), pre_hi=self.pre_hi.value(),
            post_lo=self.post_lo.value(), post_hi=self.post_hi.value(),
            pre_model=(f"power:{self.pre_exponent.value():.2f}"
                       if self.pre_model.currentData() == "power"
                       else self.pre_model.currentData()),
            post_model=self.post_model.currentData(),
            norm_energy=self.norm_energy.value(),
            exclude=excl,
            flatten=self.flatten.isChecked(),
            spoint=self.spoint.isChecked(),
            nonnegative_pre={"auto": None, "never": False,
                             "always": True}[self.pre_constraint.currentData()],
            snap_norm_energy=self.snap_box.isChecked(),
            scale_mode=self.scale_mode.currentData(),
            scale_lo=self.scale_lo.value(),
            scale_hi=self.scale_hi.value(),
            igor_strict=self.igor_strict.isChecked(),
            element=self.current_element(),
            edge=self.mc_edge.currentData() or "K",
            e0=self.mc_e0.value(),
            poly_order=self.poly_order.value(),
            edge_step=(self.mc_step.value() or None),
            norm_to_one=self.mc_norm1.isChecked(),
        )

    def load(self, p: engines.UnifiedParams):
        self._loading = True
        try:
            self._set_combo(self.engine, p.engine)
            self.stack.setCurrentIndex(0 if p.engine == "edgestep" else 1)
            self.engine_note.setText(engines.ENGINES[p.engine][1])
            self.pre_lo.setValue(p.pre_lo)
            self.pre_hi.setValue(p.pre_hi)
            self.post_lo.setValue(p.post_lo)
            self.post_hi.setValue(p.post_hi)
            self._set_combo(self.pre_model, core.model_base(p.pre_model))
            self.pre_exponent.setValue(core.power_exponent(p.pre_model))
            self._sync_exponent_row()
            self._set_combo(self.post_model, p.post_model)
            self.norm_energy.setValue(p.norm_energy)
            self.flatten.setChecked(p.flatten)
            self.spoint.setChecked(p.spoint)
            self._set_combo(self.pre_constraint,
                            {None: "auto", False: "never",
                             True: "always"}[p.nonnegative_pre])
            self.snap_box.setChecked(p.snap_norm_energy)
            self._set_combo(self.scale_mode, p.scale_mode)
            self.scale_lo.setValue(p.scale_lo)
            self.scale_hi.setValue(p.scale_hi)
            self._sync_scale_rows()
            self.igor_strict.setChecked(p.igor_strict)
            self.pre_constraint.setEnabled(not p.igor_strict)
            self.snap_box.setEnabled(not p.igor_strict)
            self.exclusions.clear()
            for a, b in p.exclude:
                self.exclusions.addItem(f"{a:.2f} – {b:.2f}")
            if p.element:
                self._set_combo(self.element, p.element)
            self._refill_edges()
            if p.edge:
                self._set_combo(self.mc_edge, p.edge)
            if p.e0:
                self.mc_e0.setValue(p.e0)
            self.poly_order.setValue(p.poly_order)
            self.mc_step.setValue(p.edge_step or 0.0)
            self.mc_norm1.setChecked(p.norm_to_one)
            self.mc_norm1.setText("Back to cm\u00b2/g" if p.norm_to_one
                                  else "Normalize to 1")
        finally:
            self._loading = False


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self._fit_to_screen()
        self.project = dataio.Project()
        #: folder of the most recently imported file; every file dialog
        #: opens here, since exports almost always belong beside the data
        self._last_dir = ""
        self._drag_target = "pre"
        self._selected = -1
        self._updating = False

        # Parameter changes arrive faster than a redraw takes: holding an
        # arrow key on a spin box, or dragging a window edge, fires one
        # change per event. They are coalesced so the work happens once
        # when the input settles rather than once per keystroke.
        self._recompute_timer = QTimer(self)
        self._recompute_timer.setSingleShot(True)
        self._recompute_timer.setInterval(80)
        self._recompute_timer.timeout.connect(self.recompute)

        self.setAcceptDrops(True)

        self._build_tabs()
        self._build_scan_dock()
        self._build_param_dock()
        self._build_log_dock()
        self._build_menu()

        # Zoom is the most-used toolbar mode, so it starts active on the
        # panels where dragging has no other meaning. The Normalization
        # tab is excluded: there a drag sets the fit windows, and a live
        # SpanSelector plus rubber-band zoom would both fire at once.
        for panel in (self.plot_data, self.plot_avg, self.plot_ana,
                      self.tab_peakfit.plot):
            panel.enable_zoom(True)

        # interpolate_to_grid uses a cubic spline (Igor's Interpolate2
        # /I=3), so scipy is needed on the first recompute. Importing it
        # here costs the user nothing -- the window is already up and they
        # have not clicked anything yet -- instead of stalling the first
        # normalization by most of a second.
        # QPlainTextEdit accepts drops by default and would swallow a
        # session dropped on the report or the log -- read-only, so
        # nothing happens and the drop appears to be ignored. Turning it
        # off lets the event reach the window, which is what makes
        # "anywhere on the interface" true rather than nearly true.
        for view in (self.report, self.log_view, self.area_report,
                     self.scan_info):
            try:
                view.setAcceptDrops(False)
            except Exception:                        # noqa: BLE001
                pass

        QTimer.singleShot(50, self._warm_imports)

        # Proportions, applied after construction: Qt otherwise hands the
        # docks whatever their contents ask for, which on a narrow screen
        # leaves almost nothing for the plots.
        QTimer.singleShot(0, self._apply_dock_sizes)

        self.statusBar().showMessage("Import ratioed aXis2000 scans to begin.")

    def _apply_dock_sizes(self):
        """Give the docks a fixed share of the width.

        Deferred to the event loop: during __init__ the window has not
        been laid out yet, so resizeDocks is overridden by whatever the
        dock contents ask for.
        """
        try:
            total = max(self.width(), 900)
            self.resizeDocks([self.scan_dock, self.param_dock],
                             [int(total * 0.19), int(total * 0.26)],
                             Qt.Horizontal)
        except Exception:                            # noqa: BLE001
            pass

    @staticmethod
    def _warm_imports():
        try:
            import scipy.interpolate                 # noqa: F401
        except Exception:                            # noqa: BLE001
            pass

    # -- construction ---------------------------------------------------
    def _fit_to_screen(self):
        """Open at a comfortable size that actually fits the display.

        A fixed 1400x900 is wider than a 1366-wide laptop screen once the
        window frame is counted, so part of the interface started off the
        edge of the display and looked cut off.
        """
        app = QApplication.instance()
        screen = app.primaryScreen() if app else None
        if screen is None:
            self.resize(1400, 900)
            return
        avail = screen.availableGeometry()
        w = min(1500, max(900, avail.width() - 60))
        h = min(950, max(600, avail.height() - 60))
        self.resize(w, h)
        self.move(avail.left() + (avail.width() - w) // 2,
                  avail.top() + (avail.height() - h) // 2)

    def _build_tabs(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # 1 -- data
        # data over I0, sharing the energy axis so zooming one zooms the
        # other and features line up vertically
        self.plot_data = PlotPanel(nrows=2, height=6.0, sharex=True)
        self.tabs.addTab(self.plot_data, "1 · Data + I\u2080")

        # 2 -- normalization
        self.plot_norm = PlotPanel(nrows=2, height=6.4, sharex=True)
        norm_wrap = QWidget()
        nl = QVBoxLayout(norm_wrap)
        nl.setContentsMargins(0, 0, 0, 0)

        drag_row = QHBoxLayout()
        drag_row.addWidget(QLabel("Drag on the plot sets:"))
        self.drag_group = QButtonGroup(self)
        for i, (key, label) in enumerate([("pre", "Pre-edge  (A/B)"),
                                          ("post", "Post-edge  (C/D)"),
                                          ("excl", "Exclusion"),
                                          ("none", "Zoom only")]):
            rb = QRadioButton(label)
            rb.setProperty("key", key)
            if i == 0:
                rb.setChecked(True)
            self.drag_group.addButton(rb, i)
            drag_row.addWidget(rb)
        self.drag_group.buttonClicked.connect(self._drag_mode_changed)
        self._colour_drag_labels()
        drag_row.addStretch(1)
        nl.addLayout(drag_row)

        split = QSplitter(Qt.Vertical)
        split.addWidget(self.plot_norm)
        self.report = QPlainTextEdit()
        self.report.setReadOnly(True)
        self.report.setMaximumHeight(190)
        split.addWidget(self.report)
        split.setStretchFactor(0, 4)
        nl.addWidget(split)
        self.tabs.addTab(norm_wrap, "2 · Normalization")

        self._span_note = QLabel(
            "Zoom and box zoom are on the toolbar above each plot. On this "
            "tab a drag sets a window instead, so pick \u201cZoom only\u201d "
            "to get rubber-band zoom back.")
        self._span_note.setWordWrap(True)
        self._span_note.setStyleSheet("font-size: 11px;")
        nl.addWidget(self._span_note)

        self.span = SpanSelector(
            self.plot_norm.ax(0), self._on_span, "horizontal",
            useblit=True, props=dict(alpha=0.25, facecolor="tab:blue"),
            interactive=False, drag_from_anywhere=True)

        # 3 -- normalized + average
        self.plot_avg = PlotPanel(height=5.2)
        res_wrap = QWidget()
        rl = QVBoxLayout(res_wrap)
        rl.setContentsMargins(0, 0, 0, 0)
        gl = QHBoxLayout()
        gl.addWidget(QLabel("Energy grid"))
        self.grid_mode = QComboBox()
        self.grid_mode.addItem("Native \u2014 keep a scan's own energies",
                               "native")
        self.grid_mode.addItem("Uniform \u2014 even steps", "uniform")
        self.grid_mode.setToolTip(
            "An XAS scan is sampled unevenly on purpose: fine across the "
            "edge, coarse elsewhere. A uniform grid throws that away. On "
            "a real C K-edge scan, 99 measured points between 283 and "
            "290 eV became 16, which visibly smooths the average.\n\n"
            "Native keeps the first included scan's own energies, clipped "
            "to the range every scan covers. This is norm2poly's default "
            "and it is the one to use.")
        self.grid_mode.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.grid_mode.setMinimumContentsLength(16)
        self.grid_mode.currentIndexChanged.connect(self._grid_changed)
        gl.addWidget(self.grid_mode)
        gl.addWidget(QLabel("Interpolation"))
        self.interp_mode = QComboBox()
        self.interp_mode.addItem("Cubic spline", "cubic")
        self.interp_mode.addItem("Linear", "linear")
        self.interp_mode.setToolTip(
            "How a scan is put onto the shared grid when its own energies "
            "differ. Cubic spline is Igor's Interpolate2 /I=3; it is "
            "exact at the measured points and closer in between, but can "
            "overshoot slightly around a sharp peak. Linear cannot "
            "overshoot.\n\nScans already on the grid are untouched "
            "either way.")
        self.interp_mode.currentIndexChanged.connect(self._grid_changed)
        gl.addWidget(self.interp_mode)
        self.show_points = QCheckBox("Show points")
        self.show_points.setChecked(True)
        self.show_points.setToolTip(
            "Mark every point of the averaged spectrum.\n\n"
            "The quickest way to see whether averaging has changed the "
            "sampling: an XAS scan is measured finely across the edge and "
            "coarsely either side, and a uniform grid throws that away.")
        self.show_points.toggled.connect(lambda _=False: self._redraw())
        gl.addWidget(self.show_points)
        gl.addWidget(QLabel("Range"))
        self.grid_clip = QComboBox()
        self.grid_clip.addItem("Overlap of all scans", True)
        self.grid_clip.addItem("Full range of reference", False)
        self.grid_clip.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.grid_clip.setMinimumContentsLength(14)
        self.grid_clip.setToolTip(
            "How far the averaged spectrum extends.\n\n"
            "Overlap keeps it to the range every scan covers, so every "
            "point is an average of the same scans.\n\n"
            "Full range uses the reference scan's own range. Points "
            "beyond the overlap are then averaged over FEWER scans \u2014 "
            "legitimate, and the standard error widens to match, but the "
            "mean there is over a different set of spectra. Those points "
            "are shaded on the plot and counted in the line below.")
        self.grid_clip.currentIndexChanged.connect(self._grid_changed)
        gl.addWidget(self.grid_clip)
        gl.addWidget(QLabel("Reference"))
        self.grid_ref = QComboBox()
        self.grid_ref.setSizeAdjustPolicy(
            QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.grid_ref.setMinimumContentsLength(12)
        self.grid_ref.setToolTip(
            "Whose energy axis the average is built on, and whose range "
            "is used when Range is set to Full.")
        self.grid_ref.currentIndexChanged.connect(self._grid_changed)
        gl.addWidget(self.grid_ref)
        gl.addStretch(1)
        # In a scroll area this row stops dictating a minimum width for
        # the whole window: adding the Range and Reference combos pushed
        # the minimum to 1464 px, past what a 1366-wide laptop can show.
        gl_host = QWidget()
        gl_host.setLayout(gl)
        gl_scroll = QScrollArea()
        gl_scroll.setWidget(gl_host)
        gl_scroll.setWidgetResizable(True)
        gl_scroll.setFrameShape(QScrollArea.NoFrame)
        gl_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        gl_scroll.setFixedHeight(gl_host.sizeHint().height() + 4)
        rl.addWidget(gl_scroll)
        self.grid_info = QLabel("")
        self.grid_info.setStyleSheet("font-size: 11px;")
        rl.addWidget(self.grid_info)
        rl.addWidget(self.plot_avg)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            ["Use", "Scan", "Shift (eV)", "Bin", "Divisor", "% of pre",
             "Stability", "Corrected", "Status"])
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setMinimumSectionSize(40)   # six columns must not set a floor
        self.table.setMaximumHeight(190)
        self.table.itemChanged.connect(self._table_changed)
        rl.addWidget(self.table)
        self.tabs.addTab(res_wrap, "3 · Normalized + average")

        # 4 -- analysis: derivatives, peak finding, edge areas
        self.plot_ana = PlotPanel(nrows=2, height=6.0, sharex=True)
        ana_wrap = QWidget()
        al = QVBoxLayout(ana_wrap)
        al.setContentsMargins(0, 0, 0, 0)

        ctl = QHBoxLayout()
        self.edge_a_box = EnergyBox()
        self.edge_b_box = EnergyBox()
        self.smooth_box = QSpinBox()
        self.smooth_box.setRange(0, 60)
        self.smooth_box.setValue(5)
        self.smooth_box.setToolTip(
            "Binomial smoothing passes, as in Igor's Smooth and the STXM "
            "fitting GUI. The derivatives are taken from the smoothed "
            "curve, which is drawn over the measured points above.\n\n"
            "More passes give cleaner derivatives and broader features. "
            "If the smoothed curve stops following the points, the "
            "derivatives are describing the filter rather than the data.")
        self.smooth_box.valueChanged.connect(lambda _: self._redraw())
        for w_ in (self.edge_a_box, self.edge_b_box):
            w_.valueChanged.connect(lambda _: self._redraw())
        find_btn = QPushButton("Find peaks")
        find_btn.clicked.connect(self._find_peaks)
        areas_btn = QPushButton("Compute areas")
        areas_btn.clicked.connect(self._compute_areas)
        clear_btn = QPushButton("Clear peaks")
        clear_btn.setToolTip("Forget edge A and B and remove their markers.")
        clear_btn.clicked.connect(self._clear_peaks)
        # Compact: at their natural widths these three boxes plus four
        # buttons demanded 871 px, which set the whole window's minimum
        # width above what a 1366-wide laptop screen can show.
        self.edge_a_box.setMaximumWidth(108)
        self.edge_b_box.setMaximumWidth(108)
        self.smooth_box.setMaximumWidth(60)
        for lbl, wid in (("Edge A", self.edge_a_box), ("Edge B", self.edge_b_box),
                         ("Smoothing", self.smooth_box)):
            ctl.addWidget(QLabel(lbl))
            ctl.addWidget(wid)
        ctl.addWidget(find_btn)
        ctl.addWidget(areas_btn)
        ctl.addWidget(clear_btn)
        ctl.addStretch(1)
        # In a scroll area the row stops dictating a minimum width for the
        # whole window: on a narrow display it scrolls sideways instead of
        # forcing the window wider than the screen.
        ctl_host = QWidget()
        ctl_host.setLayout(ctl)
        ctl_scroll = QScrollArea()
        ctl_scroll.setWidget(ctl_host)
        ctl_scroll.setWidgetResizable(True)
        ctl_scroll.setFrameShape(QScrollArea.NoFrame)
        ctl_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        ctl_scroll.setFixedHeight(ctl_host.sizeHint().height() + 4)
        al.addWidget(ctl_scroll)
        al.addWidget(self.plot_ana)
        self.area_report = QPlainTextEdit()
        self.area_report.setReadOnly(True)
        self.area_report.setMaximumHeight(170)
        al.addWidget(self.area_report)
        self.tabs.addTab(ana_wrap, "4 \u00b7 Analysis")

        # 5 -- peak fitting, ported from XASNorm unchanged. It takes the
        # spectrum through a callback, so it works with whichever scale
        # the normalization is using.
        # XASNorm's logger took a severity argument; this one does not,
        # so the callback absorbs it rather than the tab being edited.
        self.tab_peakfit = PeakFitTab(
            self._peakfit_spectrum,
            lambda msg, level="info": self.log(
                msg if level == "info" else f"! {msg}"),
            lambda r, c, h, sx: PlotPanel(r, c, h, sx))
        self.tabs.addTab(self.tab_peakfit, "5 \u00b7 Peak fitting")

        self.tabs.currentChanged.connect(lambda _: self._redraw())

    def _build_scan_dock(self):
        """Two checkable lists: the data scans, and the I0 attached to them.

        The tick next to each name controls only whether that trace is
        drawn. Whether a scan contributes to the average is a separate
        decision, made in the table on the Normalized + average tab, so
        you can hide a noisy scan to see the others without silently
        dropping it from the result.
        """
        dock = QDockWidget("Scans", self)
        dock.setObjectName("scans")
        w = QWidget()
        lay = QVBoxLayout(w)

        split = QSplitter(Qt.Vertical)

        # --- data section ---------------------------------------------
        data_box = QGroupBox("Data")
        dl = QVBoxLayout(data_box)
        self.scan_list = FileDropList()
        self.scan_list.setMinimumWidth(150)
        self.scan_list.setToolTip(
            "Drop spectrum files here to import them.\n\n"
            "Tick to show the trace in the Data plot.\n"
            "Selecting a row is what chooses the scan the Normalization "
            "tab works on.")
        self.scan_list.currentRowChanged.connect(self._select_scan)
        self.scan_list.itemChanged.connect(self._scan_shown_changed)
        self.scan_list.filesDropped.connect(self._scans_dropped)
        self.scan_list.sessionDropped.connect(self._session_dropped)
        dl.addWidget(self.scan_list)
        row = QHBoxLayout()
        for label, slot in [("Import…", self.import_scans),
                            ("Remove", self.remove_scan)]:
            b = QPushButton(label)
            b.clicked.connect(slot)
            row.addWidget(b)
        dl.addLayout(row)
        row2 = QHBoxLayout()
        for label, slot in [("All", lambda: self._set_all_shown("data", True)),
                            ("None", lambda: self._set_all_shown("data", False))]:
            b = QPushButton(label)
            b.setMaximumWidth(60)
            b.clicked.connect(slot)
            row2.addWidget(b)
        row2.addStretch(1)
        dl.addLayout(row2)
        split.addWidget(data_box)

        # --- I0 section -----------------------------------------------
        i0_box = QGroupBox("I\u2080")
        il = QVBoxLayout(i0_box)
        self.i0_list = FileDropList()
        self.i0_list.setToolTip(
            "Drop a file onto a scan to attach it as that scan's I\u2080.\n\n"
            "I0 attached to each scan. Tick to show it in the I\u2080 plot.\n"
            "Scans with no I0 are listed greyed out.")
        self.i0_list.itemChanged.connect(self._i0_shown_changed)
        self.i0_list.filesDropped.connect(self._i0_dropped)
        self.i0_list.sessionDropped.connect(self._session_dropped)
        il.addWidget(self.i0_list)
        rowi = QHBoxLayout()
        for label, slot in [("Attach I\u2080…", self.attach_i0),
                            ("Detach", self.detach_i0)]:
            b = QPushButton(label)
            b.clicked.connect(slot)
            rowi.addWidget(b)
        il.addLayout(rowi)
        rowi2 = QHBoxLayout()
        for label, slot in [("All", lambda: self._set_all_shown("i0", True)),
                            ("None", lambda: self._set_all_shown("i0", False))]:
            b = QPushButton(label)
            b.setMaximumWidth(60)
            b.clicked.connect(slot)
            rowi2.addWidget(b)
        rowi2.addStretch(1)
        il.addLayout(rowi2)
        split.addWidget(i0_box)

        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        lay.addWidget(split)

        self.scan_info = QLabel("")
        self.scan_info.setWordWrap(True)
        lay.addWidget(self.scan_info)
        dock.setWidget(w)
        self.scan_dock = dock
        self.addDockWidget(Qt.LeftDockWidgetArea, dock)

    def _build_param_dock(self):
        """Normalization settings, tabbed behind the scan list.

        Both docks share the left area so the plots get the full width of
        the window. A scroll area keeps the McMaster page reachable on a
        short screen, where the windows box plus the engine controls
        would otherwise overflow.
        """
        dock = QDockWidget("Normalization", self)
        dock.setObjectName("params")
        self.params = ParameterPanel(self._params_changed)
        self.params.default_windows_requested.connect(self.mcmaster_windows)
        self.params.use_fitted_step_requested.connect(self.use_fitted_step)
        self.params.scope_changed.connect(self._scope_changed)
        self.params.sample_changed.connect(self._sample_changed)
        self.params.fit_exponent_requested.connect(self._fit_exponent)
        self.params.scale_window_requested.connect(self._scale_from_edges)
        self.params.sample.setText(self.project.compound)

        holder = QWidget()
        hl = QVBoxLayout(holder)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.addWidget(self.params)
        hl.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidget(holder)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        dock.setWidget(scroll)
        # A hard minimum here propagates into the whole window's minimum
        # width. 260 still shows every control; the scroll area copes with
        # the rest, and the user can widen the dock whenever they like.
        dock.setMinimumWidth(260)

        # Scans on the left, parameters on the right, both visible at once.
        # The two side docks own the bottom corners, which keeps the log
        # inside the centre column instead of spanning the full width --
        # that is what buys the docks their height.
        self.addDockWidget(Qt.RightDockWidgetArea, dock)
        self.setCorner(Qt.BottomLeftCorner, Qt.LeftDockWidgetArea)
        self.setCorner(Qt.BottomRightCorner, Qt.RightDockWidgetArea)
        self.setCorner(Qt.TopLeftCorner, Qt.LeftDockWidgetArea)
        self.setCorner(Qt.TopRightCorner, Qt.RightDockWidgetArea)
        self.param_dock = dock

    def _build_log_dock(self):
        dock = QDockWidget("Log", self)
        dock.setObjectName("log")
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumHeight(140)
        dock.setWidget(self.log_view)
        self.addDockWidget(Qt.BottomDockWidgetArea, dock)

    def _build_menu(self):
        m = self.menuBar()

        f = m.addMenu("&File")
        self._act(f, "Import scans…", self.import_scans, QKeySequence.Open)
        f.addSeparator()
        self._act(f, "Export averaged spectrum…", self.export_average)
        self._act(f, "Export every scan…", self.export_all)
        self._act(f, "Export for Igor Pro (.itx)…", self.export_igor)
        f.addSeparator()
        self._act(f, "Save session…", self.save_session, QKeySequence.Save)
        self._act(f, "Open session…", self.open_session)
        self._act(f, "Close session", self.close_session)
        f.addSeparator()
        self._act(f, "Quit", self.close, QKeySequence.Quit)

        p = m.addMenu("&Process")
        self._act(p, "Suggest windows from data", self.suggest_windows)
        self._act(p, "Set edge from element…", self.set_edge_from_element)
        p.addSeparator()
        self._act(p, "Energy calibration…", self.calibrate, "Ctrl+E")
        self._act(p, "Bin scan…", self.bin_scan, "Ctrl+B")
        self._act(p, "Reset shift and binning", self.reset_processing)
        p.addSeparator()
        self._act(p, "Copy settings to all scans", self.copy_to_all)

        v = m.addMenu("&View")
        self._theme_actions = {}
        for name in ("light", "dark"):
            a = QAction(name.capitalize(), self, checkable=True)
            a.setChecked(theme.T.name == name)
            a.triggered.connect(lambda _c, n=name: self._set_theme(n))
            self._theme_actions[name] = a
            v.addAction(a)

        h = m.addMenu("&Help")
        self._act(h, "How the two engines differ", self.show_engine_help)

    def _act(self, menu, text, slot, shortcut=None):
        a = QAction(text, self)
        if shortcut:
            a.setShortcut(shortcut)
        a.triggered.connect(slot)
        menu.addAction(a)
        return a

    # -- logging --------------------------------------------------------
    def reset_views(self):
        """Forget zoom on every panel; the underlying data has changed."""
        for panel in (self.plot_data, self.plot_norm, self.plot_avg,
                      self.plot_ana, self.tab_peakfit.plot):
            panel.reset_view()

    def log(self, msg):
        self.project.log.append(msg)
        self.log_view.appendPlainText(msg)

    # -- data -----------------------------------------------------------
    def _start_dir(self, filename=""):
        """Where a file dialog should open, and with what name."""
        base = self._last_dir or str(pathlib.Path.home())
        return str(pathlib.Path(base) / filename) if filename else base

    def import_scans(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Import ratioed scans", self._start_dir(),
            "Spectra (*.txt *.xas *.dat *.csv *.tsv);;All files (*)")
        if paths:
            self._import_paths(paths, ask_columns=True)

    # -- session drag and drop -------------------------------------
    def dragEnterEvent(self, event):
        if dropped_sessions(event):
            event.acceptProposedAction()

    def dragMoveEvent(self, event):
        if dropped_sessions(event):
            event.acceptProposedAction()

    def dropEvent(self, event):
        sessions = dropped_sessions(event)
        if not sessions:
            return
        event.acceptProposedAction()
        if len(sessions) > 1:
            self.log(f"{len(sessions)} sessions dropped; opening "
                     f"{sessions[0].name} and ignoring the rest")
        self._session_dropped(str(sessions[0]))

    def _session_dropped(self, path):
        """Open a dropped session, asking first if work would be lost."""
        if self.project.scans and QMessageBox.question(
                self, "Open session",
                f"Open {pathlib.Path(path).name}? The "
                f"{len(self.project.scans)} scan"
                f"{'s' if len(self.project.scans) != 1 else ''} currently "
                "loaded will be discarded."
                ) != QMessageBox.Yes:
            return
        self.open_session(path)

    def _scans_dropped(self, paths, _row):
        self._import_paths(paths, ask_columns=False)

    def _import_paths(self, paths, ask_columns=True):
        """Import files as scans.

        ``ask_columns`` is False for a drop. A two-column file has no
        ambiguity to resolve, so dropping ten of them should not mean ten
        dialogs; anything wider still asks, because guessing which column
        is the intensity is exactly the kind of silent mistake that is
        hard to spot later.
        """
        added, failed = 0, []
        for path in paths:
            try:
                lc = dataio.load_columns(path)
            except Exception as exc:                 # noqa: BLE001
                failed.append(f"{pathlib.Path(path).name}: {exc}")
                continue
            ix, iy = dataio.guess_columns(lc)
            if ask_columns or lc.n_columns > 2:
                dlg = ImportDialog(lc, self)
                if dlg.exec() != QDialog.Accepted:
                    continue
                ix, iy = dlg.columns()
            scan = dataio.Scan(
                name=pathlib.Path(path).stem,
                energy_raw=lc.column(ix),
                intensity_raw=lc.column(iy),
                source=str(path),
                intensity_kind="od",
            )
            self.project.scans.append(scan)
            self._last_dir = str(pathlib.Path(path).parent)
            added += 1
            self.log(f"imported {scan.name}: {scan.summary()}")

        if failed:
            QMessageBox.warning(self, "Import failed", "\n".join(failed[:8]))
        if not added:
            return
        self.reset_views()
        if self.project.defaults.pre_hi <= self.project.defaults.pre_lo:
            self.suggest_windows(quiet=True)
        self._refresh_scan_list()
        self.scan_list.setCurrentRow(len(self.project.scans) - 1)
        self.recompute()

    def _i0_dropped(self, paths, row):
        """Attach a dropped file as I0.

        The row under the pointer wins, so dropping onto a scan attaches
        it there; dropping on empty space falls back to the selected
        scan. Several files at once are attached down the list in order,
        which is what dragging a folder of I0 scans should do.
        """
        if not self.project.scans:
            QMessageBox.information(self, APP_NAME,
                                    "Import some data scans first.")
            return
        start = row if row >= 0 else max(self.scan_list.currentRow(), 0)
        attached, failed = 0, []
        for k, path in enumerate(paths):
            idx = start + k
            if idx >= len(self.project.scans):
                failed.append(f"{pathlib.Path(path).name}: no scan to "
                              "attach it to")
                continue
            try:
                lc = dataio.load_columns(path)
            except Exception as exc:                 # noqa: BLE001
                failed.append(f"{pathlib.Path(path).name}: {exc}")
                continue
            ix, iy = dataio.guess_columns(lc)
            if lc.n_columns > 2:
                dlg = ImportDialog(lc, self)
                dlg.setWindowTitle(f"I\u2080 for {self.project.scans[idx].name}")
                if dlg.exec() != QDialog.Accepted:
                    continue
                ix, iy = dlg.columns()
            s = self.project.scans[idx]
            s.i0_energy = lc.column(ix)
            s.i0_intensity = lc.column(iy)
            s.intensity_kind = dataio.detect_intensity_kind(
                s.intensity_raw, s.i0_intensity)
            s.show_i0 = True
            attached += 1
            kind = dataio.INTENSITY_KINDS.get(s.intensity_kind,
                                              s.intensity_kind)
            self.log(f"{s.name}: I\u2080 from {pathlib.Path(path).name}; "
                     f"intensity treated as {kind}")
            if s.intensity_kind != "od":
                self.log(f"  ! {s.name} will now be DIVIDED by this I\u2080. "
                         "aXis2000 output is already ratioed; if this file "
                         "is, detach the I\u2080 or it will be ratioed twice.")
        if failed:
            QMessageBox.warning(self, "I\u2080 attach failed",
                                "\n".join(failed[:8]))
        if attached:
            self.reset_views()
            self._refresh_scan_list()
            self.recompute()

    def remove_scan(self):
        i = self.scan_list.currentRow()
        if 0 <= i < len(self.project.scans):
            self.log(f"removed {self.project.scans[i].name}")
            del self.project.scans[i]
            self.reset_views()
            self._refresh_scan_list()
            self.recompute()

    def _refresh_scan_list(self):
        """Repopulate both lists, preserving the selected row."""
        self.params.refresh_scope([s.name for s in self.project.scans],
                                  self.scan_list.currentRow())
        self._refresh_grid_ref()
        self._syncing_lists = True
        try:
            row = self.scan_list.currentRow()
            self.scan_list.clear()
            self.i0_list.clear()
            for s in self.project.scans:
                item = QListWidgetItem(s.name)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked if s.show else Qt.Unchecked)
                self.scan_list.addItem(item)

                has = s.i0_energy is not None
                if not has:
                    label = f"{s.name}   (no I\u2080)"
                elif s.intensity_kind == "od":
                    label = f"{s.name}   (reference only)"
                else:
                    # The data is actually being divided by this I0, which
                    # changes every number downstream. Say so in the list,
                    # not only in the log.
                    label = f"{s.name}   \u00f7 I\u2080 ({s.intensity_kind})"
                it0 = QListWidgetItem(label)
                if has:
                    it0.setFlags(it0.flags() | Qt.ItemIsUserCheckable)
                    it0.setCheckState(Qt.Checked if s.show_i0 else Qt.Unchecked)
                else:
                    it0.setFlags(Qt.ItemIsEnabled & ~Qt.ItemIsEnabled)
                self.i0_list.addItem(it0)
            if 0 <= row < self.scan_list.count():
                self.scan_list.setCurrentRow(row)
        finally:
            self._syncing_lists = False

    def _scan_shown_changed(self, item):
        if getattr(self, "_syncing_lists", False):
            return
        i = self.scan_list.row(item)
        if 0 <= i < len(self.project.scans):
            self.project.scans[i].show = item.checkState() == Qt.Checked
            self._redraw()

    def _i0_shown_changed(self, item):
        if getattr(self, "_syncing_lists", False):
            return
        i = self.i0_list.row(item)
        if 0 <= i < len(self.project.scans):
            self.project.scans[i].show_i0 = item.checkState() == Qt.Checked
            self._redraw()

    def _set_all_shown(self, which, state):
        for s in self.project.scans:
            if which == "data":
                s.show = state
            else:
                s.show_i0 = state
        self._refresh_scan_list()
        self._redraw()

    # -- I0 ---------------------------------------------------------
    def attach_i0(self):
        """Attach an I0 file to the selected scan.

        The intensity kind is guessed from the magnitudes involved: raw
        transmission sits within an order of magnitude of I0, whereas
        already-ratioed optical density does not.
        """
        s = self.current_scan()
        if s is None:
            QMessageBox.information(self, APP_NAME, "Select a scan first.")
            return
        path, _ = QFileDialog.getOpenFileName(
            self, f"Attach I\u2080 to {s.name}", self._start_dir(),
            "Spectra (*.txt *.xas *.dat *.csv *.tsv);;All files (*)")
        if not path:
            return
        try:
            lc = dataio.load_columns(path)
        except Exception as exc:                     # noqa: BLE001
            QMessageBox.warning(self, "Import failed", str(exc))
            return
        dlg = ImportDialog(lc, self)
        dlg.setWindowTitle(f"I\u2080 for {s.name}: {lc.path.name}")
        if dlg.exec() != QDialog.Accepted:
            return
        ix, iy = dlg.columns()
        s.i0_energy = lc.column(ix)
        s.i0_intensity = lc.column(iy)
        kind = dataio.detect_intensity_kind(s.intensity_raw, s.i0_intensity)
        s.intensity_kind = kind
        s.show_i0 = True
        self.log(f"{s.name}: attached I\u2080 from {pathlib.Path(path).name}; "
                 f"intensity treated as {dataio.INTENSITY_KINDS.get(kind, kind)}")
        if kind != "od":
            self.log(f"  ! {s.name} will now be DIVIDED by this I\u2080. "
                     "aXis2000 output is already ratioed; if this file is, "
                     "detach the I\u2080 or it will be ratioed twice.")
        self._refresh_scan_list()
        self.recompute()

    def detach_i0(self):
        s = self.current_scan()
        if s is None or s.i0_energy is None:
            return
        s.i0_energy = None
        s.i0_intensity = None
        s.intensity_kind = "od"
        self.log(f"{s.name}: I\u2080 detached; intensity taken as-is")
        self._refresh_scan_list()
        self.recompute()

    def _scale_from_edges(self):
        """Set the area/peak window to span both edge markers."""
        a, b = self.edge_a_box.value(), self.edge_b_box.value()
        if not a or not b:
            QMessageBox.information(
                self, APP_NAME,
                "Set edge A and B first \u2014 Find peaks on the Analysis "
                "tab does it automatically.")
            return
        lo, hi = sorted((a, b))
        pad = max(0.35 * (hi - lo), 3.0)
        p = self.params.values()
        p.scale_lo, p.scale_hi = lo - pad, hi + pad
        self._updating = True
        self.params.load(p)
        self._updating = False
        self._params_changed()
        self.log(f"normalization window set to {p.scale_lo:.1f}-"
                 f"{p.scale_hi:.1f} eV from the edge markers")

    def _fit_exponent(self):
        """Estimate the power-law exponent from the pre-edge window."""
        s = self.current_scan()
        if s is None or s.energy is None:
            QMessageBox.information(self, APP_NAME, "Select a scan first.")
            return
        p = self.params.values()
        try:
            n = core.fit_power_exponent(s.energy, s.intensity,
                                        p.pre_lo, p.pre_hi)
        except Exception as exc:                     # noqa: BLE001
            QMessageBox.information(self, APP_NAME, str(exc))
            return
        self.log(f"{s.name}: pre-edge regresses as E^({-n:+.2f})")
        if not 1.0 <= n <= 5.0:
            self.log("  ! that is outside the physical range for a "
                     "continuum (about 2 to 4); the pre-edge window is too "
                     "short or too flat to determine it. Leaving n at "
                     f"{p.pre_exponent if hasattr(p, 'pre_exponent') else 3.0:.2f}.")
            return
        self.params.pre_exponent.setValue(n)

    def _sample_changed(self, text):
        """The sample name feeds export names, so keep it usable as one."""
        name = dataio.safe_sample_name(text)
        if name == self.project.compound:
            return
        self.project.compound = name
        self.params.sample.setText(name)
        self.log(f"sample name set to {name!r}; the averaged spectrum will "
                 f"export as {dataio.average_name(self.project)}")
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}  \u2014  {name}")

    def _scope_changed(self):
        """Selector moved: follow it in the scan list and reload settings."""
        if self._updating:
            return
        which = self.params.scope.currentData()
        if isinstance(which, int) and 0 <= which < len(self.project.scans):
            if self.scan_list.currentRow() != which:
                self.scan_list.setCurrentRow(which)
        s = self.current_scan()
        self._updating = True
        try:
            self.params.load(self.project.params_for(s) if s is not None
                             else self.project.defaults)
        finally:
            self._updating = False
        self._update_mcmaster_warning(self.params.values())
        self._redraw()

    def _select_scan(self, row):
        self._selected = row
        # keep the parameter panel's selector pointing at the same scan
        if not self._updating and self.params.scope.currentData() != "all":
            self._updating = True
            try:
                self.params._set_combo(self.params.scope, row)
            finally:
                self._updating = False
        if 0 <= row < len(self.project.scans):
            s = self.project.scans[row]
            self.scan_info.setText(s.summary())
            self.params.load(self.project.params_for(s))
        self._redraw()

    def current_scan(self):
        i = self.scan_list.currentRow()
        if 0 <= i < len(self.project.scans):
            return self.project.scans[i]
        return None

    # -- parameters -----------------------------------------------------
    def _params_changed(self):
        if self._updating:
            return
        p = self.params.values()
        which = self.params.scope.currentData()
        if isinstance(which, int):
            if 0 <= which < len(self.project.scans):
                self.project.scans[which].params = p
        else:
            self.project.defaults = p
            for s in self.project.scans:
                s.params = None
        self._update_mcmaster_warning(p)
        self._recompute_timer.start()      # coalesced; see __init__

    def _update_mcmaster_warning(self, p):
        if p.engine != "mcmaster":
            self.params.set_mcmaster_warning("")
            return
        s = self.current_scan()
        if s is None or s.energy_raw is None or not p.element:
            self.params.set_mcmaster_warning("")
            return
        e = np.asarray(s.energy_raw, float)
        lo, hi = float(np.nanmin(e)), float(np.nanmax(e))
        w = engines.mcmaster_caveat(p.element, lo, hi)
        w += engines.mcmaster_window_check(p.element, p.pre_hi, p.post_lo,
                                           lo, hi)
        self.params.set_mcmaster_warning("\n".join(w))

    def calibrate(self):
        """Shift the energy axis so a known feature lands where it should."""
        if not self.project.scans:
            QMessageBox.information(self, APP_NAME, "Import a scan first.")
            return
        dlg = CalibrationDialog([s.name for s in self.project.scans],
                                self.scan_list.currentRow(), self)
        if dlg.exec() != QDialog.Accepted:
            return
        shift = dlg.shift()
        which = dlg.target.currentData()
        targets = (self.project.scans if which < 0
                   else [self.project.scans[which]])
        for s in targets:
            s.shift = s.shift + shift if dlg.additive.isChecked() else shift
        where = "all scans" if which < 0 else targets[0].name
        self.log(f"energy calibration: {shift:+.3f} eV applied to {where}")
        self.reset_views()
        self._refresh_scan_list()
        self.recompute()

    def bin_scan(self):
        """Average every N points. Non-destructive: the raw data is kept."""
        s = self.current_scan()
        if s is None:
            QMessageBox.information(self, APP_NAME, "Select a scan first.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Bin {s.name}")
        box = QSpinBox()
        box.setRange(1, 64)
        box.setValue(max(s.bin_factor, 1))
        allbox = QCheckBox("Apply to every scan")
        note = QLabel(
            "Averages every N points, which trades resolution for signal "
            "to noise. Non-destructive \u2014 set it back to 1 to recover "
            "the original sampling.\n\n"
            "Binning happens before the fits and before averaging, so the "
            "fit windows keep the same meaning.")
        note.setWordWrap(True)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("Points per bin:"))
        lay.addWidget(box)
        lay.addWidget(allbox)
        lay.addWidget(note)
        lay.addWidget(bb)
        if dlg.exec() != QDialog.Accepted:
            return
        targets = self.project.scans if allbox.isChecked() else [s]
        for t in targets:
            t.bin_factor = box.value()
        self.log(f"binning x{box.value()} on "
                 f"{'every scan' if allbox.isChecked() else s.name}")
        self.reset_views()
        self._refresh_scan_list()
        self.recompute()

    def reset_processing(self):
        """Clear every shift and bin factor, back to the imported data."""
        if not self.project.scans:
            return
        for s in self.project.scans:
            s.shift = 0.0
            s.bin_factor = 1
        self.log("cleared all energy shifts and binning")
        self.reset_views()
        self._refresh_scan_list()
        self.recompute()

    def mcmaster_windows(self):
        """Place the windows around the tabulated edge, as norm2poly does."""
        s = self.current_scan()
        if s is None or s.energy_raw is None:
            QMessageBox.information(self, APP_NAME, "Import a scan first.")
            return
        p = self.params.values()
        e = np.asarray(s.energy_raw, float)
        e0 = p.e0 or engines.mcmaster_edge_energies(p.element).get(p.edge, 0.0)
        if not e0:
            QMessageBox.information(self, APP_NAME,
                                    "No edge energy for that element.")
            return
        lo, hi, = float(np.nanmin(e)), float(np.nanmax(e))
        p.pre_lo, p.pre_hi, p.post_lo, p.post_hi = \
            engines.mcmaster_default_windows(e0, lo, hi)
        self._updating = True
        self.params.load(p)
        self._updating = False
        self._params_changed()
        self.log(f"windows placed around the {p.edge} edge at {e0:.1f} eV")

    def use_fitted_step(self):
        """Copy the fit's own edge jump into the editable field."""
        s = self.current_scan()
        if s is None or s.norm is None or s.norm.engine != "mcmaster":
            QMessageBox.information(
                self, APP_NAME,
                "Run a McMaster normalization first; the fitted edge jump "
                "comes from it.")
            return
        val = s.norm.detail.get("auto_edge_step")
        if not val or not np.isfinite(val):
            return
        p = self.params.values()
        p.edge_step = float(val)
        self._updating = True
        self.params.load(p)
        self._updating = False
        self._params_changed()
        self.log(f"edge jump set to the fitted value {val:.6g} cm\u00b2/g")

    def copy_to_all(self):
        p = self.params.values()
        self.project.defaults = p
        for s in self.project.scans:
            s.params = None
        self.log("settings copied to all scans")
        self.recompute()

    def suggest_windows(self, quiet=False):
        s = self.current_scan() or (self.project.scans[0]
                                    if self.project.scans else None)
        if s is None:
            if not quiet:
                QMessageBox.information(self, APP_NAME,
                                        "Import a scan first.")
            return
        e = np.asarray(s.energy_raw, float)
        lo, hi = float(np.nanmin(e)), float(np.nanmax(e))
        span = hi - lo
        p = self.params.values()
        p.pre_lo, p.pre_hi = lo + 0.02 * span, lo + 0.18 * span
        p.post_lo, p.post_hi = hi - 0.35 * span, hi - 0.02 * span
        p.norm_energy = hi - 0.18 * span
        self._updating = True
        self.params.load(p)
        self._updating = False
        self._params_changed()
        if not quiet:
            self.log(f"suggested windows from {s.name}")

    def set_edge_from_element(self):
        """Seed all four windows from the nominal edge pair for an element.

        The table is a convenience, not a calibration standard -- it only
        puts the windows roughly right. Drag on the plot afterwards.
        """
        table = edges.load_edges()
        dlg = QDialog(self)
        dlg.setWindowTitle("Set edge from element")
        el_box = QComboBox()
        edge_box = QComboBox()
        for sym in sorted(table):
            el_box.addItem(sym, sym)

        def _fill(*_):
            edge_box.clear()
            for label in table.get(el_box.currentData(), {}):
                edge_box.addItem(label, label)

        el_box.currentIndexChanged.connect(_fill)
        _fill()
        note = QLabel(edges.DISCLAIMER)
        note.setWordWrap(True)
        note.setStyleSheet("font-size: 11px;")

        form = QFormLayout()
        form.addRow("Element", el_box)
        form.addRow("Edge", edge_box)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        lay = QVBoxLayout(dlg)
        lay.addLayout(form)
        lay.addWidget(note)
        lay.addWidget(bb)
        if dlg.exec() != QDialog.Accepted:
            return

        el, label = el_box.currentData(), edge_box.currentData()
        if not el or not label:
            return
        a, b = table[el][label]
        self.project.element = el
        self.project.edge_label = label
        self.project.edge_a, self.project.edge_b = float(a), float(b)

        w = edges.suggest_windows(float(a), float(b))
        p = self.params.values()
        p.pre_lo, p.pre_hi = w["pre"]
        p.post_lo, p.post_hi = w["post"]
        p.norm_energy = w["norm_energy"]
        if engines.mcmaster.zymbol(el) is not None:
            p.element = el
        self._updating = True
        self.params.load(p)
        self._updating = False
        self._params_changed()
        self.log(f"windows seeded from {el} {label} "
                 f"({a:g} / {b:g} eV nominal)")

    # -- span selector --------------------------------------------------
    def _colour_drag_labels(self):
        """Tint the mode buttons to match the window shading.

        The key lives in the controls rather than the legend: labelling
        the two shaded spans instead pushed the legend to five entries and
        squashed the plot underneath it.
        """
        t = theme.T
        for i, col in ((0, t.pre), (1, t.post), (2, t.excl)):
            b = self.drag_group.button(i)
            if b is not None:
                b.setStyleSheet(f"color: {col};")

    def _drag_mode_changed(self, button):
        """Switch between setting a window and rubber-band zoom.

        A live SpanSelector and the toolbar's zoom both consume a drag, so
        they cannot be active together. Choosing "Zoom only" should
        actually give you zoom rather than merely switching the drag off,
        which is why the toolbar mode is driven from here.
        """
        self._drag_target = button.property("key")
        zoom_only = self._drag_target == "none"
        self.span.set_active(not zoom_only)
        self.plot_norm.enable_zoom(zoom_only)

    def _on_span(self, lo, hi):
        if self._drag_target == "none":
            return
        if hi - lo < 1e-6:
            return
        p = self.params.values()
        if self._drag_target == "pre":
            p.pre_lo, p.pre_hi = lo, hi
        elif self._drag_target == "post":
            p.post_lo, p.post_hi = lo, hi
            if not (p.post_lo <= p.norm_energy <= p.post_hi):
                p.norm_energy = 0.5 * (lo + hi)
        else:
            self.params.add_exclusion_range(lo, hi)
            return
        self._updating = True
        self.params.load(p)
        self._updating = False
        self._params_changed()

    # -- compute --------------------------------------------------------
    def flush(self):
        """Run a pending coalesced recompute now."""
        if self._recompute_timer.isActive():
            self._recompute_timer.stop()
            self.recompute()

    def recompute(self):
        self._recompute_timer.stop()
        if not self.project.scans:
            self._redraw()
            return
        msgs = self.project.recompute()
        seen = set()
        for m in msgs:
            if m not in seen:
                seen.add(m)
                self.log(m)
        self._refresh_table()
        self._redraw()

    def _refresh_table(self):
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.project.scans))
        for i, s in enumerate(self.project.scans):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked if s.include else Qt.Unchecked)
            self.table.setItem(i, 0, chk)
            self.table.setItem(i, 1, QTableWidgetItem(s.name))
            self.table.setItem(i, 2, QTableWidgetItem(
                f"{s.shift:+.3f}" if s.shift else ""))
            self.table.setItem(i, 3, QTableWidgetItem(
                str(s.bin_factor) if s.bin_factor > 1 else ""))
            step = "" if s.norm is None else f"{s.norm.edge_step:.6g}"
            self.table.setItem(i, 4, QTableWidgetItem(step))
            # only meaningful when the divisor is an edge step: an area
            # is in OD*eV and has no business being compared with an OD
            edge_scale = (s.norm.detail.get("scale_mode", "edge") == "edge"
                          if s.norm else False)
            frac = s.norm.detail.get("step_fraction") if s.norm else None
            fi = QTableWidgetItem(
                f"{100 * frac:.1f}%"
                if (edge_scale and frac and np.isfinite(frac)) else "")
            fi.setToolTip(
                "The divisor as a fraction of this scan's own pre-edge "
                "level. Scans of the same material at the same edge "
                "should agree; one that does not usually has a "
                "measurement problem.")
            self.table.setItem(i, 5, fi)

            st = s.norm.detail.get("stability") if s.norm else None
            si = QTableWidgetItem(f"{st:.1f}\u00d7" if st is not None else "")
            if st is not None and st > 1.0:
                si.setForeground(QColor(theme.T.excl))
            flips = (s.norm.detail.get("sign_flips") if s.norm else None)
            si.setToolTip(
                "How far the divisor moves when all four windows are "
                "nudged by \u00b12 eV, as a multiple of its own median. "
                "Above 1\u00d7 the normalized amplitude is not reliable."
                + (f"\nIt changes sign in {100 * flips:.0f}% of those "
                   "windows." if flips else ""))
            self.table.setItem(i, 6, si)

            fixed = bool(s.norm and s.norm.detail.get("rescued"))
            it = QTableWidgetItem("would invert" if fixed else "")
            if fixed:
                it.setForeground(QColor(theme.T.excl))
                it.setToolTip(
                    "The unconstrained pre-edge fit gave a negative edge "
                    "step, which would have turned this spectrum upside "
                    "down. It was refitted with the leading term alone. "
                    "Usable, but check the pre-edge window.")
            self.table.setItem(i, 7, it)
            status = s.error or ("ok" if s.norm else "not normalized")
            self.table.setItem(i, 8, QTableWidgetItem(status))
        self.table.blockSignals(False)

    def _update_grid_info(self, usable):
        """Say plainly what the averaging grid did to the sampling.

        The number worth seeing is not the total point count but the
        count where the sampling is finest, which is where the near-edge
        structure lives. On a real C K-edge set, 99 measured points
        between 283 and 290 eV became 16 on a uniform grid.
        """
        g = self.project.grid
        if g is None or not usable or g.size < 2:
            self.grid_info.setText("")
            return
        dg = np.diff(g)
        mode = self.project.grid_mode
        bits = [f"Grid: {mode}, {g.size} points",
                (f"step {dg.min():.3g} eV"
                 if np.allclose(dg, dg[0], rtol=1e-6)
                 else f"steps {dg.min():.3g}\u2013{dg.max():.3g} eV")]

        # compare against the finest sampling any contributing scan has
        fine, where = None, None
        for s in usable:
            e = np.asarray(s.norm.energy, float)
            if e.size < 2:
                continue
            d = np.diff(e)
            if fine is None or d.min() < fine:
                fine = float(d.min())
                where = float(e[:-1][np.argmin(d)])
        if fine:
            lo, hi = where - 3.0, where + 3.0
            n_grid = int(((g >= lo) & (g <= hi)).sum())
            n_src = max(int(((np.asarray(s.norm.energy) >= lo)
                             & (np.asarray(s.norm.energy) <= hi)).sum())
                        for s in usable)
            bits.append(f"around {where:.1f} eV the finest scan has "
                        f"{n_src} points, the grid has {n_grid}")
            if n_src and n_grid < 0.7 * n_src:
                bits.append("\u2014 the average is coarser than the data "
                            "there; Native keeps the measured sampling")
        n = self.project.average_n
        if n is not None and n.size and int(n.min()) < len(usable):
            bits.append(f"\u2014 {int(np.sum(n < len(usable)))} points "
                        f"averaged over as few as {int(n.min())} of "
                        f"{len(usable)} scans (shaded)")
        self.grid_info.setText("   ".join(bits))
        t = theme.T
        bad = ("coarser than the data" in self.grid_info.text()
               or "averaged over as few as" in self.grid_info.text())
        self.grid_info.setStyleSheet(
            f"font-size: 11px; color: {t.excl if bad else t.text_dim};")

    def _grid_changed(self, *_):
        if getattr(self, "_updating", False):
            return
        self.project.grid_mode = self.grid_mode.currentData()
        self.project.interp_mode = self.interp_mode.currentData()
        self.project.grid_clip = bool(self.grid_clip.currentData())
        self.project.reference_index = self.grid_ref.currentData()
        self.recompute()

    def _refresh_grid_ref(self):
        """Keep the reference-scan list in step with what is loaded."""
        want = self.grid_ref.currentData()
        self._updating = True
        try:
            self.grid_ref.clear()
            self.grid_ref.addItem("First included", None)
            for i, s in enumerate(self.project.scans):
                self.grid_ref.addItem(s.name, i)
            if want is not None:
                for i in range(self.grid_ref.count()):
                    if self.grid_ref.itemData(i) == want:
                        self.grid_ref.setCurrentIndex(i)
                        break
        finally:
            self._updating = False

    def _table_changed(self, item):
        if item.column() != 0:
            return
        i = item.row()
        if 0 <= i < len(self.project.scans):
            self.project.scans[i].include = item.checkState() == Qt.Checked
            self.recompute()

    # -- drawing --------------------------------------------------------
    def _redraw(self):
        idx = self.tabs.currentIndex()
        try:
            if idx == 0:
                self._draw_data()
            elif idx == 1:
                self._draw_norm()
            elif idx == 2:
                self._draw_average()
            elif idx == 3:
                self._draw_analysis()
            else:
                self.tab_peakfit.refresh_plot()
        except Exception:                            # noqa: BLE001
            self.log("draw error:\n" + traceback.format_exc())

    def _draw_data(self):
        t = theme.T
        ax0, ax1 = self.plot_data.ax(0), self.plot_data.ax(1)
        self.plot_data.reset(ax0)
        self.plot_data.reset(ax1)

        n_i0 = 0
        for i, s in enumerate(self.project.scans):
            if s.energy is None:
                continue
            if s.show:
                ax0.plot(s.energy, s.intensity, lw=1.1, color=t.scan_color(i),
                         label=s.name)
            if s.show_i0 and s.i0_energy is not None:
                ax1.plot(s.i0_energy, s.i0_intensity, lw=1.1,
                         color=t.scan_color(i), label=s.name)
                n_i0 += 1

        for a in (ax0, ax1):
            if a.get_legend_handles_labels()[0]:
                a.legend(fontsize=8, frameon=False)
        if n_i0 == 0:
            ax1.text(0.5, 0.5, "no I\u2080 attached\n"
                               "(Scans dock \u2192 I\u2080 \u2192 Attach)",
                     ha="center", va="center", fontsize=9, color=t.axis,
                     transform=ax1.transAxes)

        self.plot_data.style(ax0, xlabel="", ylabel="Intensity (as imported)")
        self.plot_data.style(ax1, ylabel="I\u2080")
        self.plot_data.settle(ax0)
        self.plot_data.settle(ax1)
        self.plot_data.draw()

    def _draw_norm(self):
        t = theme.T
        ax0, ax1 = self.plot_norm.ax(0), self.plot_norm.ax(1)
        self.plot_norm.reset(ax0)
        self.plot_norm.reset(ax1)
        s = self.current_scan()
        if s is None or s.energy is None:
            self.plot_norm.style(ax0, ylabel="Intensity")
            self.plot_norm.style(ax1, ylabel="Normalized")
            self.plot_norm.draw()
            self.report.setPlainText("")
            return

        p = self.project.params_for(s)
        ax0.plot(s.energy, s.intensity, lw=1.1, color=t.data, label="data")
        # Two windows, two colours. They were both drawn in the same blue,
        # which made it easy to lose track of which was which when they sit
        # close together or when one has been dragged past the other. The
        # fit curves below use the matching colour.
        ax0.axvspan(p.pre_lo, p.pre_hi, color=t.pre, alpha=0.16, lw=0)
        ax0.axvspan(p.post_lo, p.post_hi, color=t.post, alpha=0.16, lw=0)
        for val, col in ((p.pre_lo, t.pre), (p.pre_hi, t.pre),
                         (p.post_lo, t.post), (p.post_hi, t.post)):
            ln = ax0.axvline(val, color=col, lw=0.9, alpha=0.75)
            ln.set_gid(HoverCursor.MARK)
        for a, b in p.exclude:
            ax0.axvspan(a, b, color=t.excl, alpha=0.20, hatch="///", lw=0)

        if s.norm is not None:
            for label, y, hint in s.norm.overlays:
                ax0.plot(s.norm.energy, y, lw=1.3, ls="--",
                         color=t.pre if hint == "bg" else t.post,
                         label=label)
            ax1.plot(s.norm.energy, s.norm.normalized, lw=1.2, color=t.norm,
                     label="normalized")
            if s.norm.reference is not None:
                rlabel, rcurve = s.norm.reference
                ax1.plot(s.norm.energy, rcurve, lw=1.2, color=t.edge_a,
                         label=rlabel)
            if p.engine == "edgestep" or p.norm_to_one:
                ax1.axhline(1.0, color=t.guide, ls=":", lw=1.0)
            ax1.axhline(0.0, color=t.guide, ls=":", lw=1.0)
            if ax1.get_legend_handles_labels()[0]:
                ax1.legend(fontsize=8, frameon=False)
            ylab = s.norm.units
            txt = s.norm.report + self._stability_note(s, p)
            if s.norm.warnings:
                txt += "\n\nWarnings:\n" + "\n".join(
                    f"  ! {w}" for w in s.norm.warnings)
            self.report.setPlainText(txt)
        else:
            ylab = "Normalized"
            self.report.setPlainText(s.error or "not normalized")

        if ax0.get_legend_handles_labels()[0]:
            ax0.legend(fontsize=8, frameon=False)
        self.plot_norm.style(ax0, xlabel="", ylabel="Intensity")
        self.plot_norm.style(ax1, ylabel=ylab)
        self.plot_norm.settle(ax0)
        self.plot_norm.settle(ax1)
        self.plot_norm.draw()

    def _draw_average(self):
        t = theme.T
        ax = self.plot_avg.ax()
        self.plot_avg.reset(ax)
        usable = [s for s in self.project.scans
                  if s.include and s.norm is not None]
        for i, s in enumerate(usable):
            ax.plot(s.norm.energy, s.norm.normalized, lw=0.9, alpha=0.55,
                    color=t.scan_color(i), label=s.name)
        if self.project.average is not None:
            show_pts = self.show_points.isChecked()
            ax.plot(self.project.grid, self.project.average, lw=1.8,
                    color=t.norm, label="average",
                    marker="." if show_pts else "None",
                    markersize=4 if show_pts else 0,
                    markerfacecolor=t.norm, markeredgecolor=t.norm)
            if self.project.average_sem is not None:
                ax.fill_between(
                    self.project.grid,
                    self.project.average - self.project.average_sem,
                    self.project.average + self.project.average_sem,
                    color=t.norm, alpha=0.18, lw=0, label="\u00b1 s.e.m.")
        if ax.get_legend_handles_labels()[0]:
            ax.legend(fontsize=8, frameon=False)
        n = self.project.average_n
        if (n is not None and usable and n.size == self.project.grid.size
                and int(n.min()) < len(usable)):
            short = n < len(usable)
            # contiguous runs, so one span per region rather than per point
            edges = np.flatnonzero(np.diff(short.astype(int)))
            bounds = np.concatenate(([0], edges + 1, [short.size]))
            for a, b in zip(bounds[:-1], bounds[1:]):
                if short[a]:
                    ax.axvspan(self.project.grid[a],
                               self.project.grid[min(b, n.size - 1)],
                               color=t.excl, alpha=0.10, lw=0)
        self._update_grid_info(usable)
        units = usable[0].norm.units if usable else "Normalized"
        self.plot_avg.style(ax, ylabel=units)
        self.plot_avg.settle(ax)
        self.plot_avg.draw()

    # -- analysis -------------------------------------------------------
    def _peakfit_spectrum(self):
        """The spectrum the peak-fitting tab works on, with a label.

        Whatever the Analysis tab is showing, so peaks are fitted to the
        same curve the areas were measured on -- including under an area
        or peak normalization, where there is no edge step at all.
        """
        x, y, label, units = self._analysis_spectrum()
        if x is None:
            return None, None, ""
        return x, y, f"{label}  [{units}]"

    def _analysis_spectrum(self):
        """The spectrum to analyse, with a label and its units.

        Prefers the average when one exists, since a branching ratio
        should normally be measured on it.
        """
        if self.project.average is not None:
            m = np.isfinite(self.project.average)
            usable = [s for s in self.project.scans
                      if s.include and s.norm is not None]
            units = usable[0].norm.units if usable else ""
            return (self.project.grid[m], self.project.average[m],
                    "average", units)
        s = self.current_scan()
        if s is not None and s.norm is not None:
            return s.norm.energy, s.norm.normalized, s.name, s.norm.units
        return None, None, "", ""

    def _draw_analysis(self):
        t = theme.T
        ax0, ax1 = self.plot_ana.ax(0), self.plot_ana.ax(1)
        self.plot_ana.reset(ax0)
        self.plot_ana.reset(ax1)
        x, y, label, units = self._analysis_spectrum()
        if x is None or x.size < 5:
            ax0.text(0.5, 0.5, "Normalize some scans first", ha="center",
                     va="center", transform=ax0.transAxes, color=t.text_dim)
            self.plot_ana.style(ax0, xlabel="", ylabel="Normalized")
            self.plot_ana.style(ax1, ylabel="Derivative")
            self.plot_ana.draw()
            return

        passes = self.smooth_box.value()
        # measured points plus the curve the derivatives come from, so it
        # is obvious when the smoothing has gone too far
        ax0.plot(x, y, ls="none", marker=".", ms=3, color=t.data,
                 label=label)
        sm = core.smoothed_curve(x, y, passes)
        ax0.plot(x, sm, lw=1.4, color=t.norm, label="smoothed")
        d1, d2 = core.derivatives(x, y, passes=passes)
        # each scaled to unit amplitude: only the zero crossings and
        # turning points matter, and the two differ by orders of magnitude
        s1 = float(np.nanmax(np.abs(d1))) or 1.0
        s2 = float(np.nanmax(np.abs(d2))) or 1.0
        ax1.plot(x, d1 / s1, lw=1.1, color=t.deriv1,
                 label="1st derivative (scaled)")
        ax1.plot(x, d2 / s2, lw=1.0, color=t.deriv2,
                 label="2nd derivative (scaled)")
        ax1.axhline(0.0, lw=0.8, color=t.guide, ls=":")
        for val, col, nm in ((self.edge_a_box.value(), t.edge_a, "A"),
                             (self.edge_b_box.value(), t.edge_b, "B")):
            if val:
                # The marks must not take part in autoscaling. An axvline
                # spans the axes in y, but its x data still enters the data
                # limits, so a stale edge energy sitting outside the scan
                # stretched the view. Tagged and excluded, like the hover
                # marker.
                for a in (ax0, ax1):
                    ln = a.axvline(val, color=col, lw=1.0, ls="--")
                    ln.set_gid(HoverCursor.MARK)
                t_ = ax0.text(val, 0.97, f" {nm}", color=col, fontsize=9,
                              transform=ax0.get_xaxis_transform(),
                              va="top", clip_on=True)
                t_.set_gid(HoverCursor.MARK)
        for a in (ax0, ax1):
            if a.get_legend_handles_labels()[0]:
                a.legend(fontsize=8, frameon=False)
        self.plot_ana.style(ax0, xlabel="", ylabel=units or "Normalized")
        self.plot_ana.style(ax1, ylabel="Derivative")
        self.plot_ana.settle(ax0)
        self.plot_ana.settle(ax1)
        self.plot_ana.draw()

    def _clear_peaks(self):
        self.edge_a_box.setValue(0.0)
        self.edge_b_box.setValue(0.0)
        self.project.edge_a = self.project.edge_b = None
        self.area_report.setPlainText("")
        self.plot_ana.autoscale()
        self.log("cleared edge A and B")
        self._redraw()

    def _stability_note(self, scan, p):
        """How far the edge step moves under a small change of window.

        Computed only for the scan on screen, and cached, because it
        costs a handful of extra fits. An edge step that swings by more
        than its own size under a 2 eV nudge is not a measurement, and
        that is worth seeing next to the number itself.
        """
        if scan.norm is None or scan.norm.engine != "edgestep":
            return ""
        key = (id(scan), repr(p.to_dict()))
        if getattr(self, "_stab_key", None) != key:
            try:
                self._stab = core.edge_step_stability(
                    scan.energy, scan.intensity, p.to_norm_params())
            except Exception:                        # noqa: BLE001
                self._stab = None
            self._stab_key = key
        st = self._stab
        if not st:
            return ""
        line = (f"\nStability: windows nudged \u00b1{st['delta']:.0f} eV, "
                f"edge step spans {st['min']:.5g} to {st['max']:.5g} "
                f"({st['ratio']:.1f}\u00d7 its median)")
        if st["sign_flips"] > 0:
            line += (f"\n  ! it changes sign in "
                     f"{100 * st['sign_flips']:.0f}% of those windows \u2014 "
                     "the edge step is not determined by this data")
        elif st["ratio"] > 1.0:
            line += ("\n  ! it moves by more than its own size; the "
                     "normalized amplitude is not reliable. A wider "
                     "pre-edge window or a 1-term Victoreen usually helps.")
        return line

    def _find_peaks(self):
        x, y, _, _ = self._analysis_spectrum()
        if x is None:
            QMessageBox.information(self, APP_NAME,
                                    "Normalize some scans first.")
            return
        d1, d2 = core.derivatives(x, y, passes=self.smooth_box.value())
        peaks = core.find_peaks_from_derivative(x, d1, d2)
        if peaks.size == 0:
            self.log("no maxima found; try a different smoothing width")
            return
        heights = np.interp(peaks, x, y)
        order = np.argsort(heights)[::-1]
        self.log("maxima (eV): " +
                 ", ".join(f"{peaks[i]:.2f}" for i in order[:8]))
        if peaks.size >= 2:
            two = np.sort(peaks[order[:2]])
            self.edge_a_box.setValue(float(two[0]))
            self.edge_b_box.setValue(float(two[1]))
            self.project.edge_a, self.project.edge_b = float(two[0]), float(two[1])
            self.log(f"edge A = {two[0]:.2f} eV, edge B = {two[1]:.2f} eV "
                     f"(splitting {two[1] - two[0]:.2f} eV)")
        self._redraw()

    def _edge_labels(self):
        return {"L2,3": ("L3", "L2"), "M4,5": ("M5", "M4"),
                "N4,5": ("N5", "N4")}.get(self.project.edge_label, ("A", "B"))

    def _compute_areas(self):
        x, y, label, units = self._analysis_spectrum()
        if x is None:
            QMessageBox.information(self, APP_NAME,
                                    "Normalize some scans first.")
            return
        a, b = self.edge_a_box.value(), self.edge_b_box.value()
        if not a or not b or b <= a:
            QMessageBox.information(
                self, APP_NAME,
                "Set edge A and edge B first \u2014 Find peaks does it "
                "automatically.")
            return
        w = core.suggest_area_windows(a, b, float(x.min()), float(x.max()))
        mid = (core.line_through_region(x, y, *w["continuum"])
               if w["continuum"][1] > w["continuum"][0] else None)
        res = core.edge_areas(x, y, a, b, window_a=w["a"], window_b=w["b"],
                              window_continuum=w["continuum"], midline=mid)
        la, lb = self._edge_labels()

        # The two ratios are dimensionless and come out the same whichever
        # engine produced the spectrum; the raw areas carry its units.
        txt = [f"Spectrum: {label}", f"Scale: {units}", "",
               res.report(la, lb), "",
               "The integrated areas are in the units of the current "
               f"scale ({units}).",
               "",
               "White-line intensity and branching ratio are ratios of "
               "areas, so switching between cm\u00b2/g and edge jump = 1 "
               "leaves them exactly unchanged. Switching *engine* changes "
               "them slightly \u2014 a different background was removed "
               "\u2014 typically well under a percent on real data. "
               "Compare ratios only across spectra normalized the same "
               "way."]
        self.area_report.setPlainText("\n".join(txt))
        for m in res.warnings:
            self.log(f"areas: {m}")
        self.log(f"white-line intensity {res.white_line:.4f}, "
                 f"branching ratio {res.branching_ratio:.4f}")

    # -- export ---------------------------------------------------------
    def export_average(self):
        self.flush()
        if self.project.average is None:
            QMessageBox.information(self, APP_NAME, "Nothing to export yet.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export averaged spectrum",
            self._start_dir(f"{dataio.average_name(self.project)}.txt"),
            "Text (*.txt);;CSV (*.csv)")
        if path:
            dataio.export_average(self.project, path)
            self.log(f"exported average to {path}")

    def export_all(self):
        self.flush()
        d = QFileDialog.getExistingDirectory(self, "Export every scan")
        if d:
            dataio.export_all_normalized(self.project, d)
            self.log(f"exported all scans to {d}")

    def export_igor(self):
        """Write an Igor Text file with every normalized scan plus the
        average, for anyone who wants to fit the result in Igor Pro."""
        self.flush()
        if not any(s.norm is not None for s in self.project.scans):
            QMessageBox.information(self, APP_NAME, "Normalize something first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export for Igor Pro",
            self._start_dir(f"{self.project.compound}_normalized.itx"),
            "Igor Text (*.itx);;All files (*)")
        if not path:
            return
        dataio.export_igor_text(self.project, path)
        self.log(f"exported Igor Text to {path}")
        self.statusBar().showMessage(
            "Igor: Data \u25b8 Load Waves \u25b8 Load Igor Text", 8000)

    def save_session(self):
        self.flush()
        path, _ = QFileDialog.getSaveFileName(
            self, "Save session", self._start_dir(f"{self.project.compound}.stxmnorm"),
            "Session (*.stxmnorm)")
        if path:
            self.project.save(path)
            self.log(f"session saved to {path}")

    def close_session(self, confirm=True):
        """Empty the project so a new sample can be started in place.

        ``confirm`` is only False for the self-test: a modal prompt with
        nothing to click blocks a headless run forever.
        """
        if confirm and self.project.scans and QMessageBox.question(
                self, "Close session",
                f"Discard {len(self.project.scans)} loaded scan"
                f"{'s' if len(self.project.scans) != 1 else ''} and start "
                "a new session? Anything not exported or saved is lost."
                ) != QMessageBox.Yes:
            return
        self._recompute_timer.stop()
        self.project = dataio.Project()
        self.params.sample.setText(self.project.compound)
        self._updating = True
        try:
            self.params.load(self.project.defaults)
        finally:
            self._updating = False
        self.edge_a_box.setValue(0.0)
        self.edge_b_box.setValue(0.0)
        self.area_report.setPlainText("")
        self.report.setPlainText("")
        self.log_view.clear()
        self.reset_views()
        self._refresh_scan_list()
        self._refresh_table()
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.statusBar().showMessage("New session. Import scans to begin.")
        self._redraw()

    def open_session(self, path=None):
        if not path:
            path, _ = QFileDialog.getOpenFileName(
                self, "Open session", self._start_dir(),
                "Session (*.stxmnorm *.xasnorm)")
        if not path:
            return
        try:
            self.project = dataio.Project.load(path)
        except Exception as exc:                     # noqa: BLE001
            QMessageBox.warning(self, APP_NAME, f"Could not open:\n{exc}")
            return
        self._last_dir = str(pathlib.Path(path).parent)
        self.reset_views()
        self._refresh_scan_list()
        self.params.load(self.project.defaults)
        self.params.sample.setText(self.project.compound)
        self.setWindowTitle(
            f"{APP_NAME} {APP_VERSION}  \u2014  {self.project.compound}")
        self.recompute()
        self.log(f"session opened from {path}")

    # -- misc -----------------------------------------------------------
    def _set_theme(self, name):
        theme.apply(QApplication.instance(), name)
        QSettings("STXMNorm", "STXMNorm").setValue("theme", name)
        for key, act in getattr(self, "_theme_actions", {}).items():
            act.setChecked(key == name)
        for p in (self.plot_data, self.plot_norm, self.plot_avg,
                  self.plot_ana, self.tab_peakfit.plot):
            p.retheme()
        self._colour_drag_labels()
        self._redraw()

    def show_engine_help(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("How the two engines differ")
        dlg.resize(760, 560)
        txt = QPlainTextEdit(ENGINE_HELP)
        txt.setReadOnly(True)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(dlg.reject)
        bb.accepted.connect(dlg.accept)
        lay = QVBoxLayout(dlg)
        lay.addWidget(txt)
        lay.addWidget(bb)
        dlg.exec()


ENGINE_HELP = """\
TWO ENGINES, AND WHY THEY ARE NOT MERGED
========================================

XASNorm unified two Igor procedures that turned out to compute the same
thing: the Cp2VCl2 route's initial single-point scaling cancels exactly,
so the two differed in interface and default model, not in algebra. One
pipeline covered both.

norm2poly is not like that. It is a different calculation answering a
different question, so this program toggles rather than merges.

  EDGE STEP  (Branson / Cp2VCl2 / Athena lineage)
  -----------------------------------------------
      pre  = fit(pre-edge window)          Victoreen, line or polynomial
      sub  = I - pre
      post = fit(post-edge window of sub)
      norm = sub / post(E_norm)

  Two fits, in sequence. The result is dimensionless with the edge jump
  defined as 1. No element identity, no reference table, no assumption
  about what the sample is. Works at any energy.

  McMASTER  (norm2poly, Penner-Hahn group, 1998)
  -----------------------------------------------
      y ~ c0*mu_McMaster + c1*P0(x) + c2*P1(x) + ... + cn*Pn(x)
      norm = (y - polynomial part) * span_mu / c0 + mid_mu

  ONE fit, over the union of both windows. The Legendre polynomial models
  the background and c0 scales a tabulated atomic edge step; both are
  solved together. The result carries physical units, cm^2/g.


WHAT ACTUALLY DIFFERS
---------------------

1. Sequential vs simultaneous.
   The edge-step engine commits to a pre-edge fit and then fits the
   residual, so a pre-edge error propagates in full. The McMaster engine
   lets background and edge step trade off inside one solve, which is
   more forgiving of a marginal pre-edge window -- but it cannot show you
   a pre-edge fit independent of the edge-step estimate. You lose a
   diagnostic to gain robustness.

2. Empirical vs theoretical edge step.
   Edge step reads the step off your own data. McMaster takes its shape
   and size from a 1969 table and fits only the amplitude, so you inherit
   the table's errors along with its units.

3. Scale.
   "Edge jump = 1" and "cm^2/g" are not convertible without the element,
   the table, and the assumption that your sample's atomic absorption
   matches it. Set the McMaster output scale to "edge jump = 1" to put
   both on one footing for overlay, averaging and export.

4. Background basis.
   Victoreen (A/E^3 + B/E^4) is a physical parameterisation of atomic
   absorption. Legendre polynomials on [-1,1] are a numerically
   well-conditioned but purely empirical basis. Note that the polynomial
   is fitted only over the two windows yet evaluated across the whole
   scan, so a high order can swing between them. Orders 1-3 are usual.


A TABULATED EDGE IN THE WRONG PLACE IS FINE
------------------------------------------

McMaster puts the C K edge at 295.0 eV; the real one is at 284.2 eV. The
fit does not care. The template is levelled to zero across the pre-edge
window and its amplitude is fitted against the post-edge window, so all
that is needed is a tabulated edge somewhere in the gap between them.
Where your sample's edge sits is irrelevant to the arithmetic.

What you will see is the McMaster reference curve stepping at 295 eV
while your data steps at 284. That is drawn on the normalized panel so
you can judge it. The program only objects when no tabulated edge falls
between the windows, because then the template has no step to fit.


THE SOFT X-RAY LIMIT -- READ THIS ONE
-------------------------------------

McMaster's tabulation stops at the M1 edge. For a lanthanide that is
around 1.5 keV. Ln M4,5 white lines sit near 900-1000 eV, BELOW the
table, so the McMaster engine cannot run on them at all. The same is true
for actinide N4,5 edges. If your work is Ln M-edge STXM, the edge-step
engine is not merely preferable -- it is the only one available.

Transition-metal L2,3 edges (Ti 454, V 512, Mn 639, Fe 707, Cu 932 eV)
ARE inside the table, because McMaster tabulates L3. But below that L3
edge the table is the M-shell fit extrapolated over roughly a factor of
seven in energy, and it returns a few cm^2/g where the truth is
thousands. The algorithm zeroes the template's pre-edge before fitting,
so the solve stays self-consistent; what it means is that the absolute
scale rests on a jump magnitude the compilation is not really qualified
to supply down here. Treat cm^2/g at these energies as indicative, and
prefer Henke/CXRO for soft X-ray cross-sections.

Above roughly 3 keV -- K edges of the 3d metals, the regime norm2poly was
written for -- none of this applies and the McMaster scale is on solid
ground.


WHICH TO USE
------------

  Ln M4,5 or An N4,5 STXM         edge step (nothing else runs)
  TM L2,3 STXM, relative work     edge step
  TM L2,3, want absolute units    McMaster, reading the caveat above
  Hard X-ray K edges              McMaster
  Comparing shapes across samples either, consistently
  Reproducing old Igor results    edge step, flattening off

To compare the two on your own data, set the McMaster output scale to
"edge jump = 1" and toggle the engine. The windows stay put, so the only
thing that changes is the arithmetic. The difference you see is the two
background models disagreeing under the edge, which is the quantity the
choice of engine actually controls. On real data it is usually a few
percent of the white-line height; if it is much larger, one of the two
windows is in the wrong place.

(engines.compare_engines() still runs both in one call, for scripting.)
"""


def _app_icon() -> QIcon:
    """The window and taskbar icon.

    Frozen builds unpack beside sys.executable; a source checkout has it
    in the project root next to main.py. Missing is not an error -- Qt
    falls back to its default.
    """
    here = pathlib.Path(getattr(sys, "_MEIPASS", "")) if getattr(
        sys, "frozen", False) else pathlib.Path(__file__).resolve().parent.parent
    for cand in (here / "stxmnorm.ico",
                 pathlib.Path(__file__).resolve().parent.parent / "stxmnorm.ico"):
        if cand.exists():
            return QIcon(str(cand))
    return QIcon()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setWindowIcon(_app_icon())
    settings = QSettings("STXMNorm", "STXMNorm")
    theme.apply(app, settings.value("theme", "dark"))
    win = MainWindow()
    win.show()
    return app.exec()
