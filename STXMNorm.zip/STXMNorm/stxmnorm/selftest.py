"""
selftest.py -- numerical checks with known answers, runnable from a
frozen executable:  STXMNorm.exe --self-test

The checks that matter here are the ones about *unification*: that each
engine still reproduces its ancestor's arithmetic after being wrapped in
a common interface, and that the bridge between their two scales behaves.
"""

from __future__ import annotations

import pathlib
import sys

import numpy as np

from . import core, dataio, engines, mcmaster


def _synthetic(seed=0):
    """A V L2,3-like spectrum with a known edge jump."""
    rng = np.random.default_rng(seed)
    e = np.arange(505.0, 560.05, 0.15)

    def astep(x, x0, w, h):
        return h * (0.5 + np.arctan((x - x0) / (w / 2)) / np.pi)

    def gauss(x, c, f, a):
        return a * np.exp(-4 * np.log(2) * ((x - c) / f) ** 2)

    bg = 0.30 + 4.0e-4 * (e - 505) - 2.0e-6 * (e - 505) ** 2
    sig = (astep(e, 514.5, 1.5, 0.18) + astep(e, 521.8, 1.5, 0.09)
           + gauss(e, 515.74, 1.6, 0.52) + gauss(e, 517.0, 1.7, 0.16)
           + gauss(e, 522.88, 1.7, 0.26) + gauss(e, 524.2, 1.8, 0.09))
    y = bg + sig + rng.normal(0, 0.0015, e.size)
    return e, y, 0.27


CHECKS = []


def check(name):
    def deco(fn):
        CHECKS.append((name, fn))
        return fn
    return deco


@check("linear models are recovered exactly")
def _t1():
    e = np.linspace(900, 960, 200)
    y = 3.0 - 0.004 * e
    r = core.fit_region(e, y, 900, 960, "linear")
    assert abs(r.coefficients[0] - 3.0) < 1e-8, r.coefficients
    assert abs(r.coefficients[1] + 0.004) < 1e-10, r.coefficients


@check("Legendre recurrence matches numpy")
def _t2():
    for n in range(7):
        got = mcmaster.legpoly(n)
        want = np.polynomial.legendre.leg2poly(
            np.eye(n + 1)[n])[::-1]
        assert np.allclose(got, want, atol=1e-10), (n, got, want)


@check("McMaster reproduces a tabulated edge jump")
def _t3():
    el = mcmaster.elements()[29]                 # Cu
    below = mcmaster.mcmaster(29, np.array([el.L_edge[2] - 1e-4]))[0]
    above = mcmaster.mcmaster(29, np.array([el.L_edge[2] + 1e-4]))[0]
    assert above > below * 100, (below, above)


@check("edge-step engine puts the post-edge at 1")
def _t4():
    e, y, _ = _synthetic()
    p = engines.UnifiedParams(
        engine="edgestep", pre_lo=506, pre_hi=511.5,
        post_lo=535, post_hi=558, norm_energy=545, pre_model="linear")
    r = engines.normalize(e, y, p)
    post = (e >= 535) & (e <= 558)
    assert abs(np.mean(r.normalized[post]) - 1.0) < 0.05, \
        np.mean(r.normalized[post])


@check("the cosmetic pre-scale still cancels exactly")
def _t5():
    e, y, _ = _synthetic()
    base = dict(engine="edgestep", pre_lo=506, pre_hi=511.5, post_lo=535,
                post_hi=558, norm_energy=545, pre_model="linear")
    a = engines.normalize(e, y, engines.UnifiedParams(**base))
    b = engines.normalize(e, y, engines.UnifiedParams(**base, spoint=True))
    d = np.nanmax(np.abs(a.normalized - b.normalized))
    assert d < 1e-12, d


@check("McMaster fit recovers known coefficients to machine precision")
def _t6():
    """norm2poly's own round-trip check, at several polynomial orders.

    The background must be *in the model space* for this to be exact.
    A quadratic in E is not: McMaster's cross-section is exp(poly(log E)),
    so even a pure multiple of mu plus a quadratic leaves a ~4e-4
    residual. The invariant that actually holds is that a signal built
    from the design matrix comes back with its coefficients intact.
    """
    e = np.linspace(6300.0, 7000.0, 500)         # Mn, K edge at 6540 eV
    rng = (6300.0, 6520.0, 6620.0, 7000.0)
    i1 = (e >= rng[0]) & (e <= rng[1])
    i2 = (e >= rng[2]) & (e <= rng[3])
    x12 = np.concatenate((e[i1], e[i2]))
    n1 = int(i1.sum())

    mu = mcmaster.mcmaster(25, x12 / 1000.0)
    line = np.polyfit(e[i1], mu[:n1], 1)
    mu = mu - np.concatenate((mu[:n1], np.polyval(line, e[i2])))
    nx, _, _ = mcmaster.unify(x12)
    nmu, _, _ = mcmaster.unify(mu)

    for order in (1, 2, 3, 4):
        cols = [nmu, np.ones(x12.size), nx]
        cols += [np.polyval(mcmaster.legpoly(j), nx)
                 for j in range(2, order + 1)]
        A = np.column_stack(cols[:order + 2])
        c_true = np.array([0.55, 0.10, 0.22, -0.04, 0.01, 0.003])[:A.shape[1]]

        y = np.zeros_like(e)
        y[i1 | i2] = A @ c_true
        r = mcmaster.n2p_compute(e, y, 25, order, rng)

        # n2p_compute fits the *unified* y, so the recovered coefficients
        # are c_true / span_y, except the constant term (column 1), which
        # additionally absorbs -mid_y / span_y.
        _, mid_y, span_y = mcmaster.unify(y[i1 | i2])
        want = c_true / span_y
        want[1] = (c_true[1] - mid_y) / span_y
        got = np.asarray(r.C, float)
        assert np.allclose(got, want, atol=1e-9), (order, got, want)
        assert r.rms < 1e-9 * max(1.0, float(np.abs(y).max())), (order, r.rms)


@check("McMaster refuses a lanthanide M4,5 scan with an explanation")
def _t7():
    e = np.linspace(915.0, 990.0, 300)
    y = 0.3 + np.exp(-((e - 931) / 2) ** 2)
    p = engines.UnifiedParams(engine="mcmaster", pre_lo=916, pre_hi=925,
                              post_lo=970, post_hi=988, element="Pr")
    try:
        engines.normalize(e, y, p)
    except ValueError as exc:
        assert "M1 edge" in str(exc) and "edge-step" in str(exc), exc
        return
    raise AssertionError("should have refused")


@check("edge-step engine handles what McMaster cannot")
def _t8():
    e = np.linspace(915.0, 990.0, 400)
    y = (0.3 + 2e-4 * (e - 915)
         + 0.25 * (0.5 + np.arctan((e - 935) / 1.0) / np.pi)
         + 0.6 * np.exp(-4 * np.log(2) * ((e - 931) / 2.0) ** 2))
    p = engines.UnifiedParams(engine="edgestep", pre_lo=916, pre_hi=926,
                              post_lo=965, post_hi=989, norm_energy=975,
                              pre_model="linear")
    r = engines.normalize(e, y, p)
    assert np.isfinite(r.edge_step) and r.edge_step > 0, r.edge_step


@check("the two engines agree on shape to within a few percent")
def _t9():
    e, y, _ = _synthetic()
    p = engines.UnifiedParams(
        pre_lo=506, pre_hi=511.5, post_lo=535, post_hi=558,
        norm_energy=545, pre_model="linear", element="V", poly_order=2)
    res = engines.compare_engines(e, y, p)
    a, b = res["edgestep"], res["mcmaster"]
    assert not isinstance(a, str), a
    assert not isinstance(b, str), b
    post = (e >= 535) & (e <= 558)
    ja = np.mean(a.unit_jump()[post])
    jb = np.mean(b.unit_jump()[post])
    # The two engines define the unit differently, so they are only
    # expected to land near 1, not on it. Edge-step divides by the fit at
    # the normalization energy, so its post-edge window averages 1 by
    # construction. McMaster follows norm2poly and divides by the
    # tabulated cross-section at the *last point of the scan*, which the
    # post-edge window straddles rather than sits on.
    assert abs(ja - 1) < 0.05, ja
    assert abs(jb - 1) < 0.15, jb
    # The shapes must agree; the amplitudes need not. The two background
    # models genuinely disagree under the edge -- that is the quantity the
    # choice of engine controls -- so the white-line height differs by
    # some 15%. Correlation tests that they describe the same spectrum
    # without pretending they produce identical numbers.
    va, vb = a.unit_jump(), b.unit_jump()
    va = va / np.mean(va[post])
    vb = vb / np.mean(vb[post])
    corr = float(np.corrcoef(va, vb)[0, 1])
    assert corr > 0.99, corr


@check("a misplaced tabulated edge does not block the McMaster fit")
def _t11():
    """The carbon case, which an earlier guard refused outright.

    McMaster puts the C K edge at 295.0 eV; the real one is at 284.2 eV.
    That 10.8 eV discrepancy is irrelevant to the fit: what matters is
    that the tabulated edge falls between the two windows, so the
    template is zero below and the tabulated continuum above. Checked
    against norm2poly's own output on the same file: 81 pre and 54 post
    points, residual 0.019, edge jump 24776.8 cm^2/g.
    """
    e = np.arange(260.0, 379.6, 0.5)
    # a C K-edge-like spectrum: flat pre-edge, sharp rise at 284.2, decay
    y = 0.31 + 0.02 * (e - 260) / 120.0
    y = y + 0.42 * (0.5 + np.arctan((e - 284.4) / 0.4) / np.pi)
    y = y + 0.16 * np.exp(-4 * np.log(2) * ((e - 285.0) / 1.2) ** 2)
    y = y - 0.0011 * np.clip(e - 300.0, 0, None)

    p = engines.UnifiedParams(
        engine="mcmaster", element="C", edge="K",
        pre_lo=260.0, pre_hi=282.9, post_lo=299.3, post_hi=379.5,
        poly_order=2)
    r = engines.normalize(e, y, p)              # must not raise
    assert r.edge_step > 0, r.edge_step
    assert r.reference is not None

    # the tabulated edge is 10.8 eV from the data's own, and that is fine
    edges = engines.mcmaster_edge_energies("C")
    assert abs(edges["K"] - 295.0) < 0.05, edges
    assert not engines.mcmaster_window_check("C", 282.9, 299.3, 260.0, 379.5)

    # but windows that do not straddle a tabulated edge must be flagged
    bad = engines.mcmaster_window_check("C", 296.0, 299.3, 260.0, 379.5)
    assert bad and "between the windows" in bad[0], bad

    # normalize-to-1 is a pure rescaling
    q = engines.UnifiedParams(**{**p.to_dict(), "norm_to_one": True})
    r2 = engines.normalize(e, y, q)
    assert np.allclose(r2.normalized * r.edge_step, r.normalized, rtol=1e-9)


@check("a tabulated edge inside a fit window is caught")
def _t12():
    """V L2,3 with a pre-edge window ending above the tabulated L3.

    The template is levelled by a straight line across the pre-edge
    window. With the L3 edge (512.1 eV) inside it, that line is fitted
    across a jump of ~20000 cm^2/g, the extrapolation runs away and the
    edge step comes out *negative* -- silently flipping the sign of the
    normalized spectrum and of everything measured from it. Caught in
    testing when the two engines disagreed on a branching ratio.
    """
    bad = engines.mcmaster_window_check("V", 513.0, 527.7, 505.0, 545.2,
                                        505.25, 544.2)
    assert bad and "contains a tabulated edge" in bad[0], bad
    ok_ = engines.mcmaster_window_check("V", 511.5, 527.7, 505.0, 545.2,
                                        505.25, 544.2)
    assert not ok_, ok_


@check("edge areas are unaffected by the output scale")
def _t13():
    """White-line intensity and branching ratio are ratios of areas.

    Two separate claims, and only one of them is exact:

    * Changing the *scale* (cm^2/g against edge jump = 1) multiplies every
      area by the same constant, so both ratios are identical. Exact.
    * Changing the *engine* changes the background that was removed, so
      the areas change by a little more than a constant factor. On real
      V L2,3 data the branching ratio came out 0.4641 from edge-step and
      0.4626 from McMaster -- 0.3% apart; on the harsher synthetic
      spectrum here it is nearer 5%. Close, but not the same number, and
      worth knowing before comparing ratios across a data set normalized
      two different ways.
    """
    e, y, _ = _synthetic()
    base = dict(pre_lo=506, pre_hi=511.0, post_lo=535, post_hi=558)
    a, b = 515.74, 522.88

    def measure(p):
        r = engines.normalize(e, y, p)
        x, v = r.energy, r.normalized
        w = core.suggest_area_windows(a, b, float(x.min()), float(x.max()))
        mid = core.line_through_region(x, v, *w["continuum"])
        res = core.edge_areas(x, v, a, b, window_a=w["a"], window_b=w["b"],
                              window_continuum=w["continuum"], midline=mid)
        return res.white_line, res.branching_ratio

    # exact: same engine, different scale
    mc = dict(engine="mcmaster", element="V", edge="L3", poly_order=2, **base)
    w_abs, b_abs = measure(engines.UnifiedParams(**mc))
    w_one, b_one = measure(engines.UnifiedParams(norm_to_one=True, **mc))
    assert abs(w_abs - w_one) < 1e-9, (w_abs, w_one)
    assert abs(b_abs - b_one) < 1e-9, (b_abs, b_one)

    # close, not exact: different engine
    w_es, b_es = measure(engines.UnifiedParams(
        engine="edgestep", pre_model="linear", post_model="linear",
        norm_energy=545, **base))
    assert abs(b_es - b_abs) < 0.05, (b_es, b_abs)
    assert abs(w_es - w_abs) / abs(w_es) < 0.15, (w_es, w_abs)


@check("the native averaging grid keeps the near-edge sampling")
def _t14():
    """A uniform grid discards the dense sampling across the edge.

    XAS scans are deliberately uneven: fine over the edge, coarse either
    side. Averaging onto evenly spaced points throws that away. Measured
    on a real C K-edge scan, 99 measured points between 283 and 290 eV
    became 16, the pi* lost 1.6% of its height and moved 0.07 eV, and the
    288.6 eV feature moved 0.16 eV. Native is therefore the default, as
    in norm2poly.
    """
    # dense across the middle, sparse at the ends, like a real scan
    e = np.concatenate([np.arange(260.0, 283.0, 0.5),
                        np.arange(283.0, 290.0, 0.07),
                        np.arange(290.0, 380.0, 1.5)])
    g_nat = core.common_grid([e, e + 0.01], mode="native")
    g_uni = core.common_grid([e, e + 0.01], mode="uniform")
    near = lambda g: int(((g >= 283) & (g <= 290)).sum())   # noqa: E731
    assert near(g_nat) > 90, near(g_nat)
    assert near(g_uni) < 30, near(g_uni)
    assert near(g_nat) > 3 * near(g_uni), (near(g_nat), near(g_uni))

    # native must never extrapolate past what every scan covers
    g = core.common_grid([e, e[e < 350.0]], mode="native")
    assert g.max() <= e[e < 350.0].max() + 1e-9, g.max()


@check("the Igor export is loadable")
def _t15():
    """Igor Text is strict: CRLF endings, wave names of at most 31 legal
    characters, and unique -- Igor silently overwrites a wave whose name
    it already has. An earlier version built the pair by appending _e/_n
    and then truncating to 31, which gave two identical names for a long
    scan name."""
    import pathlib
    import tempfile

    e, y, _ = _synthetic()
    proj = dataio.Project(compound="test")
    long = "a_very_long_scan_name_that_exceeds_igors_limit"
    for nm in (long + "_x", long + "_y", "short one"):
        proj.scans.append(dataio.Scan(name=nm, energy_raw=e, intensity_raw=y))
    proj.defaults = engines.UnifiedParams(
        engine="edgestep", pre_lo=506, pre_hi=511.5, post_lo=535,
        post_hi=558, norm_energy=545, pre_model="linear")
    proj.recompute()

    with tempfile.TemporaryDirectory() as td:
        path = pathlib.Path(td) / "out.itx"
        dataio.export_igor_text(proj, path)
        raw = path.read_bytes()

    assert raw.count(b"\n") == raw.count(b"\r\n"), "Igor needs CRLF"
    text = raw.decode("utf-8")
    assert text.startswith("IGOR\r\n"), text[:20]

    names = [w.strip() for line in text.split("\r\n")
             if line.startswith("WAVES")
             for w in line.split("\t")[1].split(",")]
    assert names, "no waves written"
    assert len(names) == len(set(names)), names
    for n in names:
        assert n.isidentifier() and len(n) <= 31 and not n[0].isdigit(), n
    assert text.count("BEGIN") == text.count("END"), "unbalanced blocks"


@check("a degenerate edge step is caught, not silently used")
def _t16():
    """Found by adversarial probing, not by normal use.

    Three ways the edge step can be wrong while the arithmetic succeeds:
    it can be negative (the spectrum comes out upside down), tiny (the
    spectrum is scaled by 1e16), or exactly zero. Only the last was
    checked. Pre and post windows placed on the same stretch of data gave
    a step of -5e-17 and a normalized spectrum spanning 1e16 with no
    warning at all.
    """
    e = np.arange(505.0, 560.0, 0.25)
    y = 0.3 + 0.5 * np.exp(-((e - 515) / 2) ** 2) + 0.0004 * (e - 505)
    base = dict(engine="edgestep", pre_model="linear", post_model="linear",
                norm_energy=545.0)

    # negative step: must be flagged, not just produced
    r = engines.normalize(e, y, engines.UnifiedParams(
        pre_lo=506, pre_hi=511, post_lo=535, post_hi=558, **base))
    assert r.edge_step < 0, r.edge_step
    assert any("upside down" in w for w in r.warnings), r.warnings

    # degenerate step: must refuse outright
    try:
        engines.normalize(e, y, engines.UnifiedParams(
            pre_lo=535, pre_hi=558, post_lo=535, post_hi=558, **base))
    except ValueError as exc:
        assert "negligible" in str(exc), exc
    else:
        raise AssertionError("a ~1e-17 edge step was accepted")


@check("unordered energies come back sorted")
def _t17():
    """The fits cope with unordered input, but the result used to be
    returned on the unsorted axis -- which quietly breaks interpolation
    when averaging, draws a zigzag, and confuses the hover cursor."""
    e, y, _ = _synthetic()
    p = engines.UnifiedParams(
        engine="edgestep", pre_lo=506, pre_hi=511.5, post_lo=535,
        post_hi=558, norm_energy=545, pre_model="linear")
    ref = engines.normalize(e, y, p)
    for name, idx in (("reversed", np.arange(e.size)[::-1]),
                      ("shuffled", np.random.default_rng(0).permutation(e.size))):
        r = engines.normalize(e[idx], y[idx], p)
        assert np.all(np.diff(r.energy) > 0), name
        assert np.allclose(r.normalized, ref.normalized, atol=1e-12), name


@check("a byte-order mark does not eat the first data row")
def _t18():
    """Excel and Notepad leave a UTF-8 BOM. Read as plain utf-8 it sticks
    to the first character, that row fails to parse as a number, and the
    scan silently starts one point late."""
    import tempfile

    body = "260 0.3\n261 0.4\n262 0.5\n"
    with tempfile.TemporaryDirectory() as td:
        plain = pathlib.Path(td) / "plain.txt"
        withbom = pathlib.Path(td) / "bom.txt"
        plain.write_text(body, encoding="utf-8")
        withbom.write_text("\ufeff" + body, encoding="utf-8")
        a = dataio.load_columns(plain).column(0)
        b = dataio.load_columns(withbom).column(0)
    assert a.size == b.size == 3, (a.size, b.size)
    assert np.allclose(a, b), (a, b)

    # and a one-column file should say so, not "no numeric data"
    with tempfile.TemporaryDirectory() as td:
        one = pathlib.Path(td) / "one.txt"
        one.write_text("0.3\n0.4\n0.5\n", encoding="utf-8")
        try:
            dataio.load_columns(one)
        except ValueError as exc:
            assert "one column" in str(exc), exc
        else:
            raise AssertionError("a one-column file was accepted as a scan")


@check("binning and energy calibration behave")
def _t19():
    """Both were in XASNorm's data model all along but had no UI.

    Order matters and is asserted here: I0 ratio, then binning, then the
    shift. Binning before the shift keeps the bin boundaries tied to the
    measured points; shifting last means calibration never has to be
    undone to re-bin.
    """
    e = np.arange(500.0, 520.0, 0.5)
    y = np.arange(e.size, dtype=float)

    # rebin averages, and keeps a short final bin rather than discarding
    # the tail: 367 points at factor 2 give 184 bins, not 183
    eb, yb = core.rebin(e, y, 4)
    assert eb.size == yb.size == -(-e.size // 4), (eb.size, e.size)
    assert np.isclose(yb[0], y[:4].mean()), yb[0]
    assert np.isclose(eb[0], e[:4].mean()), eb[0]
    # rebin aligns bins to the HIGH-energy end, matching Igor's
    # autoBinData which walked backwards, so any partial bin lands at the
    # LOW-energy end -- the FIRST bin is the short one, not the last.
    # With 11 points and factor 2 the first bin holds one point and the
    # last holds two. An earlier comment here said the opposite; the
    # assertions happened to pass because they only tested the last bin,
    # which is always full.
    odd = np.arange(11, dtype=float)
    eo, yo = core.rebin(odd, odd, 2)
    assert eo.size == 6, eo.size
    assert np.isclose(yo[-1], odd[-2:].mean()), yo[-1]
    assert np.isclose(yo[0], odd[0]), (yo[0], "first bin should be short")
    ten, _ = core.rebin(np.arange(10, dtype=float),
                        np.arange(10, dtype=float), 3)
    assert ten.size == 4 and np.isclose(ten[-1], np.arange(10.)[-3:].mean())

    # a factor of 1 is a no-op
    e1, y1 = core.rebin(e, y, 1)
    assert np.array_equal(e1, e) and np.array_equal(y1, y)

    # Scan.energy is filled in by Project.recompute(); preprocess() is
    # what actually applies the ratio, the binning and the shift
    scan = dataio.Scan(name="s", energy_raw=e, intensity_raw=y)
    assert np.allclose(scan.preprocess()[0], e)

    scan.shift = 0.4
    assert np.allclose(scan.preprocess()[0], e + 0.4)

    scan.bin_factor = 2
    pe, py = scan.preprocess()
    assert pe.size == -(-e.size // 2), pe.size
    # the shift is applied after binning, not before, so it survives intact
    assert np.isclose(pe[0], e[:2].mean() + 0.4), pe[0]
    assert np.isclose(py[0], y[:2].mean()), py[0]

    # non-destructive: the raw arrays are untouched and it resets cleanly
    scan.shift, scan.bin_factor = 0.0, 1
    pe, py = scan.preprocess()
    assert np.allclose(pe, e) and np.allclose(py, y)
    assert np.allclose(scan.energy_raw, e)


@check("console output survives a cp1252 terminal")
def _t20():
    """A Windows console is cp1252 and has no subscript zero.

    One "I\u2080" in a status line raised UnicodeEncodeError and failed a
    build in which every test had actually passed -- the log file, being
    UTF-8, recorded the line correctly; only the print died. Reported
    output must never be able to fail a run.
    """
    import io
    import os

    stream = io.TextIOWrapper(open(os.devnull, "wb"), encoding="cp1252",
                              errors="strict", write_through=True)
    saved = sys.stdout
    try:
        sys.stdout = stream
        # the exact character that broke the build, plus its neighbours
        for text in ("I\u2080 on row 3", "\u03bc/\u03c1 cm\u00b2/g",
                     "\u2014 \u00f7 \u2192"):
            _emit(text)                      # must not raise
    finally:
        sys.stdout = saved
        stream.close()


@check("the sample name drives every export name")
def _t21():
    """One name, set in the GUI, used everywhere.

    The averaged spectrum is <sample>_Norm_Avg, matching the Igor
    convention in the reference files (Cp2VCl2_Norm_Avg_L). It heads the
    text export's column, names the Igor waves and suggests the filename,
    so those cannot drift apart.
    """
    import tempfile

    e, y, _ = _synthetic()
    proj = dataio.Project(compound="Cp2VCl2")
    for k in range(2):
        proj.scans.append(dataio.Scan(name=f"s{k}", energy_raw=e,
                                      intensity_raw=y * (1 + 0.02 * k)))
    proj.defaults = engines.UnifiedParams(
        engine="edgestep", pre_lo=506, pre_hi=511.5, post_lo=535,
        post_hi=558, norm_energy=545, pre_model="linear")
    proj.recompute()

    assert dataio.average_name(proj) == "Cp2VCl2_Norm_Avg"

    with tempfile.TemporaryDirectory() as td:
        txt = pathlib.Path(td) / "a.txt"
        dataio.export_average(proj, txt)
        body = txt.read_text(encoding="utf-8")
        assert "Cp2VCl2_Norm_Avg" in body, "column heading missing"
        assert "Sample: Cp2VCl2" in body, "provenance missing"

        itx = pathlib.Path(td) / "a.itx"
        dataio.export_igor_text(proj, itx)
        raw = itx.read_bytes().decode("utf-8")
        waves = [w.strip() for line in raw.split("\r\n")
                 if line.startswith("WAVES")
                 for w in line.split("\t")[1].split(",")]
        assert "Cp2VCl2_Norm_Avg" in waves, waves

    # A name headed for a filename must not carry path separators, and
    # Igor's 31-character limit must cut the sample, never the suffix.
    assert "/" not in dataio.safe_sample_name("Fe/III oxide")
    assert dataio.safe_sample_name("   ") == "Sample"
    assert dataio.safe_sample_name("") == "Sample"
    for messy in ("Fe (III) oxide / sample #2",
                  "a_very_long_sample_name_indeed_yes", ""):
        proj.compound = dataio.safe_sample_name(messy)
        with tempfile.TemporaryDirectory() as td:
            itx = pathlib.Path(td) / "b.itx"
            dataio.export_igor_text(proj, itx)
            raw = itx.read_bytes().decode("utf-8")
            waves = [w.strip() for line in raw.split("\r\n")
                     if line.startswith("WAVES")
                     for w in line.split("\t")[1].split(",")]
        assert len(waves) == len(set(waves)), waves
        for wv in waves:
            assert wv.isidentifier() and len(wv) <= 31, wv
        assert any(wv.endswith("_Norm_Avg") for wv in waves), waves


def _matlab_mcmaster(Z, E, unit="c"):
    """McMaster.m transcribed line for line, for comparison."""
    el = mcmaster.elements()[int(Z)]
    E = np.asarray(E, float).ravel()
    K = float(el.K_edge)
    L = np.asarray(el.L_edge, float).ravel()
    M = float(el.M_edge)
    jump = np.asarray(el.L_jump, float).ravel()
    idx_K = E >= K
    idx_L1 = (E >= L[0]) & (E < K)
    idx_L2 = (E >= L[1]) & (E < L[0])
    idx_L3 = (E >= L[2]) & (E < L[1])
    idx_M = (E >= M) & (E < L[2])

    def pv(c, t):
        return np.polyval(np.asarray(c, float).ravel()[::-1], t)

    mu_ph = np.exp(np.concatenate([
        pv(el.post_M, np.log(E[idx_M])),
        pv(el.post_L, np.log(E[idx_L3 | idx_L2 | idx_L1])),
        pv(el.post_K, np.log(E[idx_K]))]))
    mu_ph[idx_L2] = mu_ph[idx_L2] / jump[0]
    mu_ph[idx_L3] = mu_ph[idx_L3] / jump[0] / jump[1]
    mu = mu_ph + np.exp(pv(el.xsec_coh, np.log(E))) \
        + np.exp(pv(el.xsec_nch, np.log(E)))
    return mu if unit in ("b", "B") else mu / float(el.m2a)


@check("McMaster matches McMaster.m across the periodic table")
def _t22():
    """Against a literal transcription of the MATLAB, including on the
    edge boundaries where the index masks decide which polynomial is
    used, and through the L-jump divisions."""
    worst = 0.0
    for Z in range(1, 95):
        if Z in mcmaster.NO_DATA:
            continue
        el = mcmaster.elements()[Z]
        lo = max(float(el.M_edge), 1e-3)
        edges = np.concatenate([[float(el.K_edge)],
                                np.asarray(el.L_edge, float).ravel()])
        E = np.sort(np.concatenate([
            np.geomspace(lo * 1.001, 1000.0, 120),
            edges, edges * 1.0001, edges * 0.9999]))
        E = E[E >= lo]
        a = _matlab_mcmaster(Z, E)
        b = mcmaster.mcmaster(Z, E)
        worst = max(worst, float(np.max(np.abs(a - b)
                                       / np.maximum(np.abs(a), 1e-300))))
    assert worst < 1e-12, worst

    # barns/atom is the same numbers without the m2a division
    E = np.geomspace(0.2, 100.0, 200)
    assert np.allclose(_matlab_mcmaster(26, E, "b"),
                       mcmaster.mcmaster(26, E, unit="b"), rtol=0, atol=0)


@check("legpoly, unify and zymbol match their .m originals")
def _t23():
    def ml_legpoly(n):
        if n == 0:
            return np.array([1.0])
        if n == 1:
            return np.array([1.0, 0.0])
        p2, p1 = np.array([1.0]), np.array([1.0, 0.0])
        for idx in range(2, n + 1):
            p = (1.0 / idx) * ((2 * idx - 1) * np.concatenate([p1, [0.0]])
                               - (idx - 1) * np.concatenate([[0.0, 0.0], p2]))
            p2, p1 = p1, p
        return p1

    for n in range(0, 13):
        got = np.asarray(mcmaster.legpoly(n), float)
        want = ml_legpoly(n)
        assert got.shape == want.shape and np.array_equal(got, want), n

    for arr in (np.linspace(505, 545, 203), np.array([-7.0, 2.0, 99.0])):
        mid = (arr.max() + arr.min()) / 2.0
        span = (arr.max() - arr.min()) / 2.0
        a, m, sp = mcmaster.unify(arr)
        assert np.allclose(a, (arr - mid) / span, rtol=0, atol=0)
        assert m == mid and sp == span
    # unify.m copies a constant column through untouched
    const = np.array([3.0, 3.0, 3.0])
    assert np.array_equal(mcmaster.unify(const)[0], const)

    rows = ("H He" "LiBeB C N O F Ne" "NaMgAlSiP S ClAr"
            "K CaScTiV CrMnFeCoNiCuZnGaGeAsSeBrKr"
            "RbSrY ZrNbMoTcRuRhPdAgCdInSnSbTeI Xe"
            "CsBaLaCePrNdPmSmEuGdTbDyHoErTmYbLuHfTaW ReOsIrPtAuHgTlPbBiPoAtRn"
            "FrRaAcThPaU NpPuAmCmBkCfEsFmMdNoLrRfDbSgBhHsMt")
    for Z in range(1, len(rows) // 2 + 1):
        sym = rows[2 * Z - 2:2 * Z].strip()
        assert mcmaster.symbol_of(Z) == sym, (Z, sym)
        assert mcmaster.zymbol(sym) == Z, sym
    assert mcmaster.zymbol("mn") == 25 and mcmaster.zymbol("MN") == 25


@check("n2p_compute matches norm2poly.m")
def _t24():
    """Bit-identical to the MATLAB when the window rule is matched.

    norm2poly.m selects windows by index arithmetic, so a boundary that
    falls between samples pulls in one point from outside the window.
    With boundaries on measured points the two agree exactly either way;
    off them, matlab_edges=True is needed.
    """
    x = np.arange(6300.0, 7000.0, 1.0)
    rs = np.random.default_rng(3)
    y = (0.9 + 1.3e-4 * (x - 6300) + 0.02 * mcmaster.mcmaster(25, x / 1000.0)
         + rs.normal(0, 1e-4, x.size))

    def ml_norm2poly(Z, x, y, n_th, rng):
        p1, p2, q1, q2 = rng
        a = int((x <= p1).sum()) - 1
        b = int((x <= p2).sum())
        c = int((x <= q1).sum()) - 1
        d = int((x <= q2).sum())
        x_1, x_2 = x[a:b], x[c:d]
        y_12 = np.concatenate([y[a:b], y[c:d]])
        x_12 = np.concatenate([x_1, x_2])
        mu = mcmaster.mcmaster(Z, x_12 / 1000.0)
        mu = mu - np.concatenate([
            mu[:x_1.size],
            np.polyval(np.polyfit(x_1, mu[:x_1.size], 1), x_2)])
        nx, mid_x, span_x = mcmaster.unify(x_12)
        ny, mid_y, span_y = mcmaster.unify(y_12)
        nmu, mid_mu, span_mu = mcmaster.unify(mu)
        A = [nmu, np.ones(x_12.size), nx]
        A += [np.polyval(np.asarray(mcmaster.legpoly(j), float), nx)
              for j in range(2, n_th + 1)]
        C = np.linalg.lstsq(np.column_stack(A), ny, rcond=None)[0]
        nX = (x - mid_x) / span_x
        T = [np.ones(x.size), nX]
        T += [np.polyval(np.asarray(mcmaster.legpoly(j), float), nX)
              for j in range(2, n_th + 1)]
        bg = np.column_stack(T) @ C[1:]
        return C, ((y - mid_y) / span_y - bg) * span_mu / C[0] + mid_mu

    for order in (1, 2, 3):
        # boundaries between samples: needs matlab_edges to agree
        rng_ = (6300.0, 6520.5, 6620.5, 6999.0)
        C, Xa = ml_norm2poly(25, x, y, order, rng_)
        got = mcmaster.n2p_compute(x, y, 25, order, rng_, matlab_edges=True)
        assert np.allclose(got.C, C, rtol=1e-9, atol=0), (order, got.C, C)
        assert np.allclose(got.Xabs, Xa, rtol=1e-9, atol=0), order

        # boundaries on samples: identical without the option too
        on = (6300.0, 6520.0, 6620.0, 6999.0)
        C2, Xa2 = ml_norm2poly(25, x, y, order, on)
        plain = mcmaster.n2p_compute(x, y, 25, order, on)
        assert np.allclose(plain.C, C2, rtol=1e-9, atol=0), order
        assert np.allclose(plain.Xabs, Xa2, rtol=1e-9, atol=0), order

    # The reference curve deliberately departs from norm2poly.m. The
    # MATLAB picks sub-edge points with "mu < mu(end)", which assumes one
    # edge in the scan. On a K edge that agrees with splitting on the
    # pre-edge window to about 0.03%...
    r = mcmaster.n2p_compute(x, y, 25, 2, (6300.0, 6520.0, 6620.0, 6999.0))
    mu = mcmaster.mcmaster(25, x / 1000.0)
    sel = mu < mu[-1]
    res = np.empty_like(mu)
    res[sel] = mu[sel]
    res[~sel] = np.polyval(np.polyfit(x[sel], mu[sel], 1), x[~sel])
    ml = mu - res
    assert abs(ml[-1] - r.mu_ref[-1]) / abs(r.mu_ref[-1]) < 5e-4, \
        (ml[-1], r.mu_ref[-1])

    # ...but on a V L2,3 scan it swallows the L3 plateau, because L3 sits
    # below the L2 tail at the last point. That is why the window split is
    # used instead.
    xv = np.arange(505.0, 560.0, 0.25)
    muv = mcmaster.mcmaster(23, xv / 1000.0)
    selv = muv < muv[-1]
    assert xv[selv].max() > 519.0, xv[selv].max()
    assert muv[selv].max() > 2.0e4, muv[selv].max()


@check("the edge-step engine matches the Igor procedures")
def _t25():
    """Against Branson_Unified_Normalization_Procedure.ipf, transcribed.

    Igor's normalizeOne(): fit the pre-edge over cursors A-B, subtract it
    from the whole wave, fit a line to the post-edge over C-D of the
    residual, then divide by that fit read at
    ``energy2index(eV, normEnergy)`` -- the first measured point at or
    above the normalization energy, not the fit evaluated there. The
    Cp2VCl2 route's sPointNormToLineFitNP() does the same thing.

    Two findings came out of this comparison. The Victoreen fit is
    unconstrained in Igor (``FuncFit Victoreen``); defaulting a
    non-negativity constraint on shifted the edge step by 2.1% on real V
    L-edge data, for no benefit -- the unconstrained fit stayed positive
    across the whole scan. And ``snap_norm_energy`` reproduces the grid
    read, worth up to 0.17% on a coarse post-edge grid.
    """
    def igor_normalizeOne(e, y, pre, post, normE, model):
        m = (e >= pre[0]) & (e <= pre[1])
        if model == "victoreen":            # f(E) = A*E^-3 + B*E^-4
            A = np.column_stack([e[m] ** -3.0, e[m] ** -4.0])
            c = np.linalg.lstsq(A, y[m], rcond=None)[0]
            fit = c[0] * e ** -3.0 + c[1] * e ** -4.0
        else:                               # CurveFit poly 3 = quadratic
            c = np.polyfit(e[m], y[m], 2)
            fit = np.polyval(c, e)
        sub = y - fit
        mp = (e >= post[0]) & (e <= post[1])
        w = np.polyfit(e[mp], sub[mp], 1)   # CurveFit line
        postfit = w[0] * e + w[1]
        idx = int(np.sum(e < normE))        # energy2index()
        return sub / postfit[idx], float(postfit[idx]), c

    e, y, _ = _synthetic()
    pre, post, normE = (506.0, 511.5), (535.0, 558.0), 545.3   # off-grid
    for model in ("victoreen", "quadratic"):
        ig, step, c = igor_normalizeOne(e, y, pre, post, normE, model)
        r = engines.normalize(e, y, engines.UnifiedParams(
            engine="edgestep", pre_lo=pre[0], pre_hi=pre[1],
            pre_model=model, post_lo=post[0], post_hi=post[1],
            post_model="linear", norm_energy=normE,
            snap_norm_energy=True))
        # 1e-9, not machine epsilon: the design matrix is scaled here and
        # is not in polyfit, so a quadratic fit differs in the last few
        # bits through conditioning alone
        assert abs(r.edge_step - step) < 1e-9 * abs(step), \
            (model, r.edge_step, step)
        assert np.allclose(r.normalized, ig, rtol=1e-8, atol=1e-10), model

    # the Victoreen fit must be unconstrained by default, as in Igor
    ig, step, c = igor_normalizeOne(e, y, pre, post, normE, "victoreen")
    r = engines.normalize(e, y, engines.UnifiedParams(
        engine="edgestep", pre_lo=pre[0], pre_hi=pre[1],
        pre_model="victoreen", post_lo=post[0], post_hi=post[1],
        post_model="linear", norm_energy=normE))
    assert np.allclose(r.detail["pre_coef"], c, rtol=1e-9), \
        (r.detail["pre_coef"], c)

    # analytic is the default, and differs only by the grid offset
    assert abs(r.edge_step - step) / abs(step) < 5e-3, (r.edge_step, step)

    # Igor's poly 3 is a quadratic: three coefficients, not four
    assert core.FIT_MODELS["quadratic"][1] == 3
    assert "poly 3" in core.FIT_MODELS["quadratic"][2]


@check("a positive fit is not reported as going negative")
def _t26():
    """The negative-fit warning must use raw-space coefficients.

    fit_region conditions the problem by fitting in E/scale, so the
    solver's coefficients are in the scaled variable. Checking those
    against raw energies flagged a post-edge line that was positive at
    every point in the scan.
    """
    e = np.linspace(505.0, 545.0, 200)
    y = 0.2 - 2.2e-4 * (e - 505.0)          # positive throughout
    assert y.min() > 0
    r = core.fit_region(e, y, 527.7, 544.2, "linear", extrapolate_to=545.0)
    assert not any("goes negative" in w for w in r.warnings), r.warnings

    # and it must still fire when the fit really does go negative
    y2 = 0.05 - 3.0e-3 * (e - 505.0)
    r2 = core.fit_region(e, y2, 505.0, 515.0, "linear", extrapolate_to=545.0)
    assert any("goes negative" in w for w in r2.warnings), r2.warnings


@check("an unconstrained Victoreen that inverts the spectrum is rescued")
def _t27():
    """A narrow pre-edge window can make Igor's own fit unusable.

    `FuncFit Victoreen` is unconstrained, and matching that is the
    default. But A/E^3 + B/E^4 with B < 0 is (A*E - |B|)/E^4, which can
    *rise* with energy -- an absorption background that increases. On a
    1110-1233 eV scan with an 11.5 eV pre-edge window it fitted
    B = -1.3e12, a background rising from 0.2044 to 0.2121, and an edge
    step of -0.040 that turned the whole normalized spectrum upside down.

    The rule: take Igor's answer when it is usable, fall back to the
    constrained fit when the edge step comes out negative, and say so.
    An explicit nonnegative_pre still wins either way.
    """
    A, B = 1.44362e9, -1.29208e12
    e = np.linspace(1110.0, 1233.0, 145)
    vic = A * e ** -3.0 + B * e ** -4.0
    assert vic[-1] > vic[0], "this background should rise, else no test"

    def g(c, f, a):
        return a * np.exp(-4 * np.log(2) * ((e - c) / f) ** 2)

    fall = np.clip((e - 1140.0) / 93.0, 0, 1) ** 0.7 * 0.048
    y = (vic - fall + g(1130.5, 1.6, 0.66) + g(1133.5, 2.0, 0.20)
         + g(1136, 2.5, 0.10) + g(1158.5, 2.0, 0.24) + g(1162, 3.0, 0.07)
         + np.random.default_rng(1).normal(0, 0.0015, e.size))
    base = dict(engine="edgestep", pre_lo=1112.0, pre_hi=1123.5,
                pre_model="victoreen", post_lo=1170.0, post_hi=1233.0,
                post_model="linear", norm_energy=1210.86)

    # unconstrained on its own really does invert it
    bad = engines.normalize(e, y, engines.UnifiedParams(
        nonnegative_pre=False, **base))
    assert bad.edge_step < 0, bad.edge_step

    # the default must rescue it, and say why
    r = engines.normalize(e, y, engines.UnifiedParams(**base))
    assert r.edge_step > 0, r.edge_step
    assert np.nanmax(r.normalized) > 0
    assert any("inverted" in w for w in r.warnings), r.warnings

    # and an explicit choice is still honoured
    forced = engines.normalize(e, y, engines.UnifiedParams(
        nonnegative_pre=False, **base))
    assert forced.edge_step < 0, "explicit nonnegative_pre=False ignored"


@check("the pre-edge constraint policies do what they say")
def _t28():
    """Three policies plus strict mode, on the dataset that inverts.

    Auto matches Igor wherever Igor's answer is usable and falls back
    otherwise; Never reproduces Igor even when the result is unusable;
    Always constrains unconditionally; strict mode forces Never together
    with the grid-snapped edge step.
    """
    A_, B_ = 1.44362e9, -1.29208e12
    e = np.linspace(1110.0, 1233.0, 145)
    vic = A_ * e ** -3.0 + B_ * e ** -4.0

    def g(c, f, a):
        return a * np.exp(-4 * np.log(2) * ((e - c) / f) ** 2)

    y = (vic - np.clip((e - 1140.0) / 93.0, 0, 1) ** 0.7 * 0.048
         + g(1130.5, 1.6, 0.66) + g(1133.5, 2.0, 0.20) + g(1136, 2.5, 0.10)
         + g(1158.5, 2.0, 0.24) + g(1162, 3.0, 0.07)
         + np.random.default_rng(1).normal(0, 0.0015, e.size))
    base = dict(engine="edgestep", pre_lo=1112.0, pre_hi=1123.5,
                pre_model="victoreen", post_lo=1170.0, post_hi=1233.0,
                post_model="linear", norm_energy=1210.86)

    auto = engines.normalize(e, y, engines.UnifiedParams(**base))
    never = engines.normalize(e, y, engines.UnifiedParams(
        nonnegative_pre=False, **base))
    always = engines.normalize(e, y, engines.UnifiedParams(
        nonnegative_pre=True, **base))
    strict = engines.normalize(e, y, engines.UnifiedParams(
        igor_strict=True, **base))

    assert auto.edge_step > 0, auto.edge_step
    assert never.edge_step < 0, "Never must reproduce Igor, inversion included"
    assert always.edge_step > 0, always.edge_step
    assert strict.edge_step < 0, "strict mode must behave like Igor"
    assert np.isclose(auto.edge_step, always.edge_step), \
        "auto should land on the constrained answer here"

    # strict mode also snaps, so it is not identical to plain Never
    assert not np.isclose(strict.edge_step, never.edge_step, rtol=1e-6)

    # and on data where Igor is fine, auto must not depart from it
    e2, y2, _ = _synthetic()
    good = dict(engine="edgestep", pre_lo=506.0, pre_hi=511.5,
                pre_model="victoreen", post_lo=535.0, post_hi=558.0,
                post_model="linear", norm_energy=545.0)
    a2 = engines.normalize(e2, y2, engines.UnifiedParams(**good))
    n2 = engines.normalize(e2, y2, engines.UnifiedParams(
        nonnegative_pre=False, **good))
    assert np.isclose(a2.edge_step, n2.edge_step, rtol=0, atol=0), \
        "auto departed from Igor on data Igor handles fine"
    assert not any("inverted" in w for w in a2.warnings)


@check("the one-term Victoreen is stable where the two-term one is not")
def _t29():
    """A short, flat, noisy pre-edge cannot support two free parameters.

    Modelled on a real Ce M4,5 scan: a 15 eV pre-edge whose true E^-3
    decay is 5% against 1.5% scatter, extrapolated 80 eV. The two-term
    fit moved the edge step by an order of magnitude when the window
    changed by one point; A/E^3 alone stayed put.
    """
    e = np.concatenate([np.arange(864.0, 879.1, 1.5),
                        np.arange(879.2, 960.1, 0.8)])
    rs = np.random.default_rng(5)
    cont = 2.30e8 * e ** -3.0                      # ~0.34 OD at 870 eV
    step = 0.070 * (0.5 + np.arctan((e - 883.0) / 1.0) / np.pi)
    wl = 0.48 * np.exp(-4 * np.log(2) * ((e - 883.4) / 2.2) ** 2) \
        + 0.45 * np.exp(-4 * np.log(2) * ((e - 901.0) / 2.4) ** 2)
    y = cont + step + wl + rs.normal(0, 0.005, e.size)

    def step_of(model, hi):
        return engines.normalize(e, y, engines.UnifiedParams(
            engine="edgestep", pre_lo=864.0, pre_hi=hi, pre_model=model,
            post_lo=940.0, post_hi=960.0, post_model="linear",
            norm_energy=950.0)).edge_step

    windows = (879.0, 878.0, 876.5, 875.0)
    two = np.array([step_of("victoreen", h) for h in windows])
    one = np.array([step_of("victoreen_a", h) for h in windows])
    spread = lambda a: (a.max() - a.min()) / abs(np.median(a))   # noqa: E731
    assert spread(one) < 0.25, (one, spread(one))
    assert spread(one) < spread(two), (spread(one), spread(two))
    # and the one-term answer must be near the truth, 0.070
    assert abs(np.median(one) - 0.070) < 0.02, np.median(one)


@check("edge-step stability is measured and reported")
def _t30():
    """A number nobody had: how far the edge step moves under a small
    change of window. Well-determined data barely moves; the cases that
    caused trouble move by more than their own size."""
    e, y, _ = _synthetic()
    solid = engines.UnifiedParams(
        engine="edgestep", pre_lo=506.0, pre_hi=511.5, post_lo=535.0,
        post_hi=558.0, norm_energy=545.0, pre_model="linear")
    st = core.edge_step_stability(e, y, solid.to_norm_params())
    assert st is not None and st["n"] >= 5, st
    assert st["ratio"] < 1.0, st["ratio"]
    assert st["sign_flips"] == 0.0, st

    # a window deliberately placed where the step is ill-determined
    bad = engines.UnifiedParams(
        engine="edgestep", pre_lo=506.0, pre_hi=509.0, post_lo=515.0,
        post_hi=519.0, norm_energy=517.0, pre_model="quadratic")
    st2 = core.edge_step_stability(e, y, bad.to_norm_params())
    if st2 is not None:
        assert st2["ratio"] > st["ratio"], (st2["ratio"], st["ratio"])


@check("a scan out of line with its siblings is flagged")
def _t31():
    """Same material, same edge: the step should be a similar fraction of
    the pre-edge level in every scan. One that is not has a measurement
    problem, which no fitting choice can repair."""
    e, y, _ = _synthetic()
    proj = dataio.Project(compound="test")
    for k in range(3):
        proj.scans.append(dataio.Scan(name=f"good{k}", energy_raw=e,
                                      intensity_raw=y * (1 + 0.03 * k)))
    # a fourth whose edge step has been flattened away
    flat = y.copy()
    hi = e > 517.0
    flat[hi] = flat[hi] - 0.95 * (np.median(y[e > 535]) - np.median(y[e < 511]))
    proj.scans.append(dataio.Scan(name="drifted", energy_raw=e,
                                  intensity_raw=flat))
    proj.defaults = engines.UnifiedParams(
        engine="edgestep", pre_lo=506.0, pre_hi=511.5, post_lo=535.0,
        post_hi=558.0, norm_energy=545.0, pre_model="linear")
    msgs = proj.recompute()
    flagged = [m for m in msgs if "out of line" in m or "against" in m]
    assert any("drifted" in m for m in flagged), msgs


@check("the power-law background carries its own exponent")
def _t32():
    """A/E^n with n settable, so the assumption can be tested rather than
    taken on faith. The exponent rides inside the model string, so a fit
    stays self-describing."""
    assert core.power_exponent("power:2.70") == 2.70
    assert core.power_exponent("power") == 3.0
    assert core.model_base("power:2.70") == "power"
    assert core.model_base("victoreen") == "victoreen"

    e = np.linspace(864.0, 960.0, 300)
    y = 2.30e8 * e ** -3.0 + 0.070 * (e > 883.0)
    steps = {}
    for n in (2.4, 3.0, 3.6):
        r = engines.normalize(e, y, engines.UnifiedParams(
            engine="edgestep", pre_lo=864.0, pre_hi=879.0,
            pre_model=f"power:{n:.2f}", post_lo=940.0, post_hi=960.0,
            post_model="linear", norm_energy=950.0))
        steps[n] = r.edge_step
    # n = 3 must recover the injected step; the others must not, which is
    # the sensitivity worth being able to see
    assert abs(steps[3.0] - 0.070) < 1e-6, steps
    assert abs(steps[2.4] - 0.070) > 0.005, steps
    assert abs(steps[3.6] - 0.070) > 0.005, steps
    assert steps[2.4] < steps[3.0] < steps[3.6], steps

    # a fit knows its own exponent afterwards
    fr = core.fit_region(e, y, 864.0, 879.0, "power:2.70")
    assert "n = 2.70" in fr.describe(), fr.describe()
    assert abs(core.fit_power_exponent(e, y, 864.0, 879.0) - 3.0) < 0.1


@check("a spectrum that would invert is flagged, not just fixed")
def _t33():
    """The correction has to be visible after the fact, not only in a log
    line at the moment it happens."""
    A_, B_ = 1.44362e9, -1.29208e12
    e = np.linspace(1110.0, 1233.0, 145)
    vic = A_ * e ** -3.0 + B_ * e ** -4.0

    def g(c, f, a):
        return a * np.exp(-4 * np.log(2) * ((e - c) / f) ** 2)

    y = (vic - np.clip((e - 1140.0) / 93.0, 0, 1) ** 0.7 * 0.048
         + g(1130.5, 1.6, 0.66) + g(1158.5, 2.0, 0.24)
         + np.random.default_rng(1).normal(0, 0.0015, e.size))
    good = 2.9e8 * e ** -3.0 + 0.06 * (e > 1131.0) + g(1130.5, 1.6, 0.5)

    proj = dataio.Project(compound="t")
    proj.scans.append(dataio.Scan(name="inverts", energy_raw=e,
                                  intensity_raw=y))
    proj.scans.append(dataio.Scan(name="fine", energy_raw=e,
                                  intensity_raw=good))
    proj.defaults = engines.UnifiedParams(
        engine="edgestep", pre_lo=1112.0, pre_hi=1123.5,
        pre_model="victoreen", post_lo=1170.0, post_hi=1233.0,
        post_model="linear", norm_energy=1210.86)
    msgs = proj.recompute()

    flags = {s.name: bool(s.norm.detail.get("rescued")) for s in proj.scans}
    assert flags["inverts"] is True, flags
    assert flags["fine"] is False, flags
    assert any("would otherwise have normalized upside down" in m
               for m in msgs), msgs
    assert any("inverts" in m for m in msgs if "corrected" in m), msgs


@check("the McMaster background is drawn where it belongs")
def _t34():
    """Over the pre-edge window the template is levelled to zero, so the
    plotted background must pass through the pre-edge data.

    It did not: unify() maps the levelled template to -1 over that
    window, not 0, so the raw-unit background owed a -c0 term and was
    drawn c0*span_y too high. Display only -- Xabs was always right,
    which is exactly why the bit-identity checks against norm2poly.m
    never noticed."""
    e = np.linspace(6300.0, 7000.0, 500)
    mu = mcmaster.mcmaster(25, e / 1000.0)
    y = 0.02 * mu + 0.9 + 1.3e-4 * (e - 6300)
    rng = (6300.0, 6520.0, 6620.0, 7000.0)
    r = mcmaster.n2p_compute(e, y, 25, 2, rng)

    pre = (e >= rng[0]) & (e <= rng[1])
    resid = float(np.mean(r.bg_raw[pre] - y[pre]))
    spread = float(np.max(y[pre]) - np.min(y[pre]))
    assert abs(resid) < 0.05 * max(spread, 1e-9), (resid, spread)

    # and it must sit below the data above the edge, not above it
    post = (e >= rng[2]) & (e <= rng[3])
    assert np.mean(r.bg_raw[post]) < np.mean(y[post]), "background above data"

    # The normalization itself is untouched. Not asserting a machine-
    # precision residual here: mu is exp(poly(log E)), so a multiple of it
    # plus a polynomial is not in the model space and leaves ~4e-4 --
    # the same trap recorded in the round-trip check above.
    assert r.rms < 1e-3 * float(np.abs(y).max()), r.rms
    plain = mcmaster.n2p_compute(e, y, 25, 2, rng)
    assert np.allclose(plain.Xabs, r.Xabs, rtol=0, atol=0)


@check("area and peak normalization work without an edge step")
def _t35():
    """The point of them: a spectrum whose continuum step is unusable can
    still be normalized to its own resonance.

    Modelled on a Eu M4,5 scan with essentially no measurable edge jump.
    Under edge normalization the divisor swings wildly and changes sign;
    under area normalization it is steady.
    """
    e = np.linspace(1110.0, 1233.0, 400)
    cont = 2.9e8 * e ** -3.0                    # a decaying continuum...
    wl = (0.70 * np.exp(-4 * np.log(2) * ((e - 1131.0) / 2.0) ** 2)
          + 0.26 * np.exp(-4 * np.log(2) * ((e - 1158.5) / 2.2) ** 2))
    # ...and a step far too small to measure, as on the real scan
    y = cont + wl + 0.0015 * (0.5 + np.arctan((e - 1131.0) / 1.0) / np.pi)
    base = dict(engine="edgestep", pre_lo=1110.0, pre_hi=1124.0,
                pre_model="victoreen_a", post_lo=1198.0, post_hi=1233.0,
                post_model="linear", norm_energy=1215.0)

    edge = engines.normalize(e, y, engines.UnifiedParams(**base))
    area = engines.normalize(e, y, engines.UnifiedParams(
        scale_mode="area", scale_lo=1124.0, scale_hi=1172.0, **base))
    peak = engines.normalize(e, y, engines.UnifiedParams(
        scale_mode="peak", scale_lo=1126.0, scale_hi=1140.0, **base))

    # peak mode puts the largest value in its window at exactly 1
    m = (peak.energy >= 1126.0) & (peak.energy <= 1140.0)
    assert abs(float(np.nanmax(peak.normalized[m])) - 1.0) < 1e-9

    # area mode puts unit area over its window
    ma = (area.energy >= 1124.0) & (area.energy <= 1172.0)
    got = float(np.trapezoid(area.normalized[ma], area.energy[ma]))
    assert abs(got - 1.0) < 1e-6, got

    # and the labels say which was used
    assert "area = 1" in area.units, area.units
    assert "peak = 1" in peak.units, peak.units
    assert "edge jump" in edge.units, edge.units

    # the shape must be identical under all three -- only the scale moves
    ref = edge.normalized / float(np.nanmax(edge.normalized))
    for other in (area, peak):
        v = other.normalized / float(np.nanmax(other.normalized))
        assert np.allclose(v, ref, atol=1e-9), other.units

    # stability must be measured on the divisor actually in use
    pe = engines.UnifiedParams(**base).to_norm_params()
    pa = engines.UnifiedParams(scale_mode="area", scale_lo=1124.0,
                               scale_hi=1172.0, **base).to_norm_params()
    se = core.edge_step_stability(e, y, pe, n=9)
    sa = core.edge_step_stability(e, y, pa, n=9)
    assert sa is not None and se is not None
    assert sa["ratio"] < se["ratio"], (sa["ratio"], se["ratio"])
    assert sa["ratio"] < 0.5, sa["ratio"]


@check("Igor twoPsV mode reproduces the Igor peak shape")
def _t36():
    """twoPsV is a/2*(Gaussian + Lorentzian); ours is
    eta*Lorentzian + (1-eta)*Gaussian. At eta = 0.5 they are the same
    function AND the same amplitude convention -- a comment inherited
    from XASNorm claimed they differed by a factor of two, and halving
    the amplitude to "correct" for it introduces a 50% error."""
    from . import peakfit as pf

    x = np.linspace(1120.0, 1145.0, 400)
    a, x0, fw = 0.8, 1131.0, 2.5
    igor = a / 2 * (np.exp(-4 * np.log(2) * (x - x0) ** 2 / fw ** 2)
                    + (0.5 * fw) ** 2 / ((0.5 * fw) ** 2 + (x - x0) ** 2))
    ours = pf.pseudo_voigt(x, a, x0, fw, 0.5)
    assert np.max(np.abs(igor - ours)) < 1e-15, np.max(np.abs(igor - ours))

    # same peak height for the same a -- no factor of two
    assert abs(float(np.max(igor)) - float(np.max(ours))) < 1e-15
    halved = pf.pseudo_voigt(x, a / 2, x0, fw, 0.5)
    assert np.max(np.abs(igor - halved)) > 0.3, "the factor-of-two myth"

    # Igor's Gaussian is ours exactly
    ig_g = a * np.exp(-4 * np.log(2) * (x - x0) ** 2 / fw ** 2)
    assert np.array_equal(ig_g, pf.gaussian(x, a, x0, fw))

    # a two-peak twoPsV model recovers what it was given
    truth = (pf.pseudo_voigt(x, 0.60, 1131.0, 2.4, 0.5)
             + pf.pseudo_voigt(x, 0.22, 1140.0, 3.0, 0.5))
    m = pf.PeakModel()
    for amp, c, f in ((0.5, 1130.0, 2.0), (0.3, 1141.0, 2.6)):
        comp = m.add("pseudo_voigt", amplitude=amp, center=c, fwhm=f,
                     eta=0.5)
        comp.fixed.add("eta")
    rep = m.fit(x, truth, float(x.min()), float(x.max()))
    assert rep.r_squared > 0.999, rep.r_squared
    got = sorted(c.values["center"] for c in m.components)
    assert abs(got[0] - 1131.0) < 0.05 and abs(got[1] - 1140.0) < 0.05, got
    for c in m.components:
        assert c.values["eta"] == 0.5, "eta was not held"


@check("peak shape and minimiser choices actually take effect")
def _t37():
    """Two faults reported from use.

    The shape combo had no signal connected at all: it was read only
    when a peak was added, so changing it left existing components --
    and therefore the plotted curve -- untouched.

    And the minimiser was hard-wired to trust-region. Igor's FuncFit is
    Levenberg-Marquardt, which is needed to reproduce an old fit; LM
    takes no bounds, so it is offered rather than made the default.
    """
    from . import peakfit as pf

    x = np.linspace(1120.0, 1150.0, 300)
    truth = (pf.gaussian(x, 0.60, 1131.0, 2.4)
             + pf.gaussian(x, 0.22, 1140.0, 3.0))

    # converting a peak's kind must change what it evaluates to
    m = pf.PeakModel()
    c = m.add("gaussian", amplitude=0.6, center=1131.0, fwhm=2.4)
    before = m.evaluate(x).copy()
    c.kind = "lorentzian"
    for name in c.param_names:
        c.values.setdefault(name, c._default(name))
    after = m.evaluate(x)
    assert np.max(np.abs(after - before)) > 0.01, "shape change did nothing"

    # both minimisers must reach the same answer on a clean problem
    got = {}
    for method in ("trf", "lm"):
        mm = pf.PeakModel()
        for amp, cen, fw in ((0.5, 1130.0, 2.0), (0.3, 1141.0, 2.6)):
            mm.add("gaussian", amplitude=amp, center=cen, fwhm=fw)
        rep = mm.fit(x, truth, float(x.min()), float(x.max()),
                     method=method)
        assert rep.r_squared > 0.999, (method, rep.r_squared)
        got[method] = sorted(cc.values["center"] for cc in mm.components)
    for a, b in zip(got["trf"], got["lm"]):
        assert abs(a - b) < 0.02, got
    assert abs(got["lm"][0] - 1131.0) < 0.05, got


@check("the averaging range can follow a chosen scan")
def _t38():
    """Clipping to the overlap is the safe default, but it throws away
    the ends of a long scan whenever one short scan is included. Using a
    reference scan's full range is legitimate -- NaNs are ignored per
    point and the standard error widens -- provided the coverage is
    reported, because beyond the overlap the mean is over fewer scans.
    """
    e_long = np.linspace(1110.0, 1233.0, 250)
    e_short = np.linspace(1110.0, 1178.0, 140)
    y = lambda e: 0.3 + np.exp(-4 * np.log(2) * ((e - 1131.0) / 2.0) ** 2)

    g_clip = core.common_grid([e_long, e_short], reference=0, clip=True)
    g_full = core.common_grid([e_long, e_short], reference=0, clip=False)
    assert abs(g_clip.max() - 1178.0) < 1.0, g_clip.max()
    assert abs(g_full.max() - 1233.0) < 1e-6, g_full.max()
    assert g_full.size > g_clip.size

    # the reference decides whose axis is used
    g_ref1 = core.common_grid([e_long, e_short], reference=1, clip=False)
    assert abs(g_ref1.max() - 1178.0) < 1e-6, g_ref1.max()

    # and beyond the overlap the average is over fewer scans
    stack = [core.interpolate_to_grid(e, y(e), g_full)
             for e in (e_long, e_short)]
    mean, sem = core.average_spectra(stack)
    n = np.sum(np.isfinite(np.vstack(stack)), axis=0)
    assert int(n.max()) == 2 and int(n.min()) == 1, (n.min(), n.max())
    assert np.all(np.isfinite(mean)), "mean has gaps"
    inside, outside = n == 2, n == 1
    assert np.all(sem[outside] == 0.0), "one scan cannot have a spread"
    assert np.any(sem[inside] >= 0.0)

    # a project reports the shortfall rather than hiding it
    proj = dataio.Project(compound="t")
    proj.scans.append(dataio.Scan(name="long", energy_raw=e_long,
                                  intensity_raw=y(e_long)))
    proj.scans.append(dataio.Scan(name="short", energy_raw=e_short,
                                  intensity_raw=y(e_short) * 1.02))
    proj.defaults = engines.UnifiedParams(
        engine="edgestep", pre_lo=1110.0, pre_hi=1124.0,
        pre_model="victoreen_a", post_lo=1160.0, post_hi=1176.0,
        post_model="linear", norm_energy=1170.0)
    proj.grid_clip = False
    msgs = proj.recompute()
    assert proj.average_n is not None
    assert int(proj.average_n.min()) == 1, proj.average_n.min()
    assert any("beyond the overlap" in m for m in msgs), msgs
    proj.grid_clip = True
    proj.recompute()
    assert int(proj.average_n.min()) == 2, proj.average_n.min()


@check("window edges survive an engine toggle")
def _t10():
    p = engines.UnifiedParams(engine="edgestep", pre_lo=506, pre_hi=511.5,
                              post_lo=535, post_hi=558, element="V")
    q = engines.UnifiedParams.from_dict({**p.to_dict(), "engine": "mcmaster"})
    for f in ("pre_lo", "pre_hi", "post_lo", "post_hi"):
        assert getattr(p, f) == getattr(q, f), f


def _safe_console():
    """Let the console take UTF-8, or degrade instead of crashing.

    A Windows console defaults to cp1252, which has no subscript zero. A
    single "I\u2080" in a status line was enough to raise
    UnicodeEncodeError and fail an otherwise passing build -- the tests
    had all succeeded, and the log file, written as UTF-8, held the line
    correctly. Only the print died.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:                            # noqa: BLE001
            pass


def _emit(msg):
    """print that cannot take the process down."""
    try:
        print(msg)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "ascii"
        print(msg.encode(enc, "replace").decode(enc, "replace"))
    except Exception:                                # noqa: BLE001
        pass


def run() -> bool:
    _safe_console()
    ok = True
    for name, fn in CHECKS:
        try:
            fn()
            _emit(f"  pass  {name}")
        except Exception as exc:                     # noqa: BLE001
            ok = False
            _emit(f"  FAIL  {name}\n        {exc}")
    _emit(("all %d checks passed" % len(CHECKS)) if ok else "SELF-TEST FAILED")
    return ok


# ---------------------------------------------------------------------------
# GUI self-test -- what catches an over-pruned build
# ---------------------------------------------------------------------------
#
# The numerical checks above run happily inside a build that has had its
# Qt platform plugin, its fonts or its toolbar icons stripped out. Those
# faults only appear when a window is actually created and painted, so
# this test builds the whole interface, loads data, normalizes it with
# both engines, renders every tab and forces a real paint.
#
# A --windowed build has no console, so everything is also written to
# stxmnorm_guitest.log beside the executable.

def _synthetic_files(tmpdir):
    """Two V L-edge scans written as aXis2000-style .txt."""
    import pathlib
    paths = []
    for k in range(2):
        e, y, _ = _synthetic(seed=k)
        y = y * (1.0 + 0.02 * k)
        p = pathlib.Path(tmpdir) / f"selftest_S{k + 1}.txt"
        with open(p, "w", encoding="utf-8") as fh:
            fh.write("% 1d\n% stxmnorm self-test\n")
            for a, b in zip(e, y):
                fh.write(f"  {a:.4f}   {b:.6f}\n")
        paths.append(p)
    return paths


def run_gui(log_path=None) -> bool:
    import os
    import pathlib
    import sys
    import tempfile
    import traceback

    import numpy as np

    lines = []

    _safe_console()

    def say(msg):
        lines.append(msg)
        _emit(msg)

    ok = True
    headless = False
    try:
        say("STXMNorm GUI self-test")

        # On a Linux box with no display -- a CI runner, a bare container,
        # an ssh session -- Qt's native platform plugin cannot initialise
        # and aborts the process. Fall back to the offscreen plugin there
        # so the rest of the interface still gets exercised.
        #
        # This deliberately does NOT apply on Windows or macOS. There a
        # failure to load the native plugin means the build is missing
        # qwindows.dll (or the cocoa plugin), which is exactly the kind of
        # over-pruning this test exists to catch, so it must stay fatal.
        if (sys.platform.startswith("linux")
                and not os.environ.get("DISPLAY")
                and not os.environ.get("WAYLAND_DISPLAY")
                and not os.environ.get("QT_QPA_PLATFORM")):
            os.environ["QT_QPA_PLATFORM"] = "offscreen"
            headless = True

        import matplotlib
        matplotlib.use("QtAgg")
        import PySide6
        from PySide6 import QtCore, QtWidgets
        say(f"  PySide6 {PySide6.__version__} on Qt {QtCore.qVersion()}, "
            f"matplotlib {matplotlib.__version__}")
        if headless:
            say("  no display found; using the offscreen platform plugin "
                "(Linux only -- on Windows a missing plugin stays fatal)")

        from . import app as appmod, dataio, engines, theme
        from .app import HoverCursor

        qt = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
        theme.apply(qt, "light")
        say("  QApplication created and themed")

        win = appmod.MainWindow()
        win.resize(1200, 800)
        say("  MainWindow constructed")

        with tempfile.TemporaryDirectory() as td:
            for p in _synthetic_files(td):
                lc = dataio.load_columns(p)
                ix, iy = dataio.guess_columns(lc)
                win.project.scans.append(dataio.Scan(
                    name=p.stem, energy_raw=lc.column(ix),
                    intensity_raw=lc.column(iy), source=str(p)))
            say(f"  loaded {len(win.project.scans)} scans from written files")

        win._refresh_scan_list()
        win.scan_list.setCurrentRow(0)

        base = dict(pre_lo=506, pre_hi=511.5, post_lo=535, post_hi=558,
                    norm_energy=545, pre_model="linear", element="V",
                    poly_order=2)
        win.show()

        for eng in ("edgestep", "mcmaster"):
            win.project.defaults = engines.UnifiedParams(engine=eng, **base)
            for s in win.project.scans:
                s.params = None
            win.params.load(win.project.defaults)
            win.recompute()
            bad = [s.name for s in win.project.scans if s.norm is None]
            if bad:
                ok = False
                say(f"  FAIL  engine {eng}: no result for {bad}")
                continue
            for t in range(win.tabs.count()):
                win.tabs.setCurrentIndex(t)
                win._redraw()
                qt.processEvents()
            say(f"  engine {eng}: all {win.tabs.count()} tabs drew, "
                f"edge step {win.project.scans[0].norm.edge_step:.5g}")

        if win.project.average is None:
            ok = False
            say("  FAIL  average was not built")
        else:
            say(f"  average built over {win.project.average.size} points")

        # Forcing a real paint is the point: a missing Qt platform plugin,
        # font or toolbar icon fails here and nowhere else.
        pm = win.grab()
        if pm.isNull() or pm.width() < 100:
            ok = False
            say("  FAIL  window grab came back empty")
        else:
            say(f"  window painted, {pm.width()}x{pm.height()} px")

        # A zoom taken before the data existed must not survive the
        # import. Zoom is active by default on the Data tab, so a stray
        # click on the empty plot pushed a view onto the navigation stack
        # and every later redraw preserved it -- the data was drawn
        # correctly into a window looking somewhere else entirely, and the
        # tab appeared blank.
        win.tabs.setCurrentIndex(0)
        win._redraw()
        qt.processEvents()
        ax = win.plot_data.ax(0)
        win.plot_data.toolbar.push_current()
        ax.set_xlim(-0.032, -0.028)
        win.plot_data.toolbar.push_current()
        win._redraw()
        qt.processEvents()
        lo, hi = ax.get_xlim()
        e_all = np.concatenate([np.asarray(sc.energy, float)
                                for sc in win.project.scans
                                if sc.energy is not None])
        if hi < e_all.min() or lo > e_all.max():
            ok = False
            say(f"  FAIL  stale zoom survived: view {lo:.3f}-{hi:.3f} shows "
                f"none of {e_all.min():.1f}-{e_all.max():.1f} eV")
        else:
            say("  a zoom taken before the data existed is discarded")

        # I0: attach one, confirm both lists and both plots cope
        s0 = win.project.scans[0]
        e0 = np.asarray(s0.energy_raw, float)
        s0.i0_energy = e0
        s0.i0_intensity = 4.0e4 * np.exp(-(e0 - e0[0]) / 900.0)
        s0.intensity_kind = dataio.detect_intensity_kind(
            s0.intensity_raw, s0.i0_intensity)
        win._refresh_scan_list()
        win.tabs.setCurrentIndex(0)
        win._redraw()
        qt.processEvents()
        n_i0 = sum(1 for sc in win.project.scans if sc.i0_energy is not None)
        say(f"  I0 attached to {n_i0} of {len(win.project.scans)} scans, "
            f"kind {s0.intensity_kind!r}, Data+I0 tab redrew")

        # the tick marks are display-only and must not disturb `include`
        before = [sc.include for sc in win.project.scans]
        win._set_all_shown("data", False)
        qt.processEvents()
        if any(sc.show for sc in win.project.scans):
            ok = False
            say("  FAIL  'None' did not clear the data tick marks")
        if [sc.include for sc in win.project.scans] != before:
            ok = False
            say("  FAIL  hiding a scan changed whether it is averaged")
        win._set_all_shown("data", True)
        say("  show/hide ticks toggle cleanly and leave `include` alone")

        # exercise the drag-to-set-window path and the zoom-only mode
        win.tabs.setCurrentIndex(1)
        win._drag_target = "post"
        win._on_span(534.0, 557.0)
        say(f"  span selector set post window to "
            f"{win.project.defaults.post_lo:g}-{win.project.defaults.post_hi:g} eV")

        btn = {win.drag_group.button(i).property("key"): win.drag_group.button(i)
               for i in range(4)}
        win._drag_mode_changed(btn["none"])
        zoom_on = (not win.span.active
                   and str(win.plot_norm.toolbar.mode) == "zoom rect")
        win._drag_mode_changed(btn["pre"])
        span_back = win.span.active and str(win.plot_norm.toolbar.mode) != "zoom rect"
        if not (zoom_on and span_back):
            ok = False
            say(f"  FAIL  zoom-only toggle: zoom_on={zoom_on} "
                f"span_back={span_back}")
        else:
            say("  zoom-only mode hands the drag to rubber-band zoom and back")

        # a zoom must survive a parameter change: with ax.clear() every
        # nudge threw the view away
        win.tabs.setCurrentIndex(1)
        win._redraw()
        qt.processEvents()
        ax = win.plot_norm.ax(0)
        win.plot_norm.toolbar.push_current()
        ax.set_xlim(513.0, 527.0)
        win.plot_norm.toolbar.push_current()
        win.params.pre_hi.setValue(511.0)
        win.flush()
        win._redraw()
        qt.processEvents()
        lo, hi = ax.get_xlim()
        if abs(lo - 513.0) > 0.5 or abs(hi - 527.0) > 0.5:
            ok = False
            say(f"  FAIL  zoom not preserved across a redraw: {lo:.1f}-{hi:.1f}")
        else:
            say("  zoom survives a parameter change")
        win.plot_norm.toolbar.home()

        # Rapid parameter changes must coalesce.
        #
        # Timing must not enter this check. An earlier version did the
        # burst at the real 80 ms interval and asserted that nothing had
        # recomputed yet; on a slower Windows machine the timer expired
        # part-way through and it reported "1 during the burst, 1 total"
        # -- ten changes, one recompute, exactly the behaviour it was
        # meant to confirm. Here the interval is stretched so it cannot
        # expire mid-burst on any machine, which makes both halves exact:
        # nothing runs while the input is still arriving, and precisely
        # one recompute runs when it is flushed.
        hits = []
        real = win.recompute
        win.recompute = lambda: (hits.append(1), real())[1]
        win._recompute_timer.timeout.disconnect()
        win._recompute_timer.timeout.connect(win.recompute)
        was_interval = win._recompute_timer.interval()
        win._recompute_timer.setInterval(30000)
        try:
            burst = [512.0 + 0.1 * k for k in range(10)]
            for v in burst:
                win.params.pre_hi.setValue(v)
                qt.processEvents()
            during = len(hits)
            win.flush()
            total = len(hits)
        finally:
            win._recompute_timer.setInterval(was_interval)

        if during != 0 or total != 1:
            ok = False
            say(f"  FAIL  debounce: {len(burst)} changes gave {during} "
                f"recomputes before the flush and {total} in total "
                f"(expected 0 and 1)")
        else:
            say(f"  {len(burst)} rapid parameter changes coalesce into "
                "1 recompute")
        win.recompute = real

        # the hover cursor must snap to a real sample, not to the mouse
        from matplotlib.backend_bases import MouseEvent
        win.tabs.setCurrentIndex(1)
        win._redraw()
        qt.processEvents()
        panel = win.plot_norm
        ax = panel.ax(0)
        sc0 = win.project.scans[0]
        k = sc0.energy.size // 3
        tx, ty = float(sc0.energy[k]), float(sc0.intensity[k])
        # aim slightly off the sample, so snapping is what is being tested
        px, py = ax.transData.transform((tx + 0.05, ty + 0.005))
        panel.cursor.on_move(
            MouseEvent("motion_notify_event", panel.canvas, px, py))
        mx, my = panel.cursor.markers[id(ax)].get_data()
        if len(mx) != 1 or abs(float(mx[0]) - tx) > 1e-9:
            ok = False
            say(f"  FAIL  hover did not snap: marker at {list(mx)}, "
                f"sample at {tx:.4f}")
        elif not panel.readout.text():
            ok = False
            say("  FAIL  hover produced no readout")
        else:
            say(f"  hover snaps to the sample at {tx:.3f} eV")
        # the marker must not be mistaken for data
        before = ax.get_xlim()
        win._redraw()
        qt.processEvents()
        if ax.get_xlim() != before:
            ok = False
            say("  FAIL  the hover marker disturbed the view")
        panel.cursor.on_leave()
        if panel.readout.text():
            ok = False
            say("  FAIL  readout survived leaving the axes")

        # A view left over from different data must not survive. Toggling
        # the engine takes the y values from about 1 to about 25000 while
        # the energies stay put, so a check on the x overlap alone passed
        # and the plot went blank -- and Home did not help, because the
        # navigation stack still held the pre-toggle view.
        win.tabs.setCurrentIndex(1)
        win._redraw()
        qt.processEvents()
        axv = win.plot_norm.ax(1)

        def _shows_data(ax):
            xl, yl = ax.get_xlim(), ax.get_ylim()
            for ln in ax.lines:
                if HoverCursor.is_decoration(ln):
                    continue
                xx = np.asarray(ln.get_xdata(), float)
                yy = np.asarray(ln.get_ydata(), float)
                if xx.size and xx.size == yy.size and np.any(
                        (xx >= xl[0]) & (xx <= xl[1])
                        & (yy >= yl[0]) & (yy <= yl[1])):
                    return True
            return False

        win.plot_norm.autoscale()
        win.plot_norm.toolbar.push_current()
        axv.set_ylim(0.0, 7.5)
        win.plot_norm.toolbar.push_current()
        keep = dict(win.project.defaults.to_dict())
        win.project.defaults = engines.UnifiedParams(
            **{**keep, "engine": "mcmaster", "element": "V", "edge": "L3"})
        for sc in win.project.scans:
            sc.params = None
        win.params.load(win.project.defaults)
        win.recompute()
        win._redraw()
        qt.processEvents()
        if not _shows_data(axv):
            ok = False
            say(f"  FAIL  blank plot after an engine toggle: "
                f"ylim={axv.get_ylim()}")
        else:
            win.plot_norm.toolbar.home()
            win._redraw()
            qt.processEvents()
            if not _shows_data(axv):
                ok = False
                say("  FAIL  Home restored a stale view")
            else:
                say("  a stale view is dropped when the data changes scale")
        win.project.defaults = engines.UnifiedParams(**keep)
        for sc in win.project.scans:
            sc.params = None
        win.params.load(win.project.defaults)
        win.recompute()

        # ...but a deliberate zoom must still survive a parameter nudge
        win.plot_norm.autoscale()
        win.plot_norm.toolbar.push_current()
        axv.set_xlim(514.0, 518.0)
        win.plot_norm.toolbar.push_current()
        win.params.pre_hi.setValue(511.0)
        win.flush()
        win._redraw()
        qt.processEvents()
        if abs(axv.get_xlim()[0] - 514.0) > 0.5:
            ok = False
            say(f"  FAIL  a deliberate zoom was discarded: {axv.get_xlim()}")
        else:
            say("  a deliberate zoom survives a parameter change")
        win.plot_norm.autoscale()

        # drag and drop onto the two lists
        from PySide6.QtCore import QMimeData, QUrl, QPointF, Qt as _Qt
        from PySide6.QtGui import QDropEvent, QDragEnterEvent

        def _drop(widget, files, pos=QPointF(5.0, 5.0)):
            md = QMimeData()
            md.setUrls([QUrl.fromLocalFile(str(f)) for f in files])
            enter = QDragEnterEvent(pos.toPoint(), _Qt.CopyAction, md,
                                    _Qt.LeftButton, _Qt.NoModifier)
            widget.dragEnterEvent(enter)
            widget.dropEvent(QDropEvent(pos, _Qt.CopyAction, md,
                                        _Qt.LeftButton, _Qt.NoModifier))
            qt.processEvents()
            return enter.isAccepted()

        with tempfile.TemporaryDirectory() as td:
            files = _synthetic_files(td)
            junk = pathlib.Path(td) / "notes.pdf"
            junk.write_text("not a spectrum", encoding="utf-8")
            before = len(win.project.scans)
            accepted = _drop(win.scan_list, files)
            gained = len(win.project.scans) - before
            _drop(win.scan_list, [junk])
            after_junk = len(win.project.scans) - before
            if not accepted or gained != len(files):
                ok = False
                say(f"  FAIL  dropping {len(files)} files added {gained} "
                    f"scans (accepted={accepted})")
            elif after_junk != gained:
                ok = False
                say("  FAIL  a non-spectrum file was imported")
            else:
                say(f"  dropping {len(files)} files imports them; "
                    "a .pdf is ignored")

            # an I0 dropped onto a row must land on that row
            row = len(win.project.scans) - 1
            # an earlier part of this test already attached an I0 to scan
            # 0, so compare against what was attached before the drop
            had = {i for i, sc in enumerate(win.project.scans)
                   if sc.i0_energy is not None}
            item = win.i0_list.item(row)
            pos = QPointF(win.i0_list.visualItemRect(item).center())
            _drop(win.i0_list, [files[0]], pos)
            now = {i for i, sc in enumerate(win.project.scans)
                   if sc.i0_energy is not None}
            if now - had != {row}:
                ok = False
                say(f"  FAIL  I0 landed on {sorted(now - had)}, "
                    f"expected [{row}]")
            else:
                say(f"  an I\u2080 dropped on row {row} attaches to that scan")
            win.project.scans[row].i0_energy = None
            win.project.scans[row].i0_intensity = None
            win.project.scans[row].intensity_kind = "od"
            del win.project.scans[before + len(files):]
            del win.project.scans[before:before + len(files)]
            win._refresh_scan_list()
            win.recompute()

        # the export dialog decides what gets written, before anything is
        from PySide6.QtCore import Qt as _QtNS
        with tempfile.TemporaryDirectory() as td:
            dlg = appmod.ExportScansDialog(win.project, td, win)
            n_rows = dlg.table.rowCount()
            if n_rows != sum(1 for sc in win.project.scans
                             if sc.norm is not None):
                ok = False
                say(f"  FAIL  export dialog listed {n_rows} rows")
            else:
                dlg.folder.setText(td)
                # untick the first, rename and re-format the second
                dlg.table.item(0, 0).setCheckState(_QtNS.Unchecked)
                dlg.table.item(1, 2).setText("renamed.csv")
                combo = dlg.table.cellWidget(1, 3)
                for j in range(combo.count()):
                    if combo.itemData(j) == "itx":
                        combo.setCurrentIndex(j)
                jobs = dlg.jobs()
                if len(jobs) != 1:
                    ok = False
                    say(f"  FAIL  unticking left {len(jobs)} jobs, wanted 1")
                elif jobs[0][1].name != "renamed.itx":
                    ok = False
                    say(f"  FAIL  extension did not follow the format: "
                        f"{jobs[0][1].name}")
                else:
                    for sc, path, fmt in jobs:
                        dataio.export_scan_as(win.project, sc, path, fmt)
                    made = sorted(p.name for p in pathlib.Path(td).iterdir())
                    if made != ["renamed.itx"]:
                        ok = False
                        say(f"  FAIL  wrote {made}")
                    else:
                        say("  export dialog: unticked rows are skipped and "
                            "the extension follows the format")

        # closing a session must leave the program usable, not just empty
        n_before = len(win.project.scans)
        win.close_session(confirm=False)
        qt.processEvents()
        bad = []
        if win.project.scans:
            bad.append("scans remain")
        if win.project.average is not None:
            bad.append("average remains")
        if win.table.rowCount():
            bad.append("results table remains")
        if win.params.sample.text() != "Sample":
            bad.append("sample name not reset")
        try:
            for t in range(win.tabs.count()):
                win.tabs.setCurrentIndex(t)
                win._redraw()
            qt.processEvents()
        except Exception as exc:                     # noqa: BLE001
            bad.append(f"redraw raised {exc}")
        if bad:
            ok = False
            say(f"  FAIL  close session: {', '.join(bad)}")
        else:
            say(f"  close session cleared {n_before} scans and the tabs "
                "still draw")

        # and the program must still work afterwards
        with tempfile.TemporaryDirectory() as td:
            again = _synthetic_files(td)
            win._import_paths([str(p) for p in again], ask_columns=False)
            if len(win.project.scans) != len(again):
                ok = False
                say("  FAIL  could not import after closing the session")
            elif win._last_dir != td:
                ok = False
                say(f"  FAIL  last folder not remembered: {win._last_dir!r}")
            else:
                say("  importing works after a close, and the folder is "
                    "remembered for exports")

        # strict mode must own the two compatibility controls
        win.params.igor_strict.setChecked(True)
        qt.processEvents()
        v = win.params.values().to_norm_params()
        if (win.params.pre_constraint.isEnabled()
                or win.params.snap_box.isEnabled()
                or v.nonnegative_pre is not False
                or not v.snap_norm_energy):
            ok = False
            say("  FAIL  strict Igor mode did not take over the settings")
        else:
            win.params.igor_strict.setChecked(False)
            qt.processEvents()
            if not (win.params.pre_constraint.isEnabled()
                    and win.params.snap_box.isEnabled()):
                ok = False
                say("  FAIL  controls stayed disabled after strict mode off")
            else:
                say("  strict Igor mode takes over both settings and "
                    "releases them")

        # the peak-fitting tab, ported from XASNorm
        win.tabs.setCurrentIndex(4)
        win._redraw()
        qt.processEvents()
        px, py, plabel = win._peakfit_spectrum()
        if px is None or not plabel:
            ok = False
            say("  FAIL  peak-fit tab got no spectrum")
        else:
            win.tab_peakfit.seed_from_derivative()
            qt.processEvents()
            n_comp = len(win.tab_peakfit.model.components)
            if n_comp < 2:
                ok = False
                say(f"  FAIL  seeding gave {n_comp} components")
            else:
                win.tab_peakfit.run_fit()
                qt.processEvents()
                rep = win.tab_peakfit.report
                peaks = [c for c in win.tab_peakfit.model.components
                         if c.is_peak]
                if rep is None or not peaks:
                    ok = False
                    say("  FAIL  peak fit produced no report or no peaks")
                elif not (0.0 < rep.r_squared <= 1.0):
                    ok = False
                    say(f"  FAIL  peak fit R^2 = {rep.r_squared}")
                elif not all(np.isfinite(c.area()) and c.area() > 0
                             for c in peaks):
                    ok = False
                    say("  FAIL  a fitted peak has no finite positive area")
                else:
                    say(f"  peak fitting: seeded {n_comp}, fitted "
                        f"{len(peaks)} peaks, R^2 = {rep.r_squared:.4f}")
            # changing the peak shape must change the model and the plot
            t0 = win.tab_peakfit
            t0.seed_from_derivative()
            qt.processEvents()
            kinds_before = [c.kind for c in t0.model.components if c.is_peak]
            want = "lorentzian" if kinds_before and \
                kinds_before[0] != "lorentzian" else "gaussian"
            t0.shape.setCurrentIndex(t0.shape.findData(want))
            qt.processEvents()
            kinds_after = [c.kind for c in t0.model.components if c.is_peak]
            if not kinds_after or any(k != want for k in kinds_after):
                ok = False
                say(f"  FAIL  shape change left components as "
                    f"{kinds_after}")
            else:
                say(f"  changing the peak shape converts existing peaks "
                    f"({kinds_before[0]} -> {want})")
            # and the step combo must add and remove the step
            t0.step_kind.setCurrentIndex(t0.step_kind.findData("erf_step"))
            qt.processEvents()
            has = any(c.kind == "erf_step" for c in t0.model.components)
            t0.step_kind.setCurrentIndex(t0.step_kind.findData(""))
            qt.processEvents()
            gone = not any(c.kind in ("erf_step", "arctan_step")
                           for c in t0.model.components)
            if not (has and gone):
                ok = False
                say(f"  FAIL  step combo: added={has} removed={gone}")

            # the Igor toggle must own the controls it pins
            t = win.tab_peakfit
            t.igor_mode.setChecked(True)
            qt.processEvents()
            bad = []
            if t.shape.currentData() != "pseudo_voigt":
                bad.append("shape")
            if t.step_kind.currentData() != "":
                bad.append("step not removed")
            if t.n_peaks.value() != 2:
                bad.append("peak count")
            if t.shape.isEnabled() or t.n_peaks.isEnabled():
                bad.append("controls not locked")
            t.seed_from_derivative()
            qt.processEvents()
            comps = t.model.components
            if len(comps) != 2 or any(c.kind != "pseudo_voigt"
                                      for c in comps):
                bad.append(f"seeded {[c.kind for c in comps]}")
            if any("eta" not in c.fixed for c in comps):
                bad.append("eta not held")
            t.igor_mode.setChecked(False)
            qt.processEvents()
            if not (t.shape.isEnabled() and t.n_peaks.isEnabled()):
                bad.append("controls stayed locked")
            if bad:
                ok = False
                say(f"  FAIL  Igor twoPsV mode: {', '.join(bad)}")
            else:
                say("  Igor twoPsV mode pins the model and releases it")

            win.tab_peakfit.refresh_plot()
            qt.processEvents()
            win.tab_peakfit.clear()

        # the sample name field must reach the project and the exports
        win.params.sample.setText("Cp2VCl2")
        win.params.sample.editingFinished.emit()
        qt.processEvents()
        if win.project.compound != "Cp2VCl2":
            ok = False
            say(f"  FAIL  sample name did not reach the project: "
                f"{win.project.compound!r}")
        elif dataio.average_name(win.project) != "Cp2VCl2_Norm_Avg":
            ok = False
            say(f"  FAIL  average name is "
                f"{dataio.average_name(win.project)!r}")
        else:
            say("  sample name sets the averaged spectrum to "
                "Cp2VCl2_Norm_Avg")
        win.params.sample.setText("Sample")
        win.params.sample.editingFinished.emit()
        qt.processEvents()

        # a session dropped anywhere on the interface must open, and must
        # not collide with spectra dropped on the two lists
        with tempfile.TemporaryDirectory() as td:
            sess = pathlib.Path(td) / "dropped.stxmnorm"
            win.project.compound = "DropTest"
            win.project.save(sess)
            spec = _synthetic_files(td)[0]

            def _drop_on(widget, files):
                md = QMimeData()
                md.setUrls([QUrl.fromLocalFile(str(f)) for f in files])
                enter = QDragEnterEvent(QPointF(8.0, 8.0).toPoint(),
                                        _QtNS.CopyAction, md,
                                        _QtNS.LeftButton, _QtNS.NoModifier)
                widget.dragEnterEvent(enter)
                widget.dropEvent(QDropEvent(
                    QPointF(8.0, 8.0), _QtNS.CopyAction, md,
                    _QtNS.LeftButton, _QtNS.NoModifier))
                qt.processEvents()
                return enter.isAccepted()

            targets = {"window": win, "scan list": win.scan_list,
                       "I0 list": win.i0_list}
            for label, widget in targets.items():
                fresh = appmod.MainWindow()
                fresh.resize(900, 600)
                tw = {"window": fresh, "scan list": fresh.scan_list,
                      "I0 list": fresh.i0_list}[label]
                if not _drop_on(tw, [sess]):
                    ok = False
                    say(f"  FAIL  session dropped on the {label} refused")
                elif fresh.project.compound != "DropTest":
                    ok = False
                    say(f"  FAIL  session dropped on the {label} did not open")
                fresh.close()

            # a spectrum on the window must NOT be taken for a session
            fresh = appmod.MainWindow()
            if _drop_on(fresh, [spec]):
                ok = False
                say("  FAIL  a spectrum dropped on the window was accepted "
                    "as a session")
            fresh.close()

            # and nothing large may quietly intercept a drop
            greedy = [n for n, wdg in (("report", win.report),
                                       ("log", win.log_view),
                                       ("area report", win.area_report),
                                       ("canvas", win.plot_norm.canvas))
                      if wdg.acceptDrops()]
            if greedy:
                ok = False
                say(f"  FAIL  these would swallow a drop: {greedy}")
            else:
                say("  sessions can be dropped anywhere; spectra still go "
                    "to the lists")

        # the averaging grid must be inspectable: points on the curve and
        # a summary that says when resampling has coarsened the sampling
        win.tabs.setCurrentIndex(2)
        win.show_points.setChecked(True)
        win._redraw()
        qt.processEvents()
        avg_ax = win.plot_avg.ax()
        marked = [ln for ln in avg_ax.lines
                  if ln.get_label() == "average" and ln.get_marker() not in
                  ("None", "", None)]
        if not marked:
            ok = False
            say("  FAIL  'Show points' drew no markers on the average")
        else:
            win.show_points.setChecked(False)
            win._redraw()
            qt.processEvents()
            still = [ln for ln in win.plot_avg.ax().lines
                     if ln.get_label() == "average"
                     and ln.get_marker() not in ("None", "", None)]
            if still:
                ok = False
                say("  FAIL  markers survived unticking 'Show points'")
            else:
                say("  the averaged spectrum can be shown point by point")
            win.show_points.setChecked(True)

        native_txt = win.grid_info.text()
        win.project.grid_mode = "uniform"
        win.recompute()
        win.tabs.setCurrentIndex(2)
        win._redraw()
        qt.processEvents()
        uniform_txt = win.grid_info.text()
        win.project.grid_mode = "native"
        win.recompute()
        if not native_txt or "points" not in native_txt:
            ok = False
            say(f"  FAIL  no grid summary shown: {native_txt!r}")
        elif "coarser than the data" in native_txt:
            ok = False
            say("  FAIL  the native grid was reported as coarser than the "
                "data it came from")
        else:
            say("  grid summary reports the sampling and flags coarsening")

        # calibration and binning, driven as the menu drives them
        sc = win.project.scans[0]
        n_raw = sc.energy_raw.size
        sc.shift = 0.25
        sc.bin_factor = 2
        win.recompute()
        win._refresh_scan_list()
        qt.processEvents()
        want = -(-n_raw // 2)          # rebin keeps a short final bin
        if sc.energy.size != want:
            ok = False
            say(f"  FAIL  binning gave {sc.energy.size} points, "
                f"expected {want}")
        elif sc.norm is None:
            ok = False
            say("  FAIL  a binned+shifted scan failed to normalize")
        else:
            hdr = [win.table.horizontalHeaderItem(i).text()
                   for i in range(win.table.columnCount())]
            if "Shift (eV)" not in hdr or "Bin" not in hdr:
                ok = False
                say(f"  FAIL  results table lost its columns: {hdr}")
            else:
                say(f"  shift {sc.shift:+.2f} eV and bin x{sc.bin_factor} "
                    f"applied: {n_raw} -> {sc.energy.size} points")
        win.reset_processing()
        if win.project.scans[0].bin_factor != 1 or win.project.scans[0].shift:
            ok = False
            say("  FAIL  reset did not clear shift and binning")

        # the window must fit a 1366-wide laptop screen
        mw = win.minimumSizeHint().width()
        if mw > 1366:
            ok = False
            say(f"  FAIL  minimum window width {mw} px exceeds a 1366 screen")
        else:
            say(f"  minimum window width {mw} px (fits 1280 and 1366)")

        # the scan selector must track what is loaded, and scope settings
        names = [sc.name for sc in win.project.scans]
        items = [win.params.scope.itemData(i)
                 for i in range(win.params.scope.count())]
        if items != ["all"] + list(range(len(names))):
            ok = False
            say(f"  FAIL  scan selector out of step: {items}")
        else:
            win.params.scope.setCurrentIndex(2)      # the second scan
            qt.processEvents()
            win.params.pre_hi.setValue(510.5)
            win.flush()
            one = win.project.scans[1].params
            other = win.project.scans[0].params
            if one is None or abs(one.pre_hi - 510.5) > 1e-9 or other is not None:
                ok = False
                say("  FAIL  per-scan scoping did not apply to just that scan")
            else:
                say("  selector scopes settings to one scan at a time")
            win.params.scope.setCurrentIndex(0)
            qt.processEvents()

        # zoom buttons
        win.tabs.setCurrentIndex(1)
        win._redraw()
        qt.processEvents()
        axz = win.plot_norm.ax(0)
        before = axz.get_xlim()
        win.plot_norm.zoom_by(0.7)
        mid = 0.5 * (before[0] + before[1])
        got = axz.get_xlim()
        if abs((got[1] - got[0]) / (before[1] - before[0]) - 0.7) > 1e-6:
            ok = False
            say(f"  FAIL  zoom in gave {got}, from {before}")
        else:
            win.plot_norm.autoscale()
            say("  zoom in/out and autoscale buttons work")

        # the analysis tab: derivatives, peak finding, areas
        win.tabs.setCurrentIndex(3)
        win._redraw()
        qt.processEvents()
        win._find_peaks()
        ea, eb = win.edge_a_box.value(), win.edge_b_box.value()
        if not (510 < ea < 520 and 518 < eb < 530 and eb > ea):
            ok = False
            say(f"  FAIL  find peaks gave A={ea:.2f} B={eb:.2f}")
        else:
            win._compute_areas()
            txt = win.area_report.toPlainText()
            if "Branching ratio" not in txt:
                ok = False
                say("  FAIL  compute areas produced no report")
            else:
                say(f"  analysis: peaks at {ea:.2f} and {eb:.2f} eV, "
                    f"areas computed")
        # edge marks must not stretch the view, and must be clearable
        axa = win.plot_ana.ax(0)
        win.plot_ana.autoscale()
        lim_before = axa.get_xlim()
        win.edge_a_box.setValue(float(win.project.scans[0].norm.energy[5]))
        win._redraw()
        qt.processEvents()
        win.plot_ana.autoscale()
        if abs(axa.get_xlim()[0] - lim_before[0]) > 1e-6:
            ok = False
            say("  FAIL  an edge mark disturbed the analysis autoscale")
        win._find_peaks()
        win._redraw()
        qt.processEvents()
        n_marks = sum(1 for a in win.plot_ana._all_axes()
                      for art in list(a.lines) + list(a.texts)
                      if art.get_gid() == HoverCursor.MARK)
        win._clear_peaks()
        qt.processEvents()
        left = sum(1 for a in win.plot_ana._all_axes()
                   for art in list(a.lines) + list(a.texts)
                   if art.get_gid() == HoverCursor.MARK)
        if win.edge_a_box.value() or win.edge_b_box.value():
            ok = False
            say("  FAIL  clear peaks left the edge energies set")
        elif n_marks == 0:
            ok = False
            say("  FAIL  find peaks drew no markers to clear")
        elif left:
            ok = False
            say(f"  FAIL  {left} of {n_marks} peak markers survived clearing")
        else:
            say(f"  clear peaks removes all {n_marks} markers from the plots")

        # the guide line must appear in BOTH analysis panels at one energy
        from matplotlib.backend_bases import MouseEvent as _ME
        axtop = win.plot_ana.ax(0)
        gx = float(np.nanmedian(win.project.grid))
        ppx, ppy = axtop.transData.transform((gx, 1.0))
        win.plot_ana.cursor.on_move(
            _ME("motion_notify_event", win.plot_ana.canvas, ppx, ppy))
        xs = [float(v.get_xdata()[0])
              for v in win.plot_ana.cursor.vlines.values()]
        if len(xs) != 2 or abs(xs[0] - xs[1]) > 1e-9:
            ok = False
            say(f"  FAIL  guide line not shared across panels: {xs}")
        else:
            say(f"  guide line tracks {xs[0]:.2f} eV in both analysis panels")

        with tempfile.TemporaryDirectory() as td:
            out = pathlib.Path(td) / "avg.txt"
            dataio.export_average(win.project, out)
            n = len(out.read_text(encoding="utf-8").splitlines())
            say(f"  exported average, {n} lines")

        win.close()
    except Exception:                                # noqa: BLE001
        ok = False
        say("  EXCEPTION:\n" + traceback.format_exc())

    if ok and headless:
        say("GUI self-test passed (offscreen; native plugin not exercised)")
    else:
        say("GUI self-test passed" if ok else "GUI SELF-TEST FAILED")

    if log_path is None:
        exe = pathlib.Path(sys.executable if getattr(sys, "frozen", False)
                           else sys.argv[0]).resolve()
        log_path = exe.parent / "stxmnorm_guitest.log"
    try:
        pathlib.Path(log_path).write_text("\n".join(lines) + "\n",
                                          encoding="utf-8")
    except OSError:
        pass
    return ok
