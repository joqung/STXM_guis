"""
edges.py -- nominal absorption-edge energies used to seed fit windows.

IMPORTANT
---------
These are *nominal elemental binding energies*, rounded, intended only to
put the pre-edge / post-edge / integration windows in roughly the right
place when a new dataset is loaded.  They are NOT calibration standards
and they are NOT chemically shifted values for your compound.  Verify
against the X-ray Data Booklet (or your own reference measurement) before
quoting any energy.

Energy calibration in this program works the way it did in the Igor
procedures: you supply the *measured* position of a known feature and the
*expected* position, and every scan is shifted by the difference.

The table is written to ``edges.json`` next to the executable on first
run.  Edit that file to correct values or add edges; it takes precedence
over what is hard-coded here.
"""

from __future__ import annotations

import json
import pathlib

# element -> {edge label: (first edge eV, second edge eV)}
# "first" is the lower-energy, higher-J member (L3, M5, N5).
DEFAULT_EDGES: dict[str, dict[str, list[float]]] = {
    # --- 3d transition metals, L3 / L2 (2p3/2, 2p1/2) ---
    "Sc": {"L2,3": [398.7, 403.6]},
    "Ti": {"L2,3": [453.8, 460.2]},
    "V":  {"L2,3": [512.1, 520.5]},
    "Cr": {"L2,3": [574.1, 583.8]},
    "Mn": {"L2,3": [638.7, 649.9]},
    "Fe": {"L2,3": [706.8, 719.9]},
    "Co": {"L2,3": [778.1, 793.2]},
    "Ni": {"L2,3": [852.7, 870.0]},
    "Cu": {"L2,3": [932.7, 952.3]},
    "Zn": {"L2,3": [1021.8, 1044.9]},
    # --- 4d transition metals, L3 / L2 ---
    "Zr": {"L2,3": [2222.3, 2306.7]},
    "Nb": {"L2,3": [2370.5, 2464.7]},
    "Mo": {"L2,3": [2520.2, 2625.1]},
    "Ru": {"L2,3": [2838.0, 2967.0]},
    "Rh": {"L2,3": [3003.8, 3146.1]},
    "Pd": {"L2,3": [3173.3, 3330.3]},
    "Ag": {"L2,3": [3351.1, 3523.7]},
    # --- lanthanides, M5 / M4 (3d5/2, 3d3/2) ---
    "La": {"M4,5": [836.0, 853.9]},
    "Ce": {"M4,5": [883.8, 901.3]},
    "Pr": {"M4,5": [928.8, 951.1]},
    "Nd": {"M4,5": [980.4, 1003.3]},
    "Pm": {"M4,5": [1027.0, 1052.0]},
    "Sm": {"M4,5": [1083.4, 1110.9]},
    "Eu": {"M4,5": [1127.5, 1158.6]},
    "Gd": {"M4,5": [1189.6, 1221.9]},
    "Tb": {"M4,5": [1241.1, 1276.9]},
    "Dy": {"M4,5": [1292.6, 1333.0]},
    "Ho": {"M4,5": [1351.0, 1391.5]},
    "Er": {"M4,5": [1409.3, 1453.3]},
    "Tm": {"M4,5": [1468.0, 1514.6]},
    "Yb": {"M4,5": [1527.8, 1576.3]},
    "Lu": {"M4,5": [1588.5, 1639.4]},
    # --- actinides, N5 / N4 (4d5/2, 4d3/2) ---
    # Verify these especially; published values vary.
    "Th": {"N4,5": [675.2, 712.1]},
    "U":  {"N4,5": [736.2, 778.3]},
    # --- light-element edges that commonly overlap the windows above ---
    "C":  {"K": [284.2, 284.2]},
    "N":  {"K": [409.9, 409.9]},
    "O":  {"K": [543.1, 543.1]},
    "F":  {"K": [696.7, 696.7]},
    "Cl": {"L2,3": [200.0, 201.6]},
}

#: Edges whose onset frequently lands inside a post-edge fit window and
#: therefore wants an exclusion mask -- the situation Igor's
#: ``createNEdgeMask`` was written for.
COMMON_INTERFERENCES = {
    "L2,3": ["O K (~530-545)", "N K (~400-410)", "F K (~685-700)"],
    "M4,5": ["O K (~530-545)", "F K (~685-700)", "Ni L (~855-875)"],
    "N4,5": ["O K (~530-545)", "Fe L (~708-725)"],
}

DISCLAIMER = (
    "Nominal elemental binding energies for positioning fit windows only. "
    "Not calibration standards; chemical shifts are not included. "
    "Verify against the X-ray Data Booklet before quoting any value."
)


def load_edges(path: pathlib.Path | None = None) -> dict:
    """Load the edge table, preferring a user-edited ``edges.json``."""
    if path and path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("edges"):
                return data["edges"]
        except (json.JSONDecodeError, OSError):
            pass
    return DEFAULT_EDGES


def write_default_edges(path: pathlib.Path) -> None:
    """Write the built-in table so the user can edit it."""
    payload = {"_comment": DISCLAIMER, "edges": DEFAULT_EDGES}
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def suggest_windows(e_a: float, e_b: float) -> dict[str, tuple[float, float]]:
    """Starting pre-edge / post-edge windows for an edge pair.

    Scaled from the spin-orbit splitting rather than fixed offsets, so the
    same logic serves a 7 eV V L2,3 splitting and a 40 eV Er M4,5 one.
    """
    sep = max(abs(e_b - e_a), 2.0)
    pre_hi = e_a - max(sep * 0.45, 3.0)
    pre_lo = pre_hi - max(sep * 1.2, 8.0)
    post_lo = e_b + max(sep * 0.9, 8.0)
    post_hi = post_lo + max(sep * 2.5, 20.0)
    return {
        "pre": (round(pre_lo, 2), round(pre_hi, 2)),
        "post": (round(post_lo, 2), round(post_hi, 2)),
        "norm_energy": round(post_lo + (post_hi - post_lo) * 0.5, 2),
    }
