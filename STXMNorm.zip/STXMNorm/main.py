"""
STXMNorm entry point.

    python main.py                 launch the interface
    python main.py --self-test     run numerical checks and exit
    python main.py --self-test-gui build the whole interface and exit
    python main.py --version       print the version and exit
"""

import sys


def cli(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)

    if "--self-test-gui" in argv:
        from stxmnorm.selftest import run_gui
        return 0 if run_gui() else 1

    if "--self-test" in argv:
        from stxmnorm.selftest import run
        return 0 if run() else 1

    if "--version" in argv or "-V" in argv:
        from stxmnorm import __version__
        print(f"STXMNorm {__version__}")
        return 0

    if "--help" in argv or "-h" in argv:
        print(__doc__.strip())
        return 0

    from stxmnorm.app import main
    return main()


if __name__ == "__main__":
    sys.exit(cli())
