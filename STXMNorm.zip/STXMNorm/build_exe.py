#!/usr/bin/env python3
"""
build_exe.py -- build STXMNorm.exe, verify it, and explain any failure.

    python build_exe.py                 normal build
    python build_exe.py --debug         console build, so a crash shows a traceback
    python build_exe.py --onedir        a folder; starts in 0.25 s  (default)
    python build_exe.py --onefile       one portable .exe; starts in 2.0 s
    python build_exe.py --no-venv       build with the current Python
    python build_exe.py --plain         skip STXMNorm.spec, use plain flags
    python build_exe.py --no-test       skip the post-build self-tests

By default this creates a private build environment in .venv-build,
installs the requirements and PyInstaller into it, freezes the app, and
then runs the executable's two self-tests before declaring success.
Nothing is added to your system Python.

Every run writes build_log.txt. If a build fails, that file has the whole
story; the script prints the last 30 lines along with the most likely
cause.

PyInstaller does not cross-compile: a Windows .exe must be built on
Windows.
"""

import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG = HERE / "build_log.txt"
VENV = HERE / ".venv-build"
APPNAME = "STXMNorm"
SPEC = HERE / "STXMNorm.spec"
ENTRY = HERE / "main.py"

REQUIREMENTS = ["numpy>=1.24", "scipy>=1.10", "matplotlib>=3.7",
                "PySide6>=6.5", "pyinstaller>=6.0"]

# symptom in the log -> likely cause, in the order worth checking
DIAGNOSES = [
    ("access is denied", "a copy of {app}.exe is still running, or a sync "
                         "client (OneDrive, Dropbox) is holding the folder"),
    ("winerror 5", "a copy of {app}.exe is still running, or a sync client "
                   "is holding the folder"),
    ("unexpected keyword", "PyInstaller older than 6.7; let the script build "
                           "its own environment instead of passing --no-venv"),
    ("no module named 'numpy",
     "a numpy.* submodule is in EXCLUDES in {app}.spec; scipy clones "
     "numpy's namespace at import and needs all of them"),
    ("no module named", "either a needed module is in EXCLUDES in "
                        "{app}.spec, or the build environment is half-built "
                        "-- delete .venv-build and run again"),
    ("already imported as \"excludedmodule",
     "something in EXCLUDES in {app}.spec is also imported by PyInstaller's "
     "own hooks -- distutils, setuptools and pkg_resources are the usual "
     "culprits and must not be excluded"),
    ("could not load the qt platform plugin",
     "the Qt platform plugin is missing -- set AGGRESSIVE = False in "
     "{app}.spec, or check that platforms/qwindows.dll survived pruning"),
    ("no qt platform plugin could be initialized",
     "the Qt platform plugin is missing -- set AGGRESSIVE = False in "
     "{app}.spec, or check that platforms/qwindows.dll survived pruning"),
    ("failed to execute script", "the exe was built but crashes at startup; "
                                 "rebuild with --debug for a console"),
    ("filename or extension is too long", "move the folder near the drive "
                                          "root, e.g. C:\\{app}"),
    ("path too long", "move the folder near the drive root, e.g. C:\\{app}"),
    ("could not find a version", "this Python is too new or too old for one "
                                 "of the requirements; try Python 3.10-3.12"),
    ("microsoft visual c++", "a package needs to compile; install a prebuilt "
                             "wheel by using Python 3.10-3.12"),
    ("no space left", "the drive is full; a onefile build needs a few GB of "
                      "temporary space"),
]


def log(msg=""):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(msg + "\n")


def run(cmd, what):
    """Run a command, streaming its output into the log. True if it worked."""
    log(f"\n$ {' '.join(str(c) for c in cmd)}")
    try:
        p = subprocess.run(cmd, cwd=HERE, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, text=True,
                           errors="replace")
    except OSError as exc:
        log(f"!! could not start: {exc}")
        return False
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(p.stdout or "")
    if p.returncode != 0:
        log(f"!! {what} failed, exit code {p.returncode}")
        return False
    return True


def diagnose():
    """Print the tail of the log and the most likely cause."""
    try:
        tail = LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-30:]
    except OSError:
        return
    print("\n" + "-" * 68)
    print("last 30 lines of build_log.txt:")
    for line in tail:
        print("  " + line)
    print("-" * 68)
    blob = "\n".join(tail).lower()
    for needle, cause in DIAGNOSES:
        if needle in blob:
            print(f"likely cause: {cause.format(app=APPNAME)}")
            break
    else:
        print(f"no familiar symptom found; the whole story is in {LOG.name}")
    print("-" * 68)


def venv_python(venv):
    exe = "python.exe" if os.name == "nt" else "python"
    sub = "Scripts" if os.name == "nt" else "bin"
    return venv / sub / exe


def ensure_venv():
    """Create .venv-build and install the requirements into it."""
    py = venv_python(VENV)
    if not py.exists():
        log(f"creating build environment in {VENV.name}")
        if not run([sys.executable, "-m", "venv", str(VENV)], "venv creation"):
            return None
    else:
        log(f"reusing build environment in {VENV.name}")
    if not run([str(py), "-m", "pip", "install", "--upgrade", "pip", "wheel"],
               "pip upgrade"):
        return None
    if not run([str(py), "-m", "pip", "install", *REQUIREMENTS],
               "requirement install"):
        return None
    return py


def built_path(onedir):
    exe = APPNAME + (".exe" if os.name == "nt" else "")
    return (HERE / "dist" / APPNAME / exe) if onedir else (HERE / "dist" / exe)


def self_test(exe):
    """Run both self-tests on the frozen executable."""
    ok = True
    for flag, what in (("--self-test", "numerical self-test"),
                       ("--self-test-gui", "GUI self-test")):
        log(f"\nrunning {what} on the built executable")
        if not run([str(exe), flag], what):
            ok = False
            for name in ("stxmnorm_guitest.log",):
                p = exe.parent / name
                if p.exists():
                    log(f"-- {name} --")
                    log(p.read_text(encoding="utf-8", errors="replace"))
    return ok


def main(argv):
    debug = "--debug" in argv
    onedir = "--onedir" in argv
    onefile = "--onefile" in argv
    no_venv = "--no-venv" in argv
    plain = "--plain" in argv
    no_test = "--no-test" in argv

    # The spec reads this, so --onefile / --onedir work whether or not
    # the spec is being used.
    if onefile:
        os.environ["STXMNORM_ONEFILE"] = "1"
    elif onedir:
        os.environ["STXMNORM_ONEFILE"] = "0"

    LOG.write_text("", encoding="utf-8")
    log(f"{APPNAME} build   {time.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"  {platform.platform()}")
    log(f"  python {sys.version.split()[0]} at {sys.executable}")
    if os.name != "nt":
        log("  NOTE: not on Windows. PyInstaller does not cross-compile, so "
            "this will produce an executable for THIS platform, not a .exe.")
    if not ENTRY.exists():
        log(f"!! {ENTRY.name} not found; run this from the project root")
        return 1

    py = Path(sys.executable) if no_venv else ensure_venv()
    if py is None:
        log("!! could not prepare the build environment")
        diagnose()
        return 1

    # Keep a copy of the spec. PyInstaller has been known to overwrite it
    # when invoked with --name on a .py file; --specpath above prevents
    # that, and this restores it if anything else manages to.
    spec_backup = SPEC.read_bytes() if SPEC.exists() else None

    # A stale build/ directory is the most common source of confusing
    # failures, so it goes before every build.
    for d in ("build", "dist"):
        shutil.rmtree(HERE / d, ignore_errors=True)

    used_spec = SPEC.exists() and not plain
    if used_spec:
        log(f"\nbuilding with {SPEC.name}")
        cmd = [str(py), "-m", "PyInstaller", "--noconfirm", str(SPEC)]
        if debug:
            log("  note: --debug cannot override the spec; set CONSOLE = True "
                "in STXMNorm.spec for a console build")
    else:
        log("\nbuilding with plain flags")
        _specdir = tempfile.mkdtemp(prefix="stxmnorm-spec-")
        cmd = [str(py), "-m", "PyInstaller", "--noconfirm", "--clean",
               "--specpath", _specdir,
               "--name", APPNAME, str(ENTRY)]
        cmd += ["--onefile"] if onefile else ["--onedir"]
        cmd += ["--console"] if debug else ["--windowed"]
        for mod in ("tkinter", "PyQt5", "PyQt6", "PySide2", "pandas",
                    "IPython", "notebook", "pytest"):
            cmd += ["--exclude-module", mod]

    ok = run(cmd, "PyInstaller")

    if not ok and used_spec:
        log("\nspec build failed; retrying with plain flags "
            "(larger executable, simpler build)")
        log("  the spec build's own error is above -- worth reading, because "
            "the plain build hides whatever was wrong with the spec")
        shutil.rmtree(HERE / "build", ignore_errors=True)
        with tempfile.TemporaryDirectory() as td:
            # --specpath matters: without it PyInstaller writes its own
            # <name>.spec into the working directory and silently
            # overwrites STXMNorm.spec, destroying both your settings and
            # the evidence of why the spec build failed.
            cmd = [str(py), "-m", "PyInstaller", "--noconfirm", "--clean",
                   "--specpath", td,
                   "--name", APPNAME, str(ENTRY),
                   "--onefile" if onefile else "--onedir",
                   "--console" if debug else "--windowed"]
            for mod in ("tkinter", "PyQt5", "PyQt6", "PySide2", "pandas",
                        "IPython", "notebook", "pytest"):
                cmd += ["--exclude-module", mod]
            ok = run(cmd, "PyInstaller (plain)")
        used_spec = False

    if spec_backup is not None and SPEC.read_bytes() != spec_backup:
        SPEC.write_bytes(spec_backup)
        log(f"  note: {SPEC.name} was modified during the build and has been "
            "restored from the copy taken beforehand")

    if not ok:
        diagnose()
        return 1

    candidates = [built_path(True), built_path(False)]
    exe = next((c for c in candidates if c.exists()), candidates[0])
    if not exe.exists():
        log(f"!! PyInstaller reported success but {exe} is missing")
        diagnose()
        return 1

    # For a onedir build the .exe is just the bootstrap launcher -- a few
    # MB -- while the payload sits beside it in _internal. Reporting the
    # stub's size was misleading, so report the folder.
    if exe.parent != (HERE / "dist"):
        total = sum(f.stat().st_size for f in exe.parent.rglob("*")
                    if f.is_file())
        log(f"\nbuilt {exe.relative_to(HERE)}")
        log(f"  folder {exe.parent.relative_to(HERE)} is "
            f"{total / 1048576.0:.0f} MB -- ship the whole folder")
    else:
        log(f"\nbuilt {exe.relative_to(HERE)}   "
            f"{exe.stat().st_size / 1048576.0:.1f} MB")

    if no_test:
        log("skipping self-tests (--no-test)")
        log("\nBUILD OK (untested)")
        return 0

    if not self_test(exe):
        log("\nBUILD FAILED ITS OWN TESTS -- do not ship this executable")
        diagnose()
        return 1

    log("\nBUILD OK -- both self-tests passed")
    log(f"  {exe}")
    return 0


def _spec_onefile():
    """Read ONEFILE out of the spec without executing it."""
    try:
        for line in SPEC.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if s.startswith("ONEFILE"):
                return "true" in s.lower()
    except OSError:
        pass
    return True


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
